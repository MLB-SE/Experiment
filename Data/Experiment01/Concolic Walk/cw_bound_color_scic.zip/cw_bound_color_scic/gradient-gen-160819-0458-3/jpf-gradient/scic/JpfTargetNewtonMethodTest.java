import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.0,7.683307125524834);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.15343453927989928,0.0022199340836453196);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(0.17466282695572305,115.89823481719569);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-12.750000230959266,0.08899288971689799);
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(769.1442404802682,0);
  }
}
