import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,2.6169199187146304);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543467,373.21141515784655);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6542779837498396,0.016435136932997904);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.9967628875480328,0.49822941633323836);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(74.8965784976393,0);
  }
}
