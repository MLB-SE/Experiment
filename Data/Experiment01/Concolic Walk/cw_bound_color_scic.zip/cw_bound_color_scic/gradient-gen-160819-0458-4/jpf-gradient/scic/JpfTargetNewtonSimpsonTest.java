import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,3.6433841971761574);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6464985948044046,2.044148668052356);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.8441321843402378,0.23909397277066025);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(52.17116721829513,0);
  }
}
