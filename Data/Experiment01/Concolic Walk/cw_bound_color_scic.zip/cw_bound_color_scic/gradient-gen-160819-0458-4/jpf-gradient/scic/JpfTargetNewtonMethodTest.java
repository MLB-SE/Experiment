import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.0,1.2955852036406286);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.21410358508033378,15.571691860217964);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(0.23030944303577058,0.0795919858084824);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-685.25,19.74056033345275);
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(748.0177345944342,0);
  }
}
