import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-1000000,-1000000);
  }

  @Test
  public void test1() {
    bound.unbounded.solve(28,-11);
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-749979,999999);
  }
}
