import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(-1000000,0,0,0);
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(11,0,0,0);
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(1,-1000000,0,0);
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(1,11,0,0);
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(1,1,-1000000,0);
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(1,1,1,1);
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(1,1,11,0);
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(1,1,1,-1000000);
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(1,1,1,11);
  }
}
