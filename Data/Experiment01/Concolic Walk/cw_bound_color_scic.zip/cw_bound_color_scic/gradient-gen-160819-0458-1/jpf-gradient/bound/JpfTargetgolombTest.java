import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0);
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,1);
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,0,-1000000);
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,0,7);
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,1,0);
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,-1000000,0);
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,1,2);
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,7,0);
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,0,0);
  }

  @Test
  public void test9() {
    bound.golomb.solve(-1000000,0,0);
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,0,1);
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,2,0);
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,2,3);
  }

  @Test
  public void test13() {
    bound.golomb.solve(7,0,0);
  }
}
