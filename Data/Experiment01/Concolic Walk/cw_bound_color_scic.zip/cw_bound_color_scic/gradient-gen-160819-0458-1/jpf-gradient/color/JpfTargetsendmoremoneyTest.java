import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(10,0,0,0,0,0,0,0);
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(-1000000,0,0,0,0,0,0,0);
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,0,0,0,1,0,0,0);
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,0,0,0,10,0,0,0);
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(1,0,0,0,-1000000,0,0,0);
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,0,0,0,1,0,0,10);
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(1,0,0,0,1,0,0,-1000000);
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(1,0,0,0,1,0,10,0);
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(1,0,0,0,1,0,-1000000,0);
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(1,0,0,0,1,10,0,0);
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(1,0,0,0,1,-1000000,0,0);
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(1,0,0,10,0,0,0,0);
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(1,0,0,-1000000,0,0,0,0);
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(1,0,10,0,0,0,0,0);
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(1,0,-1000000,0,0,0,0,0);
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(1,10,0,0,0,0,0,0);
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(1,-1000000,0,0,0,0,0,0);
  }
}
