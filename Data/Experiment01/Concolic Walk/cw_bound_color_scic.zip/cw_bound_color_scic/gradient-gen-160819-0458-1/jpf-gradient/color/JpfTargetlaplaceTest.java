import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-8.0f,0,0,-4.4784684f,-8.0f,-8.0f,-1.9138755f,-3.1770334f,-2.794258f);
  }

  @Test
  public void test1() {
    color.laplace.solve(-8.0f,0,0,-4.4784684f,-8.0f,-8.0f,-1.9138756f,-3.1770334f,-2.7942584f);
  }

  @Test
  public void test2() {
    color.laplace.solve(-8.0f,0,0,-4.5714283f,-8.0f,0,-2.2857141f,-4.5714283f,-8.0f);
  }

  @Test
  public void test3() {
    color.laplace.solve(-8.0f,0,0,-4.5714283f,-8.0f,-8.0f,-2.2857141f,-4.571429f,-8.0f);
  }

  @Test
  public void test4() {
    color.laplace.solve(-8.0f,0,0,-4.7999997f,-8.0f,0,-3.1999996f,-8.0f,0);
  }

  @Test
  public void test5() {
    color.laplace.solve(-8.0f,0,0,-4.7999997f,-8.0f,0,-3.2f,-8.0f,-8.0f);
  }

  @Test
  public void test6() {
    color.laplace.solve(-8.0f,0,0,-5.9999995f,-8.0f,0,-8.0f,-8.0f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,0,-3.2f,-4.7999997f,-8.0f);
  }

  @Test
  public void test8() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,0,-3.9999998f,-8.0f,0);
  }

  @Test
  public void test9() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,0,-4.0f,-8.0f,-8.0f);
  }

  @Test
  public void test10() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,0,-8.0f,-8.0f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,-8.0f,-2.857143f,-3.4285715f,-2.8571427f);
  }

  @Test
  public void test12() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,-8.0f,-2.857143f,-3.4285715f,-2.857143f);
  }

  @Test
  public void test13() {
    color.laplace.solve(-8.0f,0,0,-8.0f,-8.0f,-8.0f,-3.2f,-4.8f,-8.0f);
  }

  @Test
  public void test14() {
    color.laplace.solve(-8.0f,-8.0f,0,-3.7752807f,-5.5505614f,-8.0f,-1.5505618f,-2.4269662f,-2.6067412f);
  }

  @Test
  public void test15() {
    color.laplace.solve(-8.0f,-8.0f,0,-3.7752807f,-5.5505614f,-8.0f,-1.5505618f,-2.4269662f,-2.6067417f);
  }

  @Test
  public void test16() {
    color.laplace.solve(-8.0f,-8.0f,0,-3.9999998f,-5.9999995f,-8.0f,-1.9999999f,-3.9999995f,-8.0f);
  }

  @Test
  public void test17() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.0f,-5.9999995f,-8.0f,-2.0f,-4.0f,-8.0f);
  }

  @Test
  public void test18() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.478469f,-8.0f,-8.0f,-1.9138756f,-3.1770334f,-2.7942584f);
  }

  @Test
  public void test19() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.478469f,-8.0f,-8.0f,-1.9138756f,-3.1770334f,-2.794258f);
  }

  @Test
  public void test20() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.5714283f,-7.142857f,-8.0f,-3.1428568f,-8.0f,0);
  }

  @Test
  public void test21() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.5714283f,-7.142857f,-8.0f,-3.142857f,-8.0f,-8.0f);
  }

  @Test
  public void test22() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.571429f,-8.0f,-8.0f,-2.2857141f,-4.5714283f,-8.0f);
  }

  @Test
  public void test23() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.571429f,-8.0f,-8.0f,-2.2857144f,-4.571429f,-8.0f);
  }

  @Test
  public void test24() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.7999997f,-8.0f,-8.0f,-3.1999998f,-8.0f,0);
  }

  @Test
  public void test25() {
    color.laplace.solve(-8.0f,-8.0f,0,-4.8f,-8.0f,-8.0f,-3.2f,-8.0f,-8.0f);
  }

  @Test
  public void test26() {
    color.laplace.solve(-8.0f,-8.0f,0,-5.866667f,-7.466666f,-8.0f,-8.0f,-8.0f,0);
  }

  @Test
  public void test27() {
    color.laplace.solve(-8.0f,-8.0f,0,-6.0f,-8.0f,-8.0f,-8.0f,-8.0f,0);
  }

  @Test
  public void test28() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.3291924f,-4.074534f,-3.3291922f,-1.242236f,-1.6397514f,-1.2422357f);
  }

  @Test
  public void test29() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.3291924f,-4.074534f,-3.3291922f,-1.242236f,-1.6397516f,-1.2422359f);
  }

  @Test
  public void test30() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.3291926f,-4.074534f,-3.3291924f,-1.242236f,-1.6397514f,-1.2422358f);
  }

  @Test
  public void test31() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.3291926f,-4.074534f,-3.3291926f,-1.242236f,-1.6397516f,-1.242236f);
  }

  @Test
  public void test32() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.7752807f,-5.213483f,-5.3033705f,-1.8876404f,-3.7752805f,-8.0f);
  }

  @Test
  public void test33() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.775281f,-5.2134833f,-5.303371f,-1.8876405f,-3.775281f,-8.0f);
  }

  @Test
  public void test34() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.775281f,-5.213483f,-5.3033705f,-1.8876405f,-3.775281f,-8.0f);
  }

  @Test
  public void test35() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.775281f,-5.213483f,-5.303371f,-1.8876404f,-3.7752807f,-8.0f);
  }

  @Test
  public void test36() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.775281f,-5.550562f,-8.0f,-1.5505618f,-2.4269662f,-2.6067412f);
  }

  @Test
  public void test37() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-3.775281f,-5.550562f,-8.0f,-1.5505618f,-2.4269662f,-2.6067417f);
  }

  @Test
  public void test38() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.0f,-6.0f,-8.0f,-1.9999999f,-3.9999998f,-8.0f);
  }

  @Test
  public void test39() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.0f,-6.0f,-8.0f,-2.0f,-4.0f,-8.0f);
  }

  @Test
  public void test40() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.4019136f,-6.507177f,-5.6267943f,-3.1004782f,-8.0f,-8.0f);
  }

  @Test
  public void test41() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.4019136f,-6.507177f,-5.6267943f,-3.1004784f,-8.0f,-8.0f);
  }

  @Test
  public void test42() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.4019136f,-6.507177f,-5.626794f,-3.1004782f,-8.0f,-8.0f);
  }

  @Test
  public void test43() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.4019136f,-6.507177f,-5.626794f,-3.1004784f,-8.0f,-8.0f);
  }

  @Test
  public void test44() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.5714283f,-7.142857f,-8.0f,-3.1428568f,-8.0f,-8.0f);
  }

  @Test
  public void test45() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-4.571429f,-7.142857f,-8.0f,-3.142857f,-8.0f,-8.0f);
  }

  @Test
  public void test46() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-5.714286f,-6.857143f,-5.7142854f,-8.0f,-8.0f,-8.0f);
  }

  @Test
  public void test47() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-5.714286f,-6.857143f,-5.714286f,-8.0f,-8.0f,-8.0f);
  }

  @Test
  public void test48() {
    color.laplace.solve(-8.0f,-8.0f,-8.0f,-5.866667f,-7.4666667f,-8.0f,-8.0f,-8.0f,-8.0f);
  }
}
