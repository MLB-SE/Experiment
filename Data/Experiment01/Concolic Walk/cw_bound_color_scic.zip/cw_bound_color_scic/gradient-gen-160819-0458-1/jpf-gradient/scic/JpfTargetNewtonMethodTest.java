import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.0,0.590000000000001);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-0.12005209889043815,0.07983102890068479);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.15187315385480477,29.199264994150546);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(1132.0407619737962,0);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-2.755062382784828,1910.2175226695704);
  }
}
