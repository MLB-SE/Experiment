import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,3.3952279979883944);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543467,33.135994893954695);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.676191422614233,2.5499090171799415);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.8400947745331362,0.2332999128878599);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(82.72734920888922,0);
  }
}
