import org.junit.Test;

public class JpfTargetDartTest {

  @Test
  public void test0() {
    concolic.DART.test(-1000000,0);
  }

  @Test
  public void test1() {
    concolic.DART.test(1,10);
  }

  @Test
  public void test2() {
    concolic.DART.test(1,-1000000);
  }

  @Test
  public void test3() {
    concolic.DART.test(1861,-999982);
  }

  @Test
  public void test4() {
    concolic.DART.test(1981,20);
  }

  @Test
  public void test5() {
    concolic.DART.test(-999972,0);
  }
}
