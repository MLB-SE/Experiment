import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(0,0l,0);
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-429258,0l,303);
  }
}
