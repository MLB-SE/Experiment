import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(0,0);
  }
}
