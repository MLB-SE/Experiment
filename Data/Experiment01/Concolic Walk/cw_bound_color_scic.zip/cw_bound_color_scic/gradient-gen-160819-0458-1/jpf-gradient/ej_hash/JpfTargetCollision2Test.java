import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(0l,0,0l,0);
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(0l,961,0l,0);
  }
}
