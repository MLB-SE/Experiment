import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.0,0.9149999999999998);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.15147513470959867,2.655530269280726E-4);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(0.16607089760825036,14.844078064007192);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(1534.7591805666266,0);
  }
}
