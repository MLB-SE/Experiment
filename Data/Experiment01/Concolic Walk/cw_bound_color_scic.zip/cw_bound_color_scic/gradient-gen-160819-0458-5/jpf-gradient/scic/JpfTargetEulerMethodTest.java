import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(0.0);
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070213);
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-2.413959364521957);
  }
}
