import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,1.15054237805563);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543465,0);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6968169739868622,0.16452333697302565);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.7147154984258586,0.07415646521360375);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(7612.231478599357,0);
  }
}
