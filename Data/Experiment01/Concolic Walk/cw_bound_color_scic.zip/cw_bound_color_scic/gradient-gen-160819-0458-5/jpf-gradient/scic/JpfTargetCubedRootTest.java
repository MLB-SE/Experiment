import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(0.0);
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(988.015018728061);
  }
}
