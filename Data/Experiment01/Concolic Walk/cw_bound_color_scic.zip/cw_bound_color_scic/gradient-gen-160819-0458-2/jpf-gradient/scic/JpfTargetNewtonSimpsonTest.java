import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,7.148936010263434);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(144.6358381907744,0);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448607098579513,1.7155717193976465);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.7371205700391212,0.09992502826908045);
  }
}
