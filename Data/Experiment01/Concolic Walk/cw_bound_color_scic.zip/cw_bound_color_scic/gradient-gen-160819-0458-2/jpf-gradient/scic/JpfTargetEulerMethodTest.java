import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(0.0);
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070202);
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-3.197572628336977);
  }
}
