import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.0,1.51);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.17285345416216227,0.021306658770422288);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(0.17406913182036005,0.06567944295689766);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-2.755062382784828,0.12229703879614813);
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(774.4857049455443,0);
  }
}
