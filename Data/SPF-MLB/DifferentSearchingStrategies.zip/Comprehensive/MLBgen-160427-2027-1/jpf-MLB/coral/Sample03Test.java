import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(77.77281534626505,-27.378846268989193 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(82.85182165428046,81.28102532748557 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-83.68153881099916,-25.270865878030023 ) ;
  }
}
