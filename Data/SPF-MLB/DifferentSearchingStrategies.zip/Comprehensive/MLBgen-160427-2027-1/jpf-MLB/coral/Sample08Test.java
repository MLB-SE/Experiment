import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-63.47441621828975,-1.3171335394504666,-24.248374191050093 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-67.59249691994668,-61.13319990381654,-47.78512624775579 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-69.65922796423429,27.37219057224489,73.75983457041616 ) ;
  }
}
