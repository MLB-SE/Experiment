import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(31.078237798067978,-77.30670875088587 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-44.1754770809867,50.10995827729053 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-49.58656276778706,70.81278509017412 ) ;
  }
}
