import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,383 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-503 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,-538 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-984 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(-1,10 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(117,-470 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(124,1 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1390,-1 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-1439,5 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(1445,4 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(149,-597 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(181,17 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(195,166 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-2015,4 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(203,-814 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(-236,0 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(297,-1187 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(-322,2 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(39,-5 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(-4,2 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(446,1 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(-496,-31 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(5,-14 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(-53,0 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(531,3 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(-536,-440 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(550,0 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(563,464 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(564,3 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(-63,1 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(-664,697 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(674,2 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(-68,270 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(699,2 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(-751,158 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(792,149 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(801,5 ) ;
  }

  @Test
  public void test47() {
    caldat.flmoon(-810,2 ) ;
  }

  @Test
  public void test48() {
    caldat.flmoon(821,0 ) ;
  }

  @Test
  public void test49() {
    caldat.flmoon(-845,3 ) ;
  }

  @Test
  public void test50() {
    caldat.flmoon(-88,350 ) ;
  }

  @Test
  public void test51() {
    caldat.flmoon(925,8 ) ;
  }

  @Test
  public void test52() {
    caldat.flmoon(-929,3 ) ;
  }

  @Test
  public void test53() {
    caldat.flmoon(-976,1 ) ;
  }
}
