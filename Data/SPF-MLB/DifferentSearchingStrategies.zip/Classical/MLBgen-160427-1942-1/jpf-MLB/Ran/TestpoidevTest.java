import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,210 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(10.0,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0000000000000009,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,107 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,-526 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,830 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(11.0,346 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(12.13456741644903,0 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(-2.0,0 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(22.69361146786393,0 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(-258.0,-44 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(27.107049660404243,0 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(3.0,-217 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(-492.0,-1 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(6.0,-204 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-71.1758433094004,0 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(7.130855985972872,0 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(-76.0,966 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(-852.0,-357 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(9.0,-1 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(-90.24213929662359,0 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(-918.0,719 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(-962.0,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(98.22806529130656,0 ) ;
  }
}
