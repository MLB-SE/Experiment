import org.junit.Test;

public class Testran1Test {

  @Test
  public void test0() {
    ran.ran1(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran1(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran1(270 ) ;
  }

  @Test
  public void test3() {
    ran.ran1(275 ) ;
  }

  @Test
  public void test4() {
    ran.ran1(-39 ) ;
  }

  @Test
  public void test5() {
    ran.ran1(-621 ) ;
  }

  @Test
  public void test6() {
    ran.ran1(-631 ) ;
  }

  @Test
  public void test7() {
    ran.ran1(-73 ) ;
  }

  @Test
  public void test8() {
    ran.ran1(-980 ) ;
  }
}
