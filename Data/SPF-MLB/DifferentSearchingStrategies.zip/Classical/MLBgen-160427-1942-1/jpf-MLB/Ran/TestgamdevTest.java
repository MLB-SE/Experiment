import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(-109,0 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(-130,0 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(210,-73 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(2,-34 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(276,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(3,0 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(358,158 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(466,-855 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(516,-1 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(523,4 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(530,0 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(5,624 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(-73,0 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(862,0 ) ;
  }
}
