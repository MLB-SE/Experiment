import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(111 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(-181 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(-26349 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(-26448 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(26484 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(27442 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(-567 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(-571 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(586 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-593 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(882 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(922 ) ;
  }
}
