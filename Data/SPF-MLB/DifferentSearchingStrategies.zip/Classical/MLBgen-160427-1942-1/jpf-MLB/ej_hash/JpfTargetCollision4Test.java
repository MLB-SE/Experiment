import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-25206,1777,-929 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(761,325,-972 ) ;
  }
}
