import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(607,-50,-877,-618 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(944,-631,862,950 ) ;
  }
}
