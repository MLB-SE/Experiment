import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(870,-2,970,854,-533,-115 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-96,-857,663,644,34,-825 ) ;
  }
}
