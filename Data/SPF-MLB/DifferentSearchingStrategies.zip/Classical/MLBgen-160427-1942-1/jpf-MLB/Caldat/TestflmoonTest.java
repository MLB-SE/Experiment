import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,-113 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,-133 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-227 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-374 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(100,0 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(128,-511 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-137,1 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1390,-1 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-139,3 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(1808,-14 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(-1898,-24 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(-200,5 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(208,2 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(2,3 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(-267,0 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(-338,0 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(-371,698 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(386,-510 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(440,1 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(463,8 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(-467,1 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(-476,6 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(547,6 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(-636,2 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(709,9 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(722,0 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(-724,279 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(77,1 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(793,2 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(805,800 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(-859,2 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(94,3 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(96,-386 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(-972,3 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(98,172 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(99,-398 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(-995,-161 ) ;
  }
}
