import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,73.46686743808439 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,7.6537074384433765 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.9091272452136453,21.124511661699074,20.141668427788343,-0.06098947964874685 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.9437600050831912,-22.114894165835288,-21.484025031158833,0.31426584113950734 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(11.329619358553373,83.67701706786121,56.42316767376306,-72.6180263510021 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(144.5360333523949,-3.38045731533758,-20.784244108525776,174.0348574382928 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(26.662721714833438,16.48704480460374,37.366809364115284,80.21040829632426 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(2.6690484898321283,2.185957325183021,-72.10849436793843,78.21333715780861 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(-31.741176788594345,30.67607021965656,-84.49928114800257,79.33410948002356 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(33.21161088028205,37.34084351302826,17.63781375895573,-72.99393068745923 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(33.727729187552555,0.0,-4.217008741636674,44.08736917158642 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(45.38391910712946,-69.28720106734339,22.402287400462654,-0.6550115808981627 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(47.975175758424605,-57.62445817945228,85.42402225442277,-7.118917206126759 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(48.655635126187434,-3.6692013056695174,-74.86822429478777,-66.14995248252373 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(53.30893462918252,-5.482089353920202,48.7852076988419,73.48744414763877 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(57.702227696876896,-32.18593885027806,88.24642006627366,-62.73013121967482 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(68.39754435472983,1.4649447108352813,-33.401252377763925,6.480263945070746 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(70.44122898836423,-28.123435812847177,91.8316998554063,-22.09403615739312 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(75.89227188657651,9.474861744631525,79.71038685210223,29.440472562826727 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(77.13566496409564,81.36380807039006,-24.088657921595868,-62.15428166001964 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(82.48309027496381,-4.055659105190074,45.02651971319142,36.45428328392862 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(83.66497616523455,-8.126381151338048,-74.33083885006623,93.34279929837209 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(-93.35950575804448,41.716111247847294,-75.28718170581554,22.12115500028085 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.85443515274396,-9.9610603111566,35.20424703508917,54.68912780649819 ) ;
  }
}
