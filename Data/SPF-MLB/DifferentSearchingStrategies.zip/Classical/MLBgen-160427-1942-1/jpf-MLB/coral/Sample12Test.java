import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.603354856942758,-0.6797683825890459,90.27461524497039,-61.65693864970824 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.7578158121926037,0.12169509132520773,-98.64878311171668,62.145380425831945 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.8793919134867849,-0.1262883087486557,-29.091252155834255,-1.3502448509235165 ) ;
  }
}
