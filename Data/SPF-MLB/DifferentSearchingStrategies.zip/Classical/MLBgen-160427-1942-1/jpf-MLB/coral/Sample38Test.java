import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-35.822799882847605,59.97040909581389 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(74.35609860493514,45.47824377813211 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(90.0699108841291,57.833224696562496 ) ;
  }
}
