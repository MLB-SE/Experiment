import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-38.37243744268799,25.155601587920202,-27.781440801290344 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-66.97750580252118,97.63721529819674,-88.28654559723378 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-6.864892375791129,-47.11557254478846,-35.86143002620233 ) ;
  }
}
