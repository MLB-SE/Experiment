import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(0.44230101003313393,85.03879790964456 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-14.337051192242086,74.20638008358239 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(8.575642518475973,64.96600208621696 ) ;
  }
}
