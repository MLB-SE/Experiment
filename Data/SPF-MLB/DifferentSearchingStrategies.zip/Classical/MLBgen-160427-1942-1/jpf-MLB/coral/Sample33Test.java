import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-24.08908022871242 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-36.91371367968007 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(69.74238775608254 ) ;
  }
}
