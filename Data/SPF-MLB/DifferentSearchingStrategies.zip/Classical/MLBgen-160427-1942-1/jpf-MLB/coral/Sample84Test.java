import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.9794098401206606,0.959243634925178,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-14.945194699470195,-28.489840494731386 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,4.499334791329141,20.244013564464844 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-4.5365435634651226,20.580227503216832 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-5.118483746746731,54.199118305850696 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-6.8644333515889855,47.12044523840719 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,-31.546166673020203,1.0,33.5461666730202 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(-1.3439070088904685,1.806086048544926,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(2.3595366875721453,68.74263214405897,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(3.9681621209372824,15.746310618041472,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(-50.34744536021256,10.533154148492102,0,0 ) ;
  }
}
