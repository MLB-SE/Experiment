import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(66.93390588727358,4.401610468873191 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(81.40979215831084,80.33558375248181 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-85.11774591756098,-39.27313486011925 ) ;
  }
}
