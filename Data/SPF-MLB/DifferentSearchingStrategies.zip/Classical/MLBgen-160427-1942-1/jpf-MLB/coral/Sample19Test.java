import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.4439001588063576,20.797374150651237,0.2939381071063849 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.8090384139872171,26.080871632760577,0.3451263871002652 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9623789517001882,34.63830052773571,0.6751366611361505 ) ;
  }
}
