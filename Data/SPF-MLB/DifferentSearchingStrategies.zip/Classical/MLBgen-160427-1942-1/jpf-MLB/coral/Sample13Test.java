import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.007161180386944466,-70.37337078795062,-74.27328937502594,77.1161354249179 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.5001356325869466,-1.8103665759196872,-2.792559731840072,-61.4294448466419 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9664053116611058,36.40911947064467,-94.65897820596005,17.446558011557087 ) ;
  }
}
