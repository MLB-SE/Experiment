import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-59.09955604904036,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,0.9999999999999998,36.80924015335982,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(1.1102230246251565E-16,68.47963189472969,1.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(14.228196519192181,0,26.70696110481981,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(1.9721522630525295E-31,100.0,1.916524386853359E-17,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(-31.254828571469176,0,31.96322551398626,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(42.66894345247985,1.0,92.14291701676628,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(5.580491417545062,34.78954100667772,26.738999363427467,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(69.85366675496509,1.0000000000000249,53.29983969259933,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(71.16487169017458,85.13891517910724,64.93705019926242,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(75.40264037199012,0,17.098087057247398,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(-782.6823034945813,0,36.34209667502074,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(-90.8889000718429,0,0.8124262240638132,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(91.57103354499907,92.27049416828069,44.89654482099462,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(97.07590148889867,-14.35399117170006,12.651922185321808,0 ) ;
  }
}
