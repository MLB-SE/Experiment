import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-17.74424690588971,-78.27961180365376,-96.02385870954348 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-20.572323534480134,61.72749511553346,90.35817723567496 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(46.27452587679315,67.81732637633385,99.9819743877108 ) ;
  }
}
