import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-34.56541874416513,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,6.984931483291064,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(13.517811040346784,28.339965394476877,-41.9739016381305,82.40381466046846,-11.431974821284673 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(1.4201572863138998,-57.95876454183702,-82.52241418512212,72.09514405022509,-37.96071738853348 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(17.589869030948545,14.78419588452868,-32.40850687410317,100.0,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-19.935189029920124,-62.82155234874529,-71.56567562534921,-4.863491353887554,-81.72651552498391 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(2.304272964558653,54.95632808548909,-58.15520797000643,49.93587228724226,98.11937003988314 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(26.354180979195505,9.41435017344628,-36.487728842131474,52.790976511442324,27.3349035507743 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(27.333772425824776,18.99199253185838,94.50626166016646,83.35910817350526,-97.64071628031101 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(58.734978627170136,47.4900573024004,84.75917275611954,90.34070916412341,69.62945982771168 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(6.98008497847205,17.52048917697344,-25.171927584528415,45.42704653991842,20.554892668212798 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(7.287748799054754,45.60466099494042,-53.76616771270262,-0.2327130436551954,68.09677397175489 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(86.03688986174203,-49.32648836432274,-55.63904625198539,72.69261534407266,15.510943622495702 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(95.63331767448875,13.418938677530264,50.094910076406364,91.74511171675363,48.114181397984396 ) ;
  }
}
