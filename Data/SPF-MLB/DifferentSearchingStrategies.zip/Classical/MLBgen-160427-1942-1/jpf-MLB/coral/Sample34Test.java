import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-80.62354130272564 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(81.83378245854064 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(95.03317777109125 ) ;
  }
}
