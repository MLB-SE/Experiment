import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(18.8495813681884,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(39.216638153523775,-80.27749243967898,6.81453783806964 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-49.2204067465202,-89.61964675350207,62.613782751597086 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-54.86551186389255,-100.0,9.92755186490925 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(83.00545860869354,0,0 ) ;
  }
}
