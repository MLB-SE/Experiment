import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(23.049904537575046,71.06089559399109,-8.682809305922689 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(49.31399163447651,-77.23953451322384,6.954595068978648 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(92.5277158815943,-52.35519010355909,-18.71006296509418 ) ;
  }
}
