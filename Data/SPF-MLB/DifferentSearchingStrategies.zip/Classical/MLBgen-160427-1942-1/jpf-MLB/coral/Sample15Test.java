import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.12446096750835522,-88.00850173595536,75.832924671809,76.7404521734664 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.7506427913830436,-49.603692340217506,28.67212074422423,-87.07842116869729 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.9114215252850215,160.48919193951374,-65.95077896913477,-40.741466618830934 ) ;
  }
}
