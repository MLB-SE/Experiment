import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(10.04259481403061,47.549671393542404 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(20.02075089714579,-13.598061704179898 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(35.21657722531413,-41.07501229524903 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(65.98081750009553,49.53966757614393 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-91.08315693012969,85.42571215789869 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(98.21781986707808,42.91084451710864 ) ;
  }
}
