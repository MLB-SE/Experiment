import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-18.997706669315704,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,3.3657291282071213,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(-1.5093467221006234,34.84368990065303,-57.246322981808376,-83.37248563636477,-15.83163385389193 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-31.504000911708843,58.99728089756954,9.847118610399065,-51.76442552753464,-62.02144154943679 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(35.65003097640778,96.391888860465,96.50538266088441,-30.375342006743395,54.72495830123296 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-77.89473179295948,-64.88224671030224,-85.06785098537071,63.71258339032201,-53.63410090656415 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(90.02921702778656,53.90453367641902,37.52330290850446,77.75323861533545,39.126347119935616 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(9.696964705368359,67.6951974916641,99.85608848694483,-51.47437158995838,-31.917397213135985 ) ;
  }
}
