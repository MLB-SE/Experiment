import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(11.813018943107977,-9.64686792767418 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(27.34116587964901,-81.84491776613024 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(60.053623250480484,-4.349026148110277 ) ;
  }
}
