import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(18.68148738279703,17.81365954673211 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(4.457301153403894,0.6634734902633852 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-46.49495499653149,92.59522695315445 ) ;
  }
}
