import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.32903516177864595,0.10810521571755766 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(3.881254135760689,15.064413106873285 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-54.41092598451795,-16.67251304414296 ) ;
  }
}
