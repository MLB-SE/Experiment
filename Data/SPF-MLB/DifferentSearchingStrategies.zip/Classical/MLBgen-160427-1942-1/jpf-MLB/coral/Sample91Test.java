import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-43.142207514631515,-69.95512801460104 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-63.72249230179457,0.5307787630302983 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(66.36519687007095,-3.768664347340959 ) ;
  }
}
