import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(2.060637722818697,23.577756102765647,64.21125321427084 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(62.39717723457868,-59.7360308838776,96.53942387977284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(94.21667962775734,89.20757140035596,-95.4824782925626 ) ;
  }
}
