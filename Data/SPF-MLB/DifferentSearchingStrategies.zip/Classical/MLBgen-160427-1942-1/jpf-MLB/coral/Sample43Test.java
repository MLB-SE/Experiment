import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-0.9538949261864076,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(15.12642657527961,47.10904165995578 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(23.1590171150319,14.709795803582466 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(3.594700991278117,28.941009314251062 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(4.551180055002968,4.551180055002968 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(5.771761708788787,1.2740246280168162 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(6.248735346705246,39.046693433163526 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(64.04282992706118,90.55639186468463 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.851244820315912,21.521215072716515 ) ;
  }
}
