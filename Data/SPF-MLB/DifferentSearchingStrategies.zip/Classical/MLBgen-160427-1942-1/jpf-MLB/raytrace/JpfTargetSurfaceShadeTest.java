import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0.0f,136.0f,0f,0f,1.0f,-1161.0f,0f,-424.0f,0f,0f,0f,0f,0f,-1538.0f,-1050.0f,146.0f,0f,0f,0f,-1,100.0f,-100.0f,100.0f,-8.699793f,-5.344672f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-0.0408803f,0f,0.0f,0f,0f,0f,0f,0f,16.857399f,34.34236f,48.868942f,0f,0f,0f,-1,-41.515022f,-100.0f,46.85268f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-51.66121f,1.918423f,34.760925f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-64.88591f,-29.196508f,0f,0f,0f,783,0.50664157f,0.84083295f,-0.10636775f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,88.061905f,-76.307846f,0f,0f,0f,-211,100.0f,-100.0f,93.103004f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-105.911514f,-41.58626f,-25.501455f,0f,0f,0f,1,-26.019253f,62.421154f,56.693317f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-57.545147f,79.2623f,-32.977806f,0f,0f,0f,-772,0.17535268f,-0.466582f,0.22118917f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-98.69304f,62.486763f,-45.39539f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,14.396104f,0f,0f,0f,-450,96.27338f,-100.0f,-63.4548f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-1.2136468f,-22.208601f,18.49945f,1102.0f,607.0f,801.0f,218,-0.06177606f,0.20246667f,-1.3108269f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-16.502003f,30.26598f,-1.201696f,1283.0f,-719.0f,-473.0f,9,-25.105862f,-29.910429f,-26.208265f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-32.719364f,100.0f,10.748043f,303.0f,143.0f,-408.0f,-1,100.0f,-22.40795f,-37.866123f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-36.74479f,23.170912f,22.619907f,0f,0f,0f,1,16.342522f,-38.206043f,-2.1453528f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,42.948055f,87.25227f,-100.0f,0f,0f,0f,1,-99.93509f,-100.0f,26.700546f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,51.88902f,-4.471634f,28.86625f,0f,0f,0f,-874,0.30494812f,0.02834813f,-0.5523953f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-65.62756f,27.131554f,16.428753f,-449.0f,-1601.0f,857.0f,-4,90.527504f,62.787704f,37.138283f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,83.63741f,48.152752f,-79.39377f,-583.0f,-956.0f,-504.0f,2,5.108729f,-76.40272f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,96.239944f,45.013264f,-5.919064f,93.0f,697.0f,680.0f,1,1.400515f,-68.81828f,87.714966f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,96.25263f,100.0f,-100.0f,0f,0f,0f,-833,-0.23081164f,0.7142478f,0.660739f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-86.05037f,73.1284f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-89.18761f,45.207943f,24.3447f,0f,0f,0f,2,34.99108f,67.57999f,-0.65618366f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-99.99995f,-17.273188f,4.1758122f,0f,0f,0f,1209,0.05735015f,0.47357798f,-0.8788827f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,105.03433f,0f,0f,0f,0f,0f,46.08301f,-40.924572f,-86.9322f,0f,0f,0f,1,-4.0995173f,38.08595f,20.770231f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-11.510892f,0f,0f,0f,0f,0f,-100.0f,48.505093f,100.0f,0f,0f,0f,1,51.81274f,71.00141f,-16.75045f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-28.91254f,0f,0f,0f,0f,0f,-21.018215f,49.295643f,91.006226f,0f,0f,0f,-97,12.654251f,100.0f,-83.91115f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,29.669363f,0f,0f,0f,0f,0f,-16.311415f,-90.342064f,10.146805f,0f,0f,0f,2,13.519199f,-3.635092f,-16.913033f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,51.170567f,0f,0f,0f,0f,0f,47.450375f,-54.213623f,32.730545f,0f,0f,0f,1197,-0.5119451f,-0.09386929f,0.49001592f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-51.336216f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,52.264313f,-2.244435f,-51.1943f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-59.87007f,0f,0f,0f,0f,0f,-38.04066f,45.630074f,-23.974516f,0f,0f,0f,1683,0.9503393f,-6.1897346E-4f,-0.31121364f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,70.050766f,0f,0f,0f,0f,0f,37.38606f,92.80978f,8.778335f,0f,0f,0f,-719,-81.96322f,-73.976944f,15.803609f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-83.3731f,0f,0f,0f,0f,0f,-99.96457f,-71.217705f,55.360466f,0f,0f,0f,304,-0.47334674f,0.14911059f,-0.66290253f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,976.0f,0f,0f,0f,0f,0f,1608.0f,-1464.0f,637.0f,-593.0f,124.0f,178.0f,-572,-6.3686433f,-0.19500199f,-40.867523f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,17.94887f,31.424543f,90.32509f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,11.292322f,100.0f,100.0f,0f,0f,0f,961,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,115.44566f,-100.0f,-54.24124f,0f,0f,0f,1,-88.593376f,84.96244f,24.556023f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,55.702885f,61.17686f,11.918578f,0f,0f,0f,1758,0.15753718f,-0.07355048f,-0.35874143f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.43408f,27.204071f,60.0476f,0f,0f,0f,-1280,-0.07202479f,-0.10720974f,-0.9916242f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,83.71752f,55.590137f,-47.879242f,0f,0f,0f,1,-26.277737f,-20.77016f,-36.80094f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,96.84659f,33.016808f,54.868137f,0f,0f,0f,3,-2.7746298f,-0.2888118f,1.683005f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,58.764782f,-100.0f,0f,0f,0f,-338,-100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,22.773714f,100.0f,-100.0f,0f,0f,0f,884,-0.7396781f,-0.52723384f,-0.41821164f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0.94871444f,-6.0071187f,-14.491619f,-1071.0f,292.0f,-779.0f,-440,60.360645f,4.8590364f,1.93741f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,10.145223f,40.28576f,-21.08957f,604.0f,-686.0f,-1020.0f,1359,-53.981426f,-58.68061f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-15.667986f,-99.99125f,-10.990897f,-1082.0f,16.0f,1356.0f,2,-46.10691f,15.100439f,-67.463646f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-1.6001898f,51.811794f,-48.26769f,0f,0f,0f,-586,0.11054003f,-0.39227724f,-0.075832136f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,32.527245f,-91.8341f,-20.835096f,0f,0f,0f,1,-14.90892f,38.857376f,-86.54104f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,90.76392f,-81.964096f,54.206055f,-163.0f,-301.0f,1926.0f,976,-0.47554788f,0.69174504f,0.5434547f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-99.22328f,10.997078f,100.0f,187.0f,51.0f,2115.0f,-320,-0.6583017f,-0.083088f,-0.7481545f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,-14.358541f,67.87557f,90.36617f,0f,0f,0f,1,-40.953564f,-27.654617f,-53.161503f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,-28.997324f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-26.749866f,-5.7067847f,-57.39698f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,37.308044f,0f,0f,0f,0f,0f,55.267677f,-15.4938f,87.44683f,0f,0f,0f,1,-100.0f,31.80575f,-28.102077f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,4.635833f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-51.151485f,-58.13355f,-7.1799817f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,-93.05629f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-97.03381f,-13.856334f,-53.43359f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.0f,0f,168.0f,0f,0f,0f,0f,0f,1504.0f,435.0f,-520.0f,588.0f,-1368.0f,559.0f,11,1.9714942f,-9.662254f,-4.9201927f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.0f,0f,429.0f,0f,0f,0f,0f,0f,-173.0f,829.0f,-1424.0f,1003.0f,1204.0f,501.0f,9,184.50972f,12.468611f,100.5295f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,11.879402f,0f,0f,0f,0f,0f,0f,0f,-146.95372f,94.83572f,-94.05106f,-831.0f,161.0f,660.0f,3,115.44207f,-94.75325f,94.235756f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1205.0f,0f,1260.0f,0f,0f,0f,0f,0f,386.0f,-367.0f,453.0f,-712.0f,-654.0f,245.0f,-891,25.592701f,42.916065f,12.96118f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-123.0f,0f,59.0f,0f,0f,0f,0f,0f,264.0f,114.0f,528.0f,152.0f,-888.0f,44.0f,5,-100.854805f,-50.462112f,59.24272f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-126.0f,0f,924.0f,0f,0f,0f,0f,0f,202.0f,-987.0f,-1927.0f,-408.0f,-930.0f,-668.0f,-1,100.0f,47.818954f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.383221E-14f,0f,0f,0f,0f,0f,0f,0f,-52.25511f,-100.0f,-11.852582f,-429.0f,691.0f,2277.0f,-333,0.34590352f,-0.004692688f,-0.9382584f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,150.0f,0f,386.0f,0f,0f,0f,0f,0f,-461.0f,987.0f,-168.0f,-491.0f,16.0f,-3.0f,1847,19.687963f,20.664652f,67.38012f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-15.172451f,0f,100.0f,0f,0f,0f,0f,0f,-99.99938f,-100.0f,-41.697227f,0f,0f,0f,1109,0.7865943f,-0.49435213f,-0.36998037f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1710.0f,0f,724.0f,0f,0f,0f,0f,0f,-217.0f,-946.0f,290.0f,884.0f,24.0f,1686.0f,1304,-0.7631931f,0.15549985f,-0.15403703f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,17.506346f,0f,0f,0f,0f,0f,0f,0f,5.458192f,-14.312772f,-83.72176f,-898.0f,-904.0f,96.0f,419,64.915596f,5.143185f,62.817417f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1813.0f,0f,2.0f,0f,0f,0f,0f,0f,779.0f,-1227.0f,274.0f,-1367.0f,-1309.0f,-159.0f,426,-0.8108061f,0.10632785f,-0.3347561f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-18.522396f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,40.884396f,66.67047f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1866.0f,0f,2150.0f,0f,0f,0f,0f,0f,535.0f,993.0f,120.0f,-702.0f,-1641.0f,-757.0f,-746,-80.44531f,7.6971483f,76.689926f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1910.0f,0f,162.0f,0f,0f,0f,0f,0f,-837.0f,-984.0f,-127.0f,-707.0f,318.0f,-84.0f,-1441,-0.61018175f,0.7877687f,-0.084253564f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2075.0f,0f,554.0f,0f,0f,0f,0f,0f,-461.0f,-808.0f,-649.0f,496.0f,122.0f,1216.0f,-287,0.8204441f,-0.34806722f,0.11983792f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-22.343513f,0f,24.587639f,0f,0f,0f,0f,0f,3.721769f,-63.321674f,-44.079384f,0f,0f,0f,-1974,0.07810906f,0.5013665f,0.20625687f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2.529473f,0f,0f,0f,0f,0f,0f,0f,-46.413235f,30.576576f,90.932785f,0f,0f,0f,1,20.228626f,80.39369f,-52.267876f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,3.007968f,0f,0f,0f,0f,0f,0f,0f,78.53011f,48.202168f,100.0f,-374.0f,130.0f,-180.0f,-571,-70.50144f,-48.176605f,65.67642f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,30.273052f,0f,0f,0f,0f,0f,0f,0f,-0.49344364f,15.056836f,30.872915f,-364.0f,-1560.0f,755.0f,-816,135.2535f,-100.0f,-185.47957f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-30.60116f,0f,-57.47953f,0f,0f,0f,0f,0f,98.41985f,-75.025055f,-85.436935f,0f,0f,0f,-984,-0.04928315f,0.7947951f,0.26361412f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,3.1092503f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-45.99334f,-53.620693f,15.465505f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,31.1057f,0f,0f,0f,0f,0f,0f,0f,61.120213f,-33.419582f,-39.89915f,-413.0f,-695.0f,118.0f,2,47.14305f,100.0f,99.15574f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,3.230343f,0f,0f,0f,0f,0f,0f,0f,21.173397f,-49.58218f,66.10078f,993.0f,1667.0f,935.0f,1945,-0.24554127f,-0.35613716f,-1.4916228f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,33.671337f,0f,0f,0f,0f,0f,0f,0f,28.403254f,26.774973f,-42.657993f,214.0f,114.0f,226.0f,1566,53.298298f,15.276949f,45.615803f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-33.724365f,0f,74.66243f,0f,0f,0f,0f,0f,17.545574f,95.51536f,-114.89894f,0f,0f,0f,1,20.452753f,44.648033f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,36.55205f,0f,0f,0f,0f,0f,0f,0f,100.0f,25.639687f,44.04916f,575.0f,584.0f,818.0f,-958,0.14886366f,0.65894157f,-0.7215114f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-37.694378f,0f,0f,0f,0f,0f,0f,0f,64.90618f,100.0f,62.66736f,0f,0f,0f,-989,0.02804539f,-0.91846013f,0.39451802f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,38.768623f,0f,0f,0f,0f,0f,0f,0f,0.563446f,12.316605f,31.879038f,0f,0f,0f,1,42.426846f,47.54407f,-96.34979f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-39.411884f,0f,0f,0f,0f,0f,0f,0f,43.637238f,-58.963917f,-76.35873f,0f,0f,0f,1,-100.0f,74.5047f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,39.4542f,0f,0f,0f,0f,0f,0f,0f,-60.270363f,-87.068634f,-65.709206f,0f,0f,0f,379,45.84485f,38.25987f,11.159657f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,4.0f,0f,1274.0f,0f,0f,0f,0f,0f,919.0f,706.0f,-63.0f,44.0f,-130.0f,-819.0f,-639,23.473206f,-28.93471f,36.419277f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,41.04882f,0f,0f,0f,0f,0f,0f,0f,-82.38926f,-75.614365f,-82.023476f,-487.0f,-665.0f,573.0f,3,100.0f,-36.845894f,-55.582405f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,41.313396f,0f,0f,0f,0f,0f,0f,0f,-99.61223f,-40.185734f,-70.329155f,791.0f,-3095.0f,1147.0f,-750,-2.7237575f,-1.057634f,4.4633346f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,415.0f,0f,-740.0f,0f,0f,0f,0f,0f,467.0f,701.0f,-1382.0f,606.0f,-88.0f,-187.0f,-2534,-20.611504f,9.877339f,-1.9548072f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-424.0f,0f,570.0f,0f,0f,0f,0f,0f,508.0f,1097.0f,-391.0f,274.0f,1303.0f,591.0f,3,78.63075f,-159.5706f,-36.896725f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,42.742462f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-70.6715f,92.919556f,1610.0f,610.0f,566.0f,1,30.085453f,48.259727f,-53.91547f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-47.6667f,0f,0f,0f,0f,0f,0f,0f,-41.00913f,97.47268f,-53.34806f,0f,0f,0f,-583,51.01658f,-93.85011f,47.600677f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,48.20927f,0f,0f,0f,0f,0f,0f,0f,-3.2162638f,48.512318f,14.319924f,241.0f,132.0f,-253.0f,-505,-26.59074f,-28.530642f,90.53587f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,48.622944f,0f,0f,0f,0f,0f,0f,0f,-97.19849f,-55.115173f,-5.5138826f,-377.0f,760.0f,-951.0f,-927,74.50837f,28.672178f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,50.17241f,0f,0f,0f,0f,0f,0f,0f,11.050968f,-8.530902f,8.14918f,-274.0f,58.0f,432.0f,1679,-0.8084413f,-0.56812525f,0.15399456f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,52.05962f,0f,77.2907f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,-82.92398f,-11.610505f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,5.400728f,0f,0f,0f,0f,0f,0f,0f,12.713175f,10.28923f,-17.807756f,979.0f,372.0f,909.0f,-272,-0.22907811f,0.35053372f,0.90846217f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-55.437534f,0f,0.0f,0f,0f,0f,0f,0f,91.11359f,11.938955f,36.8873f,0f,0f,0f,568,-0.2658152f,0.09541564f,0.16825871f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-57.0f,0f,1256.0f,0f,0f,0f,0f,0f,911.0f,1360.0f,-57.0f,-615.0f,-150.0f,-635.0f,-1210,-0.58195585f,-0.47219235f,-0.011101876f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,5.893701f,0f,0f,0f,0f,0f,0f,0f,-66.01671f,100.0f,-32.818047f,49.0f,193.0f,-889.0f,324,100.0f,57.35433f,13.902527f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,59.77663f,0f,0f,0f,0f,0f,0f,0f,4.3259034f,17.328354f,-58.999756f,323.0f,390.0f,1117.0f,954,23.649517f,75.962616f,74.62887f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,6.2217984f,0f,0f,0f,0f,0f,0f,0f,-8.527829f,-13.378714f,2.0484254f,1929.0f,-1537.0f,-1874.0f,-2462,0.16768415f,0.30119908f,-0.9232258f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-66.47452f,0f,-34.99544f,0f,0f,0f,0f,0f,100.0f,2.454844f,-64.27045f,0f,0f,0f,688,0.08241941f,0.69028974f,0.71882343f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,67.68345f,0f,0f,0f,0f,0f,0f,0f,-43.027447f,25.362108f,16.804384f,555.0f,656.0f,431.0f,-858,46.519783f,-100.0f,90.006546f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,692.0f,0f,-1470.0f,0f,0f,0f,0f,0f,298.0f,220.0f,82.0f,-623.0f,326.0f,-901.0f,-275,0.21230666f,-0.83030826f,-0.2694719f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,69.39394f,0f,0f,0f,0f,0f,0f,0f,53.318707f,12.01954f,-12.286942f,-73.0f,439.0f,270.0f,1,100.0f,10.013042f,-53.932915f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,6.9428244f,0f,0f,0f,0f,0f,0f,0f,-86.55572f,-77.31811f,3.0792525f,63.0f,266.0f,-43.0f,-819,0.35724562f,-0.43217894f,-0.80981004f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,69.443985f,0f,0f,0f,0f,0f,0f,0f,-66.06079f,48.53411f,46.491295f,819.0f,243.0f,167.0f,1270,0.4774625f,0.8521027f,-0.2143608f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,70.090805f,0f,0f,0f,0f,0f,0f,0f,100.0f,43.540493f,100.0f,1177.0f,-139.0f,685.0f,-1241,0.39105955f,-0.92015266f,-0.019785471f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-72.53635f,0f,25.249481f,0f,0f,0f,0f,0f,60.294044f,79.70476f,38.01644f,0f,0f,0f,-385,40.444035f,-30.06817f,-53.29641f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-75.02251f,0f,-23.38344f,0f,0f,0f,0f,0f,77.745155f,94.20679f,-19.720432f,0f,0f,0f,1,41.056698f,-58.488308f,20.947514f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,75.62219f,0f,0f,0f,0f,0f,0f,0f,97.14335f,-27.054987f,73.95812f,579.0f,-207.0f,370.0f,490,0.6113214f,0.32768756f,-0.72035205f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,7.697792f,0f,0f,0f,0f,0f,0f,0f,-87.69531f,-91.48972f,45.851994f,595.0f,-432.0f,276.0f,-1121,-9.441052f,23.217978f,18.746225f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-8.177583f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,32.243717f,38.5516f,60.40541f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,81.887665f,0f,0f,0f,0f,0f,0f,0f,-43.931484f,-52.39908f,-39.287968f,-947.0f,-347.0f,156.0f,-376,34.813538f,-49.659878f,27.30407f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-83.04588f,0f,0f,0f,0f,0f,0f,0f,40.162502f,47.30266f,-65.87722f,0f,0f,0f,-430,0.08791637f,-0.48696792f,0.04265903f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,839.0f,0f,4.0f,0f,0f,0f,0f,0f,-729.0f,1728.0f,1933.0f,-1597.0f,-1178.0f,-1401.0f,-6,-44.43899f,-43.396538f,8.0431595f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-84.23575f,0f,-20.147068f,0f,0f,0f,0f,0f,24.131012f,25.29713f,12.962287f,0f,0f,0f,-967,-68.04973f,22.93364f,53.10876f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,85.277504f,0f,0f,0f,0f,0f,0f,0f,59.63066f,6.054367f,48.883656f,641.0f,-1819.0f,-808.0f,2,14.750475f,32.87349f,-22.044323f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-871.0f,0f,1121.0f,0f,0f,0f,0f,0f,-504.0f,1079.0f,-113.0f,-497.0f,-667.0f,-950.0f,7,-41.827076f,-44.287193f,-58.08226f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-8.87301f,0f,-1.9721523E-31f,0f,0f,0f,0f,0f,40.204124f,-67.886955f,87.20137f,0f,0f,0f,1,4.4863405f,72.1671f,-27.349733f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,93.59074f,0f,0f,0f,0f,0f,0f,0f,100.0f,84.73464f,-100.0f,0f,0f,0f,-396,-0.76595587f,-0.4418796f,-0.46696258f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,9.364036f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,20.776018f,10.028329f,-32.572357f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,94.44069f,0f,0f,0f,0f,0f,0f,0f,-5.294624f,9.896427f,12.287226f,836.0f,-433.0f,703.0f,-745,-0.3473297f,-0.8100118f,0.48063773f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-950.0f,0f,578.0f,0f,0f,0f,0f,0f,20.0f,517.0f,-164.0f,-836.0f,-272.0f,-1212.0f,-1461,-0.10442277f,-0.6203207f,-0.77020425f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,96.77884f,0f,0f,0f,0f,0f,0f,0f,-78.50111f,-56.19798f,-37.740574f,450.0f,-959.0f,492.0f,906,-0.31797403f,0.33113068f,1.3653424f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,97.418175f,0f,0f,0f,0f,0f,0f,0f,73.40441f,100.0f,114.58342f,18.0f,22.0f,-31.0f,2,153.72328f,-85.93723f,-32.99542f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,97.55919f,0f,0f,0f,0f,0f,0f,0f,27.662807f,5.083702f,2.7548132f,28.0f,-387.0f,433.0f,453,-47.798355f,84.50114f,15.510412f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,97.610825f,0f,0f,0f,0f,0f,0f,0f,9.109664f,0.20477785f,-53.760128f,-958.0f,143.0f,-887.0f,-17,-0.9165052f,-0.27788764f,-0.14786555f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,98.309586f,0f,0f,0f,0f,0f,0f,0f,51.54225f,-100.0f,-71.72613f,-338.0f,1107.0f,-135.0f,1,73.60099f,25.9507f,16.709263f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.593025f,0f,0f,0f,0f,0f,0f,0f,6.3357425f,-54.699993f,68.01525f,160.0f,1361.0f,-168.0f,2296,0.59154105f,0.43319878f,-0.58750063f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.99994f,0f,0f,0f,0f,0f,0f,0f,79.85552f,99.82216f,12.4739895f,-2415.0f,2359.0f,-1497.0f,-509,-0.5349339f,0.2560826f,0.80515057f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.27118215f,0.0f,0f,0f,0f,0f,0f,0f,0f,-76.64281f,100.0f,90.854095f,-964.0f,237.0f,-1077.0f,-5,32.63296f,-56.25011f,-29.374313f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-17.202301f,100.0f,-97.69751f,0f,0f,0f,1,-0.035284907f,0.39299616f,-0.53470844f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-30.10183f,-23.452484f,100.0f,0f,0f,0f,1,100.0f,-100.0f,6.6493454f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,30.616869f,-58.24239f,62.860752f,0f,0f,0f,-2263,-1.7546217f,11.8896f,11.597892f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-37.393986f,54.513367f,66.35817f,0f,0f,0f,1,0.4473249f,5.066208f,6.975941f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-44.88716f,61.84331f,72.35487f,0f,0f,0f,385,16.054989f,81.70154f,26.844715f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-48.43066f,-17.132809f,23.046103f,0f,0f,0f,-151,-0.03271278f,0.078349255f,0.5377936f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,50.26945f,100.0f,-13.170084f,0f,0f,0f,-1,0.26921943f,-0.07106697f,-1.1043903f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,69.426636f,123.92113f,-14.811165f,0f,0f,0f,-1,99.08519f,-33.390804f,-88.65723f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-6.9476357f,48.8303f,2.8604414f,0f,0f,0f,1,2.4283843f,52.048664f,57.519333f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-75.08546f,-52.284767f,-87.77962f,0f,0f,0f,796,-45.11005f,-7.585953f,43.10498f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,8.43274f,6.07476f,53.50108f,0f,0f,0f,1,-0.67124623f,0.7302264f,0.12727094f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,99.53116f,100.0f,65.65796f,0f,0f,0f,-346,0.36885077f,-0.37905902f,0.8486833f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.3148705f,-73.712685f,-99.87902f,0f,0f,0f,1,0.13675587f,-0.5275896f,0.20360819f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.02627265f,0.6706815f,0.51504916f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.030050192f,-0.01809093f,0.99938464f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.06879307f,0.6256681f,0.77705014f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.086587965f,-0.9954605f,0.03950776f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.09138223f,-0.27560142f,0.20103453f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.111604154f,-0.006834788f,0.021113852f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.14471568f,0.093173854f,0.98507667f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.16479221f,-0.55112535f,0.81798804f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.16591366f,0.27957898f,0.511028f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.18927048f,0.21649836f,0.034017187f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.2457295f,0.07364002f,-0.7777819f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.25499135f,-0.9634079f,0.0826116f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.29611957f,-0.19328475f,0.44546103f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.31576392f,-0.77614516f,0.13723814f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3609367f,0.047386568f,0.93138564f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.37203893f,0.19067904f,-0.9084209f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.39585152f,-0.26059523f,-0.055376954f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.41491985f,-0.3384303f,-0.4810541f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.4266695f,-0.58216566f,-0.24936578f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.4954939f,-0.17419611f,-0.06292668f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5750248f,-0.40477365f,-0.1399001f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5979538f,-0.6496714f,-0.46944472f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.61920345f,0.13051775f,-0.7743076f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.6282223f,0.08609933f,-0.6697493f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.6842637f,-0.15222438f,0.19020092f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.81326056f,-0.09916701f,-0.47619236f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.85505533f,0.29945707f,0.42332712f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-103.51008f,74.35658f,0.36276567f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.7654078f,87.02806f,91.15171f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,17.809963f,-38.739105f,68.6669f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-2.1542572E-4f,-1.005978E-4f,-8.733735E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,2.3672669E-4f,-7.526134E-4f,-2.949049E-6f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,32.91411f,-88.67662f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-36.890797f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1388,0.8427127f,-0.4814981f,0.24082136f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,40.283997f,-151.9901f,38.136448f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,52.501057f,7.380686f,-25.946917f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-53.29762f,82.532364f,33.65995f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-57.11327f,-3.8509357f,83.99831f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-60.021328f,-44.507034f,-29.019655f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-65.70817f,27.841908f,84.046196f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,6.820903f,-37.79856f,-79.428635f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,72.99887f,-60.659054f,-52.070637f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,79.46518f,99.77757f,81.74949f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-96.84113f,-33.92298f,25.181587f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.27956334f,-0.5362039f,0.7964482f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,75.66055f,99.765915f,43.21205f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,-7.139436E-6f,-0.001168632f,0.0016298607f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,418,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,528,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,553,66.274895f,45.25727f,-97.853745f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-570,0.9982086f,-0.0039196494f,-0.05970114f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-590,65.89882f,87.49232f,-53.8491f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-761,0.0017358589f,-0.0052898745f,-4.823397E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-858,-2.5172073E-6f,-7.358867E-7f,5.3730525E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,891,5.0218747E-5f,2.3369871E-4f,4.966381E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-894,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-896,-0.73837876f,0.30254984f,0.07200061f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,918,-88.106804f,-96.4337f,97.53153f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,942,-0.8257442f,0.13443145f,0.08971551f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,981,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-80.271416f,0f,0f,0f,1,0.6910117f,-0.46730468f,0.08105116f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,13.268492f,-17.411983f,0f,0f,0f,2153,-0.20246147f,0.6711725f,-0.6513158f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-22.56276f,-20.20757f,0f,0f,0f,1,0.31166106f,0.107479274f,-0.24441941f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,43.51727f,-80.02634f,0f,0f,0f,1,-0.7225119f,0.09554338f,-0.35855347f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-45.867313f,64.12823f,0f,0f,0f,1,-69.18127f,-100.0f,13.468539f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-13.908998f,-93.72194f,-94.42462f,0f,0f,0f,1,-76.30668f,-85.43616f,-28.741623f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.585052f,-15.742762f,-73.846275f,0f,0f,0f,1503,-0.2683783f,-0.774798f,0.23898882f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.25353f,5.2481494f,52.213505f,-571.0f,637.0f,685.0f,43,0.95214504f,-0.5315651f,-0.35237736f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.923317f,90.95335f,-97.99108f,0f,0f,0f,1061,0.7446045f,-0.3599463f,-0.56214124f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.5187752f,36.77161f,95.136696f,0f,0f,0f,-1,39.230316f,81.705055f,-4.5236173f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.471529f,-79.08338f,74.56112f,0f,0f,0f,1734,2.1018732f,-2.0728471f,-1.4523381f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,32.731052f,21.958933f,94.25801f,0f,0f,0f,1,0.7275421f,0.6274509f,0.27746695f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.886917f,73.147095f,-2.0027797f,0f,0f,0f,1,98.83726f,-49.781704f,-96.49575f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.530533f,-25.439457f,-36.595634f,0f,0f,0f,1,-15.280486f,3.3872452f,-17.607946f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.58491f,51.99014f,54.28784f,0f,0f,0f,2,0.08070732f,-0.33443892f,-0.43323943f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,44.148514f,-44.951847f,54.064293f,-360.0f,-457.0f,-86.0f,601,-3.666403f,-0.55211836f,2.5348988f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.57896f,-100.0f,91.83829f,0f,0f,0f,-1,-0.07097522f,-0.27742293f,-0.9581227f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-50.777428f,54.612595f,-72.94515f,0f,0f,0f,1,100.0f,55.63335f,35.547356f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,50.978344f,-23.767948f,28.738941f,0f,0f,0f,1,13.528518f,30.840925f,1.5088961f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-52.599007f,85.4791f,-51.298664f,0f,0f,0f,718,-91.12967f,-9.519972f,-75.13444f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-52.60019f,-43.819168f,63.414806f,-180.0f,822.0f,-1000.0f,-380,-0.65880024f,2.2077382f,0.97908103f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-57.500942f,-5.553589f,-23.595058f,0f,0f,0f,1,-27.424347f,46.20201f,55.958275f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,59.90416f,100.0f,-29.84301f,0f,0f,0f,2,0.58408344f,-1.0142801f,-1.024741f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.94057f,-20.947964f,68.1786f,0f,0f,0f,935,44.170105f,4.7443056f,-32.4609f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,78.46785f,36.173096f,78.3355f,0f,0f,0f,1,50.988514f,-18.96606f,-42.316673f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,84.35971f,47.733303f,25.309381f,0f,0f,0f,-588,37.36514f,-58.028744f,-15.101475f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-85.94807f,16.491955f,-85.42066f,0f,0f,0f,-443,0.7050495f,0.3954048f,0.062308043f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,89.8721f,-47.08126f,99.88912f,0f,0f,0f,1,-0.013382998f,-0.9090672f,-0.41643447f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-94.58672f,-48.702305f,-13.611195f,0f,0f,0f,1,55.17641f,75.99902f,93.377495f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-96.4429f,65.78815f,42.840214f,0f,0f,0f,1,-2.2384071f,2.244232f,-8.48554f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,98.121315f,33.284184f,-58.695744f,0f,0f,0f,1,-25.237728f,100.0f,-53.500313f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.90494f,-100.0f,10.123305f,0f,0f,0f,-718,0.63696676f,0.73686945f,0.22648783f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,4.8594246f,0f,0f,0f,0f,0f,0f,2,100.0f,-100.0f,4.8594246f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.81124f,49.866875f,-57.290833f,0f,0f,0f,0f,0f,0f,3,16.491812f,50.016464f,-57.331547f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,18.71443f,-22.24582f,-20.663303f,0f,0f,0f,0f,0f,0f,2,-0.81154f,66.355286f,55.45157f,0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.133263f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f,2,36.1333f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-56.051723f,-84.75846f,44.404472f,0f,0f,0f,0f,0f,0f,2,-55.594414f,-84.631935f,44.24296f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.8247495f,-61.735203f,59.10825f,0f,0f,0f,0f,0f,0f,2,5.824755f,-61.735207f,59.10825f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.3554f,-14.812036f,-99.03582f,0f,0f,0f,0f,0f,0f,2,68.47761f,-14.204566f,-99.36401f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.09712f,100.0f,-6.1705575f,0f,0f,0f,0f,0f,0f,2,-78.54456f,100.0f,-7.067959f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.58323f,1.1288855f,57.674244f,0f,0f,0f,0f,0f,0f,5,54.714527f,-13.976913f,73.855095f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,80.63187f,33.243607f,-75.28234f,0f,0f,0f,0f,0f,0f,2,81.222244f,33.21143f,-74.97798f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,81.53644f,-7.880772f,-34.91835f,0f,0f,0f,0f,0f,0f,2,45.565872f,95.37517f,9.155611f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-95.36481f,67.05623f,100.0f,0f,0f,0f,0f,0f,0f,2,-95.28442f,66.05947f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.99673f,100.0f,-16.622263f,0f,0f,0f,0f,0f,0f,2,100.0f,100.0f,-17.332785f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-25.742624f,68.49494f,26.401068f,-87.0f,-662.0f,834.0f,1,-54.684002f,74.49552f,93.14103f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-29.294634f,-5.228337f,-30.93319f,627.0f,232.0f,-633.0f,843,24.104956f,-77.104355f,-53.381706f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,32.739044f,68.03554f,-55.96419f,111.0f,1050.0f,-1075.0f,1495,-0.40043145f,0.74743366f,0.4110789f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,40.026363f,-100.0f,-66.68415f,0f,0f,0f,-421,-0.2332771f,0.07643362f,-0.25464216f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,53.106606f,-45.05376f,-5.6330886f,637.0f,827.0f,-609.0f,-1017,-0.31026667f,-0.66186583f,0.2707955f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-87.68389f,100.0f,-48.63131f,-833.0f,918.0f,-850.0f,462,-0.20322168f,0.47924247f,0.8538311f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,-90.82641f,100.0f,-99.40031f,0f,0f,0f,4,0.046466798f,0.9891789f,-0.13916157f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-9.739997f,-51.38865f,-100.0f,1402.0f,-2815.0f,-812.0f,-1,0.20060933f,0.22214125f,-0.95417804f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-101.03712f,0f,0f,0f,0f,0f,100.0f,136.43698f,100.0f,0f,0f,0f,1,46.33849f,77.75962f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,104.784424f,0f,0f,0f,0f,0f,-30.691126f,-39.532562f,8.3821745f,376.0f,-318.0f,-121.0f,1073,92.13716f,-88.04912f,-77.90508f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,120.96733f,0f,0f,0f,0f,0f,71.42774f,57.791622f,49.38319f,704.0f,-442.0f,-501.0f,-219,24.42846f,-41.96998f,13.7829f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,121.48385f,0f,0f,0f,0f,0f,10.835365f,91.26489f,72.11291f,0f,0f,0f,1,-100.0f,-52.8495f,85.048584f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.3669909f,0f,0f,0f,0f,0f,-20.56135f,62.491886f,-51.49182f,746.0f,388.0f,173.0f,141,-0.8345923f,0.10308123f,-0.42999402f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-14.098789f,0f,0f,0f,0f,0f,-83.215225f,-52.847412f,-100.0f,0f,0f,0f,259,-0.96373045f,0.12823516f,0.23404989f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,14.607406f,0f,0f,0f,0f,0f,51.179554f,50.959328f,88.016495f,918.0f,604.0f,349.0f,-680,48.049816f,66.87045f,-66.65616f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,14.788259f,0f,0f,0f,0f,0f,-86.78171f,100.0f,74.10302f,140.0f,-106.0f,309.0f,8,93.20596f,30.99241f,67.329666f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.4863139f,0f,0f,0f,0f,0f,-3.0993283f,-71.777275f,48.85476f,-876.0f,-116.0f,-226.0f,1,-4.813022f,1.7765038f,6.0375576f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,156.16418f,0f,0f,0f,0f,0f,14.611787f,-33.289013f,-1.683097f,-774.0f,517.0f,307.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,158.77426f,0f,0f,0f,0f,0f,-0.93165517f,63.910454f,-2.752435f,418.0f,-16.0f,-513.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.251379f,0f,0f,0f,0f,0f,-36.32244f,100.0f,-100.0f,0f,0f,0f,1,0.40300435f,0.13126636f,-0.6405999f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.352907f,0f,0f,0f,0f,0f,-3.382155f,-1.0989143f,22.081024f,-290.0f,243.0f,81.0f,159,31.477169f,13.818869f,5.509093f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-1.7763568E-14f,0f,0f,0f,0f,0f,74.6753f,-67.66658f,-100.0f,0f,0f,0f,2,-19.619024f,-168.85178f,99.48442f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-17.94747f,0f,0f,0f,0f,0f,-34.658764f,40.42266f,95.38072f,0f,0f,0f,-732,-77.59105f,-10.678825f,83.80357f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,20.886335f,0f,0f,0f,0f,0f,7.820472f,28.238468f,-40.603535f,-755.0f,282.0f,-822.0f,1300,0.79390514f,0.14034738f,0.10866451f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,216.45816f,0f,0f,0f,0f,0f,-56.642525f,9.430474f,14.10624f,-168.0f,-1609.0f,402.0f,-749,4.5855517f,65.53223f,-25.397465f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.700214f,0f,0f,0f,0f,0f,-75.220184f,68.888626f,-35.94795f,359.0f,588.0f,0.0f,-2,81.19702f,83.359406f,-85.80756f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-23.012835f,0f,0f,0f,0f,0f,-133.23326f,93.44815f,91.116875f,0f,0f,0f,-1,-97.98976f,-67.74172f,-61.177353f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-23.320072f,0f,0f,0f,0f,0f,-10.354743f,-100.0f,-95.71952f,0f,0f,0f,1252,-1.8324764f,-0.0860474f,0.28829688f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.65629f,0f,0f,0f,0f,0f,44.276237f,-77.4995f,15.28205f,-184.0f,-296.0f,-968.0f,585,-66.78994f,-51.023735f,15.122549f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.13179f,0f,0f,0f,0f,0f,30.005684f,47.399006f,-18.348036f,1678.0f,-936.0f,-2393.0f,131,-26.140884f,43.646942f,70.211876f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.76982f,0f,0f,0f,0f,0f,84.65588f,15.059483f,-15.491033f,398.0f,954.0f,-133.0f,1313,1.7574401f,0.808692f,0.19757572f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.15436f,0f,0f,0f,0f,0f,-6.586418f,-7.5747895f,-16.477545f,468.0f,140.0f,-1408.0f,915,104.81022f,-81.72842f,-4.3127027f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.80762f,0f,0f,0f,0f,0f,-45.875675f,-70.040016f,60.952797f,-695.0f,-566.0f,1323.0f,-742,0.39735308f,-0.33352846f,0.45104018f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.88573f,0f,0f,0f,0f,0f,-146.08838f,-58.149258f,129.33229f,-2047.0f,-559.0f,-246.0f,-76,0.51535845f,0.31045488f,2.4996643f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.28279f,0f,0f,0f,0f,0f,19.91001f,96.00494f,-76.7215f,-42.0f,280.0f,-672.0f,1106,82.9813f,-19.241829f,-2.5436423f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.45142f,0f,0f,0f,0f,0f,-141.51225f,61.553555f,-216.52663f,-869.0f,567.0f,-842.0f,552,-6.240601f,-0.23418345f,1.1989738f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.10574f,0f,0f,0f,0f,0f,-22.752148f,-27.191925f,132.5461f,-636.0f,1247.0f,1637.0f,-473,52.346684f,203.60529f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-25.42285f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.29753f,0f,0f,0f,0f,0f,-63.722717f,-84.80977f,92.169815f,-786.0f,515.0f,446.0f,455,-6.4826083f,-86.87341f,-84.40942f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.38882f,0f,0f,0f,0f,0f,27.194506f,-50.359913f,-35.190422f,-154.0f,-443.0f,61.0f,-396,-39.914734f,15.70259f,-75.47991f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.44041f,0f,0f,0f,0f,0f,-100.0f,100.0f,77.050705f,-639.0f,305.0f,-127.0f,-475,-11.467329f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.67307f,0f,0f,0f,0f,0f,-39.410862f,71.98377f,-100.0f,824.0f,451.0f,-138.0f,307,27.950129f,-34.68771f,-76.38167f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.67807f,0f,0f,0f,0f,0f,70.64161f,53.56664f,48.49161f,559.0f,-589.0f,804.0f,1420,0.5090837f,0.21707755f,-0.5891257f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.8216f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,376.0f,269.0f,-349.0f,596,97.45105f,100.0f,-38.997555f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.8309f,0f,0f,0f,0f,0f,32.327965f,153.70789f,-100.0f,136.0f,946.0f,-485.0f,463,-18.195162f,25.247908f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.8783f,0f,0f,0f,0f,0f,161.19804f,77.10977f,-31.282022f,974.0f,-1318.0f,-1353.0f,-328,1.5971034f,0.6995251f,-0.32875162f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97461f,0f,0f,0f,0f,0f,-10.034505f,-10.126964f,-56.35709f,-432.0f,-1432.0f,-2292.0f,637,99.92505f,23.977741f,-22.104439f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.04826f,0f,0f,0f,0f,0f,6.5157905f,197.13095f,168.14488f,2405.0f,39.0f,96.0f,-3906,0.30015263f,-0.021776933f,0.6517591f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.05998f,0f,0f,0f,0f,0f,-131.59566f,85.23429f,-88.03336f,-544.0f,-723.0f,-724.0f,1384,-142.41945f,44.690914f,-61.529316f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.27078f,0f,0f,0f,0f,0f,-2.1644912f,184.91986f,-60.60163f,-863.0f,641.0f,-1002.0f,112,-0.58070093f,0.49191177f,0.20862734f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.42445f,0f,0f,0f,0f,0f,-25.27135f,67.55618f,-118.72561f,-435.0f,795.0f,-1839.0f,-140,2.94655f,44.856518f,-50.262894f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.16064f,0f,0f,0f,0f,0f,-91.713196f,48.708607f,-50.345936f,-1039.0f,955.0f,398.0f,-508,0.21594037f,-0.42824346f,-3.506385f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,257.14294f,0f,0f,0f,0f,0f,-19.795979f,76.223366f,100.0f,-1086.0f,-637.0f,1172.0f,-436,-68.023605f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,258.90952f,0f,0f,0f,0f,0f,202.18155f,27.49202f,-227.9598f,-553.0f,834.0f,-1414.0f,-739,-0.38205108f,0.19231303f,-0.7045619f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,25.919426f,0f,0f,0f,0f,0f,8.532133f,41.6011f,13.087796f,-210.0f,201.0f,-502.0f,282,0.24382178f,0.26170665f,0.5359187f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.016384f,0f,0f,0f,0f,0f,-18.552435f,-3.74983f,-82.31501f,1268.0f,-588.0f,-259.0f,1,87.58051f,66.303894f,-30.825993f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,272.37622f,0f,0f,0f,0f,0f,100.0f,-100.0f,-19.530947f,1116.0f,-1091.0f,967.0f,-624,100.0f,59.013157f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.456179f,0f,0f,0f,0f,0f,-24.838133f,-54.467743f,-1.534686f,-904.0f,-611.0f,804.0f,1,100.0f,-42.78394f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.837103f,0f,0f,0f,0f,0f,-68.81983f,52.303577f,-42.07892f,342.0f,371.0f,-99.0f,-457,-93.33519f,-45.76771f,95.76047f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,310.73404f,0f,0f,0f,0f,0f,100.0f,-187.02617f,100.0f,-565.0f,-426.0f,392.0f,-949,100.0f,-151.94228f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,310.75586f,0f,0f,0f,0f,0f,-80.43441f,21.361553f,-81.59194f,-822.0f,-751.0f,-447.0f,-380,-51.59757f,13.853605f,-29.805431f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,318.67587f,0f,0f,0f,0f,0f,74.793686f,99.84501f,16.795929f,-501.0f,1227.0f,-723.0f,796,1.3044142f,0.011362596f,0.11069999f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-32.434437f,0f,0f,0f,0f,0f,14.423463f,-49.219646f,-9.74751f,0f,0f,0f,1,99.3594f,16.92175f,61.57718f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.466953f,0f,0f,0f,0f,0f,8.964733f,-30.416418f,43.89842f,-499.0f,436.0f,404.0f,2846,21.296164f,-80.45449f,21.059046f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,3.3968997f,0f,0f,0f,0f,0f,-100.0f,32.92192f,0.424403f,-1145.0f,-100.0f,-779.0f,2339,0.29382908f,0.8919294f,0.04448703f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,344.7508f,0f,0f,0f,0f,0f,-10.682861f,81.68681f,-86.86897f,-10.0f,1063.0f,-63.0f,-218,-0.6698036f,0.25359285f,-0.22590397f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,34.593445f,0f,0f,0f,0f,0f,-82.82678f,-79.60242f,99.82371f,411.0f,-876.0f,472.0f,688,62.821255f,-21.15268f,71.6959f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,34.70216f,0f,0f,0f,0f,0f,-54.954044f,-90.32475f,76.20566f,280.0f,-909.0f,875.0f,78,0.794049f,-0.16974467f,0.37141678f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,349.84555f,0f,0f,0f,0f,0f,-31.204664f,-100.0f,-29.554876f,-1189.0f,-756.0f,-1482.0f,-457,68.08857f,-50.550762f,99.171524f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,35.971394f,0f,0f,0f,0f,0f,59.33076f,13.855424f,-14.4379225f,690.0f,165.0f,370.0f,251,8.301181f,-39.790524f,-72.74995f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,38.20244f,0f,0f,0f,0f,0f,52.964504f,25.847122f,-54.258564f,-842.0f,-211.0f,366.0f,1,19.760891f,-79.739815f,-18.696016f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,40.781326f,0f,0f,0f,0f,0f,80.55115f,-24.232176f,100.0f,284.0f,812.0f,-32.0f,200,0.075113855f,-0.8796983f,0.3333694f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.13019f,0f,0f,0f,0f,0f,-51.651325f,78.504425f,-46.627586f,232.0f,715.0f,-617.0f,-764,-82.937035f,-74.99806f,-34.39749f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.904423f,0f,0f,0f,0f,0f,-35.900913f,-76.33746f,30.450964f,-269.0f,-492.0f,252.0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.880592f,0f,0f,0f,0f,0f,99.846436f,100.0f,-100.0f,0f,0f,0f,1,0.20024033f,-0.7410392f,-0.64090925f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.038036f,0f,0f,0f,0f,0f,-44.717876f,29.07826f,-64.18661f,0f,0f,0f,-573,56.51683f,89.826775f,-56.398975f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.153633f,0f,0f,0f,0f,0f,27.108541f,20.518898f,9.307852f,-787.0f,646.0f,868.0f,374,42.915897f,97.1689f,-47.772182f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.284748f,0f,0f,0f,0f,0f,20.236826f,-61.886883f,39.69663f,-593.0f,-957.0f,1883.0f,-122,67.4109f,24.0008f,3.0519502f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.34123f,0f,0f,0f,0f,0f,44.52196f,31.193577f,19.213053f,366.0f,-175.0f,-564.0f,483,0.10505157f,0.31939638f,-0.71601844f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.396618f,0f,0f,0f,0f,0f,24.713858f,0.48473874f,31.627102f,-65.0f,-248.0f,53.0f,6,57.749065f,-99.12505f,-43.606674f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.90776f,0f,0f,0f,0f,0f,9.039821f,10.344966f,1.2047856f,-594.0f,600.0f,-695.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,45.059803f,0f,0f,0f,0f,0f,-100.0f,13.78864f,93.447365f,0f,0f,0f,2,52.858807f,-55.47657f,64.751175f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-47.687317f,0f,0f,0f,0f,0f,-43.817303f,44.358627f,6.6283236f,0f,0f,0f,1,-0.44543767f,0.57896906f,-0.6737253f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.63607f,0f,0f,0f,0f,0f,100.0f,-63.860172f,-91.034096f,-1739.0f,-1001.0f,545.0f,-3,-0.32376167f,0.16509843f,-0.524164f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.868034f,0f,0f,0f,0f,0f,23.423504f,-37.913406f,80.76902f,812.0f,950.0f,795.0f,-8,-76.86461f,-90.74188f,5.484209f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,50.57414f,0f,0f,0f,0f,0f,-52.041634f,-22.84964f,-63.685593f,-1667.0f,336.0f,-1214.0f,-1431,-0.48048407f,-0.29229096f,0.3903241f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,50.717697f,0f,0f,0f,0f,0f,-30.7722f,12.536161f,-86.51347f,-619.0f,689.0f,42.0f,1310,0.11457788f,0.5067336f,-0.07022057f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.977386f,0f,0f,0f,0f,0f,-13.630413f,63.251713f,-13.494232f,738.0f,-475.0f,-329.0f,-953,17.703814f,-15.40748f,-90.10218f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,58.986946f,0f,0f,0f,0f,0f,-32.119713f,-0.09594083f,-38.46418f,-274.0f,-871.0f,-851.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-60.90804f,0f,0f,0f,0f,0f,27.355423f,-0.42872605f,-8.399134f,0f,0f,0f,418,0.7382856f,0.38610426f,-0.5401414f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.204385f,0f,0f,0f,0f,0f,100.0f,-81.250435f,100.0f,0f,0f,0f,2,-38.32402f,-6.585872f,49.285313f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,62.593105f,0f,0f,0f,0f,0f,100.0f,25.354412f,-100.0f,0f,0f,0f,432,0.017726127f,0.96160114f,-0.27387786f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.60132f,0f,0f,0f,0f,0f,-12.896038f,-52.529617f,5.054812f,495.0f,133.0f,2645.0f,1084,-0.406198f,-0.33130857f,0.25079426f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,66.74329f,0f,0f,0f,0f,0f,33.69765f,18.419033f,39.8844f,0f,0f,0f,1,64.76942f,-7.2741637f,-51.363297f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-67.562874f,0f,0f,0f,0f,0f,-34.80357f,-100.0f,-118.094666f,0f,0f,0f,2,0.025515595f,-0.7519716f,0.1980343f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,70.43419f,0f,0f,0f,0f,0f,77.948204f,25.096655f,39.75607f,0f,0f,0f,565,-39.30406f,9.35812f,71.15451f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-71.13382f,0f,0f,0f,0f,0f,-38.432663f,-79.17611f,56.69147f,0f,0f,0f,1,58.470783f,-81.8098f,-74.61781f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,72.364075f,0f,0f,0f,0f,0f,-71.49133f,-2.355216f,16.724998f,0f,0f,0f,860,-0.39812374f,-0.30299228f,0.7838125f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.461312f,0f,0f,0f,0f,0f,74.397804f,-73.90758f,-44.47136f,191.0f,166.0f,-496.0f,2,39.25195f,62.873924f,-38.82501f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.707891f,0f,0f,0f,0f,0f,41.77142f,48.67862f,-31.296982f,777.0f,904.0f,-620.0f,444,86.411804f,-76.64768f,-3.8840642f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,78.49333f,0f,0f,0f,0f,0f,60.068386f,-13.372643f,60.798958f,866.0f,-428.0f,668.0f,-292,17.533768f,88.390625f,43.60649f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,79.45415f,0f,0f,0f,0f,0f,35.313137f,58.09153f,5.0752225f,-559.0f,297.0f,490.0f,-1515,100.0f,16.389158f,-85.71837f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,79.6717f,0f,0f,0f,0f,0f,-69.86277f,94.34195f,-25.058496f,117.0f,654.0f,-725.0f,433,30.923496f,71.55664f,62.5056f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.09081f,0f,0f,0f,0f,0f,-59.65103f,-3.914815f,3.963076f,75.0f,-667.0f,470.0f,-2407,-3.76585f,71.9516f,14.392945f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-84.798325f,0f,0f,0f,0f,0f,26.70902f,-95.233795f,-93.31279f,0f,0f,0f,-357,-26.337856f,8.456623f,-16.16943f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.08711f,0f,0f,0f,0f,0f,41.15952f,61.767082f,83.33994f,-593.0f,172.0f,-190.0f,-238,-87.3818f,69.09742f,56.017082f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.63634f,0f,0f,0f,0f,0f,-19.720003f,31.495975f,-0.10790896f,-465.0f,965.0f,-316.0f,914,-31.69562f,-20.145248f,-87.63438f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-91.91439f,0f,0f,0f,0f,0f,199.19847f,28.491951f,42.63394f,0f,0f,0f,1,0.8817439f,0.23488832f,0.26736853f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,92.54416f,0f,0f,0f,0f,0f,-4.50119f,38.35307f,-7.192834f,225.0f,-112.0f,-738.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,92.691536f,0f,0f,0f,0f,0f,8.2045355f,-18.381773f,6.472079f,-662.0f,-274.0f,61.0f,90,-45.933884f,-35.938805f,75.0985f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.61603f,0f,0f,0f,0f,0f,-75.054596f,81.18152f,25.230696f,-241.0f,1701.0f,-495.0f,769,-0.4065358f,0.90833586f,0.010481212f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,94.51028f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,94.54943f,0f,0f,0f,0f,0f,114.74813f,-78.16638f,-100.0f,-122.0f,1237.0f,-38.0f,-140,0.42448f,0.3450898f,-0.5781755f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.600815f,0f,0f,0f,0f,0f,-30.458092f,-10.212553f,84.88285f,0f,0f,0f,2,0.5217922f,-0.007182579f,0.64568275f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.98798f,0f,0f,0f,0f,0f,6.1252084f,14.481667f,-48.353153f,542.0f,-699.0f,-164.0f,-756,80.65568f,-69.54981f,-41.808315f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.560165f,0f,0f,0f,0f,0f,54.864758f,50.83279f,-61.47969f,-188.0f,163.0f,-33.0f,-929,51.728954f,-8.102488f,39.46384f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.88542f,0f,0f,0f,0f,0f,-48.407185f,-99.56381f,44.21482f,-45.0f,-524.0f,-41.0f,-284,-30.753504f,4.388657f,-14.62717f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.996025f,0f,0f,0f,0f,0f,-33.657032f,100.0f,62.404957f,752.0f,-70.0f,554.0f,3,70.68236f,-0.093924664f,38.253902f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.217995f,0f,0f,0f,0f,0f,-100.0f,94.94544f,-100.0f,0f,0f,0f,1,-0.6133829f,0.47530878f,-0.77018535f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.920715f,0f,0f,0f,0f,0f,-12.12736f,38.952995f,-30.3109f,322.0f,547.0f,-721.0f,-20,-70.92651f,-99.60534f,-99.6267f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.9224f,0f,0f,0f,0f,0f,-100.0f,-22.080793f,-12.722869f,320.0f,-32.0f,617.0f,-8,0.23084365f,-0.81174934f,-0.5364459f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.93574f,0f,0f,0f,0f,0f,-99.94937f,-100.0f,-49.353764f,-540.0f,599.0f,732.0f,-1593,-0.20933822f,-0.5103687f,0.8340871f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.98615f,0f,0f,0f,0f,0f,-16.29653f,-23.948597f,100.0f,1172.0f,-476.0f,77.0f,1747,0.06612123f,-0.46328562f,0.0129041f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.99114f,0f,0f,0f,0f,0f,27.818024f,100.0f,-70.06702f,810.0f,-394.0f,-507.0f,-1,-0.3022347f,1.7018254f,0.8096462f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.99981f,0f,0f,0f,0f,0f,-8.626112f,-35.764286f,26.834705f,-1232.0f,-54.0f,-468.0f,6,-0.04306025f,-1.0096159f,0.09773734f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-12.654502f,-63.28641f,53.9444f,0f,0f,0f,-1326,-0.87050426f,-0.08063458f,-0.43645316f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,42.27743f,-11.347507f,-11.883199f,0f,0f,0f,699,-73.10282f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,52.70577f,100.0f,-91.13597f,0f,0f,0f,1,29.677956f,-11.604489f,83.10638f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,54.583897f,42.222595f,57.99377f,0f,0f,0f,1,-4.135879f,9.689845f,-7.363225f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-73.36719f,-78.326004f,-163.34933f,-1173.0f,934.0f,-528.0f,2,100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-80.750374f,25.245386f,-38.917362f,0f,0f,0f,1,87.50306f,-24.184929f,49.254925f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,91.52701f,73.555824f,-44.628372f,895.0f,-783.0f,545.0f,4,94.83298f,-60.73343f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,847,-100.0f,40.48913f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,3.0498664f,0f,0f,0f,0f,0f,86.4802f,-12.89046f,2.6221228f,0f,0f,0f,117,-98.94325f,67.32448f,30.597067f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,100.0f,0f,0f,0f,0f,0f,-26.260677f,100.0f,88.09951f,0f,0f,0f,-1296,100.0f,-100.0f,12.146435f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,100.0f,0f,0f,0f,0f,0f,4.304894f,100.0f,100.0f,0f,0f,0f,-576,0.090626836f,-0.99144375f,0.09394722f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,27.788504f,0f,0f,0f,0f,0f,-26.930079f,-84.605965f,-17.592329f,0f,0f,0f,-1,44.43624f,82.84613f,-86.9487f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,65.05797f,0f,0f,0f,0f,0f,48.622864f,84.62776f,53.043293f,0f,0f,0f,-222,0.4271239f,-0.43002033f,-0.17225055f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,-89.946945f,0f,0f,0f,0f,0f,64.439285f,-88.767426f,100.0f,0f,0f,0f,-449,-0.0041026603f,0.13852277f,0.017607562f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,11.430027f,0f,0f,0f,0f,0f,0f,0f,4.6904716f,-7.014896f,-12.536f,1194.0f,717.0f,36.0f,5,-100.0f,-35.71096f,30.672352f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,16.863396f,0f,-86.45987f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,100.0f,-96.31323f,60.67874f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,1.7985643f,0f,0f,0f,0f,0f,0f,0f,38.404205f,-9.29385f,3.019279f,-45.0f,286.0f,-877.0f,-371,-0.47919947f,0.7389445f,-0.47363374f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,1865.0f,0f,479.0f,0f,0f,0f,0f,0f,191.0f,125.0f,-8.0f,497.0f,-756.0f,3.0f,884,-69.914f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-32.501186f,0f,0.0f,0f,0f,0f,0f,0f,52.87929f,55.88373f,100.0f,0f,0f,0f,1508,-0.07147284f,-0.8169124f,-0.5723161f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,34.951992f,0f,0f,0f,0f,0f,0f,0f,21.999428f,5.3091993f,-87.18841f,379.0f,316.0f,-966.0f,189,0.5278323f,-0.08765412f,0.2958983f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,4.424882f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,494.0f,-987.0f,709.0f,-163,-50.241642f,100.0f,-14.316989f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,4.7747107f,0f,0f,0f,0f,0f,0f,0f,100.0f,-35.996628f,67.38962f,-1182.0f,104.0f,1347.0f,-823,-0.85255814f,0.34904367f,0.38898996f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-72.21673f,0f,0.0f,0f,0f,0f,0f,0f,-83.91835f,60.841827f,100.0f,0f,0f,0f,2,20.878119f,-38.92972f,-62.81157f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,87.77473f,0f,0f,0f,0f,0f,0f,0f,100.0f,-34.496876f,16.43518f,-1814.0f,-256.0f,916.0f,-345,0.34881285f,1.6410416f,1.3221112f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1010.0f,338.0f,0f,-48.0f,0f,0f,0f,0f,0f,-129.0f,-15.0f,630.0f,308.0f,308.0f,253.0f,522,-98.43068f,-74.3283f,-21.92498f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1011.0f,-408.0f,0f,253.0f,0f,0f,0f,0f,0f,-1561.0f,-1234.0f,-401.0f,177.0f,-686.0f,-1461.0f,385,147.20016f,100.0f,-50.84129f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1030.0f,118.0f,0f,159.0f,0f,0f,0f,0f,0f,-295.0f,293.0f,53.0f,669.0f,532.0f,837.0f,488,0.42225197f,-0.4854968f,0.10897066f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1032.0f,44.0f,0f,42.0f,0f,0f,0f,0f,0f,-129.0f,-165.0f,-17.0f,813.0f,-574.0f,-748.0f,610,90.08317f,-16.821463f,169.11102f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-104.0f,-640.0f,0f,822.0f,0f,0f,0f,0f,0f,-819.0f,171.0f,-878.0f,-117.0f,821.0f,-123.0f,63,74.4188f,18.72522f,-36.389126f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1046.0f,-902.0f,0f,1294.0f,0f,0f,0f,0f,0f,836.0f,9.0f,373.0f,120.0f,1344.0f,1111.0f,729,0.11629192f,-0.66423124f,-0.24461651f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-105.0f,840.0f,294.0f,1687.0f,0f,0f,0f,0f,0f,351.0f,-986.0f,-364.0f,468.0f,703.0f,-327.0f,890,60.867023f,19.539051f,5.7659893f,-8.175377f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1052.0f,350.0f,0f,1849.0f,0f,0f,0f,0f,0f,150.0f,291.0f,228.0f,-1008.0f,333.0f,238.0f,375,-71.00067f,-2.2400572f,-22.48657f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1055.0f,1.0f,0f,558.0f,0f,0f,0f,0f,0f,-1640.0f,981.0f,1643.0f,-592.0f,230.0f,-1161.0f,-1900,0.48352265f,-0.2155154f,-0.42758667f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1059.0f,468.0f,0f,142.0f,0f,0f,0f,0f,0f,557.0f,865.0f,-1409.0f,1066.0f,963.0f,-1062.0f,-864,0.18197569f,0.11836747f,0.8067997f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1074.0f,-215.0f,0f,256.0f,0f,0f,0f,0f,0f,-945.0f,672.0f,-338.0f,834.0f,1061.0f,-1220.0f,-440,0.34709924f,-0.15874413f,-0.17512658f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,109.0f,-457.0f,0f,576.0f,0f,0f,0f,0f,0f,393.0f,-222.0f,443.0f,-250.0f,-91.0f,463.0f,-856,100.0f,11.253778f,-85.669464f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1095.0f,-132.0f,0f,67.0f,0f,0f,0f,0f,0f,-1757.0f,894.0f,-403.0f,-258.0f,-877.0f,-845.0f,523,-0.01885623f,-0.24689785f,0.9583473f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,0.0f,0f,197.0f,0f,0f,0f,0f,0f,620.0f,1086.0f,1206.0f,588.0f,3.0f,-903.0f,-10,-100.0f,-100.0f,58.208733f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1049.0f,0f,498.0f,0f,0f,0f,0f,0f,60.0f,-681.0f,-558.0f,-236.0f,493.0f,-629.0f,-10,26.276356f,-31.450716f,46.510365f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1086.0f,0f,-97.0f,0f,0f,0f,0f,0f,111.0f,-212.0f,296.0f,-42.0f,518.0f,1243.0f,-471,90.44241f,-32.074482f,-56.888336f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1.0f,0f,815.0f,0f,0f,0f,0f,0f,-392.0f,-98.0f,387.0f,-406.0f,23.0f,-106.0f,-465,0.014640463f,-0.33234486f,-2.2478805f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-1210.0f,0f,1447.0f,0f,0f,0f,0f,0f,761.0f,-927.0f,-1429.0f,464.0f,708.0f,-794.0f,-501,34.513695f,100.0f,3.892166f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1230.0f,0f,254.0f,0f,0f,0f,0f,0f,-141.0f,895.0f,913.0f,-776.0f,-182.0f,940.0f,-602,-82.229515f,70.662926f,-81.968994f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-1695.0f,0f,1141.0f,0f,0f,0f,0f,0f,-1196.0f,998.0f,-549.0f,1055.0f,594.0f,-944.0f,7,51.03097f,-32.474224f,57.76102f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1787.0f,0f,241.0f,0f,0f,0f,0f,0f,72.0f,16.0f,-55.0f,836.0f,1343.0f,1074.0f,3336,-81.26105f,63.851086f,-87.78668f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1920.0f,0f,0.0f,0f,0f,0f,0f,0f,424.0f,745.0f,361.0f,-636.0f,655.0f,-115.0f,265,-109.22155f,-100.0f,90.20294f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1934.0f,0f,1058.0f,0f,0f,0f,0f,0f,467.0f,468.0f,592.0f,282.0f,759.0f,-451.0f,18,100.0f,100.0f,-2.9492917f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,2422.0f,0f,-812.0f,0f,0f,0f,0f,0f,-1024.0f,2240.0f,181.0f,-541.0f,-351.0f,348.0f,1330,0.028775157f,0.043687895f,-1.0178138f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-244.0f,0f,437.0f,0f,0f,0f,0f,0f,708.0f,-505.0f,-604.0f,209.0f,963.0f,-560.0f,-622,56.754322f,38.48957f,101.811584f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,399.0f,0f,-2.0f,0f,0f,0f,0f,0f,-179.0f,-1002.0f,655.0f,-610.0f,185.0f,-79.0f,-698,0.8413482f,-0.00989206f,-0.5404095f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,418.0f,310.0f,328.0f,0f,0f,0f,0f,0f,-908.0f,394.0f,-1303.0f,-1275.0f,69.0f,-18.0f,814,-0.23107742f,0.44935897f,0.8629483f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,444.0f,1192.0f,2.0f,0f,0f,0f,0f,0f,-297.0f,-1175.0f,-1117.0f,535.0f,-846.0f,8.0f,8,73.490005f,-61.678688f,-36.849186f,-77.516304f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,498.0f,0f,-3.0f,0f,0f,0f,0f,0f,-386.0f,94.0f,-521.0f,644.0f,-431.0f,89.0f,-662,28.561604f,81.63523f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,503.0f,0f,243.0f,0f,0f,0f,0f,0f,-921.0f,-633.0f,921.0f,315.0f,-922.0f,403.0f,333,-88.40245f,77.304276f,-35.27155f,0f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,704.0f,-72.0f,-1193.0f,0f,0f,0f,0f,0f,-1224.0f,-2639.0f,-1224.0f,-1361.0f,-500.0f,-914.0f,4,-16.271175f,3.0597165f,26.096552f,57.012054f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,775.0f,0f,362.0f,0f,0f,0f,0f,0f,796.0f,460.0f,1258.0f,-109.0f,-569.0f,-1123.0f,1830,0.18822289f,-0.8187947f,-0.521622f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,810.0f,0f,-616.0f,0f,0f,0f,0f,0f,-547.0f,-495.0f,448.0f,775.0f,391.0f,-359.0f,620,-82.61451f,159.85551f,-23.588886f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,845.0f,0f,-607.0f,0f,0f,0f,0f,0f,-1594.0f,468.0f,-1690.0f,-910.0f,-90.0f,589.0f,777,16.507818f,76.10532f,79.22174f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-862.0f,0f,105.0f,0f,0f,0f,0f,0f,738.0f,-206.0f,-714.0f,-985.0f,-319.0f,395.0f,379,-114.43108f,18.19961f,103.12696f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-11.106785f,-86.80734f,0f,0.0f,0f,0f,0f,0f,0f,68.64111f,8.009217f,-47.675724f,0f,0f,0f,1748,-0.35066307f,0.91373485f,-0.20524146f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1111.0f,-673.0f,0f,186.0f,0f,0f,0f,0f,0f,868.0f,-479.0f,32.0f,718.0f,-1911.0f,1183.0f,-426,-0.5865614f,0.75872284f,0.28334677f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1115.0f,346.0f,0f,1738.0f,0f,0f,0f,0f,0f,254.0f,-1129.0f,3241.0f,328.0f,3619.0f,2287.0f,817,0.9775955f,-0.1373523f,-0.15952787f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1118.0f,1060.0f,0f,-735.0f,0f,0f,0f,0f,0f,1199.0f,-1032.0f,-492.0f,503.0f,-494.0f,-842.0f,-858,0.46878162f,0.8568802f,-0.21447642f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1118.0f,3080.0f,0f,246.0f,0f,0f,0f,0f,0f,4.0f,-722.0f,766.0f,-418.0f,-1066.0f,-910.0f,1175,-48.034603f,98.711395f,93.29123f,0f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1129.0f,800.0f,-175.0f,-1808.0f,0f,0f,0f,0f,0f,206.0f,152.0f,1860.0f,-569.0f,758.0f,463.0f,-69,-0.6505074f,0.27884066f,-0.7064616f,-40.62122f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1130.0f,835.0f,-312.0f,302.0f,0f,0f,0f,0f,0f,-93.0f,-1086.0f,-1184.0f,466.0f,-637.0f,278.0f,1434,-0.06492511f,0.16032088f,-0.0030229373f,0f,-69.07911f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.333628f,0.0f,0f,0f,0f,0f,0f,0f,0f,-99.32059f,78.04338f,-54.830204f,0f,0f,0f,-276,-0.064836875f,-0.37485328f,0.90762615f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1138.0f,-1506.0f,0f,1349.0f,0f,0f,0f,0f,0f,-99.0f,210.0f,537.0f,-1257.0f,853.0f,-565.0f,817,0.62550807f,0.71430564f,-0.16402027f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-115.0f,50.0f,0f,1101.0f,0f,0f,0f,0f,0f,-841.0f,-236.0f,-492.0f,-291.0f,-1089.0f,1019.0f,-435,0.12803477f,0.07808617f,-0.19259419f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,116.0f,903.0f,0f,345.0f,0f,0f,0f,0f,0f,-1515.0f,306.0f,-872.0f,1409.0f,-52.0f,891.0f,-86,0.51199526f,-0.78808695f,-0.34173062f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-116.124374f,0f,0f,0f,0f,0f,0f,0f,0f,54.86189f,-98.014694f,57.677063f,0f,0f,0f,1,33.966866f,11.290054f,-35.095924f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1165.0f,-2.0f,0f,197.0f,0f,0f,0f,0f,0f,-686.0f,92.0f,1365.0f,631.0f,632.0f,451.0f,-515,100.0f,49.279774f,-87.418274f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1178.0f,0.0f,0f,387.0f,0f,0f,0f,0f,0f,-1836.0f,1697.0f,-1149.0f,238.0f,-1760.0f,-843.0f,2,31.043955f,-9.711086f,12.262104f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1183.0f,-288.0f,0f,1056.0f,0f,0f,0f,0f,0f,138.0f,-318.0f,-728.0f,1640.0f,-206.0f,401.0f,36,1.7672981f,0.07248745f,0.4252214f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,118.36726f,-2.6437867f,0f,-73.78667f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,26.44373f,3.9381928f,-49.42789f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-119.0f,409.0f,-828.0f,-546.0f,0f,0f,0f,0f,0f,-838.0f,531.0f,-599.0f,-705.0f,-897.0f,-773.0f,272,81.40809f,70.41532f,9.307912f,-71.60853f,0f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1196.0f,1103.0f,0f,782.0f,0f,0f,0f,0f,0f,-716.0f,-123.0f,91.0f,135.0f,-930.0f,300.0f,1363,0.21289846f,0.38523948f,-0.47125813f,0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1196.0f,-728.0f,0f,2678.0f,0f,0f,0f,0f,0f,745.0f,-567.0f,-1601.0f,930.0f,-2973.0f,-815.0f,1287,0.40449718f,0.89296454f,0.010991409f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1203.0f,-5.0f,0f,2061.0f,0f,0f,0f,0f,0f,-69.0f,-579.0f,934.0f,-741.0f,1155.0f,663.0f,9,62.472595f,-21.322968f,-13.084414f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1218.0f,2560.0f,0f,2217.0f,0f,0f,0f,0f,0f,192.0f,-824.0f,620.0f,902.0f,-368.0f,-768.0f,-885,-95.665474f,-89.42507f,-89.80031f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.2244195f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,-1,-0.6872209f,0.037866864f,-0.6099296f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1225.0f,217.0f,0f,775.0f,0f,0f,0f,0f,0f,-627.0f,2049.0f,-1295.0f,-217.0f,-777.0f,194.0f,-26,-0.5481728f,-0.19875738f,0.027677054f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1225.0f,-669.0f,0f,1161.0f,0f,0f,0f,0f,0f,650.0f,-287.0f,-221.0f,-182.0f,-506.0f,121.0f,-574,-140.28474f,82.877525f,-46.961426f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1229.0f,-3.0f,0f,142.0f,0f,0f,0f,0f,0f,365.0f,-698.0f,598.0f,-43.0f,-664.0f,-751.0f,1735,-126.08683f,-1.1957175f,17.041796f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1229.0f,56.0f,0f,-1408.0f,0f,0f,0f,0f,0f,-2253.0f,1255.0f,-334.0f,1329.0f,-176.0f,-508.0f,1578,0.33047396f,0.19212207f,0.92405415f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-123.0f,420.0f,273.0f,-953.0f,0f,0f,0f,0f,0f,987.0f,94.0f,-936.0f,-764.0f,-846.0f,-962.0f,149,94.6067f,81.82974f,-42.621017f,-54.419666f,15.9332485f,-37.333427f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,124.0f,275.0f,0f,842.0f,0f,0f,0f,0f,0f,-889.0f,-773.0f,-686.0f,358.0f,597.0f,-123.0f,133,-16.016014f,74.3326f,-63.004177f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-124.0f,-880.0f,0f,1361.0f,0f,0f,0f,0f,0f,317.0f,133.0f,339.0f,725.0f,-108.0f,649.0f,-72,-0.72253454f,-0.5631373f,-0.20764625f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1257.0f,1901.0f,0f,-3.0f,0f,0f,0f,0f,0f,359.0f,-566.0f,1280.0f,195.0f,-448.0f,-1192.0f,-630,-0.38037923f,0.92469734f,0.015700584f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1280.0f,-134.0f,0f,1298.0f,0f,0f,0f,0f,0f,-1009.0f,1045.0f,113.0f,-1408.0f,79.0f,1726.0f,670,0.6887005f,0.42306176f,0.58600533f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,12.805165f,-29.102146f,0f,0f,0f,0f,0f,0f,0f,-19.136602f,-35.26038f,29.444876f,0f,0f,0f,-1896,0.19206992f,-0.5446914f,-0.5274418f,0f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-128.0f,150.0f,-697.0f,308.0f,0f,0f,0f,0f,0f,-957.0f,-299.0f,404.0f,1024.0f,-1145.0f,-769.0f,-775,-3.4213593f,-0.60025036f,-8.548801f,-33.968452f,-13.041457f,-6.845847f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,128.0f,-813.0f,0f,939.0f,0f,0f,0f,0f,0f,-126.0f,368.0f,-855.0f,-517.0f,346.0f,-553.0f,6,12.876132f,-27.949295f,-0.15540145f,0f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1288.0f,612.0f,0f,-935.0f,0f,0f,0f,0f,0f,122.0f,-627.0f,433.0f,-878.0f,1062.0f,-110.0f,-672,-0.93705297f,0.23727706f,0.25618604f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,129.0f,594.0f,0f,344.0f,0f,0f,0f,0f,0f,-252.0f,2129.0f,-462.0f,63.0f,683.0f,-501.0f,-521,-0.78901625f,-0.3110569f,-0.5223988f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1291.0f,1143.0f,0f,63.0f,0f,0f,0f,0f,0f,-366.0f,-457.0f,-160.0f,-214.0f,277.0f,-301.0f,-410,1.0243438f,-0.41672486f,1.7596419f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,131.25014f,-9.6826935f,0f,0f,0f,0f,0f,0f,0f,100.0f,-179.96014f,-74.69948f,0f,0f,0f,1,54.8935f,96.66861f,59.271652f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1313.0f,-934.0f,0f,557.0f,0f,0f,0f,0f,0f,-182.0f,911.0f,-1178.0f,-999.0f,227.0f,329.0f,-8,-54.53317f,-16.184744f,65.47869f,0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.151143f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,68.84683f,-19.900112f,15.714173f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,132.54002f,-57.75103f,0f,-158.72711f,0f,0f,0f,0f,0f,-19.377563f,11.064149f,99.46825f,0f,0f,0f,1,51.91066f,36.42138f,-87.77914f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1326.0f,-297.0f,0f,1412.0f,0f,0f,0f,0f,0f,532.0f,-1160.0f,518.0f,-953.0f,396.0f,488.0f,-11,61.309f,100.0f,30.507942f,0f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1329.0f,1149.0f,0f,1700.0f,0f,0f,0f,0f,0f,53.0f,-1059.0f,-418.0f,-569.0f,-91.0f,158.0f,218,0.010104541f,0.050528347f,-0.0027961284f,0f,0f,0f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,133.0f,0.0f,0f,757.0f,0f,0f,0f,0f,0f,-149.0f,275.0f,-589.0f,256.0f,-307.0f,138.0f,629,65.20179f,81.37765f,133.4869f,0f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-13.365947f,-20.02851f,0f,-100.0f,0f,0f,0f,0f,0f,40.35564f,86.66761f,17.79509f,0f,0f,0f,-2,7.908197f,-8.068744f,-39.481102f,0f,0f,0f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-138.0f,-746.0f,0f,123.0f,0f,0f,0f,0f,0f,940.0f,750.0f,134.0f,514.0f,-273.0f,54.0f,418,-22.226679f,-97.23863f,25.251026f,0f,0f,0f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-140.0f,-633.0f,0f,255.0f,0f,0f,0f,0f,0f,-722.0f,620.0f,-69.0f,-46.0f,640.0f,-304.0f,534,-9.525587f,-29.156668f,-68.24975f,0f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.0f,202.0f,0f,897.0f,0f,0f,0f,0f,0f,2101.0f,1343.0f,-1939.0f,21.0f,620.0f,883.0f,582,-0.1837298f,-0.25756273f,0.04064441f,0f,0f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1410.0f,-577.0f,0f,4.0f,0f,0f,0f,0f,0f,-104.0f,-635.0f,-237.0f,423.0f,-104.0f,-548.0f,130,84.69156f,-34.720615f,120.63337f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1435.0f,17.0f,0f,3.0f,0f,0f,0f,0f,0f,700.0f,855.0f,-871.0f,193.0f,594.0f,667.0f,166,-0.098548174f,-0.25827244f,-0.3289423f,0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1440.0f,413.0f,0f,0.0f,0f,0f,0f,0f,0f,-546.0f,-241.0f,56.0f,853.0f,647.0f,289.0f,38,33.701706f,-53.116653f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-145.0f,396.0f,0f,14.0f,0f,0f,0f,0f,0f,502.0f,-141.0f,-1183.0f,-513.0f,-441.0f,1250.0f,18,-42.7681f,96.43043f,-74.236145f,0f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1451.0f,3.0f,0f,1387.0f,0f,0f,0f,0f,0f,966.0f,866.0f,1001.0f,-1729.0f,-1448.0f,1297.0f,-2,-12.232169f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1466.0f,128.0f,0f,1967.0f,0f,0f,0f,0f,0f,198.0f,728.0f,664.0f,-423.0f,1570.0f,-548.0f,-329,-0.3512836f,-1.9762763f,2.2715085f,0f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,147.0f,992.0f,0f,2462.0f,0f,0f,0f,0f,0f,169.0f,-308.0f,-236.0f,0.0f,-448.0f,153.0f,-327,91.825775f,31.613676f,24.49807f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,147.79573f,0.0f,0f,-19.818796f,0f,0f,0f,0f,0f,-47.234257f,-21.865763f,32.02501f,0f,0f,0f,1,67.14459f,-68.91567f,-38.124664f,0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-148.0f,-742.0f,0f,1593.0f,0f,0f,0f,0f,0f,-607.0f,173.0f,-1766.0f,-826.0f,-43.0f,-1348.0f,427,0.5779788f,-0.539537f,-0.24346048f,0f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,15.0f,-217.0f,0f,436.0f,0f,0f,0f,0f,0f,-888.0f,-79.0f,271.0f,-305.0f,685.0f,-803.0f,-3,-7.8443556f,17.438944f,59.129986f,0f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,15.0f,-2449.0f,0f,585.0f,0f,0f,0f,0f,0f,147.0f,-20.0f,15.0f,419.0f,787.0f,-2252.0f,-763,-0.13899697f,-0.61139315f,-0.28935975f,0f,0f,0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.0f,676.0f,725.0f,-1475.0f,0f,0f,0f,0f,0f,-732.0f,743.0f,391.0f,893.0f,309.0f,730.0f,-1,89.64174f,-27.700367f,-50.564117f,2.1414423f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1512.0f,589.0f,0f,891.0f,0f,0f,0f,0f,0f,985.0f,-954.0f,-873.0f,-418.0f,-1044.0f,669.0f,685,-100.0f,-85.55841f,-19.332502f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1523.0f,-1484.0f,0f,708.0f,0f,0f,0f,0f,0f,371.0f,-1693.0f,-1835.0f,740.0f,-825.0f,227.0f,11,92.358315f,39.621216f,63.37926f,0f,0f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.278694f,0.0f,0f,-27.505606f,0f,0f,0f,0f,0f,-31.71982f,118.794174f,19.396463f,0f,0f,0f,1,-30.33255f,-14.746391f,-57.29665f,0f,0f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.540744E-33f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,99.22035f,-40.72936f,-3.856821f,0f,0f,0f,1,-90.36776f,83.95802f,35.098667f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,15.529354f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,99.53311f,23.98987f,73.44303f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1560.0f,1055.0f,0f,971.0f,0f,0f,0f,0f,0f,-801.0f,883.0f,213.0f,460.0f,1093.0f,-409.0f,637,-0.7870875f,-14.778093f,58.303284f,0f,0f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-156.0f,-822.0f,0f,109.0f,0f,0f,0f,0f,0f,-454.0f,219.0f,-425.0f,-881.0f,-1436.0f,201.0f,413,-2.5875547f,-85.43876f,2.917023f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1562.0f,0.0f,0f,205.0f,0f,0f,0f,0f,0f,2021.0f,858.0f,-1608.0f,714.0f,-152.0f,-607.0f,5,-100.0f,-76.26907f,-150.4391f,0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1572.0f,-243.0f,0f,1326.0f,0f,0f,0f,0f,0f,256.0f,-163.0f,13.0f,1167.0f,1738.0f,-1145.0f,710,0.03537966f,0.08369032f,-0.002326154f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1573.0f,1076.0f,0f,791.0f,0f,0f,0f,0f,0f,-504.0f,-112.0f,145.0f,328.0f,-512.0f,-989.0f,-263,8.333799f,19.64874f,-39.021477f,0f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1583.0f,908.0f,0f,330.0f,0f,0f,0f,0f,0f,-1920.0f,-830.0f,1327.0f,1700.0f,-79.0f,67.0f,-668,0.035696335f,0.99083996f,0.13023807f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-159.0f,275.0f,0f,255.0f,0f,0f,0f,0f,0f,-749.0f,-309.0f,-76.0f,-1219.0f,423.0f,2124.0f,221,-10.159613f,34.07316f,-38.40803f,0f,0f,0f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,160.0f,2015.0f,0f,1639.0f,0f,0f,0f,0f,0f,-202.0f,138.0f,-1038.0f,1728.0f,947.0f,543.0f,-465,-0.5261385f,-0.13098256f,0.5518001f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1617.0f,2045.0f,0f,1.0f,0f,0f,0f,0f,0f,246.0f,-901.0f,-1432.0f,-907.0f,485.0f,720.0f,131,-0.21469428f,0.100474715f,0.95664465f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,16.192148f,-69.988914f,0f,78.32772f,0f,0f,0f,0f,0f,-55.772255f,78.00689f,6.0639725f,0f,0f,0f,-968,-67.82132f,-99.38373f,-64.99117f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1639.0f,-737.0f,0f,532.0f,0f,0f,0f,0f,0f,-483.0f,-319.0f,-1780.0f,-180.0f,255.0f,-1115.0f,1219,0.8885686f,0.08827054f,0.026159223f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,164.54948f,-99.46479f,0f,82.02732f,0f,0f,0f,0f,0f,-39.132168f,100.0f,-0.47202408f,0f,0f,0f,1,100.0f,-100.0f,24.585749f,0f,0f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-16.484285f,0.0f,0f,84.16833f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,36.562233f,97.58025f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1658.0f,-526.0f,0f,1257.0f,0f,0f,0f,0f,0f,39.0f,174.0f,146.0f,643.0f,20.0f,-178.0f,-1973,-0.15035057f,-0.6310495f,-0.9234564f,0f,0f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1658.0f,904.0f,-266.0f,-1034.0f,0f,0f,0f,0f,0f,-741.0f,306.0f,871.0f,-1119.0f,-348.0f,345.0f,-1179,0.310677f,0.926531f,-0.13597499f,55.057804f,91.15811f,0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,166.0f,306.0f,0f,470.0f,0f,0f,0f,0f,0f,-378.0f,-768.0f,325.0f,-990.0f,132.0f,-840.0f,-728,100.0f,-34.959732f,-102.314896f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1664.0f,0.0f,0f,767.0f,0f,0f,0f,0f,0f,-879.0f,-1088.0f,-179.0f,-120.0f,115.0f,-109.0f,-1825,198.18002f,-87.08159f,-42.469975f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1685.0f,-1510.0f,0f,599.0f,0f,0f,0f,0f,0f,501.0f,-557.0f,-298.0f,-406.0f,-45.0f,-598.0f,-1306,-0.92057127f,0.086830124f,-1.3851f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1695.0f,0.0f,0f,1692.0f,0f,0f,0f,0f,0f,535.0f,493.0f,269.0f,-348.0f,-1390.0f,435.0f,-1,-111.60133f,-57.378803f,-25.367683f,0f,0f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1708.0f,1024.0f,0f,869.0f,0f,0f,0f,0f,0f,56.0f,-946.0f,-254.0f,-740.0f,77.0f,-450.0f,-237,63.628197f,96.90393f,0.44515023f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,171.0f,-60.0f,626.0f,581.0f,0f,0f,0f,0f,0f,-697.0f,322.0f,520.0f,260.0f,-908.0f,952.0f,-735,38.6999f,11.659254f,78.55247f,83.4538f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,17.296661f,-64.57492f,0f,0.0f,0f,0f,0f,0f,0f,-20.532906f,30.476332f,35.947323f,0f,0f,0f,-847,7.973255f,-89.74144f,-25.249996f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-173.0f,1107.0f,-2118.0f,5.0f,0f,0f,0f,0f,0f,1407.0f,-756.0f,-1259.0f,265.0f,-1147.0f,-745.0f,2,-100.0f,44.914814f,-78.2262f,100.0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,17.313839f,-53.143612f,0f,0f,0f,0f,0f,0f,0f,-59.287853f,-99.979164f,88.30323f,0f,0f,0f,-1476,-0.119702406f,0.14650765f,-0.9819403f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-177.0f,853.0f,0f,2.0f,0f,0f,0f,0f,0f,-1347.0f,455.0f,547.0f,866.0f,-980.0f,-144.0f,1402,54.41901f,10.00585f,-146.85355f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1795.0f,-1059.0f,0f,353.0f,0f,0f,0f,0f,0f,126.0f,616.0f,167.0f,459.0f,-1210.0f,-704.0f,233,0.6566323f,-0.034478247f,-0.36824593f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,18.0f,-1239.0f,0f,1026.0f,0f,0f,0f,0f,0f,11.0f,-572.0f,847.0f,-4801.0f,-1332.0f,-839.0f,7,-100.0f,-47.26837f,-57.97808f,0f,0f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1819.0f,110.0f,0f,253.0f,0f,0f,0f,0f,0f,260.0f,400.0f,-628.0f,187.0f,-1002.0f,-567.0f,-525,93.450775f,37.06767f,62.31103f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,182.0f,1613.0f,0f,586.0f,0f,0f,0f,0f,0f,-329.0f,286.0f,215.0f,-698.0f,-69.0f,-965.0f,2745,53.72933f,100.0f,-51.281933f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1831.0f,874.0f,-1394.0f,-1562.0f,0f,0f,0f,0f,0f,1084.0f,1323.0f,-645.0f,-538.0f,1239.0f,194.0f,-719,0.0996652f,-0.34685466f,-0.5138259f,-53.35407f,-69.07951f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1851.0f,562.0f,0f,915.0f,0f,0f,0f,0f,0f,-1145.0f,-958.0f,-958.0f,-527.0f,55.0f,574.0f,869,66.81621f,-32.194874f,-47.65954f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1866.0f,227.0f,0f,1180.0f,0f,0f,0f,0f,0f,502.0f,902.0f,823.0f,-1396.0f,-21.0f,255.0f,1100,-6.253095f,-0.013447965f,3.8288906f,0f,0f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1870.0f,996.0f,0f,2395.0f,0f,0f,0f,0f,0f,-1094.0f,-185.0f,-99.0f,-146.0f,872.0f,-17.0f,-627,-0.1444747f,1.3997664f,-1.0192069f,0f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1895.0f,874.0f,0f,535.0f,0f,0f,0f,0f,0f,-244.0f,873.0f,-390.0f,633.0f,750.0f,-1175.0f,353,-1.0875796f,0.87012494f,2.628177f,0f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-19.0f,-1664.0f,0f,1790.0f,0f,0f,0f,0f,0f,381.0f,-87.0f,165.0f,-80.0f,-377.0f,-14.0f,28,-49.335308f,67.06397f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-191.0f,3355.0f,0f,1202.0f,0f,0f,0f,0f,0f,-423.0f,-1969.0f,1073.0f,-902.0f,-1136.0f,-371.0f,1192,-0.76906216f,0.2200811f,-0.39488015f,0f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1917.0f,-1454.0f,0f,827.0f,0f,0f,0f,0f,0f,-37.0f,17.0f,-13.0f,-714.0f,-1544.0f,13.0f,-1124,0.22624499f,-0.85870844f,0.18900476f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1936.0f,161.0f,-681.0f,263.0f,0f,0f,0f,0f,0f,-10.0f,-57.0f,-6.0f,-1969.0f,428.0f,-638.0f,369,-100.0f,20.170258f,-15.009611f,-48.212704f,100.0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-195.0f,283.0f,-579.0f,-489.0f,0f,0f,0f,0f,0f,-501.0f,685.0f,580.0f,355.0f,-23.0f,338.0f,-339,96.26582f,-40.409f,65.940025f,-2.0879614f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1951.0f,-656.0f,0f,838.0f,0f,0f,0f,0f,0f,507.0f,-143.0f,1004.0f,99.0f,-274.0f,-89.0f,-751,-0.12969407f,0.19120504f,0.054015324f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1980.0f,1618.0f,0f,240.0f,0f,0f,0f,0f,0f,-1213.0f,-2385.0f,-452.0f,-116.0f,804.0f,385.0f,1625,-0.08929931f,0.20137295f,-0.46114954f,0f,0f,0f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1985.0f,-609.0f,0f,252.0f,0f,0f,0f,0f,0f,483.0f,1204.0f,-18.0f,-1440.0f,1626.0f,-1623.0f,-560,0.02493421f,-0.16402672f,-0.3186312f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-20.046494f,-100.0f,0f,98.23793f,0f,0f,0f,0f,0f,2.469233f,-61.11616f,66.56042f,0f,0f,0f,2,-100.0f,39.695427f,8.658198f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2014.0f,761.0f,0f,160.0f,0f,0f,0f,0f,0f,613.0f,-571.0f,-142.0f,328.0f,491.0f,-558.0f,-546,0.066997886f,-0.2222753f,1.2290637f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-20.203232f,42.269135f,0f,0f,0f,0f,0f,0f,0f,2.4154892f,-38.966713f,4.834074f,-845.0f,8.0f,-477.0f,1840,0.013296159f,-0.077668816f,-0.6392264f,0f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-202.0f,876.0f,0f,248.0f,0f,0f,0f,0f,0f,-550.0f,-818.0f,569.0f,-1089.0f,279.0f,-536.0f,-894,-149.87238f,100.0f,-7.362017f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,204.0f,338.0f,0f,912.0f,0f,0f,0f,0f,0f,274.0f,-506.0f,915.0f,-195.0f,-821.0f,-206.0f,-23,24.955061f,-87.69413f,-59.479794f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-204.0f,-40.0f,330.0f,-614.0f,0f,0f,0f,0f,0f,398.0f,-781.0f,-823.0f,904.0f,700.0f,-27.0f,-278,24.738235f,25.506483f,-77.33626f,-60.574486f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2053.0f,-2424.0f,0f,1129.0f,0f,0f,0f,0f,0f,-861.0f,-12.0f,164.0f,-176.0f,379.0f,-878.0f,596,-0.22334394f,-0.23807116f,-1.6518518f,0f,0f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2076.0f,613.0f,0f,255.0f,0f,0f,0f,0f,0f,968.0f,-44.0f,-316.0f,133.0f,-59.0f,-747.0f,677,-0.58714885f,-57.816208f,6.25175f,0f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2097.0f,961.0f,0f,871.0f,0f,0f,0f,0f,0f,-531.0f,-971.0f,-675.0f,619.0f,-182.0f,-224.0f,-1287,0.36271247f,-0.43795815f,0.3446771f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-1.0f,0f,238.0f,0f,0f,0f,0f,0f,-940.0f,-253.0f,1374.0f,1428.0f,-1731.0f,1089.0f,1,79.56237f,-149.31224f,-86.21789f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,164.0f,0f,216.0f,0f,0f,0f,0f,0f,201.0f,917.0f,-334.0f,-355.0f,480.0f,230.0f,746,46.227737f,-24.392405f,-39.14988f,0f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,194.0f,0f,-1340.0f,0f,0f,0f,0f,0f,988.0f,649.0f,172.0f,992.0f,574.0f,909.0f,-348,0.446684f,-0.7491607f,-0.2479144f,0f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,331.0f,0f,1864.0f,0f,0f,0f,0f,0f,999.0f,-435.0f,1449.0f,1037.0f,138.0f,509.0f,999,-26.671686f,-74.66883f,-4.027556f,0f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-380.0f,0f,2172.0f,0f,0f,0f,0f,0f,23.0f,-357.0f,-578.0f,1802.0f,-254.0f,227.0f,-1629,0.4801093f,-0.78839475f,0.50700665f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,38.0f,0f,262.0f,0f,0f,0f,0f,0f,-287.0f,-776.0f,-917.0f,226.0f,291.0f,-408.0f,-6,-87.50025f,-3.6551995f,30.478958f,0f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,498.0f,0f,394.0f,0f,0f,0f,0f,0f,-387.0f,-402.0f,-396.0f,744.0f,-919.0f,743.0f,2,151.651f,-26.868742f,68.51907f,0f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-8.0f,0f,66.0f,0f,0f,0f,0f,0f,-951.0f,-450.0f,1536.0f,-58.0f,-464.0f,-172.0f,-3229,-9.108714f,2.3994493f,-6.557058f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,841.0f,0f,1004.0f,0f,0f,0f,0f,0f,-796.0f,1782.0f,2016.0f,1380.0f,-1804.0f,-716.0f,952,-0.56808436f,0.15255144f,-0.8087085f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,946.0f,0f,-2.0f,0f,0f,0f,0f,0f,-459.0f,-1636.0f,-739.0f,945.0f,441.0f,1045.0f,978,72.686676f,148.6014f,43.72797f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2148.0f,612.0f,0f,405.0f,0f,0f,0f,0f,0f,666.0f,415.0f,-574.0f,-305.0f,527.0f,27.0f,884,-71.90933f,-139.95097f,-13.583827f,0f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-217.0f,342.0f,277.0f,-763.0f,0f,0f,0f,0f,0f,-684.0f,266.0f,-97.0f,-889.0f,-651.0f,147.0f,-337,-66.32477f,-10.285448f,-88.60736f,54.22282f,55.73316f,-87.61646f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,21.715218f,-74.00225f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,45.340298f,-42.972332f,-82.68373f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.729113f,-10.764679f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,67.29286f,71.16121f,44.34678f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2179.0f,-692.0f,0f,84.0f,0f,0f,0f,0f,0f,-1084.0f,71.0f,-3.0f,-1490.0f,1241.0f,-1792.0f,952,-0.010687146f,-0.538716f,-0.44922075f,0f,0f,0f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,218.0f,-1108.0f,0f,965.0f,0f,0f,0f,0f,0f,-293.0f,-329.0f,520.0f,55.0f,177.0f,143.0f,1280,29.422386f,69.235f,-4.834301f,0f,0f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-218.0f,-1260.0f,0f,250.0f,0f,0f,0f,0f,0f,-2145.0f,-1810.0f,687.0f,-1462.0f,-276.0f,-2180.0f,-1746,0.52312016f,0.04284408f,-0.72694147f,0f,0f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,22.346941f,0.0f,0f,9.8607613E-32f,0f,0f,0f,0f,0f,94.56804f,32.081295f,90.60091f,0f,0f,0f,-1175,-0.44521198f,-0.71395546f,0.5404201f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.372612f,82.64616f,0f,0f,0f,0f,0f,0f,0f,-21.15868f,9.397259f,-91.38492f,1136.0f,-355.0f,-778.0f,147,0.3070581f,0.5694937f,-0.012532312f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-227.0f,-12.0f,0f,254.0f,0f,0f,0f,0f,0f,256.0f,1122.0f,1875.0f,1352.0f,603.0f,224.0f,-596,-3.9718735f,-1.3500894f,-0.2959088f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.772991f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,15.915528f,17.80311f,0f,0f,0f,1,-77.80487f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.860094f,0.0f,0f,57.39503f,0f,0f,0f,0f,0f,-44.888947f,35.00716f,19.535528f,0f,0f,0f,51,-41.70761f,-68.09479f,-65.82538f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-229.0f,797.0f,347.0f,560.0f,0f,0f,0f,0f,0f,-162.0f,154.0f,755.0f,-513.0f,572.0f,-709.0f,252,-90.005585f,-94.54175f,-51.953022f,-10.675968f,0f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-230.0f,-3.0f,0f,1144.0f,0f,0f,0f,0f,0f,1453.0f,1586.0f,-74.0f,835.0f,-158.0f,459.0f,-1,-1.4877406f,96.16337f,-76.56247f,0f,0f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.037388f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,64.2257f,74.695175f,-65.01653f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.3094964f,45.69434f,0f,21.430601f,0f,0f,0f,0f,0f,-57.961357f,87.392876f,-57.48612f,0f,0f,0f,-1,80.5562f,-92.863235f,2.1053874f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.1328f,65.042206f,0f,0f,0f,0f,0f,0f,0f,36.453938f,52.863846f,97.83507f,-288.0f,513.0f,-596.0f,798,13.166338f,33.429794f,-25.070705f,0f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.170626f,69.47778f,0f,0f,0f,0f,0f,0f,0f,14.63123f,-100.0f,-100.0f,0f,0f,0f,-1005,0.6985902f,-0.05728622f,0.15949857f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-232.0f,865.0f,0f,-236.0f,0f,0f,0f,0f,0f,844.0f,53.0f,89.0f,-321.0f,956.0f,-146.0f,379,-8.539526f,37.950043f,58.38138f,0f,0f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.3502045f,0f,0f,0f,0f,0f,0f,0f,0f,-99.73392f,-9.660774f,-14.19707f,0f,0f,0f,775,0.19163096f,0.22368015f,0.9556384f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2370.0f,508.0f,0f,1237.0f,0f,0f,0f,0f,0f,-198.0f,-149.0f,186.0f,-762.0f,352.0f,-490.0f,98,39.238815f,22.82795f,60.03834f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.706358f,-79.79793f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-146.9885f,-10.262121f,-87.97853f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-237.0f,470.0f,588.0f,879.0f,0f,0f,0f,0f,0f,-779.0f,814.0f,829.0f,84.0f,780.0f,-88.0f,-431,0.05710996f,51.026432f,87.90102f,-87.29962f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.828802f,0f,0f,0f,0f,0f,0f,0f,0f,75.84373f,-59.857395f,-97.45853f,0f,0f,0f,-1107,0.7391915f,-0.045362126f,0.6031108f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2383.0f,1606.0f,0f,98.0f,0f,0f,0f,0f,0f,45.0f,-398.0f,-943.0f,-557.0f,-826.0f,322.0f,-719,100.0f,42.645596f,-13.13314f,0f,0f,0f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-242.0f,-292.0f,0f,773.0f,0f,0f,0f,0f,0f,1329.0f,1156.0f,-183.0f,174.0f,1113.0f,1503.0f,451,-0.2939218f,-0.55395526f,0.7288424f,0f,0f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2468.0f,139.0f,0f,952.0f,0f,0f,0f,0f,0f,814.0f,487.0f,-449.0f,875.0f,-304.0f,1217.0f,907,-13.849221f,93.906075f,76.77693f,0f,0f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.4823248E-38f,-2.9969252E-15f,0f,0f,0f,0f,0f,0f,0f,-100.0f,97.580605f,-40.987667f,-1124.0f,-521.0f,-424.0f,-684,0.27472126f,0.5978361f,0.7530739f,0f,0f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-250.0f,185.0f,-237.0f,278.0f,0f,0f,0f,0f,0f,124.0f,-165.0f,-76.0f,-649.0f,458.0f,-486.0f,-1181,87.42453f,99.25292f,-72.84329f,70.57338f,0f,0f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-250.0f,-76.0f,0f,1026.0f,0f,0f,0f,0f,0f,338.0f,-929.0f,-309.0f,-647.0f,-21.0f,-645.0f,-11,-50.195103f,54.324234f,-55.365776f,0f,0f,0f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,252.0f,-149.0f,0f,1255.0f,0f,0f,0f,0f,0f,1201.0f,1615.0f,1119.0f,-950.0f,-1789.0f,695.0f,-70,-0.9782396f,0.07405738f,0.19381128f,0f,0f,0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,253.0f,0.0f,0f,959.0f,0f,0f,0f,0f,0f,-44.0f,532.0f,235.0f,-419.0f,513.0f,113.0f,460,-25.596693f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-254.0f,-1198.0f,0f,359.0f,0f,0f,0f,0f,0f,-394.0f,-158.0f,867.0f,-129.0f,929.0f,327.0f,-51,4.894409f,24.773798f,-14.758553f,0f,0f,0f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-25.548962f,0.6191917f,0f,0f,0f,0f,0f,0f,0f,61.302975f,100.0f,-3.0633137f,402.0f,-715.0f,183.0f,1,100.0f,-34.941628f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2556.0f,102.0f,0f,3879.0f,0f,0f,0f,0f,0f,341.0f,-353.0f,-791.0f,-122.0f,628.0f,-333.0f,435,-0.12791298f,0.14493045f,0.6838729f,0f,0f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-25.657335f,0.0f,0f,-43.805054f,0f,0f,0f,0f,0f,-8.821327f,37.06526f,-94.76804f,0f,0f,0f,1212,-0.29618135f,0.4835999f,0.21671304f,0f,0f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2579.0f,670.0f,0f,1644.0f,0f,0f,0f,0f,0f,37.0f,-598.0f,-560.0f,-63.0f,283.0f,-307.0f,431,0.9169551f,0.25859848f,-0.18663052f,0f,0f,0f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-258.0f,-1.0f,0f,181.0f,0f,0f,0f,0f,0f,-559.0f,-1314.0f,-435.0f,-321.0f,66.0f,907.0f,-65,86.41577f,-2.4921246f,84.94056f,0f,0f,0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,259.0f,-77.0f,0f,815.0f,0f,0f,0f,0f,0f,807.0f,-429.0f,-778.0f,-498.0f,-687.0f,495.0f,88,-100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,259.0f,958.0f,0f,998.0f,0f,0f,0f,0f,0f,746.0f,-760.0f,639.0f,858.0f,-765.0f,-239.0f,-1082,-6.658429f,-1.6911863f,5.7619467f,0f,0f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-261.0f,1483.0f,0f,1171.0f,0f,0f,0f,0f,0f,-145.0f,438.0f,-708.0f,189.0f,-626.0f,-429.0f,114,-0.61473715f,0.46236968f,0.5817988f,0f,0f,0f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-270.0f,218.0f,-340.0f,-516.0f,0f,0f,0f,0f,0f,-2775.0f,385.0f,660.0f,-1844.0f,-1945.0f,812.0f,-846,0.35541296f,0.92805576f,0.11121317f,-76.43812f,0f,0f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-271.0f,-722.0f,0f,255.0f,0f,0f,0f,0f,0f,619.0f,143.0f,-642.0f,1310.0f,-309.0f,-396.0f,-604,-90.73043f,62.358585f,62.51028f,0f,0f,0f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.724277f,48.712006f,0f,0f,0f,0f,0f,0f,0f,-27.15743f,52.46898f,-36.984898f,0f,0f,0f,-1202,-0.03462595f,-0.058813516f,0.6479521f,0f,0f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2783.0f,-2.0f,0f,488.0f,0f,0f,0f,0f,0f,-1298.0f,637.0f,-417.0f,1038.0f,-90.0f,-2671.0f,482,-0.10650049f,-0.12055005f,0.14735553f,0f,0f,0f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2788.0f,-1707.0f,0f,597.0f,0f,0f,0f,0f,0f,636.0f,-548.0f,-1040.0f,1528.0f,-1751.0f,1176.0f,828,0.669385f,-0.21665551f,0.67262244f,0f,0f,0f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,28.175102f,0.0f,0f,63.196636f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,7.4250326f,-100.0f,-11.764275f,0f,0f,0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-285.0f,1692.0f,-432.0f,1713.0f,0f,0f,0f,0f,0f,-390.0f,-106.0f,1233.0f,898.0f,51.0f,891.0f,-1667,0.030898137f,-0.358688f,-0.33441752f,-67.82921f,0f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-28.517508f,-71.316635f,0f,-38.041958f,0f,0f,0f,0f,0f,89.66077f,-81.02737f,-72.92016f,0f,0f,0f,-964,-34.785767f,-98.04793f,92.93253f,0f,0f,0f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-28.648619f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,60.54778f,-23.273487f,0f,0f,0f,-670,-100.0f,-100.0f,-87.27749f,0f,0f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-29.120274f,0f,0f,0f,0f,0f,0f,0f,0f,41.630394f,39.883553f,3.000855f,0f,0f,0f,-1527,-0.082007855f,-0.7105176f,0.6988844f,0f,0f,0f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,293.0f,-222.0f,534.0f,493.0f,0f,0f,0f,0f,0f,246.0f,-698.0f,553.0f,-854.0f,-455.0f,516.0f,848,-26.019114f,-33.975883f,-42.04202f,83.10835f,0f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,297.0f,-1.0f,0f,560.0f,0f,0f,0f,0f,0f,-670.0f,1166.0f,-1093.0f,-1874.0f,878.0f,-722.0f,-9,-85.3139f,-65.30653f,47.983177f,0f,0f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,30.034584f,-58.80238f,0f,-93.16476f,0f,0f,0f,0f,0f,79.8698f,-100.0f,-12.734459f,0f,0f,0f,-892,0.33247942f,0.30774865f,-0.33136868f,0f,0f,0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,30.072622f,0.0f,0f,0f,0f,0f,0f,0f,0f,-49.770817f,-40.847767f,-33.833416f,0f,0f,0f,-556,20.375216f,6.416386f,51.461967f,0f,0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,30.0f,374.0f,0f,2035.0f,0f,0f,0f,0f,0f,632.0f,-300.0f,-405.0f,-697.0f,412.0f,-206.0f,1617,-0.5360467f,0.04794345f,-0.87201124f,0f,0f,0f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3016.0f,1686.0f,0f,-9.0f,0f,0f,0f,0f,0f,983.0f,1955.0f,-616.0f,-62.0f,-236.0f,182.0f,-225,-0.35577193f,-0.49624476f,-0.7949175f,0f,0f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-304.0f,2171.0f,-297.0f,124.0f,0f,0f,0f,0f,0f,-287.0f,1431.0f,-336.0f,432.0f,-176.0f,-1749.0f,-331,-0.34150606f,-0.41956323f,0.31395882f,0f,-76.17078f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-305.0f,-142.0f,0f,255.0f,0f,0f,0f,0f,0f,719.0f,-911.0f,1586.0f,347.0f,-947.0f,970.0f,-570,-62.268238f,-9.973136f,-1.798655f,0f,0f,0f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,309.0f,-1282.0f,0f,5.0f,0f,0f,0f,0f,0f,66.0f,-731.0f,523.0f,284.0f,522.0f,694.0f,-69,-87.32296f,50.27324f,15.477554f,0f,0f,0f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,1204.0f,0f,-67.0f,0f,0f,0f,0f,0f,576.0f,828.0f,498.0f,-88.0f,-499.0f,-461.0f,6,53.260418f,-53.699535f,24.430391f,0f,0f,0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,2010.0f,0f,9.0f,0f,0f,0f,0f,0f,2588.0f,-253.0f,-1262.0f,824.0f,-1380.0f,641.0f,-775,-0.5147776f,-0.8186129f,-0.2547095f,0f,0f,0f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,201.0f,0f,0.0f,0f,0f,0f,0f,0f,-549.0f,-1398.0f,587.0f,1119.0f,3151.0f,-769.0f,-580,0.71078384f,0.019787401f,-0.3212536f,0f,0f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,329.0f,0f,269.0f,0f,0f,0f,0f,0f,-1810.0f,-331.0f,-191.0f,-1471.0f,-883.0f,-51.0f,885,0.27544132f,0.41139582f,-0.61616784f,0f,0f,0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,416.0f,0f,249.0f,0f,0f,0f,0f,0f,-137.0f,-494.0f,-716.0f,-144.0f,-301.0f,48.0f,459,-87.43161f,73.34305f,-33.873314f,0f,0f,0f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,578.0f,0f,481.0f,0f,0f,0f,0f,0f,1124.0f,92.0f,976.0f,307.0f,1122.0f,-677.0f,1,132.12955f,-114.11815f,-213.50648f,0f,0f,0f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3101.0f,-478.0f,0f,665.0f,0f,0f,0f,0f,0f,-533.0f,-12.0f,-965.0f,29.0f,1853.0f,-39.0f,7,50.786613f,100.0f,-141.51328f,0f,0f,0f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-311.0f,801.0f,0f,348.0f,0f,0f,0f,0f,0f,451.0f,782.0f,-209.0f,624.0f,-416.0f,-210.0f,-886,-80.65793f,47.532455f,24.58251f,0f,0f,0f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-312.0f,2.0f,0f,1422.0f,0f,0f,0f,0f,0f,-230.0f,156.0f,-489.0f,191.0f,2644.0f,752.0f,367,-0.4705313f,-0.5932656f,0.49209443f,0f,0f,0f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-315.0f,11.0f,0f,1638.0f,0f,0f,0f,0f,0f,225.0f,-181.0f,-619.0f,-1062.0f,553.0f,-548.0f,-688,5.4365807f,-69.761894f,41.71266f,0f,0f,0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-316.0f,1.0f,0f,222.0f,0f,0f,0f,0f,0f,-219.0f,-695.0f,-25.0f,-367.0f,117.0f,-44.0f,5,-30.44628f,21.78119f,127.9851f,0f,0f,0f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-316.0f,-585.0f,0f,72.0f,0f,0f,0f,0f,0f,927.0f,945.0f,174.0f,962.0f,204.0f,-685.0f,-966,-94.580635f,-52.33328f,-4.355644f,0f,0f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-317.0f,-1052.0f,0f,1151.0f,0f,0f,0f,0f,0f,42.0f,-476.0f,-966.0f,-1250.0f,-3.0f,-53.0f,995,0.09016005f,0.7409444f,0.06720603f,0f,0f,0f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-318.0f,-171.0f,0f,957.0f,0f,0f,0f,0f,0f,-336.0f,297.0f,-273.0f,-687.0f,889.0f,-714.0f,739,75.44602f,-37.972103f,-21.252026f,0f,0f,0f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,321.0f,1.0f,0f,324.0f,0f,0f,0f,0f,0f,1841.0f,-173.0f,-637.0f,1701.0f,-668.0f,220.0f,906,-0.33363658f,-0.74661326f,-0.40557444f,0f,0f,0f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-323.0f,999.0f,370.0f,-567.0f,0f,0f,0f,0f,0f,-809.0f,274.0f,-281.0f,-834.0f,411.0f,-978.0f,-554,49.598614f,-9.683604f,-48.668674f,1.5353217f,35.07983f,82.16179f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-324.0f,248.0f,0f,26.0f,0f,0f,0f,0f,0f,-207.0f,-694.0f,489.0f,1053.0f,-1972.0f,841.0f,-2,-59.06678f,-70.028755f,81.271454f,0f,0f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3269.0f,761.0f,0f,726.0f,0f,0f,0f,0f,0f,-253.0f,-359.0f,160.0f,10.0f,-321.0f,-695.0f,527,-0.71169895f,0.5264001f,0.055736225f,0f,0f,0f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,327.0f,2489.0f,0f,624.0f,0f,0f,0f,0f,0f,290.0f,523.0f,1012.0f,-925.0f,871.0f,-184.0f,-701,-0.4575293f,-0.71422064f,-0.49512058f,0f,0f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,330.0f,-30.0f,0f,5028.0f,0f,0f,0f,0f,0f,433.0f,258.0f,133.0f,-193.0f,574.0f,-485.0f,257,-0.4501257f,0.25322554f,0.9403834f,0f,0f,0f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.3665001f,-84.72337f,0f,-52.55021f,0f,0f,0f,0f,0f,-11.323087f,65.9336f,78.01409f,0f,0f,0f,275,-0.88806623f,-0.36764494f,-0.27599922f,0f,0f,0f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3460.0f,-767.0f,0f,1059.0f,0f,0f,0f,0f,0f,397.0f,-118.0f,206.0f,616.0f,-804.0f,1596.0f,1508,-0.7437815f,0.07708376f,0.0671078f,0f,0f,0f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,351.0f,1214.0f,0f,672.0f,0f,0f,0f,0f,0f,281.0f,-70.0f,-1413.0f,-638.0f,447.0f,-759.0f,-51,-0.29486623f,-0.5777181f,0.5938547f,0f,0f,0f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.171436f,0.0f,0f,77.005196f,0f,0f,0f,0f,0f,100.0f,74.012405f,100.0f,0f,0f,0f,1,31.462479f,-4.7383604f,-33.379715f,0f,0f,0f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,352.0f,130.0f,190.0f,324.0f,0f,0f,0f,0f,0f,-558.0f,968.0f,-831.0f,-849.0f,557.0f,-724.0f,-773,-89.86261f,-38.23112f,9.419468f,46.638996f,0f,0f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3558.0f,-582.0f,0f,1043.0f,0f,0f,0f,0f,0f,-468.0f,58.0f,-393.0f,-44.0f,-890.0f,-79.0f,-1768,0.20149636f,-0.2492269f,0.7944223f,0f,0f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,356.0f,531.0f,0f,291.0f,0f,0f,0f,0f,0f,730.0f,347.0f,530.0f,175.0f,787.0f,-192.0f,53,15.402635f,-61.55923f,-24.51124f,0f,0f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,357.0f,1790.0f,0f,244.0f,0f,0f,0f,0f,0f,-110.0f,1666.0f,-871.0f,1355.0f,49.0f,-214.0f,-571,0.09641976f,0.18552811f,0.52487594f,0f,0f,0f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-358.0f,289.0f,0f,939.0f,0f,0f,0f,0f,0f,809.0f,663.0f,120.0f,596.0f,372.0f,-458.0f,-767,-89.629456f,9.18356f,53.797256f,0f,0f,0f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,360.0f,-49.0f,0f,1185.0f,0f,0f,0f,0f,0f,1057.0f,-346.0f,256.0f,243.0f,1383.0f,869.0f,-528,-0.21530443f,0.6981679f,0.39696395f,0f,0f,0f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-361.0f,121.0f,0f,75.0f,0f,0f,0f,0f,0f,-100.0f,987.0f,173.0f,805.0f,465.0f,205.0f,954,48.158623f,-1.8390166f,0.23168655f,0f,0f,0f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-364.0f,-321.0f,0f,171.0f,0f,0f,0f,0f,0f,381.0f,179.0f,623.0f,-848.0f,-96.0f,31.0f,1,-75.82481f,56.557896f,90.160095f,0f,0f,0f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-36.538467f,30.997694f,0f,49.744534f,0f,0f,0f,0f,0f,1.383963f,-15.252501f,-36.984184f,0f,0f,0f,2,98.63804f,97.73139f,0.26603842f,0f,0f,0f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-370.0f,881.0f,0f,901.0f,0f,0f,0f,0f,0f,-449.0f,174.0f,242.0f,-811.0f,-628.0f,87.0f,782,-7.063657f,56.068893f,-60.13892f,0f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-371.0f,-119.0f,0f,347.0f,0f,0f,0f,0f,0f,-369.0f,658.0f,519.0f,-70.0f,-829.0f,1002.0f,-201,63.22031f,-61.850246f,-276.97418f,0f,0f,0f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-371.0f,-960.0f,0f,253.0f,0f,0f,0f,0f,0f,-1130.0f,214.0f,-337.0f,-678.0f,1192.0f,-978.0f,-778,-4.671304f,-68.03688f,57.496872f,0f,0f,0f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.155354f,-144.24286f,0f,0.0f,0f,0f,0f,0f,0f,59.77993f,64.43609f,119.56714f,0f,0f,0f,3,-17.227848f,30.69335f,-80.920906f,0f,0f,0f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-373.0f,1377.0f,0f,261.0f,0f,0f,0f,0f,0f,-229.0f,-485.0f,266.0f,687.0f,-1248.0f,-1109.0f,1875,57.590393f,14.111391f,75.30895f,0f,0f,0f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,377.0f,403.0f,0f,730.0f,0f,0f,0f,0f,0f,-986.0f,626.0f,-672.0f,987.0f,-965.0f,-118.0f,607,0.8150514f,-83.00515f,-75.59522f,0f,0f,0f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.7905264f,-122.58569f,0f,-136.39893f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,2.4877207f,100.0f,20.200687f,0f,0f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-379.0f,438.0f,-559.0f,-724.0f,0f,0f,0f,0f,0f,231.0f,666.0f,772.0f,393.0f,58.0f,706.0f,-158,-29.805109f,51.061497f,-94.9677f,91.04936f,0f,0f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-382.0f,342.0f,0f,251.0f,0f,0f,0f,0f,0f,786.0f,-508.0f,-927.0f,-145.0f,866.0f,-831.0f,-54,-7.543922f,-84.71913f,40.03025f,0f,0f,0f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,38.528946f,43.66664f,0f,0f,0f,0f,0f,0f,0f,-20.18108f,89.537926f,61.35441f,-1092.0f,2477.0f,2393.0f,-966,-0.09744814f,0.2244293f,-0.9696949f,0f,0f,0f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-388.0f,1312.0f,-6.0f,1312.0f,0f,0f,0f,0f,0f,356.0f,-918.0f,639.0f,-1037.0f,-131.0f,1191.0f,-212,0.39677146f,0.6346177f,-0.326988f,-4.528475f,0f,0f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,390.0f,986.0f,0f,731.0f,0f,0f,0f,0f,0f,-881.0f,861.0f,217.0f,-210.0f,-168.0f,998.0f,927,-33.609802f,-57.1586f,15.898097f,0f,0f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,39.447605f,9.575565f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-89.46089f,44.0f,-220.0f,323.0f,-1,-100.0f,14.590894f,73.6263f,0f,0f,0f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-395.0f,592.0f,985.0f,112.0f,0f,0f,0f,0f,0f,-941.0f,-294.0f,659.0f,-107.0f,11.0f,-733.0f,-875,79.71241f,91.10153f,-88.80019f,11.480857f,64.41393f,0f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-396.0f,-418.0f,0f,249.0f,0f,0f,0f,0f,0f,654.0f,-464.0f,536.0f,1970.0f,-1312.0f,-1239.0f,-172,0.31691703f,0.30924356f,-0.6061835f,0f,0f,0f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-39.70695f,-30.75363f,0f,-87.38879f,0f,0f,0f,0f,0f,-60.709904f,41.582016f,11.786602f,0f,0f,0f,-502,0.5121208f,0.70445937f,-0.49139526f,0f,0f,0f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-397.0f,10.0f,0f,1218.0f,0f,0f,0f,0f,0f,819.0f,-1602.0f,728.0f,-403.0f,44.0f,549.0f,-894,-0.729969f,2.445879f,-0.23707245f,0f,0f,0f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,402.0f,-1507.0f,0f,924.0f,0f,0f,0f,0f,0f,-719.0f,-949.0f,-1476.0f,1817.0f,900.0f,-1463.0f,-4,-34.455547f,-50.549557f,73.36063f,0f,0f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,40.532284f,-56.048996f,0f,-35.825382f,0f,0f,0f,0f,0f,-24.421444f,32.608864f,-33.18163f,0f,0f,0f,-650,9.699537f,-58.49656f,-45.892582f,0f,0f,0f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-406.0f,578.0f,0f,205.0f,0f,0f,0f,0f,0f,948.0f,-235.0f,-260.0f,379.0f,8.0f,172.0f,-79,-9.21417f,9.18421f,-41.897373f,0f,0f,0f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,40.905357f,0.0f,0f,83.747345f,0f,0f,0f,0f,0f,-67.55159f,-12.587085f,-78.973175f,0f,0f,0f,-7,-0.31129384f,0.3251463f,0.88131607f,0f,0f,0f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,204.0f,0f,367.0f,0f,0f,0f,0f,0f,536.0f,-586.0f,416.0f,-232.0f,453.0f,-579.0f,815,54.87692f,27.828114f,-31.506618f,0f,0f,0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,-555.0f,0f,15.0f,0f,0f,0f,0f,0f,1210.0f,-339.0f,1557.0f,-119.0f,1096.0f,-880.0f,1051,-0.3244759f,0.43347517f,0.34654075f,0f,0f,0f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-416.0f,766.0f,0f,1071.0f,0f,0f,0f,0f,0f,-73.0f,1326.0f,-147.0f,-558.0f,658.0f,-611.0f,-105,-0.11507412f,-0.011504503f,0.6045744f,0f,0f,0f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.1896253f,73.607574f,0f,0f,0f,0f,0f,0f,0f,-59.014137f,-47.12344f,-38.639404f,-1730.0f,-931.0f,340.0f,1,-51.766174f,51.289497f,110.57322f,0f,0f,0f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.22915f,3.9926255f,0f,0f,0f,0f,0f,0f,0f,-155.55925f,-100.0f,-40.82884f,0f,0f,0f,1,14.344459f,30.622692f,-43.107758f,0f,0f,0f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.2470465f,43.890526f,0f,0f,0f,0f,0f,0f,0f,-27.851402f,21.554075f,25.084778f,0f,0f,0f,2,96.62527f,91.4324f,10.922778f,0f,0f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,430.0f,0.0f,0f,520.0f,0f,0f,0f,0f,0f,2162.0f,-1001.0f,-728.0f,188.0f,445.0f,-52.0f,-2,-56.736935f,-41.350243f,46.470528f,0f,0f,0f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,430.0f,796.0f,0f,-608.0f,0f,0f,0f,0f,0f,518.0f,-303.0f,-170.0f,-466.0f,-315.0f,-976.0f,-965,-0.5990932f,0.46103033f,-0.12029381f,0f,0f,0f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-43.061802f,-22.358334f,0f,0.0f,0f,0f,0f,0f,0f,64.36254f,41.469868f,28.335356f,0f,0f,0f,1,-13.266913f,0.17697544f,1.8397442f,0f,0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-43.175262f,100.0f,0f,0f,0f,0f,0f,0f,0f,99.98453f,22.741667f,99.16899f,750.0f,656.0f,-331.0f,943,-0.031349305f,-0.73174894f,-0.68085295f,0f,0f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,432.0f,363.0f,0f,0.0f,0f,0f,0f,0f,0f,178.0f,-1963.0f,-218.0f,-1086.0f,-1226.0f,-78.0f,393,-91.54427f,89.44454f,29.894018f,0f,0f,0f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.458412f,0.0f,0f,-36.23452f,0f,0f,0f,0f,0f,77.42688f,36.75935f,-51.943153f,0f,0f,0f,1,-186.62056f,69.137314f,-41.435722f,0f,0f,0f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-43.460785f,0.0f,0f,0f,0f,0f,0f,0f,0f,-40.172955f,-20.55646f,-15.932079f,0f,0f,0f,551,-27.949728f,74.03013f,-4.226196f,0f,0f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-436.0f,447.0f,0f,457.0f,0f,0f,0f,0f,0f,-504.0f,-532.0f,621.0f,321.0f,43.0f,1084.0f,-570,-90.40229f,29.48973f,-48.106712f,0f,0f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.62525f,-87.030846f,0f,0f,0f,0f,0f,0f,0f,-74.419f,76.04876f,-42.432575f,0f,0f,0f,1,44.86308f,-31.196253f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.79286f,0f,0f,0f,0f,0f,0f,0f,0f,-88.14649f,-31.00543f,31.925173f,0f,0f,0f,907,0.73548305f,0.1287944f,-0.1288597f,0f,0f,0f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-438.0f,-589.0f,317.0f,-90.0f,0f,0f,0f,0f,0f,-266.0f,106.0f,-270.0f,803.0f,-764.0f,-661.0f,851,63.867924f,20.120163f,-13.2074375f,40.841625f,0f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.987736f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,56.434975f,-5.402346f,-65.17733f,0f,0f,0f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-447.0f,-304.0f,0f,261.0f,0f,0f,0f,0f,0f,-16.0f,-1447.0f,-1285.0f,-1047.0f,-842.0f,-593.0f,-789,48.59963f,12.586882f,-5.514679f,0f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-447.0f,-400.0f,0f,120.0f,0f,0f,0f,0f,0f,-84.0f,160.0f,-1435.0f,-1191.0f,-150.0f,2.0f,13,-1.0251883f,-5.831426f,24.24134f,0f,0f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,450.0f,-1436.0f,0f,313.0f,0f,0f,0f,0f,0f,927.0f,262.0f,-120.0f,-450.0f,1580.0f,-27.0f,-219,-123.15505f,71.82691f,77.75591f,0f,0f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,455.0f,1978.0f,0f,986.0f,0f,0f,0f,0f,0f,-84.0f,135.0f,-50.0f,-49.0f,-37.0f,-17.0f,-764,-0.42908624f,-0.28288162f,-0.04291552f,0f,0f,0f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,46.325123f,27.522472f,0f,0f,0f,0f,0f,0f,0f,-10.54164f,-55.672253f,16.195343f,0f,0f,0f,677,94.09215f,-4.8332953f,-29.683203f,0f,0f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-466.0f,-134.0f,0f,259.0f,0f,0f,0f,0f,0f,1356.0f,297.0f,-1032.0f,41.0f,169.0f,-350.0f,245,0.22669394f,-0.3008351f,0.7102816f,0f,0f,0f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,46.963337f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,37.332478f,41.84427f,0f,0f,0f,1,-100.0f,-24.179142f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-46.98227f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-56.09644f,-8.427741f,-72.37852f,0f,0f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-471.0f,595.0f,0f,167.0f,0f,0f,0f,0f,0f,-807.0f,908.0f,-592.0f,-708.0f,-199.0f,634.0f,100,18.837606f,-22.914547f,48.02909f,0f,0f,0f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,47.96609f,-100.0f,0f,-75.01042f,0f,0f,0f,0f,0f,-89.62201f,9.587904f,9.40947f,0f,0f,0f,1,16.977766f,-100.0f,33.576355f,0f,0f,0f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-480.0f,1851.0f,313.0f,355.0f,0f,0f,0f,0f,0f,619.0f,-393.0f,688.0f,531.0f,-120.0f,-635.0f,864,98.13556f,-20.491394f,-99.99999f,91.82069f,-41.283646f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-48.06515f,0.0f,0f,0f,0f,0f,0f,0f,0f,5.11367f,15.022386f,100.0f,0f,0f,0f,285,-0.46972448f,0.49704233f,-0.56650347f,0f,0f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.8699274f,0.0f,0f,18.282694f,0f,0f,0f,0f,0f,100.0f,-24.509903f,100.0f,0f,0f,0f,608,0.057636064f,-0.2657414f,-0.88011944f,0f,0f,0f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.8854384f,-10.151921f,0f,0.0f,0f,0f,0f,0f,0f,30.621447f,-34.848133f,-105.85538f,0f,0f,0f,1,84.46344f,49.022034f,33.85736f,0f,0f,0f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-490.0f,503.0f,0f,221.0f,0f,0f,0f,0f,0f,-508.0f,-363.0f,-705.0f,138.0f,151.0f,-868.0f,779,-75.443085f,-55.433384f,82.90412f,0f,0f,0f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-493.0f,-1426.0f,0f,253.0f,0f,0f,0f,0f,0f,-1724.0f,-1669.0f,485.0f,-1010.0f,-1.0f,-267.0f,-554,0.40132734f,-0.3424424f,0.2481484f,0f,0f,0f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-495.0f,1631.0f,0f,856.0f,0f,0f,0f,0f,0f,1160.0f,961.0f,-82.0f,524.0f,1612.0f,-1173.0f,632,-0.24149224f,-0.08539294f,0.13534382f,0f,0f,0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,496.0f,2.0f,0f,1582.0f,0f,0f,0f,0f,0f,-822.0f,2096.0f,-101.0f,139.0f,14.0f,-830.0f,1448,-3.728556f,-1.890041f,1.193679f,0f,0f,0f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,498.0f,288.0f,0f,1.0f,0f,0f,0f,0f,0f,-86.0f,1749.0f,1172.0f,399.0f,-631.0f,-462.0f,-155,0.25915116f,-0.7467078f,-0.026355997f,0f,0f,0f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,498.0f,-919.0f,0f,516.0f,0f,0f,0f,0f,0f,-789.0f,-881.0f,447.0f,219.0f,-973.0f,329.0f,393,66.39619f,-74.94799f,-76.94416f,0f,0f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.989957f,32.61403f,0f,0f,0f,0f,0f,0f,0f,64.234924f,51.04653f,-149.5884f,0f,0f,0f,1,-99.67514f,7.805941f,39.8133f,0f,0f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,499.0f,-2.0f,0f,1506.0f,0f,0f,0f,0f,0f,1342.0f,818.0f,-389.0f,405.0f,246.0f,-703.0f,42,23.572365f,-100.0f,52.228477f,0f,0f,0f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.0f,-172.0f,0f,534.0f,0f,0f,0f,0f,0f,468.0f,299.0f,-75.0f,503.0f,-581.0f,826.0f,-425,-31.185837f,18.664755f,24.053097f,0f,0f,0f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.637287f,-59.89663f,0f,0.0f,0f,0f,0f,0f,0f,42.884235f,71.39268f,-51.034798f,0f,0f,0f,-614,-5.2546597f,-7.6361847f,13.143648f,0f,0f,0f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,508.0f,0.0f,0f,880.0f,0f,0f,0f,0f,0f,-1440.0f,1314.0f,1205.0f,77.0f,867.0f,-853.0f,-1647,-24.829855f,-34.657104f,-21.693735f,0f,0f,0f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,50.969532f,30.772532f,0f,0f,0f,0f,0f,0f,0f,-83.74708f,-66.59423f,33.078808f,941.0f,-670.0f,877.0f,-582,79.167725f,-92.11663f,14.5484f,0f,0f,0f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.0f,-1062.0f,0f,15.0f,0f,0f,0f,0f,0f,-486.0f,493.0f,-92.0f,586.0f,627.0f,321.0f,-868,-1.9957409f,-2.2522483f,-1.5263951f,0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.0f,-1442.0f,0f,534.0f,0f,0f,0f,0f,0f,679.0f,307.0f,892.0f,1271.0f,-660.0f,1713.0f,-1,-98.08917f,100.0f,-52.32255f,0f,0f,0f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.0f,2016.0f,0f,252.0f,0f,0f,0f,0f,0f,-415.0f,90.0f,428.0f,144.0f,321.0f,1416.0f,2665,39.619125f,-46.61109f,48.21714f,0f,0f,0f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.0f,823.0f,-1080.0f,2.0f,0f,0f,0f,0f,0f,-315.0f,447.0f,870.0f,975.0f,797.0f,-1863.0f,5,38.170193f,-66.76864f,22.55129f,-54.277668f,0f,0f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-510.0f,479.0f,0f,381.0f,0f,0f,0f,0f,0f,69.0f,-993.0f,634.0f,-582.0f,216.0f,402.0f,769,-74.48948f,100.0f,77.98819f,0f,0f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-51.0f,992.0f,28.0f,1829.0f,0f,0f,0f,0f,0f,904.0f,162.0f,-782.0f,-377.0f,1549.0f,-77.0f,282,-98.21221f,72.60805f,-98.49032f,28.175583f,6.4507923f,0f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-514.0f,-731.0f,0f,624.0f,0f,0f,0f,0f,0f,700.0f,-814.0f,988.0f,-73.0f,707.0f,1495.0f,-846,-30.478363f,-19.861652f,-23.615543f,0f,0f,0f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-52.0f,674.0f,12.0f,772.0f,0f,0f,0f,0f,0f,-36.0f,621.0f,530.0f,-398.0f,132.0f,-182.0f,-235,3.5606356f,37.8224f,-44.074577f,141.571f,0f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-52.28412f,-69.2055f,0f,0f,0f,0f,0f,0f,0f,-97.861626f,-37.548595f,99.178055f,0f,0f,0f,954,98.76019f,74.0179f,-19.672005f,0f,0f,0f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,52.48748f,0.0f,0f,6.466084f,0f,0f,0f,0f,0f,-114.27723f,-34.949863f,-66.0333f,0f,0f,0f,1,45.684856f,0.36291394f,-19.298372f,0f,0f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,52.611206f,29.363775f,0f,0f,0f,0f,0f,0f,0f,-0.6196023f,-37.253506f,-30.847843f,721.0f,-144.0f,-684.0f,1,54.448093f,54.104095f,39.998856f,0f,0f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-528.0f,-120.0f,0f,255.0f,0f,0f,0f,0f,0f,923.0f,959.0f,-129.0f,-186.0f,2010.0f,284.0f,-1923,0.24762687f,-0.5661133f,-0.6149096f,0f,0f,0f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-53.0f,2574.0f,0f,1255.0f,0f,0f,0f,0f,0f,105.0f,-111.0f,-200.0f,-750.0f,997.0f,-945.0f,-1177,-0.48928905f,-0.39327654f,-0.03854291f,0f,0f,0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-534.0f,993.0f,0f,839.0f,0f,0f,0f,0f,0f,-262.0f,-540.0f,-459.0f,93.0f,-868.0f,796.0f,20,-46.323753f,93.668686f,-83.75657f,0f,0f,0f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-53.878983f,-45.398087f,0f,35.45096f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,94.99384f,-92.42313f,-52.4187f,0f,0f,0f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-54.33691f,-1.3171525f,0f,0f,0f,0f,0f,0f,0f,-2.4261925f,9.313313f,25.617636f,0f,0f,0f,1,-0.5020355f,0.46661305f,-1.1180136f,0f,0f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,544.0f,932.0f,0f,432.0f,0f,0f,0f,0f,0f,539.0f,-968.0f,-972.0f,-807.0f,133.0f,-580.0f,-728,-93.5017f,-72.55313f,21.69585f,0f,0f,0f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,54.681583f,0f,0f,0f,0f,0f,0f,0f,0f,-46.867344f,42.19798f,-3.676321f,0f,0f,0f,1,60.96969f,-48.265102f,84.397095f,0f,0f,0f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-55.0f,586.0f,-397.0f,1904.0f,0f,0f,0f,0f,0f,793.0f,2399.0f,-1167.0f,40.0f,193.0f,-1139.0f,-2203,-0.68095857f,0.14262532f,9.360469E-4f,0f,-43.937366f,0f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,551.0f,47.0f,0f,1084.0f,0f,0f,0f,0f,0f,77.0f,-104.0f,-196.0f,231.0f,-1078.0f,-432.0f,857,-18.490307f,0.12642531f,-7.3311324f,0f,0f,0f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,554.0f,214.0f,0f,163.0f,0f,0f,0f,0f,0f,-752.0f,-65.0f,-700.0f,-947.0f,598.0f,925.0f,1539,0.11544076f,0.36261022f,-0.1576873f,0f,0f,0f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-555.0f,-218.0f,0f,42.0f,0f,0f,0f,0f,0f,659.0f,-643.0f,1360.0f,535.0f,863.0f,693.0f,-1364,-0.09255402f,0.82779276f,-0.4908504f,0f,0f,0f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-556.0f,832.0f,0f,274.0f,0f,0f,0f,0f,0f,60.0f,262.0f,-317.0f,351.0f,414.0f,410.0f,1562,-0.815385f,-0.60051185f,0.5612052f,0f,0f,0f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,557.0f,707.0f,0f,1480.0f,0f,0f,0f,0f,0f,-829.0f,-151.0f,887.0f,-452.0f,-550.0f,-734.0f,659,-12.214815f,-55.2109f,-20.815174f,0f,0f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,558.0f,-4.0f,0f,2950.0f,0f,0f,0f,0f,0f,62.0f,219.0f,123.0f,786.0f,-3.0f,-345.0f,494,-87.67347f,-26.260593f,-133.40884f,0f,0f,0f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-559.0f,189.0f,-461.0f,-346.0f,0f,0f,0f,0f,0f,62.0f,-3560.0f,168.0f,269.0f,-310.0f,713.0f,431,-0.96424353f,0.0924851f,0.038880017f,38.655582f,0f,0f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.0f,-260.0f,0f,480.0f,0f,0f,0f,0f,0f,952.0f,-183.0f,-241.0f,931.0f,637.0f,-314.0f,-754,-91.28347f,-41.492992f,-12.942207f,0f,0f,0f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.24746f,0f,0f,0f,0f,0f,0f,0f,0f,21.483688f,68.45758f,24.908058f,0f,0f,0f,201,-25.072596f,-10.333593f,-29.731909f,0f,0f,0f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.478893f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-55.87831f,-113.64343f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,56.88556f,100.0f,0f,0f,0f,0f,0f,0f,0f,32.74466f,-87.95122f,-69.05154f,257.0f,-5.0f,457.0f,-503,-0.78958225f,-1.1679251f,1.1132655f,0f,0f,0f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,570.0f,-589.0f,0f,419.0f,0f,0f,0f,0f,0f,5.0f,500.0f,453.0f,-153.0f,559.0f,820.0f,849,93.54626f,67.42879f,-79.88911f,0f,0f,0f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,57.0f,873.0f,0f,1353.0f,0f,0f,0f,0f,0f,72.0f,-8.0f,19.0f,270.0f,330.0f,-875.0f,1406,-0.014434794f,-4.278681E-4f,0.047643878f,0f,0f,0f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-587.0f,946.0f,0f,-2.0f,0f,0f,0f,0f,0f,-787.0f,-764.0f,149.0f,-408.0f,-854.0f,-307.0f,-632,-29.504692f,84.26202f,-21.225368f,0f,0f,0f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,589.0f,-504.0f,0f,797.0f,0f,0f,0f,0f,0f,-558.0f,379.0f,1624.0f,-337.0f,-611.0f,-833.0f,249,-0.23373663f,0.09186117f,-0.7596601f,0f,0f,0f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,590.0f,386.0f,0f,732.0f,0f,0f,0f,0f,0f,837.0f,-389.0f,-324.0f,-442.0f,-371.0f,-697.0f,688,-143.34888f,-100.0f,66.01437f,0f,0f,0f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.954556f,-62.380043f,0f,79.98554f,0f,0f,0f,0f,0f,87.12992f,-80.43475f,38.99002f,0f,0f,0f,-997,0.6260709f,0.639102f,-0.14896128f,0f,0f,0f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,60.02948f,0.0f,0f,-15.06339f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,65.43481f,33.98527f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,60.59252f,-38.28135f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,45.406433f,-87.65068f,-67.96575f,0f,0f,0f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,60.840366f,100.0f,0f,0f,0f,0f,0f,0f,0f,-81.24021f,30.941303f,-79.84507f,1047.0f,-400.0f,441.0f,2,40.483868f,-89.91114f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,0.0f,0f,1354.0f,0f,0f,0f,0f,0f,-480.0f,817.0f,-366.0f,-568.0f,-1442.0f,738.0f,-769,0.02188261f,0.013392034f,0.06573391f,0f,0f,0f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,-1403.0f,0f,397.0f,0f,0f,0f,0f,0f,18.0f,-947.0f,-463.0f,-505.0f,-738.0f,-1386.0f,370,-0.06059087f,0.47955468f,-0.8164257f,0f,0f,0f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.0f,1519.0f,0f,-812.0f,0f,0f,0f,0f,0f,1239.0f,-1080.0f,-1622.0f,-623.0f,391.0f,-3096.0f,-360,-0.9996862f,-0.008752353f,0.02351914f,0f,0f,0f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,-39.0f,0f,847.0f,0f,0f,0f,0f,0f,332.0f,891.0f,-757.0f,380.0f,357.0f,581.0f,-8,40.813416f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,613.0f,-138.0f,0f,180.0f,0f,0f,0f,0f,0f,-452.0f,-1205.0f,-788.0f,-155.0f,203.0f,-221.0f,-1,100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.940456f,99.553116f,0f,0f,0f,0f,0f,0f,0f,81.39646f,15.013723f,-55.04031f,1039.0f,936.0f,-700.0f,-1,72.74377f,44.67748f,-57.358074f,0f,0f,0f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-620.0f,583.0f,0f,-4.0f,0f,0f,0f,0f,0f,401.0f,1352.0f,-737.0f,894.0f,114.0f,-1125.0f,-788,0.8353065f,-0.45209682f,-0.19175704f,0f,0f,0f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.0f,1799.0f,0f,281.0f,0f,0f,0f,0f,0f,713.0f,820.0f,-471.0f,751.0f,-465.0f,-395.0f,-472,-67.14698f,39.1234f,-33.534172f,0f,0f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.3171535f,0f,0f,0f,0f,0f,0f,0f,0f,11.434779f,-23.317287f,-42.43557f,0f,0f,0f,323,-5.6292353f,3.326569f,76.10957f,0f,0f,0f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,632.0f,-2084.0f,0f,792.0f,0f,0f,0f,0f,0f,-43.0f,-30.0f,90.0f,231.0f,712.0f,599.0f,1268,-0.6867485f,0.6761015f,-0.2698727f,0f,0f,0f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-64.16515f,63.900635f,0f,0f,0f,0f,0f,0f,0f,-39.978874f,78.98437f,43.459396f,1150.0f,-346.0f,-1833.0f,-312,-0.4580213f,-0.43616235f,-0.69399744f,0f,0f,0f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.43857f,0.0f,0f,-80.59058f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,685,0.0017812845f,0.9514734f,-0.30772582f,0f,0f,0f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-644.0f,582.0f,0f,178.0f,0f,0f,0f,0f,0f,-80.0f,-99.0f,416.0f,656.0f,-455.0f,446.0f,-186,22.012314f,52.42402f,16.709045f,0f,0f,0f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,64.58556f,0.0f,0f,-100.855316f,0f,0f,0f,0f,0f,75.171974f,-54.6578f,55.621494f,0f,0f,0f,-214,-0.33276653f,0.7251539f,-0.41067508f,0f,0f,0f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.465766f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-75.81617f,100.0f,87.38495f,0f,0f,0f,1,-100.0f,-100.0f,10.424052f,0f,0f,0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,65.0f,25.0f,0f,1539.0f,0f,0f,0f,0f,0f,424.0f,650.0f,-1734.0f,-532.0f,-580.0f,-1354.0f,1320,-0.89238113f,0.0262433f,0.21276622f,0f,0f,0f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,659.0f,144.0f,0f,345.0f,0f,0f,0f,0f,0f,-967.0f,-539.0f,-672.0f,-445.0f,797.0f,-135.0f,-92,21.877628f,90.298485f,98.833984f,0f,0f,0f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,66.101204f,-6.116991f,0f,0f,0f,0f,0f,0f,0f,95.755394f,49.108276f,20.892603f,0f,0f,0f,117,-59.40497f,12.468414f,-3.8246748f,0f,0f,0f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-664.0f,-182.0f,0f,251.0f,0f,0f,0f,0f,0f,887.0f,325.0f,654.0f,-502.0f,464.0f,859.0f,-897,-18.496742f,-33.240368f,-60.56139f,0f,0f,0f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-670.0f,0.0f,0f,1943.0f,0f,0f,0f,0f,0f,-931.0f,-425.0f,2459.0f,1.0f,287.0f,1360.0f,-872,-0.55316144f,-0.23643658f,-0.45349205f,0f,0f,0f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-675.0f,518.0f,0f,373.0f,0f,0f,0f,0f,0f,-605.0f,-291.0f,839.0f,32.0f,-356.0f,-100.0f,-11,35.765522f,-97.40403f,-83.552795f,0f,0f,0f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-676.0f,453.0f,0f,258.0f,0f,0f,0f,0f,0f,-686.0f,285.0f,-162.0f,-960.0f,302.0f,-544.0f,763,-22.690685f,-7.8274198f,82.31489f,0f,0f,0f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-681.0f,-24.0f,0f,56.0f,0f,0f,0f,0f,0f,-513.0f,-638.0f,-542.0f,57.0f,-193.0f,-875.0f,-521,-59.911396f,58.27549f,54.7659f,0f,0f,0f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,68.24009f,0f,0f,0f,0f,0f,0f,0f,0f,-31.026234f,10.164563f,-88.80942f,0f,0f,0f,1,29.627808f,27.263401f,111.07958f,0f,0f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.53986f,0.0f,0f,0f,0f,0f,0f,0f,0f,-118.88273f,1.0876695f,76.17834f,1079.0f,1207.0f,737.0f,1,0.022148663f,20.891905f,-2.9454145f,0f,0f,0f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.61107f,100.0f,0f,0f,0f,0f,0f,0f,0f,85.186264f,-68.22682f,-37.8596f,330.0f,-191.0f,252.0f,297,51.46606f,71.8f,-13.589209f,0f,0f,0f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,69.018364f,2.0118458f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-61.92433f,-33.890663f,87.02923f,0f,0f,0f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,696.0f,125.0f,524.0f,-852.0f,0f,0f,0f,0f,0f,264.0f,352.0f,759.0f,-568.0f,469.0f,-834.0f,-275,4.4436493f,-57.96141f,-89.27964f,87.48656f,26.10649f,0f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,70.16958f,75.95622f,0f,0f,0f,0f,0f,0f,0f,-3.126227f,42.124985f,-108.18894f,-1007.0f,-561.0f,936.0f,2,134.79193f,136.94919f,96.917656f,0f,0f,0f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,70.84054f,75.284294f,0f,-71.73105f,0f,0f,0f,0f,0f,-45.546867f,91.28604f,-33.386074f,0f,0f,0f,2,26.323557f,35.106705f,96.78602f,0f,0f,0f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-7.0f,-2460.0f,0f,1307.0f,0f,0f,0f,0f,0f,-148.0f,-77.0f,-42.0f,202.0f,469.0f,-1417.0f,864,0.42225936f,0.89138335f,0.054775197f,0f,0f,0f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-710.0f,-1.0f,0f,70.0f,0f,0f,0f,0f,0f,99.0f,-699.0f,-336.0f,-699.0f,376.0f,-987.0f,619,-0.83950114f,-0.4587488f,0.71038914f,0f,0f,0f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-710.0f,-112.0f,0f,258.0f,0f,0f,0f,0f,0f,870.0f,34.0f,-690.0f,981.0f,261.0f,-679.0f,-663,-84.27408f,20.03974f,-23.574476f,0f,0f,0f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-712.0f,-4.0f,0f,42.0f,0f,0f,0f,0f,0f,339.0f,1079.0f,-77.0f,-327.0f,19.0f,-1176.0f,-2,16.378988f,4.5073414f,-113.95949f,0f,0f,0f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-714.0f,804.0f,0f,-1305.0f,0f,0f,0f,0f,0f,120.0f,848.0f,-235.0f,33.0f,679.0f,420.0f,312,-0.26425272f,-0.042644132f,-0.28881937f,0f,0f,0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,717.0f,274.0f,0f,334.0f,0f,0f,0f,0f,0f,407.0f,270.0f,-66.0f,386.0f,-610.0f,-162.0f,430,80.52154f,-96.934616f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,718.0f,-737.0f,0f,1273.0f,0f,0f,0f,0f,0f,-693.0f,-778.0f,796.0f,-295.0f,-433.0f,-680.0f,665,-68.821396f,157.24724f,-45.150723f,0f,0f,0f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,72.03149f,98.94379f,0f,0.0f,0f,0f,0f,0f,0f,-34.517246f,100.0f,28.473085f,0f,0f,0f,1,-17.793455f,-17.62223f,33.171616f,0f,0f,0f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-72.21135f,91.97446f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,83.555f,68.51051f,80.16075f,0f,0f,0f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-72.4264f,100.0f,0f,0f,0f,0f,0f,0f,0f,-17.634703f,9.958311f,5.3393483f,2254.0f,-458.0f,21.0f,1,53.788578f,95.96213f,-1.4887785f,0f,0f,0f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-72.461464f,-1.7763568E-15f,0f,0f,0f,0f,0f,0f,0f,83.75774f,100.0f,-65.98148f,0f,0f,0f,-1057,-0.79249936f,-0.45491886f,-0.406194f,0f,0f,0f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,73.24592f,-21.187944f,0f,55.36566f,0f,0f,0f,0f,0f,-25.475178f,-100.0f,56.63253f,0f,0f,0f,1,68.83444f,-9.148218f,-32.184208f,0f,0f,0f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-740.0f,-1414.0f,0f,664.0f,0f,0f,0f,0f,0f,410.0f,196.0f,-794.0f,581.0f,980.0f,542.0f,-1658,-35.853786f,85.53822f,92.68023f,0f,0f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,742.0f,6.0f,0f,24.0f,0f,0f,0f,0f,0f,18.0f,823.0f,-848.0f,-1791.0f,-187.0f,-220.0f,15,-45.582737f,-3.2616925f,4.773584f,0f,0f,0f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.27182f,-11.250884f,0f,0f,0f,0f,0f,0f,0f,35.88835f,-66.79454f,-53.69401f,0f,0f,0f,1,-111.83568f,78.61864f,-53.162468f,0f,0f,0f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-748.0f,681.0f,0f,948.0f,0f,0f,0f,0f,0f,-856.0f,-363.0f,-149.0f,-476.0f,1283.0f,-382.0f,-530,-0.9110578f,2.2769213f,-0.30453715f,0f,0f,0f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,74.86407f,119.42598f,0f,0f,0f,0f,0f,0f,0f,44.366066f,-62.198154f,-80.32688f,-168.0f,250.0f,331.0f,4,19.829092f,55.933308f,-32.357906f,0f,0f,0f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.90484f,0f,0f,0f,0f,0f,0f,0f,0f,-15.708074f,22.102034f,100.0f,0f,0f,0f,1,-0.3377299f,-0.06862002f,-0.09864661f,0f,0f,0f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,75.0f,184.0f,0f,-417.0f,0f,0f,0f,0f,0f,608.0f,-651.0f,651.0f,-585.0f,736.0f,-1584.0f,-693,-0.33651933f,-0.30569926f,-0.8855414f,0f,0f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-75.15962f,46.192276f,0f,0f,0f,0f,0f,0f,0f,-44.633038f,0.17302263f,82.29931f,1136.0f,-680.0f,529.0f,-1,41.473217f,-64.409904f,-67.85758f,0f,0f,0f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,757.0f,-432.0f,0f,262.0f,0f,0f,0f,0f,0f,-156.0f,311.0f,-358.0f,-99.0f,853.0f,-58.0f,989,-4.942421f,-61.568443f,12.878465f,0f,0f,0f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,758.0f,-1179.0f,0f,205.0f,0f,0f,0f,0f,0f,-1759.0f,524.0f,-407.0f,366.0f,1052.0f,999.0f,-3,75.60105f,-34.73838f,57.130524f,0f,0f,0f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-770.0f,912.0f,-1102.0f,913.0f,0f,0f,0f,0f,0f,140.0f,10.0f,-153.0f,269.0f,-691.0f,888.0f,-50,100.0f,86.76644f,97.17559f,32.181034f,-27.296581f,0f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-774.0f,161.0f,-1186.0f,-5.0f,0f,0f,0f,0f,0f,-1112.0f,-526.0f,663.0f,-94.0f,223.0f,-1170.0f,-1,-16.362082f,-38.092552f,-93.98213f,-174.86003f,0f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-785.0f,60.0f,0f,1078.0f,0f,0f,0f,0f,0f,-516.0f,-569.0f,623.0f,-211.0f,-844.0f,-945.0f,82,-20.54428f,36.164482f,-50.84929f,0f,0f,0f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-787.0f,1858.0f,0f,1378.0f,0f,0f,0f,0f,0f,861.0f,-348.0f,736.0f,198.0f,-233.0f,-334.0f,-706,-61.428036f,-6.247211f,68.8032f,0f,0f,0f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-789.0f,572.0f,-157.0f,-77.0f,0f,0f,0f,0f,0f,-613.0f,245.0f,-121.0f,-730.0f,280.0f,300.0f,478,56.905453f,25.781672f,-36.846012f,59.935566f,-77.210846f,0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-791.0f,8.0f,0f,1630.0f,0f,0f,0f,0f,0f,387.0f,-131.0f,966.0f,-1412.0f,24.0f,569.0f,558,68.6926f,-74.49434f,-39.674515f,0f,0f,0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-792.0f,780.0f,0f,-363.0f,0f,0f,0f,0f,0f,323.0f,-743.0f,-280.0f,-287.0f,511.0f,-15.0f,572,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-79.218956f,0f,0f,0f,0f,0f,0f,0f,0f,96.954605f,8.627388f,28.102804f,0f,0f,0f,1,-86.47956f,-83.36327f,-90.2715f,0f,0f,0f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,797.0f,-489.0f,0f,347.0f,0f,0f,0f,0f,0f,-1312.0f,874.0f,2160.0f,736.0f,-770.0f,-296.0f,13,23.755295f,-35.804966f,-25.28568f,0f,0f,0f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-80.10696f,19.888033f,0f,-38.303307f,0f,0f,0f,0f,0f,-139.70377f,-88.36099f,-36.179543f,0f,0f,0f,1,-22.193024f,80.07535f,-22.949776f,0f,0f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-802.0f,28.0f,0f,1117.0f,0f,0f,0f,0f,0f,224.0f,921.0f,-1192.0f,1717.0f,-485.0f,-778.0f,2788,0.059545666f,-0.86009645f,0.5066442f,0f,0f,0f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-808.0f,1284.0f,0f,1787.0f,0f,0f,0f,0f,0f,163.0f,85.0f,-677.0f,-242.0f,800.0f,-252.0f,-217,15.685175f,-12.320199f,2.2296896f,0f,0f,0f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.0f,0.0f,0f,418.0f,0f,0f,0f,0f,0f,706.0f,2739.0f,-149.0f,-2184.0f,238.0f,1065.0f,-58,-0.94187194f,-0.07255549f,0.10115719f,0f,0f,0f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,8.0f,659.0f,236.0f,-725.0f,0f,0f,0f,0f,0f,-45.0f,-243.0f,553.0f,195.0f,-19.0f,-975.0f,424,97.39989f,38.87382f,32.95074f,28.337547f,-60.175533f,78.59975f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,8.0f,840.0f,0f,-767.0f,0f,0f,0f,0f,0f,-484.0f,311.0f,-622.0f,535.0f,888.0f,-279.0f,-186,76.24539f,25.16702f,16.838144f,0f,0f,0f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-810.0f,10.0f,0f,255.0f,0f,0f,0f,0f,0f,537.0f,-213.0f,-854.0f,-515.0f,-1196.0f,-1388.0f,855,100.0f,-48.386192f,74.948784f,0f,0f,0f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-811.0f,44.0f,0f,451.0f,0f,0f,0f,0f,0f,238.0f,-603.0f,-780.0f,591.0f,-501.0f,80.0f,184,-33.24863f,33.845104f,42.784218f,0f,0f,0f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-812.0f,882.0f,-223.0f,1157.0f,0f,0f,0f,0f,0f,22.0f,198.0f,217.0f,147.0f,202.0f,-666.0f,-800,-32.10714f,79.416435f,-69.207825f,-63.544903f,-24.687092f,0f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-819.0f,-1384.0f,0f,254.0f,0f,0f,0f,0f,0f,-1208.0f,1251.0f,-438.0f,1130.0f,934.0f,-601.0f,189,87.97774f,-53.444393f,45.89559f,0f,0f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-823.0f,742.0f,-76.0f,-1048.0f,0f,0f,0f,0f,0f,-1019.0f,1101.0f,499.0f,871.0f,921.0f,1204.0f,762,0.70605737f,-0.14449248f,-0.005908407f,-82.480484f,0f,0f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-824.0f,-803.0f,0f,106.0f,0f,0f,0f,0f,0f,610.0f,310.0f,-269.0f,-420.0f,544.0f,-327.0f,1716,-0.128242f,-0.15129663f,0.21171467f,0f,0f,0f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-82.419044f,0.0f,0f,-51.60797f,0f,0f,0f,0f,0f,15.980764f,-82.85256f,40.820957f,0f,0f,0f,4,73.93832f,8.398449f,-69.22068f,0f,0f,0f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,825.0f,1033.0f,0f,114.0f,0f,0f,0f,0f,0f,-106.0f,-165.0f,-757.0f,-694.0f,636.0f,-41.0f,916,-237.92075f,26.16264f,27.943918f,0f,0f,0f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,83.0f,17.0f,0f,2.0f,0f,0f,0f,0f,0f,321.0f,442.0f,-791.0f,-771.0f,-53.0f,-821.0f,-109,11.559226f,88.78015f,56.465446f,0f,0f,0f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.0f,-271.0f,0f,217.0f,0f,0f,0f,0f,0f,-244.0f,293.0f,972.0f,-655.0f,253.0f,634.0f,-572,-62.54262f,60.608467f,-50.646935f,0f,0f,0f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,83.38967f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-18.577492f,0f,0f,0f,1562,0.31719556f,0.056982983f,-0.9466467f,0f,0f,0f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.510994f,0.0f,0f,-120.897644f,0f,0f,0f,0f,0f,12.458014f,-80.02033f,46.346622f,0f,0f,0f,-273,-9.493258f,46.27766f,-1.8414257f,0f,0f,0f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-84.0f,7.0f,0f,5.0f,0f,0f,0f,0f,0f,938.0f,-99.0f,1419.0f,1959.0f,1341.0f,1467.0f,3,-9.262075f,120.4763f,-35.97365f,0f,0f,0f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,842.0f,589.0f,0f,-417.0f,0f,0f,0f,0f,0f,-258.0f,522.0f,-1860.0f,297.0f,571.0f,198.0f,-986,-75.14287f,-6.60907f,91.274315f,0f,0f,0f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-85.0f,3004.0f,0f,1397.0f,0f,0f,0f,0f,0f,-419.0f,1494.0f,559.0f,1420.0f,-1893.0f,424.0f,-895,0.92403495f,-0.013758441f,-0.3820604f,0f,0f,0f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-85.138054f,-137.66296f,0f,-66.65972f,0f,0f,0f,0f,0f,43.608246f,-9.353454f,20.172472f,0f,0f,0f,1,-43.775013f,-95.07856f,36.848824f,0f,0f,0f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-856.0f,1492.0f,0f,1790.0f,0f,0f,0f,0f,0f,-210.0f,867.0f,-557.0f,-423.0f,-277.0f,-272.0f,-963,52.31051f,-1.4598111f,74.58551f,0f,0f,0f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-858.0f,740.0f,0f,302.0f,0f,0f,0f,0f,0f,23.0f,911.0f,52.0f,-240.0f,-834.0f,-997.0f,-798,27.509125f,-96.426544f,65.070465f,0f,0f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-862.0f,1245.0f,0f,-1474.0f,0f,0f,0f,0f,0f,-1763.0f,776.0f,913.0f,-1965.0f,1162.0f,1524.0f,-101,0.7495035f,0.1682646f,0.6041062f,0f,0f,0f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-86.3551f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,7.0187545f,-13.284275f,-27.97473f,0f,0f,0f,-293,0.5630026f,0.12111188f,0.08374321f,0f,0f,0f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-867.0f,-661.0f,862.0f,-647.0f,0f,0f,0f,0f,0f,-621.0f,335.0f,631.0f,-705.0f,156.0f,-288.0f,-902,-74.76372f,-36.033405f,-39.27433f,63.966072f,0f,0f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-871.0f,1.0f,0f,355.0f,0f,0f,0f,0f,0f,-63.0f,-924.0f,688.0f,-331.0f,1326.0f,746.0f,10,-89.193054f,63.62109f,-60.46933f,0f,0f,0f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-874.0f,1314.0f,-916.0f,1127.0f,0f,0f,0f,0f,0f,-764.0f,-77.0f,1253.0f,-880.0f,833.0f,24.0f,-305,0.6093882f,0.27939174f,-0.5041513f,-99.96947f,0f,0f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,87.445564f,-80.332436f,0f,83.41185f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,15.4210205f,-54.715527f,196.76848f,0f,0f,0f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-876.0f,67.0f,285.0f,-98.0f,0f,0f,0f,0f,0f,-489.0f,-766.0f,950.0f,63.0f,789.0f,939.0f,-781,30.184967f,34.17527f,-24.529715f,-2.2601297f,-78.44106f,-83.16104f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,88.0f,966.0f,848.0f,21.0f,0f,0f,0f,0f,0f,-936.0f,135.0f,-265.0f,774.0f,515.0f,663.0f,-11,27.039898f,-3.5338907f,-25.665417f,11.836476f,-2.5155208f,0f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-883.0f,374.0f,0f,491.0f,0f,0f,0f,0f,0f,-756.0f,-885.0f,-663.0f,936.0f,305.0f,828.0f,-957,28.756073f,35.337116f,-42.833908f,0f,0f,0f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-883.0f,994.0f,657.0f,-925.0f,0f,0f,0f,0f,0f,41.0f,172.0f,-164.0f,592.0f,621.0f,-429.0f,-688,75.07773f,2.3037586f,-80.26451f,89.05109f,0f,0f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,88.77059f,37.363235f,0f,0f,0f,0f,0f,0f,0f,55.78413f,-66.206924f,4.9297185f,-727.0f,-217.0f,-546.0f,-370,-0.32651752f,0.4616576f,0.13568799f,0f,0f,0f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,890.0f,-272.0f,0f,952.0f,0f,0f,0f,0f,0f,386.0f,-493.0f,151.0f,-50.0f,28.0f,219.0f,-703,0.3071976f,-0.10039181f,-1.2291162f,0f,0f,0f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-891.0f,957.0f,628.0f,-602.0f,0f,0f,0f,0f,0f,869.0f,10.0f,-306.0f,1541.0f,-969.0f,-809.0f,-9,-97.43029f,-72.97715f,65.4834f,30.777323f,0f,0f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-89.25807f,0.0f,0f,-167.67445f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-41.12774f,9.542069f,42.962246f,0f,0f,0f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-90.3024f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-59.987675f,-95.588356f,-100.0f,0f,0f,0f,2,-30.988031f,100.0f,116.2051f,0f,0f,0f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.0f,-1430.0f,0f,881.0f,0f,0f,0f,0f,0f,-53.0f,237.0f,-134.0f,1233.0f,916.0f,1130.0f,-783,1.8141179f,2.1709414f,3.1221256f,0f,0f,0f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.0f,999.0f,-183.0f,-744.0f,0f,0f,0f,0f,0f,-1515.0f,722.0f,-792.0f,-35.0f,382.0f,-960.0f,4,69.57672f,-93.60363f,90.26885f,6.267592f,0f,0f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,91.0f,-603.0f,0f,790.0f,0f,0f,0f,0f,0f,154.0f,-554.0f,131.0f,-924.0f,-307.0f,-212.0f,878,4.3939886f,80.278915f,-57.307995f,0f,0f,0f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-911.0f,-144.0f,0f,255.0f,0f,0f,0f,0f,0f,-1126.0f,-216.0f,1273.0f,-700.0f,-405.0f,-594.0f,1468,0.8740505f,-0.16006264f,0.27676955f,0f,0f,0f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-913.0f,-1.0f,0f,1437.0f,0f,0f,0f,0f,0f,-923.0f,217.0f,798.0f,639.0f,-914.0f,-518.0f,1,85.45968f,59.145535f,49.009792f,0f,0f,0f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-91.31604f,0.0f,0f,0f,0f,0f,0f,0f,0f,42.18886f,68.245125f,-87.098564f,0f,0f,0f,1,-90.73663f,-12.025231f,-45.92924f,0f,0f,0f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-91.36194f,64.400246f,0f,3.9443045E-31f,0f,0f,0f,0f,0f,100.0f,-7.7431245f,-20.782028f,0f,0f,0f,-1,-25.51421f,-29.923277f,-51.11801f,0f,0f,0f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,916.0f,-1553.0f,0f,1790.0f,0f,0f,0f,0f,0f,-229.0f,168.0f,-8.0f,-85.0f,1085.0f,1212.0f,-1202,0.33618146f,0.3899035f,0.03728306f,0f,0f,0f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,916.0f,2143.0f,0f,842.0f,0f,0f,0f,0f,0f,50.0f,-531.0f,233.0f,1047.0f,383.0f,648.0f,-162,-4.5803905f,1.7597972f,-3.6498582f,0f,0f,0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,920.0f,-38.0f,0f,1109.0f,0f,0f,0f,0f,0f,-585.0f,1013.0f,-731.0f,-610.0f,313.0f,922.0f,-509,64.136795f,-11.625158f,9.552166f,0f,0f,0f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,923.0f,839.0f,0f,124.0f,0f,0f,0f,0f,0f,-706.0f,-848.0f,284.0f,449.0f,-480.0f,-293.0f,1305,-75.72109f,33.464428f,-88.31428f,0f,0f,0f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-927.0f,67.0f,0f,962.0f,0f,0f,0f,0f,0f,449.0f,-520.0f,-624.0f,-572.0f,-1471.0f,260.0f,-801,-0.76516557f,-0.29424006f,-0.2941897f,0f,0f,0f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,93.0f,-946.0f,0f,1011.0f,0f,0f,0f,0f,0f,269.0f,-77.0f,366.0f,538.0f,-820.0f,-7.0f,944,-0.8985303f,-0.007978062f,-0.4271145f,0f,0f,0f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.29213f,43.49319f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,72.554565f,-77.94577f,-63.705284f,0f,0f,0f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-936.0f,2058.0f,-281.0f,-1133.0f,0f,0f,0f,0f,0f,227.0f,1688.0f,-1201.0f,242.0f,1120.0f,255.0f,-423,0.07780461f,0.044380393f,0.99629104f,100.0f,0f,0f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,93.90421f,65.74809f,0f,0f,0f,0f,0f,0f,0f,-98.907524f,7.988486f,76.977455f,0f,0f,0f,2,147.75005f,7.9370055f,-44.50593f,0f,0f,0f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-939.0f,252.0f,0f,142.0f,0f,0f,0f,0f,0f,126.0f,452.0f,-404.0f,-1144.0f,654.0f,545.0f,-731,40.321182f,78.14051f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-939.0f,973.0f,0f,349.0f,0f,0f,0f,0f,0f,-581.0f,-302.0f,438.0f,-948.0f,-884.0f,-893.0f,395,50.225178f,10.059689f,73.55898f,0f,0f,0f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.385895f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,80.05147f,-14.608327f,0f,0f,0f,1,-96.533966f,-48.19948f,-3.1818311f,0f,0f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.4864f,28.390516f,0f,0f,0f,0f,0f,0f,0f,-82.21125f,-2.6385856f,-66.06671f,519.0f,4.0f,906.0f,727,-28.898144f,-86.92755f,58.90234f,0f,0f,0f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.962776f,0.0f,0f,0f,0f,0f,0f,0f,0f,35.758755f,-57.666023f,100.0f,0f,0f,0f,-827,0.6582084f,0.73531777f,-0.16146047f,0f,0f,0f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,95.03354f,74.5855f,0f,0f,0f,0f,0f,0f,0f,-9.958131f,22.955938f,14.150668f,133.0f,469.0f,598.0f,782,-64.30683f,12.670235f,-65.89133f,0f,0f,0f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.09363f,-47.3149f,0f,0f,0f,0f,0f,0f,0f,22.015701f,-10.493212f,29.604464f,0f,0f,0f,1,68.53522f,-73.13403f,-79.130325f,0f,0f,0f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.23461f,49.857777f,0f,0f,0f,0f,0f,0f,0f,-43.331486f,-12.503524f,-0.83227944f,0f,0f,0f,1,1.3175263f,0.3292972f,0.15972547f,0f,0f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-954.0f,805.0f,0f,1379.0f,0f,0f,0f,0f,0f,645.0f,327.0f,25.0f,66.0f,10.0f,474.0f,772,-29.621439f,63.97808f,-72.60015f,0f,0f,0f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,959.0f,-815.0f,0f,899.0f,0f,0f,0f,0f,0f,-934.0f,-943.0f,453.0f,179.0f,-178.0f,619.0f,-1,47.95874f,-21.096148f,52.50398f,0f,0f,0f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,960.0f,0.0f,0f,63.0f,0f,0f,0f,0f,0f,-325.0f,481.0f,-1568.0f,172.0f,979.0f,199.0f,8,73.62228f,-112.37367f,-86.65474f,0f,0f,0f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-96.052055f,0.0f,0f,99.01779f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,1,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-96.072685f,-63.249146f,0f,0.0f,0f,0f,0f,0f,0f,-85.40167f,-15.415844f,-86.09247f,0f,0f,0f,-838,0.3601409f,0.38411653f,-0.31208345f,0f,0f,0f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-97.406845f,35.395103f,0f,0f,0f,0f,0f,0f,0f,93.440475f,-32.39603f,-89.46538f,0f,0f,0f,-20,-68.128426f,51.145447f,33.169575f,0f,0f,0f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-97.543236f,63.01789f,0f,0f,0f,0f,0f,0f,0f,-70.938576f,20.79359f,45.807716f,-242.0f,-997.0f,26.0f,2,48.843346f,-54.106094f,99.99987f,0f,0f,0f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,980.0f,-160.0f,0f,2097.0f,0f,0f,0f,0f,0f,-665.0f,-271.0f,1654.0f,-939.0f,-13.0f,-318.0f,10,0.21920803f,0.050091986f,-0.9743914f,0f,0f,0f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-980.0f,260.0f,0f,1208.0f,0f,0f,0f,0f,0f,-981.0f,64.0f,-544.0f,-468.0f,-2035.0f,674.0f,-319,-1.1386905f,0.8134792f,2.149122f,0f,0f,0f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.0f,526.0f,0f,2190.0f,0f,0f,0f,0f,0f,-491.0f,571.0f,35.0f,528.0f,516.0f,-1009.0f,1862,-28.55618f,-79.17791f,-6.974602f,0f,0f,0f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.237404f,-25.156298f,0f,0f,0f,0f,0f,0f,0f,-36.47876f,-100.0f,64.702644f,0f,0f,0f,-877,-0.21362282f,0.3015634f,-0.6588444f,0f,0f,0f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-983.0f,166.0f,0f,-1.0f,0f,0f,0f,0f,0f,660.0f,-833.0f,402.0f,5.0f,-828.0f,213.0f,507,0.6958948f,0.7050233f,-0.13664797f,0f,0f,0f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-984.0f,897.0f,-991.0f,729.0f,0f,0f,0f,0f,0f,587.0f,584.0f,-1109.0f,939.0f,-429.0f,282.0f,-915,42.294086f,61.33569f,54.686848f,-56.90327f,-100.0f,0f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.46937f,-44.43983f,0f,0.0f,0f,0f,0f,0f,0f,-83.488594f,4.052245f,33.13035f,0f,0f,0f,494,-0.094721146f,0.68879795f,-0.5455288f,0f,0f,0f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.4926f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,65.58209f,67.45263f,0f,0f,0f,90,0.5204554f,-0.8517893f,0.059842836f,0f,0f,0f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-986.0f,105.0f,-1560.0f,-888.0f,0f,0f,0f,0f,0f,-1095.0f,472.0f,-790.0f,378.0f,910.0f,-5.0f,367,-0.14711015f,-0.50715375f,0.19162446f,-29.413523f,0f,0f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.43078f,100.0f,0f,0f,0f,0f,0f,0f,0f,-2.9274058f,99.95894f,97.32167f,0f,0f,0f,-2508,-0.92324185f,-0.2959316f,-0.24504888f,0f,0f,0f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.47621f,0.0f,0f,0f,0f,0f,0f,0f,0f,99.96578f,-7.3034086f,-75.64798f,0f,0f,0f,3,-0.95920724f,-0.2350334f,-0.36480585f,0f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.69763f,83.2794f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,-100.0f,2.4590538f,0f,0f,0f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.89001f,100.0f,0f,0f,0f,0f,0f,0f,0f,50.50133f,-100.0f,14.644045f,0f,0f,0f,22,-0.8911743f,0.4535866f,0.008219985f,0f,0f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.975876f,100.0f,0f,0f,0f,0f,0f,0f,0f,99.93706f,20.386799f,-44.427708f,-6.0f,-205.0f,567.0f,-581,-0.04817377f,-2.2270517f,-1.1303036f,0f,0f,0f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.977974f,-100.0f,0f,94.60906f,0f,0f,0f,0f,0f,-99.83794f,-15.062101f,72.16024f,0f,0f,0f,-667,0.01437688f,-0.71774954f,-0.696153f,0f,0f,0f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(0f,0f,-341.0f,-566.0f,0f,0f,0f,1.4210855E-14f,0f,0f,0f,0f,0f,15.392422f,16.87078f,-51.2387f,-1336.0f,-1008.0f,1471.0f,-1,0f,0f,0f,0f,0f,5.181186E-6f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(0f,0f,-680.0f,-223.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,41.355854f,-100.0f,-8.491235f,-1107.0f,612.0f,534.0f,4,0f,0f,0f,0f,0f,-55.90185f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(0f,0f,727.0f,721.0f,0f,0f,0f,63.528748f,0f,0f,0f,0f,0f,99.45912f,-36.316597f,-89.85404f,202.0f,808.0f,1701.0f,0,0f,0f,0f,0f,0f,81.70588f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(0f,-1088.0f,718.0f,0f,519.0f,7.0f,0f,-337.0f,0f,0f,0f,0f,0f,-150.0f,720.0f,-552.0f,0f,0f,0f,11,-162.36546f,21.409454f,0.07883854f,0f,-81.5179f,-12.51424f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(0f,1.0f,0f,0f,0.04530833f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-10.507711f,25.25552f,68.34348f,0f,0f,0f,1,60.48057f,-42.00809f,23.633968f,0f,21.015816f,0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(0f,143.0f,0f,0f,39.601192f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,-47.03372f,-22.79166f,0f,0f,0f,-1,-119.16759f,-45.878067f,33.882317f,0f,100.0f,0f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(0f,-1440.0f,0f,0f,262.0f,348.0f,560.0f,-94.0f,0f,0f,0f,0f,0f,494.0f,998.0f,602.0f,334.0f,251.0f,117.0f,-986,-71.325905f,-100.0f,89.97275f,0f,-33.692364f,0f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(0f,-147.0f,-62.0f,0f,40.0f,-5.0f,0f,-391.0f,0f,0f,0f,0f,0f,370.0f,563.0f,227.0f,0f,0f,0f,3,-80.64937f,24.769714f,100.0f,0f,-65.865486f,7.752464E-6f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(0f,-162.0f,400.0f,0f,536.0f,152.0f,583.0f,-194.0f,0f,0f,0f,0f,0f,502.0f,-711.0f,-386.0f,808.0f,-865.0f,123.0f,737,-48.91084f,-43.921867f,69.21337f,0f,-53.491188f,2.9942553f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(0f,168.0f,0f,-1416.0f,0f,0f,0f,16.932852f,0f,0f,0f,0f,0f,33.86132f,2.181581f,18.222652f,575.0f,-764.0f,-977.0f,-1,0f,0f,0f,0f,-37.852722f,0f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(0f,1788.0f,-249.0f,0f,81.0f,2.0f,0f,15.0f,0f,0f,0f,0f,0f,14.0f,-413.0f,-473.0f,0f,0f,0f,-37,-180.38176f,66.39518f,-47.35513f,0f,1.8940995f,-8.707399f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(0f,-1900.0f,622.0f,0f,257.0f,-1.0f,0f,-2567.0f,0f,0f,0f,0f,0f,542.0f,-863.0f,-391.0f,0f,0f,0f,5,-61.217514f,-56.75021f,23.623922f,0f,-68.444084f,73.053665f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(0f,-21.0f,0f,0f,51.44765f,0.0f,0f,-82.53589f,0f,0f,0f,0f,0f,-95.702034f,41.500393f,9.71365f,0f,0f,0f,1,17.609634f,78.95634f,-64.60892f,0f,8.275972E-5f,0f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(0f,2124.0f,17.0f,0f,1214.0f,-2.0f,0f,19.0f,0f,0f,0f,0f,0f,-12.0f,150.0f,158.0f,0f,0f,0f,-2,-61.024117f,100.0f,-100.0f,0f,38.83648f,12.202724f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(0f,218.0f,0f,-225.0f,0f,0f,0f,43.642555f,0f,0f,0f,0f,0f,-98.52253f,43.31588f,52.577026f,1559.0f,468.0f,227.0f,-1,0f,0f,0f,0f,99.3388f,0f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(0f,-228.0f,0f,0f,31.79279f,0.0f,0f,-165.66124f,0f,0f,0f,0f,0f,114.83689f,-63.497402f,48.61268f,0f,0f,0f,1,-61.69487f,-72.40206f,-96.997795f,0f,67.31032f,0f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(0f,243.0f,-1432.0f,0f,126.0f,-1.0f,0f,-17.0f,0f,0f,0f,0f,0f,-578.0f,1216.0f,-612.0f,0f,0f,0f,-1,-100.0f,-99.41945f,-100.0f,0f,-0.056617927f,-100.0f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(0f,271.0f,479.0f,0f,676.0f,714.0f,-774.0f,-533.0f,0f,0f,0f,0f,0f,-129.0f,-97.0f,-514.0f,-833.0f,672.0f,74.0f,-512,66.17851f,-65.73676f,36.527264f,0f,-60.045784f,23.267975f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(0f,28.0f,928.0f,0f,108.0f,-2.0f,0f,7.0f,0f,0f,0f,0f,0f,773.0f,-433.0f,68.0f,0f,0f,0f,-4,-7.099298f,-15.290019f,-23.56821f,0f,2.039563E-5f,-100.0f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(0f,-296.0f,0f,0f,-626.0f,-760.0f,406.0f,-309.0f,0f,0f,0f,0f,0f,472.0f,-713.0f,-455.0f,-375.0f,-611.0f,-236.0f,-355,25.228128f,-48.84314f,5.4102774f,0f,-77.24358f,0f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(0f,302.0f,0f,-14.0f,0f,0f,0f,16.270473f,0f,0f,0f,0f,0f,-100.0f,-85.828964f,46.047607f,770.0f,81.0f,-531.0f,-1,0f,0f,0f,0f,-2.3651845E-4f,0f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(0f,319.0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,49.436783f,100.0f,-86.03356f,0f,0f,0f,1,-51.607155f,-94.33113f,-74.82974f,0f,34.73484f,0f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(0f,-325.0f,0f,0f,16.800797f,-23.412786f,0f,-5.4210134E-20f,0f,0f,0f,0f,0f,0.5569021f,79.622604f,-100.0f,0f,0f,0f,1930,-0.085432306f,-2.1035938f,-1.6740903f,0f,-13.620464f,0f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(0f,391.0f,0f,0f,13.293657f,-3.3311682f,0f,0.0f,0f,0f,0f,0f,0f,-39.623276f,-3.5051475f,-100.0f,0f,0f,0f,-877,0.5845394f,0.8113585f,0.0033241918f,0f,27.66311f,0f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(0f,-437.0f,0f,0f,122.0f,1320.0f,-886.0f,-46.0f,0f,0f,0f,0f,0f,-733.0f,378.0f,931.0f,94.0f,-488.0f,462.0f,-365,48.097393f,-67.612785f,-53.223434f,0f,-13.425676f,0f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(0f,-485.0f,0f,0f,32.58977f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-90.1658f,36.36711f,35.468403f,0f,0f,0f,4,52.353863f,-100.0f,2.9383545f,0f,151.25026f,0f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(0f,-533.0f,0f,0f,30.0f,866.0f,-1431.0f,578.0f,0f,0f,0f,0f,0f,785.0f,383.0f,699.0f,-466.0f,516.0f,328.0f,-939,-100.0f,-69.01902f,43.862114f,0f,-100.0f,0f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(0f,-547.0f,870.0f,0f,328.0f,0.0f,0f,-27.0f,0f,0f,0f,0f,0f,920.0f,-506.0f,164.0f,0f,0f,0f,25,47.805878f,133.37242f,82.97173f,0f,-114.79526f,62.719677f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(0f,-589.0f,0f,0f,-941.0f,-643.0f,899.0f,-973.0f,0f,0f,0f,0f,0f,245.0f,-555.0f,342.0f,-871.0f,53.0f,-269.0f,739,0.8357704f,-75.058525f,-33.578087f,0f,83.16143f,0f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(0f,-61.0f,0f,-923.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,14.027007f,55.900463f,35.69732f,852.0f,170.0f,-601.0f,2,0f,0f,0f,0f,1.7761044E-5f,0f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(0f,-637.0f,0f,-418.0f,0f,0f,0f,11.31548f,0f,0f,0f,0f,0f,-46.38018f,82.86706f,-100.0f,-278.0f,-228.0f,-60.0f,-3,0f,0f,0f,0f,1.4449531E-6f,0f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(0f,-671.0f,0f,-175.0f,0f,0f,0f,76.94764f,0f,0f,0f,0f,0f,-50.960358f,112.44682f,1.0865738f,-147.0f,-318.0f,682.0f,0,0f,0f,0f,0f,51.831787f,0f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(0f,-767.0f,0f,0f,100.0f,-84.36106f,0f,0.0f,0f,0f,0f,0f,0f,-24.153399f,-5.510582f,30.277868f,0f,0f,0f,-394,0.8081925f,0.43025866f,0.4021223f,0f,0.16638784f,0f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(0f,-813.0f,0f,0f,536.0f,1473.0f,-506.0f,-105.0f,0f,0f,0f,0f,0f,-785.0f,373.0f,158.0f,-953.0f,-209.0f,82.0f,751,34.403587f,21.899038f,30.8267f,0f,77.32022f,0f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(0f,860.0f,595.0f,0f,456.0f,560.0f,-568.0f,-183.0f,0f,0f,0f,0f,0f,-294.0f,72.0f,-62.0f,-199.0f,144.0f,441.0f,896,0.8560873f,-47.707222f,80.112236f,0f,74.80985f,10.270448f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(0f,-940.0f,279.0f,0f,56.0f,2.0f,0f,2.0f,0f,0f,0f,0f,0f,-1745.0f,351.0f,1727.0f,0f,0f,0f,-4,64.60089f,100.0f,6.1358867f,0f,-92.70345f,-21.37743f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(-100.0f,0f,0f,0f,9.962637f,-62.533367f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-45.500317f,80.15025f,0f,0f,0f,-176,-0.6818056f,0.009953218f,-0.7314657f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(1007.0f,0f,0f,0f,72.64418f,0.0f,0f,-8.143892f,0f,0f,0f,0f,0f,-100.0f,-10.800781f,17.985386f,0f,0f,0f,1,11.221874f,25.261372f,-100.0f,-65.538086f,0f,0f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(101.0f,-2224.0f,0f,0f,79.0f,-444.0f,0f,0.0f,0f,0f,0f,0f,0f,428.0f,-1434.0f,-410.0f,0f,0f,0f,1362,57.317825f,4.7907133f,43.078407f,4.1975894f,20.338505f,0f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(1013.0f,935.0f,-127.0f,0f,345.0f,-312.0f,0f,377.0f,0f,0f,0f,0f,0f,965.0f,405.0f,65.0f,243.0f,283.0f,-101.0f,-937,11.612961f,-28.22771f,3.4725444f,22.680172f,-92.79708f,59.610096f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(-1019.0f,1873.0f,0f,0f,385.0f,-528.0f,0f,-7.0f,0f,0f,0f,0f,0f,508.0f,-461.0f,-844.0f,0f,0f,0f,8,-100.0f,-27.315329f,-43.025623f,100.0f,0.295518f,0f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(1021.0f,0f,0f,0f,100.0f,-38.261044f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-55.526363f,-79.450836f,0f,0f,0f,2,77.81573f,0.95494306f,44.203663f,-46.07993f,0f,0f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(-1021.0f,-308.0f,0f,0f,275.0f,-604.0f,0f,-1082.0f,0f,0f,0f,0f,0f,-940.0f,776.0f,-279.0f,0f,0f,0f,-489,0.49677622f,-0.41063562f,-0.5898358f,16.168818f,0.5515547f,0f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(-1035.0f,-1931.0f,748.0f,0f,1580.0f,951.0f,0f,723.0f,0f,0f,0f,0f,0f,254.0f,663.0f,-857.0f,-401.0f,796.0f,-435.0f,1434,89.95219f,88.59792f,95.202194f,-76.62742f,30.811205f,-100.0f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(1037.0f,0f,0f,1860.0f,0f,0f,0f,46.948265f,0f,0f,0f,0f,0f,-1.6532593f,100.0f,91.626686f,1334.0f,-426.0f,489.0f,0,0f,0f,0f,87.65525f,0f,0f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(1037.0f,-852.0f,-663.0f,0f,286.0f,120.0f,0f,-1091.0f,0f,0f,0f,0f,0f,-674.0f,-296.0f,-795.0f,396.0f,492.0f,650.0f,414,50.377827f,26.843317f,55.829006f,90.11704f,100.0f,-100.0f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(1041.0f,0f,0f,0f,13.985722f,-115.81784f,0f,-23.733173f,0f,0f,0f,0f,0f,-100.0f,-38.333717f,81.39729f,0f,0f,0f,1,48.396893f,100.0f,-31.943413f,70.52478f,0f,0f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(1048.0f,128.0f,340.0f,0f,1070.0f,-813.0f,0f,-671.0f,0f,0f,0f,0f,0f,1130.0f,-1612.0f,826.0f,0f,0f,0f,-542,-0.6197857f,0.08414702f,0.2817213f,-68.083015f,-2.7948387f,9.650129f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(-1052.0f,-906.0f,0f,0f,965.0f,-902.0f,0f,-441.0f,0f,0f,0f,0f,0f,113.0f,-87.0f,605.0f,0f,0f,0f,664,-100.0f,-100.0f,-100.0f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(-1061.0f,-17.0f,-1583.0f,0f,637.0f,-369.0f,0f,228.0f,0f,0f,0f,0f,0f,-824.0f,-872.0f,-482.0f,-865.0f,-649.0f,855.0f,596,-17.203993f,-13.459056f,53.76014f,-100.0f,-100.0f,-43.091854f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(1074.0f,-574.0f,0f,0f,764.0f,433.0f,0f,362.0f,0f,0f,0f,0f,0f,-996.0f,480.0f,977.0f,150.0f,-440.0f,743.0f,-324,-27.536793f,76.29347f,-65.55528f,-1.1097273f,47.768185f,0f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(1078.0f,545.0f,1031.0f,0f,598.0f,-982.0f,0f,-609.0f,0f,0f,0f,0f,0f,-711.0f,908.0f,1489.0f,0f,0f,0f,564,-0.6560082f,0.1560901f,-0.7181962f,-100.0f,18.758566f,-62.947765f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(-1082.0f,13.0f,0f,-1632.0f,0f,0f,0f,-91.3624f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-37.377773f,-53.25257f,0f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(1090.0f,-252.0f,546.0f,0f,248.0f,1835.0f,0f,758.0f,0f,0f,0f,0f,0f,-520.0f,494.0f,662.0f,193.0f,1760.0f,945.0f,706,-65.78908f,-92.951126f,17.6851f,-47.94785f,165.63223f,-78.9303f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(-1094.0f,38.0f,0f,0f,576.0f,1.0f,0f,-118.0f,0f,0f,0f,0f,0f,1542.0f,-1564.0f,-898.0f,0f,0f,0f,-1030,-0.8359949f,-0.8664968f,0.07815695f,79.51223f,-6.7409306f,0f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(-1096.0f,0f,0f,0f,631.0f,841.0f,0f,-243.0f,0f,0f,0f,0f,0f,-295.0f,744.0f,950.0f,586.0f,-98.0f,-593.0f,-89,-30.323233f,-67.38054f,43.35344f,-83.959854f,0f,0f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(-1096.0f,348.0f,834.0f,0f,197.0f,-748.0f,0f,-698.0f,0f,0f,0f,0f,0f,750.0f,151.0f,774.0f,0f,0f,0f,-238,64.7994f,-42.76132f,-54.44779f,-93.97982f,91.614456f,16.61976f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(-1.0f,0f,0f,0f,46.9564f,0.0f,0f,-79.79377f,0f,0f,0f,0f,0f,-40.23888f,-84.63961f,36.626385f,0f,0f,0f,1,17.167917f,52.399685f,100.0f,-0.0016619875f,0f,0f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(-110.0f,1.0f,0f,0f,756.0f,-1473.0f,0f,-66.0f,0f,0f,0f,0f,0f,-256.0f,1313.0f,-228.0f,0f,0f,0f,-503,-0.555355f,-0.3935192f,0.23082618f,-78.43897f,3.0967037E-6f,0f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(110.0f,370.0f,693.0f,0f,266.0f,-1257.0f,0f,446.0f,0f,0f,0f,0f,0f,-288.0f,868.0f,-18.0f,33.0f,-132.0f,1237.0f,104,-47.596172f,-16.195148f,-19.427252f,27.737741f,63.723152f,33.666145f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(1105.0f,0f,0f,0f,2.9684145f,-4.9113923E-18f,0f,3.081488E-33f,0f,0f,0f,0f,0f,-35.634212f,-0.062285144f,-51.995003f,0f,0f,0f,3,40.401237f,-0.5056369f,-27.610497f,-14.022937f,0f,0f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(-1113.0f,945.0f,1091.0f,0f,691.0f,-637.0f,0f,215.0f,0f,0f,0f,0f,0f,-278.0f,-764.0f,696.0f,-1244.0f,362.0f,476.0f,-1351,-7.9324303f,-3.743231f,-7.2773623f,-100.0f,-176.36864f,100.0f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(112.0f,-1515.0f,62.0f,-607.0f,0f,0f,0f,-90.65582f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.4709343E-5f,69.957405f,84.96936f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(-1122.0f,-344.0f,0f,0f,9.0f,-1100.0f,0f,-62.0f,0f,0f,0f,0f,0f,-84.0f,-2192.0f,1961.0f,0f,0f,0f,1400,-0.15535216f,-0.33023426f,-0.38425356f,-5.966295E-6f,-100.0f,0f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-113.0f,0f,0f,798.0f,0f,0f,0f,1.7794333f,0f,0f,0f,0f,0f,-14.715533f,3.1676145f,-11.61519f,249.0f,-629.0f,-487.0f,1,0f,0f,0f,-1.7699115E-4f,0f,0f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(-1133.0f,-590.0f,84.0f,0f,7.0f,-400.0f,0f,-235.0f,0f,0f,0f,0f,0f,-127.0f,-278.0f,-164.0f,0f,0f,0f,-882,-86.4434f,76.312904f,-62.418755f,68.70724f,-86.6767f,-76.46865f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(-1139.0f,-8.0f,0f,0f,179.0f,-1420.0f,0f,-585.0f,0f,0f,0f,0f,0f,200.0f,-75.0f,361.0f,0f,0f,0f,14,100.0f,-100.0f,-99.67116f,100.0f,-1.4263496E-5f,0f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(-114.0f,-58.0f,0f,0f,729.0f,-222.0f,0f,-893.0f,0f,0f,0f,0f,0f,-502.0f,612.0f,898.0f,0f,0f,0f,-199,56.189453f,-55.311172f,69.1064f,-33.129505f,-63.409412f,0f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(-1145.0f,-764.0f,0f,0f,65.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,119.0f,1313.0f,198.0f,0f,0f,0f,1599,-0.033703946f,-0.054383297f,0.23218767f,-3.0314453f,100.0f,0f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(-1151.0f,0f,0f,0f,542.0f,383.0f,-476.0f,0f,0f,0f,0f,0f,0f,-851.0f,-785.0f,492.0f,-324.0f,-448.0f,77.0f,2,70.82769f,73.240486f,-97.55619f,40.36465f,0f,0f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(-1153.0f,-489.0f,2378.0f,0f,243.0f,-1115.0f,0f,930.0f,0f,0f,0f,0f,0f,-574.0f,628.0f,-1676.0f,-75.0f,-130.0f,-274.0f,-1340,-0.6403762f,0.10646702f,0.41037065f,46.146473f,-48.308784f,55.461964f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(-1158.0f,-302.0f,0f,0f,591.0f,-1314.0f,0f,1.0f,0f,0f,0f,0f,0f,2397.0f,-278.0f,361.0f,0f,0f,0f,315,-0.59220505f,2.3790908f,-0.10585579f,-0.3821727f,-9.481542f,0f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(-1161.0f,702.0f,13.0f,0f,602.0f,-683.0f,0f,849.0f,0f,0f,0f,0f,0f,-535.0f,1333.0f,-989.0f,337.0f,-209.0f,1844.0f,35,0.8313726f,0.19141251f,0.48830646f,-119.91077f,-38.14402f,8.175801f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(1164.0f,-62.0f,0f,0f,255.0f,-965.0f,0f,-1.0f,0f,0f,0f,0f,0f,-675.0f,16.0f,-792.0f,0f,0f,0f,1221,-0.08290771f,-0.05790617f,0.34422094f,32.418587f,100.0f,0f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(117.0f,246.0f,0f,0f,106.0f,-2.0f,0f,-2230.0f,0f,0f,0f,0f,0f,-589.0f,1982.0f,525.0f,0f,0f,0f,411,0.52504987f,0.28253055f,-0.52716017f,5.0396676f,-98.11877f,0f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(-1180.0f,19.0f,0f,0f,1777.0f,-785.0f,0f,-3.0f,0f,0f,0f,0f,0f,854.0f,-618.0f,-918.0f,0f,0f,0f,2039,-0.058840327f,-0.3264351f,0.1650188f,-63.75581f,18.799278f,0f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(-118.0f,0f,0f,0f,5.1782517f,-99.759315f,0f,-21.340586f,0f,0f,0f,0f,0f,128.97455f,-48.433983f,-45.084274f,0f,0f,0f,1,-168.16658f,-81.38659f,-34.758892f,71.02401f,0f,0f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(-1181.0f,0f,-14.0f,0f,13.0f,-49.0f,0f,-951.0f,0f,0f,0f,0f,0f,132.0f,37.0f,-214.0f,0f,0f,0f,-8,99.297f,-56.58224f,53.069946f,100.0f,0f,-0.0020166968f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(119.0f,0f,0f,0f,75.98601f,0.0f,0f,-71.15499f,0f,0f,0f,0f,0f,16.041903f,96.98477f,-4.000318f,0f,0f,0f,1,100.0f,69.64315f,-9.243165f,-65.35197f,0f,0f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(-1191.0f,0f,0f,0f,549.0f,-1299.0f,0f,250.0f,0f,0f,0f,0f,0f,249.0f,1771.0f,-1280.0f,-1428.0f,796.0f,-1209.0f,-420,0.1456311f,0.44660315f,0.86576164f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(-1192.0f,-1118.0f,0f,0f,207.0f,-1042.0f,0f,1.0f,0f,0f,0f,0f,0f,-683.0f,-839.0f,-1486.0f,0f,0f,0f,6,-38.82484f,81.55988f,-3.436794f,33.706158f,37.96374f,0f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(-1192.0f,-1815.0f,0f,0f,187.0f,-9.0f,0f,331.0f,0f,0f,0f,0f,0f,-77.0f,-691.0f,-640.0f,-175.0f,-1435.0f,766.0f,287,30.614439f,76.22985f,-85.987724f,22.792831f,21.58982f,0f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(-1212.0f,0f,0f,0f,60.88375f,0.0f,0f,-2.8736656f,0f,0f,0f,0f,0f,-5.6144624f,-26.204865f,16.069553f,0f,0f,0f,2255,-0.2591092f,0.70012856f,-0.26164073f,-16.05978f,0f,0f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(1213.0f,-823.0f,1082.0f,0f,284.0f,957.0f,0f,554.0f,0f,0f,0f,0f,0f,-324.0f,-76.0f,-144.0f,-144.0f,563.0f,-909.0f,1126,-50.250355f,83.73799f,68.86825f,-68.061676f,11.681017f,-5.3372703f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(1215.0f,583.0f,0f,0f,1222.0f,-475.0f,0f,0.0f,0f,0f,0f,0f,0f,131.0f,-862.0f,384.0f,0f,0f,0f,-361,-23.884752f,-41.490623f,-84.989624f,38.83669f,-90.99662f,0f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(-1217.0f,-531.0f,-42.0f,0f,217.0f,-3028.0f,0f,657.0f,0f,0f,0f,0f,0f,-568.0f,971.0f,1549.0f,118.0f,422.0f,701.0f,706,-0.52289546f,0.5109844f,-0.51205325f,100.0f,-78.07752f,21.449528f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(-1219.0f,0f,0f,0f,9.364571f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-88.09072f,-32.35118f,29.542238f,0f,0f,0f,1,43.429546f,19.96435f,-21.06554f,-13.460931f,0f,0f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(1221.0f,-1274.0f,0f,0f,530.0f,-1112.0f,0f,741.0f,0f,0f,0f,0f,0f,213.0f,456.0f,-322.0f,214.0f,-1367.0f,976.0f,692,-0.006339942f,-0.1451661f,0.5466272f,18.93016f,32.924892f,0f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(-1227.0f,-2115.0f,0f,0f,9.0f,1147.0f,0f,1372.0f,0f,0f,0f,0f,0f,-755.0f,-57.0f,-1185.0f,1331.0f,385.0f,276.0f,746,0.099036165f,0.62144566f,-0.059415977f,-80.63689f,14.466676f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-123.0f,1612.0f,-1440.0f,-1488.0f,0f,0f,0f,-66.61729f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-55.043007f,-8.590739f,-19.43875f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(123.0f,46.0f,0f,0f,232.0f,1.0f,0f,-774.0f,0f,0f,0f,0f,0f,-168.0f,28.0f,1082.0f,0f,0f,0f,20,88.16755f,108.402245f,-116.557175f,55.304554f,14.213327f,0f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(125.0f,-1386.0f,0f,0f,6.0f,-634.0f,0f,546.0f,0f,0f,0f,0f,0f,1074.0f,665.0f,-1052.0f,-325.0f,-1948.0f,-1124.0f,-729,0.40683776f,-0.74141455f,1.2203377f,-4.0616536f,4.613913f,0f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(125.0f,-801.0f,0f,0f,-524.0f,906.0f,189.0f,-17.0f,0f,0f,0f,0f,0f,386.0f,349.0f,239.0f,-486.0f,64.0f,758.0f,-914,89.32969f,94.561714f,-32.702053f,-58.01399f,-60.560684f,0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(-1258.0f,-20.0f,0f,0f,18.0f,-1948.0f,0f,34.0f,0f,0f,0f,0f,0f,1459.0f,-529.0f,-672.0f,-940.0f,256.0f,744.0f,-403,-0.893552f,-0.43680713f,0.10375136f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(1262.0f,751.0f,192.0f,0f,440.0f,-583.0f,0f,-1074.0f,0f,0f,0f,0f,0f,-525.0f,957.0f,933.0f,0f,0f,0f,1421,13.984921f,-54.193703f,63.457085f,100.0f,100.0f,85.18231f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(-127.0f,0f,0f,0f,39.474365f,0.0f,0f,-31.670935f,0f,0f,0f,0f,0f,-30.298464f,17.900259f,35.771324f,0f,0f,0f,-744,52.042694f,51.489624f,18.31456f,-4.892733f,0f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(-127.0f,-580.0f,0f,0f,404.0f,-1656.0f,0f,-254.0f,0f,0f,0f,0f,0f,67.0f,1027.0f,185.0f,0f,0f,0f,9,-100.0f,-81.965096f,-41.167473f,36.92424f,73.859764f,0f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(-1280.0f,773.0f,0f,0f,815.0f,2688.0f,0f,549.0f,0f,0f,0f,0f,0f,-884.0f,-233.0f,-683.0f,-2174.0f,564.0f,1518.0f,291,12.83318f,55.6563f,-35.596558f,30.729856f,-25.606844f,0f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(-128.0f,498.0f,-820.0f,0f,198.0f,-781.0f,0f,940.0f,0f,0f,0f,0f,0f,-552.0f,74.0f,-819.0f,88.0f,-971.0f,-886.0f,-717,-64.74187f,85.97861f,53.13316f,13.540262f,-64.25942f,-14.459491f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(128.0f,-744.0f,757.0f,0f,114.0f,241.0f,0f,268.0f,0f,0f,0f,0f,0f,179.0f,-121.0f,-1072.0f,-1156.0f,-620.0f,-616.0f,86,30.603806f,-39.70244f,9.591489f,2.5508866f,6.9026976f,13.382737f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(130.0f,-425.0f,-1193.0f,58.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.32626E-4f,-56.493336f,36.240875f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(-1302.0f,0f,0f,0f,71.0f,-983.0f,0f,1162.0f,0f,0f,0f,0f,0f,-634.0f,-767.0f,-1308.0f,-554.0f,-573.0f,242.0f,-952,0.5825893f,-0.2917719f,-0.08135608f,-1.0316008f,0f,0f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(-13.0f,0f,0f,0f,8.010753f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,0.32044536f,92.74517f,0f,0f,0f,3,-66.94983f,-100.0f,29.959045f,1.2612995E-4f,0f,0f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(-13.0f,1.0f,0f,-2.0f,0f,0f,0f,3.837966E-26f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.03846154f,-0.5f,0f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(131.0f,-727.0f,0f,0f,256.0f,3.0f,0f,-465.0f,0f,0f,0f,0f,0f,-669.0f,227.0f,786.0f,0f,0f,0f,-1386,-47.49783f,5.758651f,-42.090664f,71.30973f,-58.159058f,0f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(1312.0f,-187.0f,10.0f,0f,725.0f,-91.0f,0f,-851.0f,0f,0f,0f,0f,0f,383.0f,315.0f,-793.0f,0f,0f,0f,-61,-0.55865747f,0.8604487f,0.6601807f,99.35007f,55.96855f,3.8248258f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(-1317.0f,0f,0f,0f,186.0f,-1411.0f,0f,2209.0f,0f,0f,0f,0f,0f,-100.0f,-2079.0f,328.0f,1050.0f,1688.0f,-1675.0f,560,0.10596723f,0.34550804f,0.29136947f,-11.418903f,0f,0f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(-133.0f,0f,0f,0f,149.0f,-11.0f,0f,1377.0f,0f,0f,0f,0f,0f,-602.0f,661.0f,-1574.0f,2891.0f,-38.0f,645.0f,-809,0.62900513f,-0.9666243f,-0.64650553f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(-1336.0f,0f,0f,0f,112.0f,95.0f,0f,-914.0f,0f,0f,0f,0f,0f,1946.0f,-97.0f,-961.0f,-1325.0f,642.0f,-332.0f,786,-0.35497528f,0.06916611f,0.30057f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(1350.0f,-658.0f,0f,0f,1099.0f,2.0f,0f,-1427.0f,0f,0f,0f,0f,0f,-624.0f,385.0f,-661.0f,0f,0f,0f,17,5.784295f,11.728168f,84.69317f,-121.03873f,-4.052271f,0f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(-1352.0f,1108.0f,0f,0f,179.0f,1754.0f,-2420.0f,-2.0f,0f,0f,0f,0f,0f,-291.0f,623.0f,-724.0f,1345.0f,1920.0f,-189.0f,-24,12.245025f,-186.44014f,5.798054f,61.554825f,-41.505093f,0f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(1360.0f,-356.0f,0f,0f,393.0f,-1596.0f,0f,4.0f,0f,0f,0f,0f,0f,-903.0f,320.0f,-426.0f,0f,0f,0f,-686,-6.733624f,-27.088943f,-6.0751166f,-60.137283f,-18.53624f,0f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(136.0f,-118.0f,-828.0f,0f,598.0f,233.0f,0f,233.0f,0f,0f,0f,0f,0f,-451.0f,-1669.0f,-690.0f,-818.0f,467.0f,244.0f,332,-0.46065548f,0.6804178f,-0.3743823f,22.795082f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(1365.0f,-362.0f,-1902.0f,0f,790.0f,257.0f,0f,260.0f,0f,0f,0f,0f,0f,-841.0f,400.0f,404.0f,-123.0f,488.0f,739.0f,821,-41.097115f,-50.41675f,-35.6336f,70.78652f,23.913464f,49.95862f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(1370.0f,1398.0f,-362.0f,0f,1249.0f,1049.0f,0f,-716.0f,0f,0f,0f,0f,0f,-462.0f,40.0f,-1110.0f,-1329.0f,-234.0f,1327.0f,-52,-0.50785357f,-0.26263985f,0.21254656f,-86.6368f,-35.456272f,-4.68138f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(1389.0f,-75.0f,235.0f,0f,635.0f,-794.0f,0f,163.0f,0f,0f,0f,0f,0f,154.0f,-711.0f,-877.0f,419.0f,-73.0f,-556.0f,-491,0.046410058f,-0.020955741f,0.25480554f,-82.75108f,15.29746f,-100.0f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(-1403.0f,0f,0f,0f,397.0f,-1.0f,0f,383.0f,0f,0f,0f,0f,0f,407.0f,137.0f,1084.0f,-1028.0f,-536.0f,-964.0f,487,-0.688981f,-0.36143932f,-0.13413519f,73.68172f,0f,0f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(-1405.0f,-968.0f,1533.0f,0f,993.0f,47.0f,0f,-7.0f,0f,0f,0f,0f,0f,14.0f,-1345.0f,-247.0f,-473.0f,154.0f,755.0f,150,0.39974338f,0.79391825f,-0.393057f,-33.022663f,-24.725874f,45.75611f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(1408.0f,-832.0f,0f,0f,601.0f,-798.0f,0f,0.0f,0f,0f,0f,0f,0f,-1104.0f,1015.0f,-1352.0f,0f,0f,0f,4,36.927895f,-33.411884f,-98.926994f,44.40304f,-85.149445f,0f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(-14.0f,0f,0f,0f,1544.0f,557.0f,0f,993.0f,0f,0f,0f,0f,0f,-1876.0f,985.0f,-12.0f,527.0f,-385.0f,532.0f,-46,0.031459495f,0.05994814f,0.0025752275f,-71.9819f,0f,0f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(-14.0f,-1.0f,-17.0f,146.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,0f,0f,0f,-4.892368E-4f,-0.001010101f,1.869159E-5f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(-1411.0f,9.0f,-2479.0f,0f,920.0f,-496.0f,0f,525.0f,0f,0f,0f,0f,0f,1314.0f,-648.0f,995.0f,-523.0f,-1209.0f,1942.0f,-863,-42.948105f,-97.94307f,-7.068643f,-2.1972246f,100.0f,43.60252f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(1417.0f,-623.0f,821.0f,0f,1489.0f,-1918.0f,0f,-1566.0f,0f,0f,0f,0f,0f,409.0f,283.0f,395.0f,0f,0f,0f,-1004,0.36857665f,0.594942f,-0.8078897f,-79.589836f,100.0f,36.523666f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(142.0f,-537.0f,931.0f,0f,590.0f,-674.0f,0f,-718.0f,0f,0f,0f,0f,0f,-833.0f,-989.0f,-390.0f,0f,0f,0f,315,62.13197f,5.164501f,-25.33231f,-34.06915f,65.48765f,-1.1207923f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(1421.0f,0f,0f,0f,278.0f,-1025.0f,0f,609.0f,0f,0f,0f,0f,0f,276.0f,-1612.0f,-277.0f,-857.0f,-858.0f,58.0f,864,-0.9206539f,0.1836991f,-0.2721532f,-17.732822f,0f,0f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(-143.0f,0f,0f,0f,85.91334f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,42.65111f,0.7116802f,87.97806f,0f,0f,0f,1114,26.728567f,47.595608f,-13.342826f,-28.478409f,0f,0f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(-143.0f,20.0f,422.0f,0f,46.0f,760.0f,0f,-1465.0f,0f,0f,0f,0f,0f,1305.0f,-176.0f,-792.0f,-760.0f,502.0f,636.0f,-17,0.20157956f,0.25840768f,0.92918134f,97.66236f,0.3582318f,19.56102f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(-1436.0f,-1049.0f,-469.0f,0f,865.0f,-285.0f,0f,-1232.0f,0f,0f,0f,0f,0f,2084.0f,-1026.0f,848.0f,0f,0f,0f,21,0.96528375f,2.2108843f,0.302731f,-100.0f,-68.53713f,-121.51333f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(1448.0f,244.0f,550.0f,0f,46.0f,-732.0f,0f,1461.0f,0f,0f,0f,0f,0f,860.0f,110.0f,-62.0f,-1150.0f,-200.0f,-912.0f,-786,0.8886283f,45.303246f,92.702866f,100.0f,55.642708f,25.643164f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(-1451.0f,0f,0f,0f,100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,-10.277287f,100.0f,0f,0f,0f,-1492,0.6887556f,-0.3436205f,0.63839024f,-56.32434f,0f,0f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(1457.0f,-1136.0f,0f,0f,598.0f,-1.0f,0f,-89.0f,0f,0f,0f,0f,0f,-1496.0f,1635.0f,691.0f,0f,0f,0f,378,-0.2165531f,-0.53414935f,0.7914896f,100.0f,11.078774f,0f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(146.0f,-358.0f,0f,0f,538.0f,-963.0f,0f,-1409.0f,0f,0f,0f,0f,0f,582.0f,-513.0f,-587.0f,0f,0f,0f,4,100.0f,49.474285f,100.0f,100.0f,-2.7302246E-8f,0f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(1469.0f,403.0f,0f,0f,48.0f,50.0f,0f,-124.0f,0f,0f,0f,0f,0f,-704.0f,956.0f,9.0f,-456.0f,478.0f,823.0f,-564,-67.98525f,-49.945618f,-12.623227f,-51.51792f,27.462997f,0f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(1477.0f,854.0f,0f,0f,894.0f,-322.0f,0f,-1745.0f,0f,0f,0f,0f,0f,542.0f,616.0f,726.0f,0f,0f,0f,-275,-1.8809628f,1.1391894f,0.43766007f,57.81997f,100.0f,0f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(1478.0f,-1467.0f,-943.0f,0f,662.0f,83.0f,0f,977.0f,0f,0f,0f,0f,0f,-245.0f,380.0f,90.0f,-488.0f,-1703.0f,-173.0f,1627,2.3602707f,1.9696753f,-1.8912252f,100.0f,-86.86684f,-100.0f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(148.0f,184.0f,-476.0f,0f,469.0f,589.0f,0f,805.0f,0f,0f,0f,0f,0f,-946.0f,-417.0f,-644.0f,916.0f,-153.0f,1152.0f,-290,43.68751f,-100.0f,61.084618f,23.41292f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(-1484.0f,1276.0f,-1393.0f,0f,688.0f,-171.0f,0f,2.0f,0f,0f,0f,0f,0f,-551.0f,-121.0f,242.0f,1336.0f,-310.0f,839.0f,128,18.034443f,-55.62718f,13.248306f,-73.92188f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(-1496.0f,43.0f,0f,0f,18.0f,3.0f,0f,-3.0f,0f,0f,0f,0f,0f,979.0f,1465.0f,-1063.0f,0f,0f,0f,-873,0.684081f,-0.60826534f,-0.17487703f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(-1511.0f,1615.0f,0f,0f,893.0f,-1.0f,0f,-13.0f,0f,0f,0f,0f,0f,976.0f,250.0f,421.0f,0f,0f,0f,663,0.11320428f,0.2611962f,-0.60020167f,-142.60562f,15.307716f,0f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(-1524.0f,-38.0f,-531.0f,0f,688.0f,251.0f,0f,-786.0f,0f,0f,0f,0f,0f,685.0f,-657.0f,910.0f,721.0f,275.0f,174.0f,-13,-23.505852f,-27.63727f,-2.259537f,-76.75158f,-93.035065f,-53.173664f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(-1534.0f,235.0f,154.0f,0f,1949.0f,-367.0f,0f,-813.0f,0f,0f,0f,0f,0f,777.0f,772.0f,-37.0f,0f,0f,0f,653,-0.5640588f,0.14040685f,-0.14848813f,100.0f,-14.9173155f,-86.846725f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(1535.0f,-14.0f,0f,0f,621.0f,406.0f,0f,-1430.0f,0f,0f,0f,0f,0f,-683.0f,205.0f,1431.0f,-724.0f,291.0f,-302.0f,497,0.272865f,-1.2088319f,0.303408f,-31.266197f,-0.36764744f,0f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(-1543.0f,647.0f,0f,0f,718.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,-141.0f,247.0f,143.0f,0f,0f,0f,226,-96.503296f,-54.7384f,-174.49129f,-57.3768f,-6.8190427f,0f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(-1558.0f,985.0f,0f,0f,710.0f,-1.0f,0f,-549.0f,0f,0f,0f,0f,0f,-745.0f,-3919.0f,699.0f,0f,0f,0f,-1402,0.80399376f,0.594602f,-0.00651797f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(-156.0f,1114.0f,0f,0f,172.0f,2749.0f,0f,1071.0f,0f,0f,0f,0f,0f,1649.0f,873.0f,203.0f,-64.0f,-1261.0f,-493.0f,-270,-0.4136495f,0.049705192f,-0.5558269f,59.159653f,100.0f,0f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(156.0f,-1589.0f,905.0f,0f,41.0f,370.0f,0f,-1706.0f,0f,0f,0f,0f,0f,-1525.0f,-202.0f,296.0f,-23.0f,-190.0f,843.0f,-1371,-8.329057f,87.78715f,16.997269f,-81.83116f,100.0f,100.0f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(1564.0f,217.0f,0f,0f,808.0f,-6.0f,0f,-39.0f,0f,0f,0f,0f,0f,952.0f,-83.0f,651.0f,0f,0f,0f,-757,-147.24825f,-26.133852f,100.0f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(1565.0f,0f,-1.0f,0f,891.0f,-1705.0f,0f,-131.0f,0f,0f,0f,0f,0f,137.0f,-876.0f,-367.0f,0f,0f,0f,1,-55.758774f,18.280901f,50.8227f,100.0f,0f,92.57557f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(1581.0f,-108.0f,0f,0f,96.0f,298.0f,-884.0f,-1.0f,0f,0f,0f,0f,0f,-427.0f,-1390.0f,-1509.0f,-306.0f,416.0f,-716.0f,40,40.96048f,59.9685f,67.298035f,1.0304669f,-90.059235f,0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(1587.0f,0f,0f,0f,42.4009f,-53.77508f,0f,-57.902203f,0f,0f,0f,0f,0f,-96.40263f,43.666103f,100.0f,0f,0f,0f,638,0.25552312f,-0.85729283f,-0.12806423f,56.69059f,0f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(159.0f,1319.0f,0f,0f,1254.0f,5.0f,0f,-4.0f,0f,0f,0f,0f,0f,-1130.0f,257.0f,-514.0f,0f,0f,0f,8,96.17645f,58.68709f,-16.039467f,-56.491013f,21.59614f,0f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(-1591.0f,978.0f,0f,0f,438.0f,744.0f,0f,-1267.0f,0f,0f,0f,0f,0f,-479.0f,-968.0f,-238.0f,-578.0f,-265.0f,-125.0f,998,20.158913f,14.005151f,-97.53406f,-29.397709f,47.8732f,0f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(-1595.0f,-948.0f,0f,0f,825.0f,-229.0f,0f,949.0f,0f,0f,0f,0f,0f,467.0f,-695.0f,-892.0f,103.0f,34.0f,-1467.0f,-650,-0.12735112f,0.630321f,-0.15130809f,6.4543447f,-6.6946244f,0f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(1597.0f,-1781.0f,0f,-98.0f,0f,0f,0f,-67.13878f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.3895313E-6f,91.81079f,0f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(16.0f,0f,0f,0f,55.886913f,-54.527542f,0f,-67.442245f,0f,0f,0f,0f,0f,-28.403597f,37.32271f,-63.094177f,0f,0f,0f,872,16.041035f,-94.24323f,-62.969925f,87.926956f,0f,0f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(16.0f,-896.0f,0f,0f,965.0f,-727.0f,0f,-3.0f,0f,0f,0f,0f,0f,814.0f,-204.0f,-361.0f,0f,0f,0f,-860,0.008466044f,0.27515787f,0.26703644f,-56.6046f,-100.0f,0f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(161.0f,357.0f,0f,-713.0f,0f,0f,0f,-85.54124f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-77.09676f,-3.92864E-6f,0f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(1616.0f,926.0f,0f,0f,1489.0f,-1.0f,0f,-2.0f,0f,0f,0f,0f,0f,1047.0f,-1086.0f,157.0f,0f,0f,0f,-1,-77.48034f,39.819138f,73.61857f,98.84213f,44.77529f,0f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(162.0f,0f,0f,0f,190.0f,223.0f,0f,28.0f,0f,0f,0f,0f,0f,-343.0f,495.0f,358.0f,-441.0f,-212.0f,748.0f,-160,79.77372f,31.014828f,33.54762f,92.7374f,0f,0f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(-162.0f,0f,0f,0f,687.0f,-995.0f,246.0f,-880.0f,0f,0f,0f,0f,0f,-837.0f,737.0f,-723.0f,-117.0f,-965.0f,-397.0f,562,-57.64454f,-83.07801f,-22.621752f,10.862585f,0f,0f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(1630.0f,1071.0f,66.0f,0f,395.0f,-111.0f,0f,480.0f,0f,0f,0f,0f,0f,994.0f,610.0f,665.0f,-117.0f,-702.0f,230.0f,-922,-0.0020559498f,-0.087034605f,-0.021047475f,85.67318f,-96.37647f,-25.796583f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(1636.0f,0f,0f,0f,0.6263967f,-16.808027f,0f,-31.296095f,0f,0f,0f,0f,0f,-78.130295f,-23.322859f,-100.0f,0f,0f,0f,1,59.517273f,24.319063f,-41.367283f,80.59997f,0f,0f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(1636.0f,0f,0f,0f,100.0f,-100.0f,0f,-15.022825f,0f,0f,0f,0f,0f,12.946798f,-69.08916f,-2.0034301f,0f,0f,0f,-1,-68.48172f,-13.184924f,12.13736f,16.879665f,0f,0f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(-1646.0f,-1950.0f,-161.0f,0f,117.0f,-1117.0f,0f,2070.0f,0f,0f,0f,0f,0f,-1102.0f,492.0f,-1248.0f,1108.0f,929.0f,-972.0f,361,0.9411378f,-0.18160209f,0.25809288f,100.0f,-18.558065f,18.091196f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(165.0f,0f,0f,0f,33.234173f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-38.06212f,37.280933f,-34.20045f,0f,0f,0f,81,-1.809613f,-71.19661f,-37.748745f,73.08459f,0f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(-165.0f,-206.0f,0f,401.0f,0f,0f,0f,3.9443045E-31f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(-1651.0f,720.0f,118.0f,0f,53.0f,-1459.0f,0f,733.0f,0f,0f,0f,0f,0f,-414.0f,-251.0f,575.0f,25.0f,-609.0f,87.0f,-799,0.12366248f,-0.31628492f,-0.8901715f,-60.45242f,-74.83718f,-6.173047f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(166.0f,0f,0f,0f,0.3666103f,0.0f,0f,6.938894E-18f,0f,0f,0f,0f,0f,95.22478f,77.309425f,-56.755985f,0f,0f,0f,8,-31.943432f,19.202885f,-26.894567f,0.25280976f,0f,0f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(-166.0f,1410.0f,-1072.0f,0f,312.0f,376.0f,0f,135.0f,0f,0f,0f,0f,0f,156.0f,500.0f,536.0f,-83.0f,704.0f,1060.0f,-406,75.995636f,-56.2026f,30.309666f,-23.987242f,-74.3269f,55.729446f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(1665.0f,0f,0f,0f,20.579453f,0.0f,0f,-32.813538f,0f,0f,0f,0f,0f,-73.18364f,21.280432f,98.64714f,0f,0f,0f,2,-48.58715f,-38.132427f,-27.819458f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(1665.0f,258.0f,0f,0f,1310.0f,1153.0f,0f,-871.0f,0f,0f,0f,0f,0f,661.0f,786.0f,-29.0f,532.0f,-618.0f,-853.0f,-953,0.2797269f,-0.23533164f,0.59785324f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(1675.0f,112.0f,-1199.0f,0f,336.0f,-1593.0f,0f,1532.0f,0f,0f,0f,0f,0f,-810.0f,870.0f,-502.0f,11.0f,-780.0f,-1056.0f,1127,-0.16173692f,-0.46919233f,-0.40070692f,-11.680485f,44.436844f,53.727814f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(-168.0f,-880.0f,0f,0f,50.0f,-715.0f,0f,349.0f,0f,0f,0f,0f,0f,580.0f,-920.0f,-59.0f,511.0f,-535.0f,-414.0f,-231,100.0f,100.0f,100.0f,-55.497f,-66.576614f,0f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(1692.0f,616.0f,0f,0f,1445.0f,0.0f,0f,2.0f,0f,0f,0f,0f,0f,-974.0f,-1497.0f,921.0f,0f,0f,0f,-247,-0.3403256f,-0.84222645f,-1.728871f,-32.058475f,-22.63784f,0f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(-1695.0f,-418.0f,-641.0f,0f,149.0f,667.0f,0f,566.0f,0f,0f,0f,0f,0f,-52.0f,-874.0f,965.0f,490.0f,508.0f,-812.0f,-130,60.191113f,56.51314f,34.172966f,16.568277f,-25.302446f,51.37709f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(1697.0f,642.0f,0f,0f,931.0f,-505.0f,0f,-87.0f,0f,0f,0f,0f,0f,-259.0f,-492.0f,817.0f,0f,0f,0f,-1,-30.23688f,60.855442f,-7.004446f,-16.103106f,-82.14217f,0f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(-170.0f,0f,0f,0f,404.0f,330.0f,-1472.0f,-3.0f,0f,0f,0f,0f,0f,266.0f,1448.0f,330.0f,-1028.0f,921.0f,959.0f,-123,-80.64472f,-135.22871f,40.628006f,-40.72111f,0f,0f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(1702.0f,635.0f,0f,0f,280.0f,-871.0f,0f,2291.0f,0f,0f,0f,0f,0f,-1694.0f,217.0f,360.0f,1395.0f,-1183.0f,111.0f,-66,0.79089797f,0.262064f,-0.15402317f,-86.071594f,-83.84336f,0f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(-17.0f,0f,0f,0f,0.08626399f,-10.925625f,0f,-46.800144f,0f,0f,0f,0f,0f,-5.488583f,0.68847793f,72.08672f,0f,0f,0f,1,-100.0f,95.06125f,-21.187895f,-0.10425063f,0f,0f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(-17.0f,-715.0f,478.0f,977.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.020832E-5f,-80.782845f,8.929678f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(-171.0f,575.0f,0f,0f,4.0f,-464.0f,0f,-1301.0f,0f,0f,0f,0f,0f,-518.0f,-129.0f,971.0f,0f,0f,0f,-4,26.817894f,62.6416f,22.628157f,-0.09988007f,-4.546995E-5f,0f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(1713.0f,-835.0f,2043.0f,0f,1797.0f,-1580.0f,0f,1.0f,0f,0f,0f,0f,0f,525.0f,809.0f,246.0f,0f,0f,0f,36,100.0f,-95.30284f,100.0f,0.20517945f,100.0f,100.0f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(-1719.0f,0f,0f,0f,463.0f,220.0f,0f,-559.0f,0f,0f,0f,0f,0f,-2165.0f,942.0f,-453.0f,13.0f,-315.0f,372.0f,59,0.7946109f,0.5624631f,0.22853598f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(1723.0f,712.0f,63.0f,0f,9.0f,-513.0f,0f,-2.0f,0f,0f,0f,0f,0f,-289.0f,-440.0f,-626.0f,0f,0f,0f,1254,4.929063f,-53.002453f,34.978565f,0.3913816f,-86.241844f,24.854525f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(1738.0f,609.0f,0f,0f,530.0f,-2.0f,0f,1.0f,0f,0f,0f,0f,0f,-482.0f,1473.0f,-432.0f,0f,0f,0f,99,-24.037924f,-73.791374f,98.13958f,-109.748055f,100.0f,0f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(174.0f,0f,0f,0f,38.906006f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-99.61248f,-100.0f,-0.6820763f,0f,0f,0f,-3,31.833647f,-31.117958f,-86.83647f,4.0585303f,0f,0f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(-1749.0f,-1472.0f,-201.0f,0f,1582.0f,-1273.0f,0f,1059.0f,0f,0f,0f,0f,0f,875.0f,879.0f,-202.0f,523.0f,-451.0f,695.0f,573,7.1012735f,-6.880025f,0.8221418f,-47.677452f,-66.76503f,-46.969704f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(1750.0f,0f,0f,0f,1107.0f,-272.0f,0f,128.0f,0f,0f,0f,0f,0f,-980.0f,-283.0f,-789.0f,368.0f,-1148.0f,469.0f,1493,-0.15909296f,0.9338277f,0.33043444f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(1755.0f,-1528.0f,1790.0f,0f,268.0f,-61.0f,0f,-881.0f,0f,0f,0f,0f,0f,885.0f,361.0f,-577.0f,0f,0f,0f,545,-0.099873014f,-0.648734f,0.67862296f,89.668976f,-5.1490173f,-100.0f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(-1758.0f,-558.0f,0f,0f,892.0f,238.0f,-493.0f,-1386.0f,0f,0f,0f,0f,0f,-40.0f,1684.0f,633.0f,-154.0f,696.0f,-495.0f,-1504,-0.6914658f,-0.21268956f,-0.6748991f,37.38353f,86.857285f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(-1767.0f,0f,0f,0f,1849.0f,710.0f,-1319.0f,-320.0f,0f,0f,0f,0f,0f,2117.0f,-607.0f,145.0f,574.0f,-291.0f,-1290.0f,-243,0.08535334f,0.4667304f,0.18866813f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(177.0f,-642.0f,-611.0f,0f,325.0f,2919.0f,0f,-846.0f,0f,0f,0f,0f,0f,-513.0f,-134.0f,739.0f,1320.0f,1975.0f,300.0f,-58,-0.4816146f,-0.0046237754f,-0.8290373f,36.025723f,100.0f,-19.430084f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(1771.0f,-1323.0f,0f,0f,763.0f,-790.0f,0f,-218.0f,0f,0f,0f,0f,0f,448.0f,-749.0f,479.0f,0f,0f,0f,838,9.456335f,24.036928f,28.741589f,34.316357f,-98.178986f,0f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(1795.0f,-2678.0f,-991.0f,0f,294.0f,992.0f,0f,-1762.0f,0f,0f,0f,0f,0f,-734.0f,363.0f,560.0f,556.0f,-1026.0f,53.0f,721,0.80430645f,1.449594f,0.1145684f,99.99988f,-100.0f,-54.116554f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(-180.0f,0f,0f,276.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,497.0f,-1939.0f,-336.0f,-1,0f,0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(-1805.0f,-231.0f,0f,0f,31.0f,0.0f,0f,-138.0f,0f,0f,0f,0f,0f,1004.0f,247.0f,266.0f,0f,0f,0f,-3,-49.495384f,88.93589f,-55.133705f,-0.74613434f,66.88961f,0f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(18.0f,-41.0f,-113.0f,0f,364.0f,-7.0f,0f,410.0f,0f,0f,0f,0f,0f,-300.0f,179.0f,923.0f,620.0f,108.0f,-488.0f,377,27.378546f,5.39113f,-62.25029f,-49.878853f,-63.609035f,43.225937f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(-18.0f,-72.0f,0f,0f,268.0f,-1062.0f,0f,1759.0f,0f,0f,0f,0f,0f,-1145.0f,122.0f,587.0f,557.0f,2261.0f,1964.0f,-965,-0.18561564f,-0.149831f,-0.33092085f,-99.99998f,46.229973f,0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(-183.0f,8.0f,0f,0f,270.0f,546.0f,0f,620.0f,0f,0f,0f,0f,0f,3152.0f,1008.0f,409.0f,-493.0f,1094.0f,145.0f,975,0.13971126f,-0.7005385f,0.5462344f,57.148174f,1.0928453E-5f,0f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(-185.0f,633.0f,965.0f,0f,29.0f,-848.0f,0f,-622.0f,0f,0f,0f,0f,0f,-316.0f,757.0f,710.0f,0f,0f,0f,786,-21.975348f,-99.70958f,-7.3441586f,-66.217186f,-33.30518f,82.01298f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(-1864.0f,466.0f,139.0f,0f,1355.0f,121.0f,0f,969.0f,0f,0f,0f,0f,0f,893.0f,-133.0f,637.0f,-322.0f,376.0f,815.0f,650,7.216601f,-88.41464f,-28.57729f,-21.690718f,38.251865f,-14.583321f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(188.0f,0f,0f,0f,260.0f,-871.0f,0f,709.0f,0f,0f,0f,0f,0f,-218.0f,258.0f,422.0f,-261.0f,304.0f,-852.0f,-89,48.18513f,-10.226994f,22.927515f,34.401756f,0f,0f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(1894.0f,-19.0f,790.0f,-417.0f,0f,0f,0f,7.888609E-31f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,-41.486115f,1.2621481E-4f,91.90824f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(-1901.0f,-365.0f,-947.0f,0f,831.0f,-110.0f,0f,309.0f,0f,0f,0f,0f,0f,-912.0f,-237.0f,641.0f,1373.0f,-436.0f,903.0f,-723,-0.027481245f,-0.45278558f,-0.24253532f,100.0f,7.3595777f,44.502876f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(-19.0f,-1068.0f,-33.0f,0f,6.0f,-254.0f,0f,239.0f,0f,0f,0f,0f,0f,1043.0f,-78.0f,-735.0f,942.0f,-3875.0f,1338.0f,1413,0.3979086f,0.19154157f,0.5443244f,105.64907f,100.0f,-207.54602f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(-191.0f,0f,0f,0f,75.42571f,0.0f,0f,-12.764429f,0f,0f,0f,0f,0f,-7.426678f,-47.743294f,-36.3592f,0f,0f,0f,-454,71.99034f,21.755514f,-28.289345f,73.5799f,0f,0f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(-191.0f,533.0f,-621.0f,0f,915.0f,-2207.0f,0f,251.0f,0f,0f,0f,0f,0f,-409.0f,-662.0f,378.0f,-369.0f,154.0f,-5.0f,459,56.08011f,-49.40433f,-25.843657f,-13.259241f,-72.445465f,-33.23269f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(194.0f,0f,0f,0f,291.0f,803.0f,-322.0f,38.0f,0f,0f,0f,0f,0f,522.0f,-460.0f,-178.0f,-799.0f,791.0f,-1520.0f,-938,-76.05117f,-53.086727f,-85.83604f,29.333445f,0f,0f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(-197.0f,0f,0f,0f,123.0f,-873.0f,706.0f,-271.0f,0f,0f,0f,0f,0f,347.0f,470.0f,300.0f,196.0f,667.0f,167.0f,939,-94.94941f,10.046656f,28.860207f,93.168274f,0f,0f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(-1976.0f,-372.0f,1853.0f,0f,1223.0f,-663.0f,0f,2570.0f,0f,0f,0f,0f,0f,111.0f,-768.0f,-2789.0f,1144.0f,1179.0f,-675.0f,-905,0.76428163f,0.6185016f,0.064244084f,-100.0f,-100.0f,11.701652f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(198.0f,-1727.0f,0f,0f,9.0f,-1109.0f,0f,-1156.0f,0f,0f,0f,0f,0f,912.0f,238.0f,644.0f,0f,0f,0f,-5,-100.0f,100.0f,100.0f,-58.46884f,-100.0f,0f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(-20.0f,0f,0f,0f,84.193794f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-93.17214f,-2.148597f,38.867085f,0f,0f,0f,2,-18.87707f,100.0f,-35.445747f,-38.89012f,0f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(201.0f,-112.0f,0f,0f,246.0f,54.0f,0f,-1722.0f,0f,0f,0f,0f,0f,-60.0f,-345.0f,-576.0f,62.0f,869.0f,827.0f,1110,-0.19019337f,0.4005755f,0.86340064f,67.175354f,73.839584f,0f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(-201.0f,-944.0f,0f,0f,110.0f,0.0f,0f,-1743.0f,0f,0f,0f,0f,0f,51.0f,-179.0f,-292.0f,0f,0f,0f,2151,89.75742f,-10.955821f,22.39288f,-100.0f,-23.858797f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(-2046.0f,2182.0f,0f,0f,1737.0f,-903.0f,0f,246.0f,0f,0f,0f,0f,0f,1453.0f,-188.0f,-739.0f,936.0f,887.0f,-722.0f,402,-0.13030873f,-0.38924256f,-0.15718672f,100.0f,0.28831407f,0f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(2047.0f,9.0f,0f,0f,333.0f,3.0f,0f,-1090.0f,0f,0f,0f,0f,0f,621.0f,-253.0f,-415.0f,0f,0f,0f,1705,0.16466849f,-0.08799654f,0.30005363f,-53.66217f,0.5197967f,0f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-206.0f,0f,0f,210.0f,0f,0f,0f,63.951645f,0f,0f,0f,0f,0f,-61.591892f,100.0f,-68.146576f,-623.0f,-980.0f,-875.0f,-1,0f,0f,0f,6.171786f,0f,0f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(211.0f,721.0f,-491.0f,0f,517.0f,-173.0f,0f,722.0f,0f,0f,0f,0f,0f,491.0f,40.0f,-180.0f,854.0f,-953.0f,-213.0f,891,-50.633625f,13.967385f,80.5332f,40.31918f,20.26439f,27.879457f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(-2131.0f,124.0f,617.0f,0f,710.0f,666.0f,0f,1836.0f,0f,0f,0f,0f,0f,291.0f,-1196.0f,1729.0f,2140.0f,322.0f,-823.0f,411,-0.52545714f,0.78069735f,0.24963702f,38.287395f,-78.74895f,-51.997463f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(214.0f,350.0f,72.0f,0f,835.0f,110.0f,0f,817.0f,0f,0f,0f,0f,0f,341.0f,-510.0f,-315.0f,-315.0f,278.0f,-752.0f,-819,56.913292f,9.451948f,49.57233f,2.1689796f,76.31563f,-21.067823f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(2163.0f,559.0f,0f,0f,764.0f,-4.0f,0f,-770.0f,0f,0f,0f,0f,0f,-230.0f,-412.0f,672.0f,0f,0f,0f,-263,-25.307024f,60.39705f,28.360266f,-6.6413326f,4.807218E-7f,0f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(220.0f,-1805.0f,276.0f,0f,1029.0f,355.0f,0f,47.0f,0f,0f,0f,0f,0f,-808.0f,364.0f,380.0f,-2870.0f,-387.0f,558.0f,-1666,49.688484f,40.1604f,67.183975f,-24.221237f,-10.0750675f,65.28682f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(22.0f,-1547.0f,-1606.0f,6.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0.007575758f,99.22273f,-34.717957f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(-222.0f,0f,0f,0f,38.22628f,0.0f,0f,-57.070885f,0f,0f,0f,0f,0f,99.98781f,-29.34794f,-25.027548f,0f,0f,0f,-812,-0.18118629f,0.5096551f,-1.3214935f,-34.46557f,0f,0f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(224.0f,1438.0f,0f,0f,629.0f,-7.0f,0f,0.0f,0f,0f,0f,0f,0f,-571.0f,525.0f,-267.0f,0f,0f,0f,345,61.862827f,13.651843f,31.87556f,10.771652f,55.292896f,0f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(-224.0f,308.0f,107.0f,0f,302.0f,1089.0f,0f,-837.0f,0f,0f,0f,0f,0f,-595.0f,-251.0f,-542.0f,923.0f,1036.0f,68.0f,-335,0.39635336f,-0.585661f,-0.16389163f,64.91189f,2.910677f,0.3711562f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(2268.0f,0f,0f,0f,41.866802f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,43.452175f,-6.2086477f,-100.0f,0f,0f,0f,771,0.39491007f,0.061957102f,0.3653373f,-97.31535f,0f,0f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(-228.0f,0f,0f,571.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,48.516155f,0f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(228.0f,-686.0f,0f,0f,7.0f,-94.0f,0f,971.0f,0f,0f,0f,0f,0f,482.0f,346.0f,482.0f,127.0f,7.0f,871.0f,772,-32.90286f,-50.25352f,-3.017145f,-35.064255f,-11.895307f,0f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(2282.0f,0f,-5.0f,0f,24.0f,-1564.0f,0f,-386.0f,0f,0f,0f,0f,0f,-12.0f,107.0f,-117.0f,0f,0f,0f,-1,100.0f,67.8467f,64.935646f,30.446302f,0f,-7.43371E-4f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(229.0f,0f,0f,0f,-307.0f,777.0f,803.0f,0f,0f,0f,0f,0f,0f,-532.0f,27.0f,958.0f,539.0f,-71.0f,85.0f,687,4.6040196f,4.9374566f,73.0398f,-86.40962f,0f,0f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(23.0f,-690.0f,1476.0f,17.0f,0f,0f,0f,-10.010794f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0025575447f,-8.525149E-5f,100.0f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(-2320.0f,439.0f,-773.0f,0f,600.0f,974.0f,0f,276.0f,0f,0f,0f,0f,0f,-284.0f,594.0f,688.0f,752.0f,468.0f,87.0f,507,-88.38445f,-13.304283f,-24.997734f,-100.0f,-8.489605f,4.8801394f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(-233.0f,0f,0f,0f,81.54617f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,30.539572f,86.14595f,70.70575f,0f,0f,0f,-2,96.31726f,38.077194f,-88.29924f,-3.3193268E-4f,0f,0f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(-2352.0f,-2438.0f,-17.0f,0f,2353.0f,-1568.0f,0f,305.0f,0f,0f,0f,0f,0f,-372.0f,-873.0f,299.0f,460.0f,-1595.0f,-359.0f,-1610,0.008238928f,0.68182063f,-0.41039717f,58.164356f,73.04453f,-82.42791f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(236.0f,-443.0f,6.0f,11.0f,0f,0f,0f,-56.877346f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.8520803E-4f,-2.0521239E-4f,-99.99999f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(237.0f,1424.0f,-887.0f,0f,68.0f,-529.0f,0f,-1295.0f,0f,0f,0f,0f,0f,-62.0f,264.0f,1061.0f,0f,0f,0f,-1589,-0.14372301f,0.92224735f,-0.23787382f,81.29427f,13.51906f,100.0f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(237.0f,792.0f,-916.0f,-120.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.5161745E-5f,-100.0f,9.097525E-6f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(238.0f,0f,0f,0f,208.0f,395.0f,870.0f,951.0f,0f,0f,0f,0f,0f,756.0f,-457.0f,194.0f,-193.0f,279.0f,-1711.0f,598,-32.904053f,-69.72373f,-36.02227f,-69.077675f,0f,0f ) ;
  }

  @Test
  public void test1149() {
    TestDrivers.surfaceShade(240.0f,0f,0f,0f,476.0f,255.0f,0f,989.0f,0f,0f,0f,0f,0f,-728.0f,-945.0f,436.0f,704.0f,318.0f,439.0f,-483,-19.060747f,14.956552f,-10.461202f,1.8165309E-9f,0f,0f ) ;
  }

  @Test
  public void test1150() {
    TestDrivers.surfaceShade(-240.0f,-321.0f,-131.0f,0f,705.0f,120.0f,0f,38.0f,0f,0f,0f,0f,0f,921.0f,715.0f,871.0f,156.0f,-309.0f,523.0f,-851,57.408096f,-25.354311f,-39.890385f,79.577866f,-22.593876f,-11.232027f ) ;
  }

  @Test
  public void test1151() {
    TestDrivers.surfaceShade(2436.0f,0f,0f,0f,80.43196f,-59.30117f,0f,0.0f,0f,0f,0f,0f,0f,67.29046f,92.91713f,-99.75452f,0f,0f,0f,871,0.7564588f,-0.632137f,0.16784766f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1152() {
    TestDrivers.surfaceShade(-2436.0f,-130.0f,0f,0f,702.0f,-603.0f,0f,456.0f,0f,0f,0f,0f,0f,400.0f,-733.0f,-497.0f,388.0f,1141.0f,338.0f,842,95.485466f,71.1784f,-28.127926f,34.839756f,-58.238377f,0f ) ;
  }

  @Test
  public void test1153() {
    TestDrivers.surfaceShade(250.0f,-634.0f,0f,0f,150.0f,620.0f,0f,141.0f,0f,0f,0f,0f,0f,-849.0f,-871.0f,1449.0f,-794.0f,299.0f,-291.0f,-470,76.45359f,-20.346378f,-1.9290682f,20.163605f,44.804546f,0f ) ;
  }

  @Test
  public void test1154() {
    TestDrivers.surfaceShade(252.0f,0f,0f,0f,79.52695f,-69.56118f,0f,-1.4210855E-14f,0f,0f,0f,0f,0f,-20.152067f,23.573227f,-89.9057f,0f,0f,0f,2189,-0.17191382f,0.19032604f,0.9650513f,-98.71409f,0f,0f ) ;
  }

  @Test
  public void test1155() {
    TestDrivers.surfaceShade(255.0f,0f,0f,0f,587.0f,-1.0f,0f,537.0f,0f,0f,0f,0f,0f,-617.0f,-725.0f,-1096.0f,-747.0f,611.0f,591.0f,-274,-19.61188f,67.5241f,-13.703492f,-90.620316f,0f,0f ) ;
  }

  @Test
  public void test1156() {
    TestDrivers.surfaceShade(255.0f,566.0f,0f,0f,899.0f,587.0f,0f,993.0f,0f,0f,0f,0f,0f,-487.0f,507.0f,550.0f,741.0f,-347.0f,144.0f,452,86.84074f,37.274452f,42.529984f,26.060514f,12.132366f,0f ) ;
  }

  @Test
  public void test1157() {
    TestDrivers.surfaceShade(255.0f,615.0f,1820.0f,0f,1470.0f,610.0f,0f,110.0f,0f,0f,0f,0f,0f,888.0f,2042.0f,106.0f,41.0f,-76.0f,-517.0f,-225,-0.6186784f,0.23531179f,0.054474607f,-100.0f,-100.0f,100.0f ) ;
  }

  @Test
  public void test1158() {
    TestDrivers.surfaceShade(-257.0f,-447.0f,0f,0f,838.0f,-8.0f,0f,-164.0f,0f,0f,0f,0f,0f,-651.0f,-206.0f,-623.0f,0f,0f,0f,-7,94.64447f,-100.0f,-14.4913025f,38.27879f,-3.9248413E-8f,0f ) ;
  }

  @Test
  public void test1159() {
    TestDrivers.surfaceShade(257.0f,-450.0f,0f,0f,1105.0f,-1083.0f,0f,4.0f,0f,0f,0f,0f,0f,2231.0f,2303.0f,781.0f,0f,0f,0f,2,-51.3948f,-81.97777f,53.134254f,-100.0f,-25.422152f,0f ) ;
  }

  @Test
  public void test1160() {
    TestDrivers.surfaceShade(-2575.0f,-798.0f,0f,0f,1209.0f,-253.0f,0f,-3.0f,0f,0f,0f,0f,0f,752.0f,-359.0f,185.0f,0f,0f,0f,-17,0.02708055f,0.9456637f,-1.3352653f,64.65469f,100.0f,0f ) ;
  }

  @Test
  public void test1161() {
    TestDrivers.surfaceShade(-258.0f,-514.0f,592.0f,0f,336.0f,-934.0f,0f,982.0f,0f,0f,0f,0f,0f,907.0f,-646.0f,747.0f,588.0f,234.0f,-616.0f,-96,-50.0819f,28.697754f,-27.40441f,75.389366f,-80.25022f,68.79721f ) ;
  }

  @Test
  public void test1162() {
    TestDrivers.surfaceShade(259.0f,159.0f,-160.0f,0f,908.0f,1286.0f,0f,190.0f,0f,0f,0f,0f,0f,-378.0f,108.0f,845.0f,-1301.0f,-823.0f,1387.0f,2249,-39.96788f,78.19173f,-27.872858f,-66.79645f,1.9051541f,-42.138897f ) ;
  }

  @Test
  public void test1163() {
    TestDrivers.surfaceShade(26.0f,-1061.0f,0f,0f,104.0f,1.0f,0f,-81.0f,0f,0f,0f,0f,0f,1642.0f,-779.0f,571.0f,0f,0f,0f,7,-64.44394f,-110.16163f,-3.8240857f,-62.894543f,18.371151f,0f ) ;
  }

  @Test
  public void test1164() {
    TestDrivers.surfaceShade(262.0f,-931.0f,23.0f,0f,23.0f,-290.0f,0f,-1084.0f,0f,0f,0f,0f,0f,555.0f,-1522.0f,838.0f,0f,0f,0f,-162,0.7771179f,0.036804568f,-0.4478328f,62.847816f,-36.73435f,118.54675f ) ;
  }

  @Test
  public void test1165() {
    TestDrivers.surfaceShade(-264.0f,850.0f,0f,0f,1789.0f,1176.0f,21.0f,-1200.0f,0f,0f,0f,0f,0f,-1099.0f,-5.0f,-373.0f,115.0f,-948.0f,-402.0f,-220,0.8479611f,0.38083327f,-0.21708946f,87.99673f,-9.959634f,0f ) ;
  }

  @Test
  public void test1166() {
    TestDrivers.surfaceShade(2657.0f,-49.0f,0f,0f,4.0f,-1465.0f,0f,-407.0f,0f,0f,0f,0f,0f,921.0f,-227.0f,-1094.0f,0f,0f,0f,-2,-100.0f,76.36413f,-100.0f,22.682598f,-0.023660196f,0f ) ;
  }

  @Test
  public void test1167() {
    TestDrivers.surfaceShade(-2660.0f,-1748.0f,3.0f,0f,49.0f,1262.0f,0f,2231.0f,0f,0f,0f,0f,0f,-427.0f,2071.0f,-373.0f,-1635.0f,-2254.0f,-1127.0f,-117,0.25502083f,-0.040255055f,-0.51544785f,-89.2711f,3.0845644f,100.0f ) ;
  }

  @Test
  public void test1168() {
    TestDrivers.surfaceShade(-267.0f,-1390.0f,0f,0f,332.0f,-151.0f,0f,-296.0f,0f,0f,0f,0f,0f,-1260.0f,577.0f,-1254.0f,0f,0f,0f,-8,0.71647847f,-0.16828719f,0.18755132f,-61.746525f,-52.00191f,0f ) ;
  }

  @Test
  public void test1169() {
    TestDrivers.surfaceShade(267.0f,171.0f,0f,0f,908.0f,593.0f,0f,-295.0f,0f,0f,0f,0f,0f,618.0f,1509.0f,-85.0f,-1191.0f,-1856.0f,626.0f,411,-0.58546245f,0.15626703f,0.7709688f,-39.71539f,-8.171507f,0f ) ;
  }

  @Test
  public void test1170() {
    TestDrivers.surfaceShade(-269.0f,0f,0f,0f,968.0f,293.0f,-641.0f,-918.0f,0f,0f,0f,0f,0f,-100.0f,-515.0f,-326.0f,-525.0f,-28.0f,-692.0f,675,10.168393f,11.389231f,-2.0546129f,-51.90594f,0f,0f ) ;
  }

  @Test
  public void test1171() {
    TestDrivers.surfaceShade(-2696.0f,-1420.0f,729.0f,0f,649.0f,3015.0f,0f,396.0f,0f,0f,0f,0f,0f,-117.0f,1076.0f,472.0f,931.0f,-468.0f,-1666.0f,-501,-0.22588274f,-0.6343684f,0.41733828f,100.0f,-30.077934f,53.228416f ) ;
  }

  @Test
  public void test1172() {
    TestDrivers.surfaceShade(-27.0f,-124.0f,0f,0f,380.0f,-2.0f,0f,-598.0f,0f,0f,0f,0f,0f,-376.0f,-286.0f,1471.0f,0f,0f,0f,10,-121.66449f,-124.02659f,-55.255756f,-3.3848162f,-92.13255f,0f ) ;
  }

  @Test
  public void test1173() {
    TestDrivers.surfaceShade(271.0f,0f,0f,0f,100.0f,-23.433279f,0f,0.0f,0f,0f,0f,0f,0f,-76.96854f,-100.0f,7.6011114f,0f,0f,0f,-2315,-0.90316767f,0.6776146f,-0.23075978f,19.194302f,0f,0f ) ;
  }

  @Test
  public void test1174() {
    TestDrivers.surfaceShade(2727.0f,0f,0f,0f,1.4210855E-14f,-0.8583663f,0f,-1.8768521E-20f,0f,0f,0f,0f,0f,-76.00604f,95.97553f,-98.30008f,0f,0f,0f,-642,0.39574045f,-0.85457927f,-0.10570832f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1175() {
    TestDrivers.surfaceShade(-2734.0f,-730.0f,0f,0f,12.0f,-752.0f,0f,-214.0f,0f,0f,0f,0f,0f,374.0f,562.0f,203.0f,0f,0f,0f,-187,-29.906906f,-11.856635f,87.924194f,-96.50611f,-99.99986f,0f ) ;
  }

  @Test
  public void test1176() {
    TestDrivers.surfaceShade(-276.0f,-697.0f,0f,0f,468.0f,-961.0f,0f,291.0f,0f,0f,0f,0f,0f,877.0f,856.0f,333.0f,-45.0f,-234.0f,-456.0f,25,-93.69296f,-30.347889f,60.724644f,77.18306f,13.012812f,0f ) ;
  }

  @Test
  public void test1177() {
    TestDrivers.surfaceShade(278.0f,-33.0f,-129.0f,0f,167.0f,3534.0f,0f,-819.0f,0f,0f,0f,0f,0f,441.0f,-62.0f,-8.0f,1906.0f,114.0f,-56.0f,556,-0.017344205f,-0.12758437f,0.032679576f,95.25714f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test1178() {
    TestDrivers.surfaceShade(-2800.0f,-702.0f,638.0f,0f,27.0f,1613.0f,0f,-1159.0f,0f,0f,0f,0f,0f,2304.0f,-584.0f,915.0f,-267.0f,-1371.0f,676.0f,-2076,1.0519413f,-0.31033593f,-2.846895f,3.6747792f,-10.305442f,30.846506f ) ;
  }

  @Test
  public void test1179() {
    TestDrivers.surfaceShade(283.0f,223.0f,-409.0f,0f,36.0f,-859.0f,0f,620.0f,0f,0f,0f,0f,0f,-796.0f,145.0f,78.0f,403.0f,1310.0f,-955.0f,687,57.66265f,89.99143f,13.789337f,-93.06831f,-83.17888f,15.987427f ) ;
  }

  @Test
  public void test1180() {
    TestDrivers.surfaceShade(-2851.0f,0f,0f,0f,98.08405f,0.0f,0f,-98.07746f,0f,0f,0f,0f,0f,-46.016438f,61.841938f,100.0f,0f,0f,0f,-2056,0.084313f,0.8315131f,-0.54906946f,99.99845f,0f,0f ) ;
  }

  @Test
  public void test1181() {
    TestDrivers.surfaceShade(-287.0f,0f,0f,0f,414.0f,-969.0f,0f,755.0f,0f,0f,0f,0f,0f,22.0f,511.0f,-17.0f,982.0f,-653.0f,364.0f,948,-29.881838f,1.069076f,-6.5354476f,-9.961922f,0f,0f ) ;
  }

  @Test
  public void test1182() {
    TestDrivers.surfaceShade(-288.0f,0f,0f,0f,5.785725f,-29.213568f,0f,-13.566101f,0f,0f,0f,0f,0f,-26.691769f,-29.02483f,61.785015f,0f,0f,0f,874,80.119736f,-93.25939f,-72.27068f,45.26405f,0f,0f ) ;
  }

  @Test
  public void test1183() {
    TestDrivers.surfaceShade(-289.0f,679.0f,525.0f,58.0f,0f,0f,0f,-90.14474f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-5.9658752E-5f,-69.499756f,56.076f ) ;
  }

  @Test
  public void test1184() {
    TestDrivers.surfaceShade(290.0f,0f,0f,0f,41.84439f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,11.40566f,-6.9955497f,7.4852514f,0f,0f,0f,-223,31.010767f,68.13301f,15.80139f,-65.96899f,0f,0f ) ;
  }

  @Test
  public void test1185() {
    TestDrivers.surfaceShade(-29.0f,-611.0f,0f,26.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.0013262599f,100.0f,0f ) ;
  }

  @Test
  public void test1186() {
    TestDrivers.surfaceShade(-29.0f,-703.0f,-316.0f,-157.0f,0f,0f,0f,-112.80243f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,82.087456f,95.11527f,82.939644f ) ;
  }

  @Test
  public void test1187() {
    TestDrivers.surfaceShade(29.0f,77.0f,0f,0f,548.0f,0.0f,0f,3.0f,0f,0f,0f,0f,0f,-1124.0f,722.0f,1454.0f,0f,0f,0f,-7,-95.49971f,52.121635f,-99.761086f,26.135931f,5.4477987f,0f ) ;
  }

  @Test
  public void test1188() {
    TestDrivers.surfaceShade(2914.0f,432.0f,0f,0f,1364.0f,-1634.0f,0f,-1705.0f,0f,0f,0f,0f,0f,2185.0f,-2128.0f,250.0f,0f,0f,0f,-1211,-0.45230913f,0.039583396f,-0.72584563f,-60.751205f,13.89381f,0f ) ;
  }

  @Test
  public void test1189() {
    TestDrivers.surfaceShade(-292.0f,-970.0f,-1336.0f,0f,179.0f,-1916.0f,0f,-507.0f,0f,0f,0f,0f,0f,83.0f,-927.0f,-765.0f,0f,0f,0f,592,-1.8770711f,-0.11815824f,-0.0604761f,-22.708609f,-94.143906f,-21.951576f ) ;
  }

  @Test
  public void test1190() {
    TestDrivers.surfaceShade(-297.0f,-901.0f,-331.0f,-603.0f,0f,0f,0f,-93.90348f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-43.44569f,-59.324665f,-102.302475f ) ;
  }

  @Test
  public void test1191() {
    TestDrivers.surfaceShade(-2998.0f,1038.0f,0f,0f,1028.0f,-8.0f,0f,7.0f,0f,0f,0f,0f,0f,62.0f,-1260.0f,-871.0f,0f,0f,0f,-393,0.9212305f,0.2241995f,0.19968292f,26.79403f,100.0f,0f ) ;
  }

  @Test
  public void test1192() {
    TestDrivers.surfaceShade(30.0f,0f,-439.0f,0f,459.0f,-461.0f,0f,-1527.0f,0f,0f,0f,0f,0f,713.0f,991.0f,894.0f,0f,0f,0f,580,-1.5388552f,0.020205392f,1.2048995f,-6.920923f,0f,-98.131645f ) ;
  }

  @Test
  public void test1193() {
    TestDrivers.surfaceShade(30.0f,-198.0f,0f,0f,196.0f,-4.0f,0f,-485.0f,0f,0f,0f,0f,0f,563.0f,-532.0f,684.0f,0f,0f,0f,445,-53.69132f,84.15973f,40.810177f,-40.213593f,-42.379795f,0f ) ;
  }

  @Test
  public void test1194() {
    TestDrivers.surfaceShade(301.0f,-778.0f,0f,0f,370.0f,-1553.0f,0f,-1039.0f,0f,0f,0f,0f,0f,1127.0f,261.0f,-450.0f,0f,0f,0f,10,-84.42324f,88.03058f,75.03653f,11.914842f,33.875797f,0f ) ;
  }

  @Test
  public void test1195() {
    TestDrivers.surfaceShade(-3074.0f,0f,0f,329.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.412257f,0f,0f ) ;
  }

  @Test
  public void test1196() {
    TestDrivers.surfaceShade(309.0f,0f,0f,-1329.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,67.15276f,18.19496f,42.59591f,-654.0f,95.0f,-469.0f,-2,0f,0f,0f,-86.64498f,0f,0f ) ;
  }

  @Test
  public void test1197() {
    TestDrivers.surfaceShade(-309.0f,-202.0f,0f,0f,861.0f,-587.0f,0f,-682.0f,0f,0f,0f,0f,0f,73.0f,168.0f,74.0f,0f,0f,0f,296,80.33161f,-36.06284f,-92.27842f,-35.626858f,41.292908f,0f ) ;
  }

  @Test
  public void test1198() {
    TestDrivers.surfaceShade(-309.0f,436.0f,793.0f,0f,558.0f,934.0f,0f,1633.0f,0f,0f,0f,0f,0f,1443.0f,662.0f,1722.0f,714.0f,-3346.0f,-584.0f,1048,1.1089897f,0.9108582f,-1.2794775f,-29.18036f,-26.952665f,58.435474f ) ;
  }

  @Test
  public void test1199() {
    TestDrivers.surfaceShade(309.0f,509.0f,0f,0f,765.0f,839.0f,0f,-371.0f,0f,0f,0f,0f,0f,94.0f,714.0f,-728.0f,718.0f,619.0f,-373.0f,488,-29.506714f,-44.62913f,-47.58081f,-61.781216f,45.546555f,0f ) ;
  }

  @Test
  public void test1200() {
    TestDrivers.surfaceShade(-3.0f,1158.0f,0f,0f,64.0f,-10.0f,0f,514.0f,0f,0f,0f,0f,0f,-536.0f,398.0f,906.0f,479.0f,1275.0f,1060.0f,817,-26.665905f,94.99826f,-57.507984f,16.582111f,100.0f,0f ) ;
  }

  @Test
  public void test1201() {
    TestDrivers.surfaceShade(-312.0f,827.0f,0f,0f,813.0f,-925.0f,31.0f,247.0f,0f,0f,0f,0f,0f,538.0f,705.0f,-736.0f,-389.0f,963.0f,-516.0f,-790,-37.07622f,-22.828293f,72.75629f,-54.464443f,-6.3483076f,0f ) ;
  }

  @Test
  public void test1202() {
    TestDrivers.surfaceShade(-318.0f,-909.0f,0f,0f,1146.0f,-990.0f,0f,344.0f,0f,0f,0f,0f,0f,-1880.0f,956.0f,311.0f,-627.0f,1246.0f,-769.0f,1171,0.06913288f,-0.74593824f,-0.62184846f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1203() {
    TestDrivers.surfaceShade(319.0f,-1357.0f,0f,0f,1250.0f,837.0f,0f,-1597.0f,0f,0f,0f,0f,0f,694.0f,-38.0f,147.0f,-1442.0f,77.0f,949.0f,1651,14.206161f,98.37115f,-41.639263f,86.4984f,-100.0f,0f ) ;
  }

  @Test
  public void test1204() {
    TestDrivers.surfaceShade(320.0f,-222.0f,-624.0f,0f,1058.0f,832.0f,0f,832.0f,0f,0f,0f,0f,0f,-826.0f,1281.0f,298.0f,176.0f,-963.0f,-714.0f,-326,-3.9307544f,-2.8281405f,1.2618923f,-73.05923f,50.459873f,6.5918617f ) ;
  }

  @Test
  public void test1205() {
    TestDrivers.surfaceShade(-3218.0f,-729.0f,7.0f,0f,5.0f,47.0f,0f,1304.0f,0f,0f,0f,0f,0f,-826.0f,121.0f,-359.0f,555.0f,-905.0f,72.0f,-271,0.27854034f,0.25484553f,-0.50582874f,75.89004f,-11.221823f,0.001619191f ) ;
  }

  @Test
  public void test1206() {
    TestDrivers.surfaceShade(-327.0f,-472.0f,0f,0f,325.0f,-91.0f,0f,598.0f,0f,0f,0f,0f,0f,-895.0f,-951.0f,410.0f,240.0f,113.0f,-643.0f,-565,-25.774069f,53.731377f,64.717514f,-38.475212f,-4.355904E-9f,0f ) ;
  }

  @Test
  public void test1207() {
    TestDrivers.surfaceShade(328.0f,204.0f,-934.0f,0f,912.0f,985.0f,0f,-345.0f,0f,0f,0f,0f,0f,170.0f,161.0f,306.0f,-877.0f,-175.0f,-959.0f,-33,-75.595665f,100.0f,-100.0f,-3.2545846f,-100.0f,100.0f ) ;
  }

  @Test
  public void test1208() {
    TestDrivers.surfaceShade(329.0f,0f,-1262.0f,0f,236.0f,-622.0f,0f,-1895.0f,0f,0f,0f,0f,0f,-1018.0f,31.0f,1383.0f,0f,0f,0f,1,38.247166f,-23.405985f,-27.748528f,7.665001f,0f,-107.44676f ) ;
  }

  @Test
  public void test1209() {
    TestDrivers.surfaceShade(-331.0f,0f,0f,0f,1064.0f,1536.0f,0f,-1038.0f,0f,0f,0f,0f,0f,-478.0f,457.0f,798.0f,-616.0f,-1.0f,-738.0f,-582,0.54702127f,0.36146662f,-0.11598835f,37.99235f,0f,0f ) ;
  }

  @Test
  public void test1210() {
    TestDrivers.surfaceShade(-331.0f,-858.0f,-232.0f,0f,874.0f,-203.0f,0f,-1101.0f,0f,0f,0f,0f,0f,-84.0f,-739.0f,529.0f,0f,0f,0f,657,32.92522f,50.13231f,13.650838f,-4.96426f,48.481724f,3.5091074f ) ;
  }

  @Test
  public void test1211() {
    TestDrivers.surfaceShade(334.0f,1561.0f,-127.0f,0f,19.0f,85.0f,0f,736.0f,0f,0f,0f,0f,0f,-577.0f,-433.0f,-634.0f,157.0f,-453.0f,373.0f,875,47.515152f,21.476799f,-57.91119f,-99.53608f,-51.278522f,-0.39022237f ) ;
  }

  @Test
  public void test1212() {
    TestDrivers.surfaceShade(336.0f,0f,0f,0f,432.0f,332.0f,-931.0f,446.0f,0f,0f,0f,0f,0f,-80.0f,764.0f,298.0f,454.0f,84.0f,-1007.0f,-832,61.95526f,29.66124f,-59.41197f,6.9666405f,0f,0f ) ;
  }

  @Test
  public void test1213() {
    TestDrivers.surfaceShade(-339.0f,270.0f,-937.0f,51.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.2563356f,100.0f,-2.0926193E-5f ) ;
  }

  @Test
  public void test1214() {
    TestDrivers.surfaceShade(34.0f,-1120.0f,1163.0f,0f,199.0f,-2142.0f,0f,-1329.0f,0f,0f,0f,0f,0f,-121.0f,-699.0f,-808.0f,0f,0f,0f,-910,90.47351f,99.93234f,-100.0f,89.929726f,-61.358734f,58.542034f ) ;
  }

  @Test
  public void test1215() {
    TestDrivers.surfaceShade(-343.0f,918.0f,0f,0f,1927.0f,279.0f,0f,-2694.0f,0f,0f,0f,0f,0f,-1117.0f,55.0f,591.0f,526.0f,757.0f,-1336.0f,71,0.40015537f,0.379692f,-0.09351091f,-56.917053f,22.976793f,0f ) ;
  }

  @Test
  public void test1216() {
    TestDrivers.surfaceShade(-349.0f,88.0f,-848.0f,-292.0f,0f,0f,0f,-1.2325952E-32f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.7847818f,-1.44391f,22.14571f ) ;
  }

  @Test
  public void test1217() {
    TestDrivers.surfaceShade(35.0f,-1042.0f,0f,0f,452.0f,3.0f,0f,0.0f,0f,0f,0f,0f,0f,208.0f,67.0f,57.0f,0f,0f,0f,2,-40.06655f,98.93605f,29.892391f,-32.85171f,2.039196f,0f ) ;
  }

  @Test
  public void test1218() {
    TestDrivers.surfaceShade(-351.0f,0f,-359.0f,0f,840.0f,-597.0f,0f,-478.0f,0f,0f,0f,0f,0f,706.0f,-98.0f,-6.0f,0f,0f,0f,-12,-7.693823f,34.00322f,-6.519698f,38.308475f,0f,-62.088108f ) ;
  }

  @Test
  public void test1219() {
    TestDrivers.surfaceShade(352.0f,-381.0f,0f,0f,65.0f,-2230.0f,0f,-150.0f,0f,0f,0f,0f,0f,-272.0f,-1161.0f,1533.0f,0f,0f,0f,-3146,-0.40786752f,-0.61667496f,-0.56278795f,-100.0f,-1.1262116E-6f,0f ) ;
  }

  @Test
  public void test1220() {
    TestDrivers.surfaceShade(36.0f,-1212.0f,800.0f,298.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,9.321402E-5f,-66.73567f,100.0f ) ;
  }

  @Test
  public void test1221() {
    TestDrivers.surfaceShade(36.0f,2210.0f,1309.0f,546.0f,0f,0f,0f,-96.3663f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,151.53299f,52.34544f,-122.159584f ) ;
  }

  @Test
  public void test1222() {
    TestDrivers.surfaceShade(361.0f,608.0f,1000.0f,0f,157.0f,-222.0f,0f,-569.0f,0f,0f,0f,0f,0f,-224.0f,375.0f,-585.0f,0f,0f,0f,397,-64.305374f,-23.936333f,41.509735f,3.9482117f,82.74222f,2.8684163f ) ;
  }

  @Test
  public void test1223() {
    TestDrivers.surfaceShade(-362.0f,0f,0f,0f,70.99973f,-7.3169355f,0f,0.0f,0f,0f,0f,0f,0f,-14.162641f,-58.692734f,-40.68383f,0f,0f,0f,824,48.117447f,25.689005f,19.63535f,49.59554f,0f,0f ) ;
  }

  @Test
  public void test1224() {
    TestDrivers.surfaceShade(363.0f,-129.0f,119.0f,0f,1142.0f,-435.0f,0f,-660.0f,0f,0f,0f,0f,0f,785.0f,-1.0f,170.0f,0f,0f,0f,118,-29.912985f,-42.130394f,93.55775f,-38.347687f,-33.70197f,76.15988f ) ;
  }

  @Test
  public void test1225() {
    TestDrivers.surfaceShade(366.0f,0f,0f,0f,8.8257974E-7f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,88.02452f,38.660946f,-39.34509f,0f,0f,0f,5,87.58455f,-40.217705f,78.30969f,-123.04205f,0f,0f ) ;
  }

  @Test
  public void test1226() {
    TestDrivers.surfaceShade(-366.0f,-290.0f,0f,0f,741.0f,1019.0f,0f,1330.0f,0f,0f,0f,0f,0f,-1531.0f,14.0f,347.0f,-266.0f,-97.0f,-728.0f,-791,7.8783f,-32.066788f,36.053585f,76.414055f,74.01316f,0f ) ;
  }

  @Test
  public void test1227() {
    TestDrivers.surfaceShade(-368.0f,-1305.0f,0f,0f,150.0f,986.0f,0f,205.0f,0f,0f,0f,0f,0f,306.0f,-611.0f,-998.0f,614.0f,-22.0f,401.0f,999,-68.98474f,40.441097f,-45.910664f,-36.707607f,-41.78583f,0f ) ;
  }

  @Test
  public void test1228() {
    TestDrivers.surfaceShade(-37.0f,2871.0f,0f,0f,490.0f,7.0f,0f,2.0f,0f,0f,0f,0f,0f,222.0f,339.0f,14.0f,0f,0f,0f,3216,-19.932562f,15.255188f,-53.320004f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1229() {
    TestDrivers.surfaceShade(-374.0f,0f,0f,0f,1049.0f,93.0f,0f,1246.0f,0f,0f,0f,0f,0f,-2033.0f,-147.0f,101.0f,672.0f,439.0f,-124.0f,-411,-0.0071351063f,0.7834755f,0.08768976f,97.42083f,0f,0f ) ;
  }

  @Test
  public void test1230() {
    TestDrivers.surfaceShade(38.0f,0f,0f,-761.0f,0f,0f,0f,-2.163241E-14f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.458054E-5f,0f,0f ) ;
  }

  @Test
  public void test1231() {
    TestDrivers.surfaceShade(383.0f,776.0f,-310.0f,0f,301.0f,493.0f,0f,333.0f,0f,0f,0f,0f,0f,-218.0f,-340.0f,-737.0f,206.0f,527.0f,1600.0f,942,38.118797f,-25.552519f,0.5128339f,100.0f,100.0f,-99.99997f ) ;
  }

  @Test
  public void test1232() {
    TestDrivers.surfaceShade(-384.0f,-142.0f,1044.0f,0f,46.0f,-191.0f,0f,122.0f,0f,0f,0f,0f,0f,269.0f,-270.0f,663.0f,259.0f,-719.0f,-1925.0f,928,3.4200575f,-91.288025f,-38.563744f,-28.207624f,-45.275177f,95.79029f ) ;
  }

  @Test
  public void test1233() {
    TestDrivers.surfaceShade(386.0f,-1620.0f,-6.0f,13.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,69.682526f,-6.8686466f,-0.012820513f ) ;
  }

  @Test
  public void test1234() {
    TestDrivers.surfaceShade(387.0f,439.0f,0f,-9.0f,0f,0f,0f,-30.013107f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.8710882E-4f,-2.5310047E-4f,0f ) ;
  }

  @Test
  public void test1235() {
    TestDrivers.surfaceShade(3893.0f,873.0f,662.0f,0f,158.0f,-1.0f,0f,-712.0f,0f,0f,0f,0f,0f,-186.0f,-434.0f,1271.0f,0f,0f,0f,1077,28.368433f,-89.16733f,-26.2959f,61.592705f,-36.82673f,17.223051f ) ;
  }

  @Test
  public void test1236() {
    TestDrivers.surfaceShade(-39.0f,0f,0f,0f,424.0f,-1463.0f,0f,832.0f,0f,0f,0f,0f,0f,379.0f,-939.0f,725.0f,214.0f,-1846.0f,-988.0f,364,76.4806f,37.476444f,-40.31606f,3.861813E-9f,0f,0f ) ;
  }

  @Test
  public void test1237() {
    TestDrivers.surfaceShade(39.0f,-316.0f,0f,0f,1.0f,0.0f,0f,-1620.0f,0f,0f,0f,0f,0f,-178.0f,-602.0f,251.0f,0f,0f,0f,932,0.54175645f,-0.22219786f,-0.14873119f,24.115334f,-3.0520287f,0f ) ;
  }

  @Test
  public void test1238() {
    TestDrivers.surfaceShade(396.0f,-735.0f,-358.0f,0f,351.0f,-398.0f,0f,-7.0f,0f,0f,0f,0f,0f,-397.0f,581.0f,-879.0f,0f,0f,0f,199,-92.89621f,-49.989243f,33.83994f,35.237347f,-7.258036f,100.0f ) ;
  }

  @Test
  public void test1239() {
    TestDrivers.surfaceShade(397.0f,0f,0f,0f,675.0f,2.0f,0f,647.0f,0f,0f,0f,0f,0f,731.0f,-1091.0f,236.0f,915.0f,852.0f,604.0f,-471,-3.7129905f,4.608577f,25.320045f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1240() {
    TestDrivers.surfaceShade(-397.0f,355.0f,238.0f,0f,825.0f,-474.0f,0f,951.0f,0f,0f,0f,0f,0f,-265.0f,823.0f,-807.0f,-728.0f,-275.0f,-144.0f,-508,65.53927f,13.677507f,57.667984f,-24.128555f,63.50651f,23.769566f ) ;
  }

  @Test
  public void test1241() {
    TestDrivers.surfaceShade(398.0f,-243.0f,0f,0f,576.0f,249.0f,0f,-759.0f,0f,0f,0f,0f,0f,175.0f,-815.0f,-230.0f,691.0f,640.0f,-549.0f,-615,-81.46015f,7.2212677f,-67.11777f,60.752396f,55.31753f,0f ) ;
  }

  @Test
  public void test1242() {
    TestDrivers.surfaceShade(399.0f,0f,0f,0f,403.0f,-638.0f,0f,980.0f,0f,0f,0f,0f,0f,-26.0f,582.0f,-1292.0f,72.0f,734.0f,-260.0f,772,73.20688f,69.46137f,48.190037f,-67.28882f,0f,0f ) ;
  }

  @Test
  public void test1243() {
    TestDrivers.surfaceShade(-400.0f,122.0f,-241.0f,0f,593.0f,-569.0f,0f,721.0f,0f,0f,0f,0f,0f,995.0f,390.0f,-41.0f,-829.0f,-862.0f,646.0f,-703,-41.81862f,-58.949795f,44.271355f,-60.152206f,-31.036407f,62.08911f ) ;
  }

  @Test
  public void test1244() {
    TestDrivers.surfaceShade(400.0f,-253.0f,823.0f,0f,92.0f,-390.0f,0f,265.0f,0f,0f,0f,0f,0f,385.0f,333.0f,-396.0f,-1303.0f,-802.0f,-11.0f,935,-55.047176f,-4.063736f,-56.93532f,-56.48968f,-94.43595f,-64.88245f ) ;
  }

  @Test
  public void test1245() {
    TestDrivers.surfaceShade(410.0f,-75.0f,0f,0f,6.0f,-165.0f,0f,-65.0f,0f,0f,0f,0f,0f,-231.0f,-814.0f,-734.0f,0f,0f,0f,1,72.227165f,-38.6457f,29.091959f,-8.897993f,-2.9356206E-5f,0f ) ;
  }

  @Test
  public void test1246() {
    TestDrivers.surfaceShade(-41.0f,540.0f,9.0f,7.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.0034843206f,-41.80904f,0.015873017f ) ;
  }

  @Test
  public void test1247() {
    TestDrivers.surfaceShade(-419.0f,-523.0f,0f,0f,1924.0f,-761.0f,0f,-712.0f,0f,0f,0f,0f,0f,827.0f,-302.0f,-251.0f,0f,0f,0f,437,-4.614036f,70.477455f,-100.0f,100.0f,-64.77829f,0f ) ;
  }

  @Test
  public void test1248() {
    TestDrivers.surfaceShade(-420.0f,-242.0f,-213.0f,0f,203.0f,14.0f,0f,192.0f,0f,0f,0f,0f,0f,282.0f,170.0f,496.0f,658.0f,923.0f,-1489.0f,-1143,66.80576f,-99.99874f,-3.7085438f,-5.908614f,60.868046f,-6.1653614f ) ;
  }

  @Test
  public void test1249() {
    TestDrivers.surfaceShade(-428.0f,0f,0f,0f,287.0f,814.0f,-970.0f,669.0f,0f,0f,0f,0f,0f,-723.0f,-634.0f,749.0f,80.0f,-1298.0f,330.0f,-679,68.66925f,21.806223f,71.683525f,-17.887575f,0f,0f ) ;
  }

  @Test
  public void test1250() {
    TestDrivers.surfaceShade(-430.0f,0f,0f,0f,-519.0f,-858.0f,420.0f,448.0f,0f,0f,0f,0f,0f,-234.0f,765.0f,-853.0f,336.0f,218.0f,-641.0f,-695,-84.40231f,-70.980675f,-89.02443f,-43.675484f,0f,0f ) ;
  }

  @Test
  public void test1251() {
    TestDrivers.surfaceShade(43.0f,0f,0f,0f,99.99987f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,72.38632f,-62.631104f,-25.749058f,0f,0f,0f,1,-59.583527f,-27.749786f,-100.0f,0.21909368f,0f,0f ) ;
  }

  @Test
  public void test1252() {
    TestDrivers.surfaceShade(431.0f,645.0f,-1138.0f,0f,357.0f,820.0f,0f,943.0f,0f,0f,0f,0f,0f,353.0f,569.0f,-289.0f,-416.0f,-131.0f,-807.0f,-850,95.575294f,-69.31785f,-19.736263f,17.649128f,-32.123184f,-59.536625f ) ;
  }

  @Test
  public void test1253() {
    TestDrivers.surfaceShade(-431.0f,802.0f,-840.0f,0f,302.0f,1310.0f,0f,-436.0f,0f,0f,0f,0f,0f,-788.0f,580.0f,260.0f,399.0f,262.0f,294.0f,-691,100.0f,-16.561972f,-2.9096067f,12.291507f,100.0f,88.65602f ) ;
  }

  @Test
  public void test1254() {
    TestDrivers.surfaceShade(432.0f,-225.0f,311.0f,0f,64.0f,57.0f,0f,246.0f,0f,0f,0f,0f,0f,-379.0f,989.0f,552.0f,-922.0f,-757.0f,-45.0f,-902,100.0f,-100.0f,-65.42345f,100.0f,100.0f,27.96502f ) ;
  }

  @Test
  public void test1255() {
    TestDrivers.surfaceShade(432.0f,319.0f,0f,0f,155.0f,2308.0f,0f,283.0f,0f,0f,0f,0f,0f,-278.0f,374.0f,-320.0f,-1213.0f,222.0f,727.0f,572,-14.892609f,-96.6314f,-100.0f,-75.16595f,-100.0f,0f ) ;
  }

  @Test
  public void test1256() {
    TestDrivers.surfaceShade(437.0f,-15.0f,271.0f,0f,513.0f,-459.0f,0f,734.0f,0f,0f,0f,0f,0f,-7.0f,-269.0f,249.0f,-700.0f,183.0f,770.0f,480,-65.015236f,-82.2773f,-90.71365f,31.926636f,42.93744f,-7.6337757f ) ;
  }

  @Test
  public void test1257() {
    TestDrivers.surfaceShade(-445.0f,-115.0f,0f,0f,496.0f,610.0f,0f,234.0f,0f,0f,0f,0f,0f,-449.0f,293.0f,-14.0f,-714.0f,-427.0f,441.0f,1761,-7.6443586f,-13.861615f,-44.938297f,-96.775604f,-27.01011f,0f ) ;
  }

  @Test
  public void test1258() {
    TestDrivers.surfaceShade(-445.0f,133.0f,-1030.0f,0f,217.0f,-2285.0f,0f,-1582.0f,0f,0f,0f,0f,0f,11.0f,423.0f,1248.0f,0f,0f,0f,290,-5.0064864f,-55.548626f,18.871906f,100.0f,99.99999f,-100.0f ) ;
  }

  @Test
  public void test1259() {
    TestDrivers.surfaceShade(-445.0f,855.0f,0f,0f,514.0f,167.0f,0f,737.0f,0f,0f,0f,0f,0f,698.0f,-771.0f,-921.0f,-951.0f,-612.0f,657.0f,325,-60.78698f,88.78724f,-19.526823f,14.042561f,42.226948f,0f ) ;
  }

  @Test
  public void test1260() {
    TestDrivers.surfaceShade(445.0f,-961.0f,549.0f,0f,1294.0f,2053.0f,0f,-1248.0f,0f,0f,0f,0f,0f,-1597.0f,1898.0f,-181.0f,1482.0f,79.0f,-408.0f,298,0.7751665f,-0.5975308f,0.14082637f,80.12164f,-4.333566f,-99.1835f ) ;
  }

  @Test
  public void test1261() {
    TestDrivers.surfaceShade(45.0f,-1942.0f,-412.0f,0f,797.0f,-1127.0f,0f,546.0f,0f,0f,0f,0f,0f,351.0f,-308.0f,881.0f,824.0f,1476.0f,1119.0f,-726,-60.839893f,-20.152952f,17.19375f,-4.7878933f,100.0f,88.14479f ) ;
  }

  @Test
  public void test1262() {
    TestDrivers.surfaceShade(45.0f,30.0f,-779.0f,10.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0022222223f,-58.26076f,86.85599f ) ;
  }

  @Test
  public void test1263() {
    TestDrivers.surfaceShade(-452.0f,1031.0f,-873.0f,0f,147.0f,428.0f,0f,339.0f,0f,0f,0f,0f,0f,229.0f,-840.0f,265.0f,-533.0f,91.0f,754.0f,-874,24.402433f,-10.465205f,-54.260113f,56.83939f,-12.025316f,-35.96356f ) ;
  }

  @Test
  public void test1264() {
    TestDrivers.surfaceShade(454.0f,-308.0f,0f,24.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,93.61362f,-1.3528139E-4f,0f ) ;
  }

  @Test
  public void test1265() {
    TestDrivers.surfaceShade(-455.0f,0f,-574.0f,0f,86.0f,-858.0f,0f,-303.0f,0f,0f,0f,0f,0f,313.0f,146.0f,259.0f,0f,0f,0f,-6,-100.0f,100.0f,22.308975f,100.0f,0f,100.0f ) ;
  }

  @Test
  public void test1266() {
    TestDrivers.surfaceShade(460.0f,0f,0f,0f,411.0f,948.0f,0f,1238.0f,0f,0f,0f,0f,0f,534.0f,561.0f,-650.0f,282.0f,612.0f,-495.0f,-938,32.745766f,-90.70728f,-51.38544f,6.5780406f,0f,0f ) ;
  }

  @Test
  public void test1267() {
    TestDrivers.surfaceShade(462.0f,-1530.0f,0f,0f,45.0f,-2510.0f,0f,-4.0f,0f,0f,0f,0f,0f,295.0f,424.0f,889.0f,0f,0f,0f,416,19.181612f,54.560455f,-32.387184f,60.367825f,-18.227194f,0f ) ;
  }

  @Test
  public void test1268() {
    TestDrivers.surfaceShade(466.0f,300.0f,0f,0f,1121.0f,-2.0f,0f,-1559.0f,0f,0f,0f,0f,0f,-231.0f,932.0f,-1466.0f,0f,0f,0f,-1,-16.987013f,25.898718f,64.28232f,26.935255f,-94.34264f,0f ) ;
  }

  @Test
  public void test1269() {
    TestDrivers.surfaceShade(467.0f,287.0f,0f,0f,237.0f,-1042.0f,0f,-625.0f,0f,0f,0f,0f,0f,-122.0f,1130.0f,245.0f,0f,0f,0f,704,-0.33210737f,-0.011427761f,-0.112668276f,2.421041f,23.385864f,0f ) ;
  }

  @Test
  public void test1270() {
    TestDrivers.surfaceShade(-469.0f,1445.0f,0f,0f,621.0f,-740.0f,0f,848.0f,0f,0f,0f,0f,0f,-710.0f,-386.0f,179.0f,1083.0f,-712.0f,-866.0f,677,47.711315f,-39.495235f,25.040154f,93.831215f,80.48342f,0f ) ;
  }

  @Test
  public void test1271() {
    TestDrivers.surfaceShade(-471.0f,0f,788.0f,0f,896.0f,-800.0f,0f,-760.0f,0f,0f,0f,0f,0f,85.0f,127.0f,-968.0f,0f,0f,0f,-339,-1.4401256f,0.26727724f,-0.09139097f,-46.207825f,0f,57.685402f ) ;
  }

  @Test
  public void test1272() {
    TestDrivers.surfaceShade(479.0f,569.0f,913.0f,0f,286.0f,1113.0f,0f,-554.0f,0f,0f,0f,0f,0f,1192.0f,292.0f,731.0f,-375.0f,-987.0f,-191.0f,-879,-86.30411f,56.733227f,93.15763f,-7.631156f,38.045223f,35.28586f ) ;
  }

  @Test
  public void test1273() {
    TestDrivers.surfaceShade(48.0f,-2315.0f,84.0f,893.0f,0f,0f,0f,-41.689674f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.3329601E-5f,82.18138f,1.33312005E-5f ) ;
  }

  @Test
  public void test1274() {
    TestDrivers.surfaceShade(481.0f,0f,0f,0f,79.24647f,-100.0f,0f,-155.3653f,0f,0f,0f,0f,0f,-92.723434f,-42.812447f,-33.61408f,0f,0f,0f,1,95.95188f,54.029182f,63.369637f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1275() {
    TestDrivers.surfaceShade(483.0f,0f,0f,0f,870.0f,1.0f,0f,852.0f,0f,0f,0f,0f,0f,-423.0f,821.0f,844.0f,1324.0f,-738.0f,-1068.0f,-664,-27.131727f,51.790375f,-63.977036f,3.5206518f,0f,0f ) ;
  }

  @Test
  public void test1276() {
    TestDrivers.surfaceShade(483.0f,-220.0f,-942.0f,0f,8.0f,686.0f,0f,-1341.0f,0f,0f,0f,0f,0f,83.0f,718.0f,-378.0f,134.0f,-397.0f,274.0f,-140,-95.96098f,-50.79255f,17.595585f,69.6924f,77.04477f,48.85436f ) ;
  }

  @Test
  public void test1277() {
    TestDrivers.surfaceShade(-484.0f,-2313.0f,-486.0f,0f,196.0f,1676.0f,0f,-1305.0f,0f,0f,0f,0f,0f,777.0f,-490.0f,-807.0f,907.0f,-1648.0f,1314.0f,-438,-32.06423f,53.779507f,-63.526474f,-80.04559f,-100.0f,-48.236084f ) ;
  }

  @Test
  public void test1278() {
    TestDrivers.surfaceShade(489.0f,65.0f,0f,0f,507.0f,1023.0f,0f,962.0f,0f,0f,0f,0f,0f,600.0f,-821.0f,1128.0f,135.0f,-1192.0f,326.0f,414,17.638378f,32.450314f,14.236418f,-81.44619f,-94.01609f,0f ) ;
  }

  @Test
  public void test1279() {
    TestDrivers.surfaceShade(49.0f,-46.0f,-55.0f,0f,398.0f,911.0f,0f,944.0f,0f,0f,0f,0f,0f,1835.0f,-1339.0f,536.0f,7.0f,997.0f,-385.0f,244,-0.4582465f,-0.32816297f,0.7490151f,100.0f,-15.255483f,-76.78965f ) ;
  }

  @Test
  public void test1280() {
    TestDrivers.surfaceShade(496.0f,-333.0f,0f,0f,622.0f,-988.0f,0f,-559.0f,0f,0f,0f,0f,0f,-388.0f,627.0f,-661.0f,0f,0f,0f,1,-74.714005f,-61.435467f,4.9939613f,-4.6788936f,-79.363335f,0f ) ;
  }

  @Test
  public void test1281() {
    TestDrivers.surfaceShade(497.0f,-1734.0f,0f,0f,322.0f,0.0f,0f,-635.0f,0f,0f,0f,0f,0f,456.0f,-1623.0f,1421.0f,0f,0f,0f,-650,0.8961111f,-0.04809867f,-0.34953928f,-53.79813f,-78.22044f,0f ) ;
  }

  @Test
  public void test1282() {
    TestDrivers.surfaceShade(50.0f,799.0f,-92.0f,58.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,11.004196f,82.96082f,-76.47296f ) ;
  }

  @Test
  public void test1283() {
    TestDrivers.surfaceShade(-501.0f,1110.0f,0f,0f,1435.0f,-1023.0f,0f,-1.0f,0f,0f,0f,0f,0f,-251.0f,-429.0f,1156.0f,0f,0f,0f,-4,100.0f,55.93833f,27.855785f,29.515715f,3.8699083f,0f ) ;
  }

  @Test
  public void test1284() {
    TestDrivers.surfaceShade(502.0f,-940.0f,-110.0f,383.0f,0f,0f,0f,-91.213875f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,24.978828f,8.0056095f,-68.32656f ) ;
  }

  @Test
  public void test1285() {
    TestDrivers.surfaceShade(508.0f,1023.0f,0f,0f,521.0f,478.0f,0f,665.0f,0f,0f,0f,0f,0f,-127.0f,-182.0f,502.0f,719.0f,-962.0f,-621.0f,-159,-0.596432f,0.5232839f,-0.22841056f,-99.99915f,-4.34538f,0f ) ;
  }

  @Test
  public void test1286() {
    TestDrivers.surfaceShade(-508.0f,-795.0f,0f,0f,891.0f,406.0f,-458.0f,74.0f,0f,0f,0f,0f,0f,-609.0f,-220.0f,233.0f,962.0f,-492.0f,508.0f,368,14.051198f,67.01282f,100.0f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1287() {
    TestDrivers.surfaceShade(508.0f,-922.0f,0f,0f,160.0f,8.0f,0f,-1077.0f,0f,0f,0f,0f,0f,293.0f,-1291.0f,577.0f,0f,0f,0f,-152,-0.6022457f,0.6971136f,-0.006416776f,-12.493169f,-34.299385f,0f ) ;
  }

  @Test
  public void test1288() {
    TestDrivers.surfaceShade(509.0f,657.0f,537.0f,0f,109.0f,162.0f,0f,-182.0f,0f,0f,0f,0f,0f,592.0f,-184.0f,-315.0f,169.0f,27.0f,335.0f,1483,-100.0f,-69.22995f,-36.916386f,91.67775f,61.040478f,-100.0f ) ;
  }

  @Test
  public void test1289() {
    TestDrivers.surfaceShade(511.0f,1204.0f,0f,0f,887.0f,-315.0f,0f,846.0f,0f,0f,0f,0f,0f,799.0f,-914.0f,40.0f,-631.0f,1607.0f,126.0f,-272,-0.43606907f,0.4939699f,-0.3705534f,-30.613165f,69.34211f,0f ) ;
  }

  @Test
  public void test1290() {
    TestDrivers.surfaceShade(517.0f,0f,0f,0f,100.0f,0.0f,0f,-81.04107f,0f,0f,0f,0f,0f,10.621963f,100.0f,27.151644f,0f,0f,0f,-954,0.1957801f,-0.21327636f,0.17810456f,-23.203558f,0f,0f ) ;
  }

  @Test
  public void test1291() {
    TestDrivers.surfaceShade(521.0f,423.0f,0f,-517.0f,0f,0f,0f,-44.139225f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-99.0954f,84.12397f,0f ) ;
  }

  @Test
  public void test1292() {
    TestDrivers.surfaceShade(522.0f,-606.0f,1156.0f,0f,890.0f,2001.0f,0f,678.0f,0f,0f,0f,0f,0f,67.0f,-201.0f,511.0f,-177.0f,1037.0f,-1597.0f,881,-0.47963977f,-0.34027427f,-0.07717089f,-100.0f,-100.0f,-6.430049f ) ;
  }

  @Test
  public void test1293() {
    TestDrivers.surfaceShade(-526.0f,777.0f,8.0f,0f,885.0f,-731.0f,0f,937.0f,0f,0f,0f,0f,0f,-788.0f,-688.0f,997.0f,364.0f,-691.0f,99.0f,253,-59.99901f,18.01082f,-38.437057f,72.31339f,6.3610444f,32.539257f ) ;
  }

  @Test
  public void test1294() {
    TestDrivers.surfaceShade(526.0f,-992.0f,531.0f,0.0f,0f,0f,0f,-63.53133f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-10.488898f,-83.28446f,-15.177391f ) ;
  }

  @Test
  public void test1295() {
    TestDrivers.surfaceShade(531.0f,904.0f,0f,0f,1474.0f,613.0f,-362.0f,143.0f,0f,0f,0f,0f,0f,406.0f,46.0f,74.0f,-232.0f,222.0f,-696.0f,-102,3.2558036f,-12.093527f,-10.3453245f,35.616753f,-47.54891f,0f ) ;
  }

  @Test
  public void test1296() {
    TestDrivers.surfaceShade(-533.0f,164.0f,0f,0f,50.0f,2.0f,0f,-1600.0f,0f,0f,0f,0f,0f,1034.0f,431.0f,34.0f,0f,0f,0f,-1,-19.453327f,47.11218f,-5.6061444f,39.256638f,12.927121f,0f ) ;
  }

  @Test
  public void test1297() {
    TestDrivers.surfaceShade(533.0f,-652.0f,0f,0f,974.0f,1748.0f,0f,-1320.0f,0f,0f,0f,0f,0f,220.0f,146.0f,1309.0f,-165.0f,611.0f,-941.0f,652,-2.0789094f,-0.5999632f,0.41631374f,122.88218f,-53.568424f,0f ) ;
  }

  @Test
  public void test1298() {
    TestDrivers.surfaceShade(-54.0f,29.0f,-2989.0f,-181.0f,0f,0f,0f,-50.008076f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,1.0231226E-4f,92.12312f,-73.87744f ) ;
  }

  @Test
  public void test1299() {
    TestDrivers.surfaceShade(-545.0f,-478.0f,-597.0f,0f,1955.0f,2095.0f,0f,120.0f,0f,0f,0f,0f,0f,-262.0f,715.0f,417.0f,-344.0f,242.0f,-844.0f,280,-100.0f,-68.16216f,54.043034f,100.0f,-100.0f,-66.676926f ) ;
  }

  @Test
  public void test1300() {
    TestDrivers.surfaceShade(-551.0f,0f,0f,0f,-725.0f,28.0f,556.0f,-13.0f,0f,0f,0f,0f,0f,-418.0f,135.0f,887.0f,-276.0f,-956.0f,501.0f,-600,48.479046f,-25.473682f,54.60099f,-42.996223f,0f,0f ) ;
  }

  @Test
  public void test1301() {
    TestDrivers.surfaceShade(-552.0f,-725.0f,0f,0f,550.0f,-99.0f,0f,-819.0f,0f,0f,0f,0f,0f,-102.0f,-676.0f,512.0f,0f,0f,0f,-65,-60.985085f,84.34767f,-34.80379f,-52.50591f,-54.39245f,0f ) ;
  }

  @Test
  public void test1302() {
    TestDrivers.surfaceShade(-554.0f,175.0f,-857.0f,0f,210.0f,-338.0f,0f,387.0f,0f,0f,0f,0f,0f,-671.0f,-8.0f,334.0f,-965.0f,187.0f,-518.0f,543,-25.130163f,-62.2536f,-51.97715f,28.537485f,-113.526474f,22.17629f ) ;
  }

  @Test
  public void test1303() {
    TestDrivers.surfaceShade(-554.0f,479.0f,15.0f,155.0f,0f,0f,0f,-39.27422f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-57.278515f,-83.57682f,4.3010752E-4f ) ;
  }

  @Test
  public void test1304() {
    TestDrivers.surfaceShade(557.0f,-560.0f,231.0f,0f,88.0f,-1062.0f,0f,516.0f,0f,0f,0f,0f,0f,-29.0f,337.0f,-23.0f,-1022.0f,-673.0f,-1128.0f,-979,0.7724749f,-0.33277392f,-0.22019602f,-13.830839f,99.89706f,25.05923f ) ;
  }

  @Test
  public void test1305() {
    TestDrivers.surfaceShade(561.0f,0f,0f,0f,55.046394f,0.0f,0f,-39.15912f,0f,0f,0f,0f,0f,6.7348485f,-26.767551f,-50.31082f,0f,0f,0f,5,59.909428f,18.008411f,68.58005f,53.9204f,0f,0f ) ;
  }

  @Test
  public void test1306() {
    TestDrivers.surfaceShade(562.0f,162.0f,0f,0f,871.0f,-330.0f,0f,-1.0f,0f,0f,0f,0f,0f,-666.0f,993.0f,-661.0f,0f,0f,0f,-111,-13.387456f,-76.96006f,86.42624f,1.7645793f,-91.76455f,0f ) ;
  }

  @Test
  public void test1307() {
    TestDrivers.surfaceShade(568.0f,0f,0f,0f,1665.0f,-1373.0f,0f,484.0f,0f,0f,0f,0f,0f,598.0f,1559.0f,-414.0f,-1951.0f,548.0f,1078.0f,-128,-4.9655957f,1.4075185f,-1.872234f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1308() {
    TestDrivers.surfaceShade(-569.0f,590.0f,-642.0f,431.0f,0f,0f,0f,-82.77766f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,92.70572f,60.153893f,-20.362011f ) ;
  }

  @Test
  public void test1309() {
    TestDrivers.surfaceShade(-57.0f,-142.0f,0f,0f,323.0f,-634.0f,0f,-1008.0f,0f,0f,0f,0f,0f,212.0f,694.0f,48.0f,0f,0f,0f,2,-53.099403f,-89.16405f,-66.15159f,84.327835f,-69.59942f,0f ) ;
  }

  @Test
  public void test1310() {
    TestDrivers.surfaceShade(574.0f,0f,0f,-355.0f,0f,0f,0f,-61.723305f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-54.38934f,0f,0f ) ;
  }

  @Test
  public void test1311() {
    TestDrivers.surfaceShade(-577.0f,-2064.0f,-1187.0f,0f,2285.0f,-23.0f,0f,747.0f,0f,0f,0f,0f,0f,-483.0f,209.0f,-490.0f,2515.0f,389.0f,-174.0f,19,0.8413795f,0.109106496f,-0.5055877f,10.514369f,-90.223404f,-51.24818f ) ;
  }

  @Test
  public void test1312() {
    TestDrivers.surfaceShade(-579.0f,743.0f,-862.0f,0f,784.0f,-371.0f,0f,-270.0f,0f,0f,0f,0f,0f,111.0f,448.0f,-485.0f,0f,0f,0f,902,50.282227f,75.41115f,90.07833f,66.56157f,37.375492f,1.0230196f ) ;
  }

  @Test
  public void test1313() {
    TestDrivers.surfaceShade(-58.0f,0f,0f,0f,44.0f,150.0f,0f,-221.0f,0f,0f,0f,0f,0f,795.0f,-507.0f,-330.0f,-99.0f,261.0f,672.0f,-442,-29.380987f,-4.6832585f,-23.001158f,-3.234838f,0f,0f ) ;
  }

  @Test
  public void test1314() {
    TestDrivers.surfaceShade(-582.0f,270.0f,1415.0f,0f,616.0f,1016.0f,0f,935.0f,0f,0f,0f,0f,0f,-212.0f,-793.0f,-741.0f,-51.0f,-1569.0f,84.0f,-569,-44.847214f,68.887634f,-60.89107f,100.0f,-32.736435f,-23.417103f ) ;
  }

  @Test
  public void test1315() {
    TestDrivers.surfaceShade(-582.0f,284.0f,-1332.0f,-17.0f,0f,0f,0f,-81.19511f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4,0f,0f,0f,168.11774f,56.19751f,-3.7860105f ) ;
  }

  @Test
  public void test1316() {
    TestDrivers.surfaceShade(582.0f,505.0f,0f,0f,892.0f,-436.0f,0f,885.0f,0f,0f,0f,0f,0f,100.0f,595.0f,21.0f,580.0f,-517.0f,788.0f,-592,-64.18436f,-20.799742f,10.1379175f,2.1853592f,-80.374176f,0f ) ;
  }

  @Test
  public void test1317() {
    TestDrivers.surfaceShade(-586.0f,0f,0f,0f,739.0f,-335.0f,0f,505.0f,0f,0f,0f,0f,0f,472.0f,-430.0f,-226.0f,169.0f,-202.0f,49.0f,-347,-56.243305f,49.70426f,-0.23950413f,-71.27849f,0f,0f ) ;
  }

  @Test
  public void test1318() {
    TestDrivers.surfaceShade(-589.0f,39.0f,-481.0f,0f,355.0f,-998.0f,0f,449.0f,0f,0f,0f,0f,0f,-1021.0f,16.0f,-452.0f,-96.0f,306.0f,-497.0f,994,0.046412535f,-0.6029867f,0.43208325f,-27.558277f,13.100621f,100.0f ) ;
  }

  @Test
  public void test1319() {
    TestDrivers.surfaceShade(-590.0f,518.0f,0f,0f,141.0f,-786.0f,0f,-2.0f,0f,0f,0f,0f,0f,-411.0f,-682.0f,734.0f,0f,0f,0f,-1299,24.147099f,45.7748f,48.24718f,-100.0f,2.389676E-9f,0f ) ;
  }

  @Test
  public void test1320() {
    TestDrivers.surfaceShade(-59.0f,0f,0f,0f,1364.0f,-1.0f,0f,832.0f,0f,0f,0f,0f,0f,-87.0f,555.0f,1232.0f,-63.0f,-929.0f,279.0f,834,0.63496697f,0.3712451f,-0.13974354f,-65.181015f,0f,0f ) ;
  }

  @Test
  public void test1321() {
    TestDrivers.surfaceShade(591.0f,122.0f,-586.0f,0f,54.0f,-492.0f,0f,-32.0f,0f,0f,0f,0f,0f,813.0f,90.0f,249.0f,0f,0f,0f,-847,9.767068f,-4.073521f,-30.417707f,92.825386f,-100.0f,-93.1676f ) ;
  }

  @Test
  public void test1322() {
    TestDrivers.surfaceShade(596.0f,0f,0f,0f,573.0f,288.0f,-599.0f,617.0f,0f,0f,0f,0f,0f,888.0f,500.0f,-137.0f,487.0f,588.0f,999.0f,-886,-0.54013735f,-0.16180553f,-0.08439771f,-82.55269f,0f,0f ) ;
  }

  @Test
  public void test1323() {
    TestDrivers.surfaceShade(60.0f,0f,0f,0f,30.088982f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-3.991711f,-4.9824734f,79.65978f,0f,0f,0f,1,100.0f,10.688614f,-19.824162f,19.565275f,0f,0f ) ;
  }

  @Test
  public void test1324() {
    TestDrivers.surfaceShade(602.0f,-233.0f,0f,0f,493.0f,-980.0f,0f,2108.0f,0f,0f,0f,0f,0f,315.0f,617.0f,231.0f,-937.0f,-756.0f,-1165.0f,-139,-0.29316017f,-0.08686514f,0.6317803f,100.0f,-27.462435f,0f ) ;
  }

  @Test
  public void test1325() {
    TestDrivers.surfaceShade(-602.0f,996.0f,334.0f,0f,400.0f,583.0f,0f,791.0f,0f,0f,0f,0f,0f,11.0f,-478.0f,-404.0f,10.0f,-270.0f,-611.0f,494,-45.956245f,-15.37733f,16.942686f,3.7455008f,28.152245f,-31.756166f ) ;
  }

  @Test
  public void test1326() {
    TestDrivers.surfaceShade(-605.0f,1092.0f,0f,0f,1312.0f,0.0f,0f,2.0f,0f,0f,0f,0f,0f,-218.0f,1614.0f,322.0f,0f,0f,0f,2,-49.9012f,-68.78693f,-17.374006f,-82.981346f,-41.952705f,0f ) ;
  }

  @Test
  public void test1327() {
    TestDrivers.surfaceShade(-607.0f,-132.0f,-731.0f,0f,827.0f,-1243.0f,0f,560.0f,0f,0f,0f,0f,0f,687.0f,-977.0f,-662.0f,529.0f,736.0f,8.0f,-965,76.76868f,75.21149f,-31.331633f,-77.456696f,67.00263f,-49.627987f ) ;
  }

  @Test
  public void test1328() {
    TestDrivers.surfaceShade(607.0f,-817.0f,-165.0f,0f,669.0f,954.0f,0f,226.0f,0f,0f,0f,0f,0f,618.0f,502.0f,-903.0f,1157.0f,477.0f,-448.0f,964,0.25227162f,-60.739594f,-33.59399f,20.279716f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1329() {
    TestDrivers.surfaceShade(-608.0f,-763.0f,0f,0f,679.0f,-767.0f,0f,864.0f,0f,0f,0f,0f,0f,563.0f,-358.0f,-639.0f,518.0f,888.0f,658.0f,-656,-92.360916f,8.900732f,-75.97928f,-24.61356f,-77.01402f,0f ) ;
  }

  @Test
  public void test1330() {
    TestDrivers.surfaceShade(6.0f,0f,0f,0f,211.0f,-244.0f,0f,661.0f,0f,0f,0f,0f,0f,865.0f,-1723.0f,-1136.0f,951.0f,2081.0f,1060.0f,1462,-0.8881654f,-0.08502899f,-0.45227244f,7.3153747E-6f,0f,0f ) ;
  }

  @Test
  public void test1331() {
    TestDrivers.surfaceShade(6.0f,0f,0f,0f,810.0f,926.0f,0f,-2526.0f,0f,0f,0f,0f,0f,-206.0f,571.0f,-628.0f,-384.0f,-665.0f,-560.0f,-952,-0.60066694f,0.34431937f,0.5101015f,48.905125f,0f,0f ) ;
  }

  @Test
  public void test1332() {
    TestDrivers.surfaceShade(-611.0f,213.0f,0f,0f,945.0f,-798.0f,0f,564.0f,0f,0f,0f,0f,0f,-234.0f,582.0f,-291.0f,314.0f,-39.0f,-520.0f,420,-9.117659f,-79.47335f,-72.189644f,-0.80813915f,-46.82199f,0f ) ;
  }

  @Test
  public void test1333() {
    TestDrivers.surfaceShade(-615.0f,1011.0f,781.0f,0f,326.0f,-412.0f,0f,-2297.0f,0f,0f,0f,0f,0f,676.0f,698.0f,-394.0f,0f,0f,0f,-985,-0.25007102f,-0.053619545f,-0.52404684f,51.674736f,38.00503f,60.095818f ) ;
  }

  @Test
  public void test1334() {
    TestDrivers.surfaceShade(616.0f,729.0f,0f,0f,1544.0f,1.0f,0f,-78.0f,0f,0f,0f,0f,0f,298.0f,111.0f,-663.0f,0f,0f,0f,1032,24.919615f,-37.560192f,4.912314f,81.854935f,68.81096f,0f ) ;
  }

  @Test
  public void test1335() {
    TestDrivers.surfaceShade(618.0f,0f,0f,0f,61.027363f,0.0f,0f,-58.66995f,0f,0f,0f,0f,0f,49.89165f,-97.63503f,-21.729576f,0f,0f,0f,3,-94.25537f,23.29684f,61.240574f,90.39364f,0f,0f ) ;
  }

  @Test
  public void test1336() {
    TestDrivers.surfaceShade(624.0f,-1938.0f,0f,0f,276.0f,-890.0f,0f,-180.0f,0f,0f,0f,0f,0f,-494.0f,-499.0f,-38.0f,0f,0f,0f,-552,0.42246705f,0.7449304f,0.42023143f,79.41263f,98.28511f,0f ) ;
  }

  @Test
  public void test1337() {
    TestDrivers.surfaceShade(-624.0f,-274.0f,-397.0f,0f,418.0f,-1294.0f,0f,1833.0f,0f,0f,0f,0f,0f,-164.0f,-75.0f,-82.0f,825.0f,202.0f,-831.0f,2133,-6.9538155f,51.34522f,-33.05446f,100.0f,48.71541f,-11.673348f ) ;
  }

  @Test
  public void test1338() {
    TestDrivers.surfaceShade(627.0f,0f,0f,0f,917.0f,771.0f,0f,663.0f,0f,0f,0f,0f,0f,826.0f,82.0f,850.0f,-498.0f,860.0f,288.0f,-703,-20.680122f,62.817593f,-79.703926f,58.472363f,0f,0f ) ;
  }

  @Test
  public void test1339() {
    TestDrivers.surfaceShade(-630.0f,-1979.0f,0f,-473.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,52.2515f,-105.64049f,0f ) ;
  }

  @Test
  public void test1340() {
    TestDrivers.surfaceShade(63.0f,0f,0f,0f,439.0f,255.0f,0f,-596.0f,0f,0f,0f,0f,0f,453.0f,-408.0f,1086.0f,344.0f,-105.0f,-1666.0f,-494,75.969025f,76.339f,-16.185501f,-52.180435f,0f,0f ) ;
  }

  @Test
  public void test1341() {
    TestDrivers.surfaceShade(-631.0f,-995.0f,0f,0f,139.0f,-511.0f,0f,-816.0f,0f,0f,0f,0f,0f,127.0f,698.0f,527.0f,0f,0f,0f,-851,-17.41954f,1.7822247f,-54.270275f,34.776936f,51.112858f,0f ) ;
  }

  @Test
  public void test1342() {
    TestDrivers.surfaceShade(-636.0f,0f,0f,0f,2.8386116f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-27.067554f,-40.220207f,-28.011356f,0f,0f,0f,1,72.89505f,-3.2816014f,85.68265f,72.04753f,0f,0f ) ;
  }

  @Test
  public void test1343() {
    TestDrivers.surfaceShade(638.0f,0f,0f,0f,330.0f,448.0f,-88.0f,-6.0f,0f,0f,0f,0f,0f,-963.0f,912.0f,-1293.0f,778.0f,1655.0f,-745.0f,11,16.14391f,43.657417f,48.420723f,9.322666f,0f,0f ) ;
  }

  @Test
  public void test1344() {
    TestDrivers.surfaceShade(-638.0f,-130.0f,-415.0f,0f,1244.0f,166.0f,0f,354.0f,0f,0f,0f,0f,0f,-1187.0f,-34.0f,-152.0f,579.0f,-47.0f,-1684.0f,-1130,0.06843875f,0.029133862f,-0.23658298f,-100.0f,95.65948f,-85.42959f ) ;
  }

  @Test
  public void test1345() {
    TestDrivers.surfaceShade(641.0f,885.0f,-862.0f,0f,1200.0f,337.0f,0f,215.0f,0f,0f,0f,0f,0f,1616.0f,-697.0f,549.0f,-425.0f,390.0f,888.0f,-82,-0.073775455f,0.38252434f,0.6655177f,4.0513406f,-30.05415f,13.6186905f ) ;
  }

  @Test
  public void test1346() {
    TestDrivers.surfaceShade(-646.0f,-102.0f,-772.0f,0f,438.0f,1567.0f,0f,259.0f,0f,0f,0f,0f,0f,-845.0f,289.0f,-119.0f,-817.0f,144.0f,819.0f,794,25.273472f,50.346954f,-57.191715f,-39.272224f,63.296455f,56.290905f ) ;
  }

  @Test
  public void test1347() {
    TestDrivers.surfaceShade(-648.0f,1590.0f,366.0f,0f,246.0f,1411.0f,0f,907.0f,0f,0f,0f,0f,0f,-16.0f,-77.0f,493.0f,1727.0f,-2009.0f,78.0f,-1563,-38.06171f,-20.858044f,-4.493016f,-36.02656f,-18.879025f,-12.635732f ) ;
  }

  @Test
  public void test1348() {
    TestDrivers.surfaceShade(652.0f,-1957.0f,0f,0f,1543.0f,1574.0f,0f,746.0f,0f,0f,0f,0f,0f,21.0f,-370.0f,-1388.0f,-1088.0f,-467.0f,808.0f,1114,0.31857046f,-0.23788756f,0.883845f,10.824385f,-2.9253008E-10f,0f ) ;
  }

  @Test
  public void test1349() {
    TestDrivers.surfaceShade(-655.0f,-882.0f,-88.0f,-38.0f,0f,0f,0f,-124.79468f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-206.54375f,-43.691647f,9.242234f ) ;
  }

  @Test
  public void test1350() {
    TestDrivers.surfaceShade(656.0f,-725.0f,12.0f,98.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,112.316216f,-9.636429f,-18.195435f ) ;
  }

  @Test
  public void test1351() {
    TestDrivers.surfaceShade(-657.0f,238.0f,-693.0f,0f,206.0f,470.0f,0f,673.0f,0f,0f,0f,0f,0f,711.0f,170.0f,843.0f,-758.0f,-222.0f,-1597.0f,901,37.723022f,-34.241947f,-30.926355f,-6.70717f,-9.401455f,69.24091f ) ;
  }

  @Test
  public void test1352() {
    TestDrivers.surfaceShade(660.0f,73.0f,255.0f,0f,995.0f,-1381.0f,0f,554.0f,0f,0f,0f,0f,0f,-130.0f,-173.0f,82.0f,785.0f,-444.0f,76.0f,-213,-55.573193f,73.15818f,-72.32025f,80.10246f,99.8666f,-94.46654f ) ;
  }

  @Test
  public void test1353() {
    TestDrivers.surfaceShade(-66.0f,-268.0f,367.0f,0f,900.0f,708.0f,0f,546.0f,0f,0f,0f,0f,0f,46.0f,69.0f,248.0f,12.0f,785.0f,-222.0f,37,-30.918089f,35.02588f,-38.460968f,35.75291f,10.578706f,-5.2690473f ) ;
  }

  @Test
  public void test1354() {
    TestDrivers.surfaceShade(-666.0f,-2069.0f,0f,0f,451.0f,-666.0f,0f,-1.0f,0f,0f,0f,0f,0f,658.0f,-375.0f,-470.0f,0f,0f,0f,162,47.17841f,77.89798f,46.594368f,-98.011566f,-50.027912f,0f ) ;
  }

  @Test
  public void test1355() {
    TestDrivers.surfaceShade(666.0f,-738.0f,0f,0f,-267.0f,62.0f,479.0f,853.0f,0f,0f,0f,0f,0f,-795.0f,-823.0f,-16.0f,283.0f,133.0f,-7.0f,-753,-11.952715f,-91.16947f,-87.73499f,14.964217f,94.57368f,0f ) ;
  }

  @Test
  public void test1356() {
    TestDrivers.surfaceShade(668.0f,0f,0f,0f,16.03564f,-68.88372f,0f,0.0f,0f,0f,0f,0f,0f,-127.424835f,-100.0f,17.532204f,0f,0f,0f,1,64.117584f,-46.936337f,69.11917f,-8.200523f,0f,0f ) ;
  }

  @Test
  public void test1357() {
    TestDrivers.surfaceShade(-673.0f,0f,0f,0f,437.0f,333.0f,103.0f,629.0f,0f,0f,0f,0f,0f,423.0f,-26.0f,72.0f,24.0f,-259.0f,921.0f,-48,-89.26714f,20.323244f,-85.64375f,68.94857f,0f,0f ) ;
  }

  @Test
  public void test1358() {
    TestDrivers.surfaceShade(685.0f,744.0f,188.0f,-5.0f,0f,0f,0f,-50.925316f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-2.688172E-4f,-0.0010638298f ) ;
  }

  @Test
  public void test1359() {
    TestDrivers.surfaceShade(-686.0f,-254.0f,915.0f,0f,718.0f,-593.0f,0f,224.0f,0f,0f,0f,0f,0f,768.0f,-1369.0f,86.0f,528.0f,82.0f,-169.0f,1279,-8.06737f,-4.8354473f,-4.9300847f,-87.313835f,20.311062f,63.36027f ) ;
  }

  @Test
  public void test1360() {
    TestDrivers.surfaceShade(686.0f,-806.0f,0f,0f,282.0f,-2.0f,0f,-214.0f,0f,0f,0f,0f,0f,-529.0f,425.0f,-1355.0f,0f,0f,0f,-1,100.0f,100.0f,7.1239853f,-100.0f,9.064369f,0f ) ;
  }

  @Test
  public void test1361() {
    TestDrivers.surfaceShade(688.0f,-123.0f,10.0f,0f,800.0f,-948.0f,0f,693.0f,0f,0f,0f,0f,0f,150.0f,827.0f,904.0f,-292.0f,26.0f,-657.0f,-632,88.81785f,-27.731636f,-33.912243f,-100.0f,100.0f,45.984566f ) ;
  }

  @Test
  public void test1362() {
    TestDrivers.surfaceShade(-689.0f,0f,709.0f,0f,938.0f,631.0f,0f,-974.0f,0f,0f,0f,0f,0f,-128.0f,-32.0f,215.0f,615.0f,-794.0f,-348.0f,1562,14.686772f,51.60847f,16.425014f,-1.5548986f,0f,-89.15477f ) ;
  }

  @Test
  public void test1363() {
    TestDrivers.surfaceShade(697.0f,-101.0f,0f,0f,310.0f,-6.0f,0f,-434.0f,0f,0f,0f,0f,0f,-859.0f,436.0f,-1130.0f,0f,0f,0f,-1,7.956787f,-15.366424f,100.0f,-23.28845f,-17.989109f,0f ) ;
  }

  @Test
  public void test1364() {
    TestDrivers.surfaceShade(-702.0f,-210.0f,0f,0f,373.0f,-791.0f,0f,486.0f,0f,0f,0f,0f,0f,928.0f,-454.0f,-89.0f,166.0f,-117.0f,329.0f,-193,-96.438835f,48.76503f,67.10145f,90.84802f,11.895056f,0f ) ;
  }

  @Test
  public void test1365() {
    TestDrivers.surfaceShade(704.0f,0f,0f,0f,108.02159f,0.0f,0f,1.9721523E-31f,0f,0f,0f,0f,0f,100.0f,34.042282f,-8.758294f,0f,0f,0f,2,13.385352f,-70.612816f,-17.80184f,2.843574f,0f,0f ) ;
  }

  @Test
  public void test1366() {
    TestDrivers.surfaceShade(-705.0f,0f,0f,0f,610.0f,-146.0f,0f,210.0f,0f,0f,0f,0f,0f,76.0f,385.0f,451.0f,-929.0f,-737.0f,-712.0f,523,-65.99314f,83.10189f,-74.153175f,35.364723f,0f,0f ) ;
  }

  @Test
  public void test1367() {
    TestDrivers.surfaceShade(708.0f,-553.0f,0f,0f,765.0f,827.0f,328.0f,-9.0f,0f,0f,0f,0f,0f,948.0f,-1149.0f,875.0f,458.0f,365.0f,771.0f,-47,51.436405f,28.507921f,-30.812304f,-56.89741f,-59.722492f,0f ) ;
  }

  @Test
  public void test1368() {
    TestDrivers.surfaceShade(7.0f,509.0f,0f,0f,2.0f,-1290.0f,0f,-955.0f,0f,0f,0f,0f,0f,393.0f,-207.0f,970.0f,0f,0f,0f,5,-82.652176f,8.134457f,35.1172f,1.3141533f,39.903072f,0f ) ;
  }

  @Test
  public void test1369() {
    TestDrivers.surfaceShade(-7.0f,679.0f,442.0f,0f,2475.0f,-1033.0f,0f,-461.0f,0f,0f,0f,0f,0f,1785.0f,-1064.0f,-552.0f,0f,0f,0f,-669,0.19570725f,0.3399146f,0.45551717f,-93.34481f,-5.101346f,-100.0f ) ;
  }

  @Test
  public void test1370() {
    TestDrivers.surfaceShade(-710.0f,1076.0f,0f,0f,935.0f,-763.0f,0f,190.0f,0f,0f,0f,0f,0f,1131.0f,-350.0f,788.0f,-210.0f,-59.0f,1397.0f,-503,-0.2588652f,0.7215928f,-0.061727915f,-19.403547f,29.917067f,0f ) ;
  }

  @Test
  public void test1371() {
    TestDrivers.surfaceShade(-71.0f,0f,0f,0f,29.00481f,-4.1692696f,0f,0.0f,0f,0f,0f,0f,0f,40.21839f,25.462774f,90.18359f,0f,0f,0f,1,31.89043f,24.429106f,-21.743221f,91.09355f,0f,0f ) ;
  }

  @Test
  public void test1372() {
    TestDrivers.surfaceShade(-711.0f,1304.0f,0f,0f,1292.0f,858.0f,0f,-2447.0f,0f,0f,0f,0f,0f,419.0f,950.0f,-485.0f,384.0f,-248.0f,-677.0f,-502,23.692722f,34.44216f,87.93259f,-98.275024f,15.916333f,0f ) ;
  }

  @Test
  public void test1373() {
    TestDrivers.surfaceShade(713.0f,-850.0f,0f,0f,21.0f,-1137.0f,0f,-1.0f,0f,0f,0f,0f,0f,-742.0f,-162.0f,534.0f,0f,0f,0f,-230,-7.616289f,51.040314f,-38.056496f,-87.74365f,-100.0f,0f ) ;
  }

  @Test
  public void test1374() {
    TestDrivers.surfaceShade(-714.0f,0f,0f,0f,-782.0f,581.0f,314.0f,0f,0f,0f,0f,0f,0f,-496.0f,-503.0f,-746.0f,793.0f,828.0f,-19.0f,885,68.306816f,-42.17077f,55.868477f,-88.885994f,0f,0f ) ;
  }

  @Test
  public void test1375() {
    TestDrivers.surfaceShade(715.0f,-109.0f,0f,0f,1695.0f,0.0f,0f,-1999.0f,0f,0f,0f,0f,0f,-111.0f,77.0f,468.0f,0f,0f,0f,904,32.72282f,17.140839f,4.9410014f,100.0f,-43.563175f,0f ) ;
  }

  @Test
  public void test1376() {
    TestDrivers.surfaceShade(718.0f,0f,-1004.0f,0f,1.0f,886.0f,0f,-238.0f,0f,0f,0f,0f,0f,408.0f,431.0f,418.0f,-114.0f,152.0f,-168.0f,143,81.21849f,-32.638885f,-45.62149f,67.01705f,0f,-69.2325f ) ;
  }

  @Test
  public void test1377() {
    TestDrivers.surfaceShade(721.0f,0f,0f,0f,-347.0f,-543.0f,831.0f,524.0f,0f,0f,0f,0f,0f,-931.0f,-966.0f,-653.0f,514.0f,-510.0f,143.0f,-304,62.842472f,47.643383f,-25.143879f,86.23262f,0f,0f ) ;
  }

  @Test
  public void test1378() {
    TestDrivers.surfaceShade(-722.0f,-1697.0f,0f,0f,507.0f,210.0f,0f,544.0f,0f,0f,0f,0f,0f,353.0f,387.0f,-191.0f,1567.0f,366.0f,-143.0f,-16,-18.97767f,21.012676f,7.501505f,90.00496f,100.0f,0f ) ;
  }

  @Test
  public void test1379() {
    TestDrivers.surfaceShade(729.0f,0f,0f,0f,14.553668f,0.0f,0f,-11.520748f,0f,0f,0f,0f,0f,-42.27723f,81.74717f,-43.123035f,0f,0f,0f,2,-67.701744f,-9.434704f,-34.198578f,7.799801f,0f,0f ) ;
  }

  @Test
  public void test1380() {
    TestDrivers.surfaceShade(732.0f,1012.0f,0f,215.0f,0f,0f,0f,-59.044773f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-52.35073f,4.5960105E-6f,0f ) ;
  }

  @Test
  public void test1381() {
    TestDrivers.surfaceShade(-733.0f,-1202.0f,0f,0f,138.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1009.0f,-996.0f,-496.0f,0f,0f,0f,1368,78.954994f,-1.0875227f,-26.11271f,2.5869908f,16.484264f,0f ) ;
  }

  @Test
  public void test1382() {
    TestDrivers.surfaceShade(-739.0f,-219.0f,0f,0f,543.0f,-812.0f,0f,-271.0f,0f,0f,0f,0f,0f,460.0f,364.0f,792.0f,0f,0f,0f,1,-70.78212f,-49.86551f,-46.82314f,-48.710144f,-24.872068f,0f ) ;
  }

  @Test
  public void test1383() {
    TestDrivers.surfaceShade(744.0f,-1706.0f,2001.0f,0f,364.0f,-2538.0f,0f,721.0f,0f,0f,0f,0f,0f,123.0f,752.0f,1803.0f,1174.0f,-1179.0f,371.0f,-970,-0.7242792f,-3.6246996E-4f,-0.6080978f,40.671665f,94.21152f,55.790024f ) ;
  }

  @Test
  public void test1384() {
    TestDrivers.surfaceShade(-744.0f,-204.0f,0f,0f,19.0f,-1323.0f,0f,-3.0f,0f,0f,0f,0f,0f,-1825.0f,1382.0f,-147.0f,0f,0f,0f,-1,48.84115f,65.69802f,18.296227f,1.6121812f,-1.9936851E-5f,0f ) ;
  }

  @Test
  public void test1385() {
    TestDrivers.surfaceShade(746.0f,496.0f,638.0f,0f,390.0f,830.0f,0f,78.0f,0f,0f,0f,0f,0f,-1641.0f,671.0f,156.0f,407.0f,238.0f,380.0f,1170,22.21638f,5.762035f,-30.748577f,-88.51955f,-84.76022f,69.027336f ) ;
  }

  @Test
  public void test1386() {
    TestDrivers.surfaceShade(-749.0f,-220.0f,0f,0f,741.0f,5.0f,0f,5.0f,0f,0f,0f,0f,0f,-346.0f,-526.0f,1138.0f,0f,0f,0f,-20,-100.0f,-4.769301f,-37.796486f,100.0f,19.292809f,0f ) ;
  }

  @Test
  public void test1387() {
    TestDrivers.surfaceShade(75.0f,0f,0f,0f,160.0f,1031.0f,0f,-889.0f,0f,0f,0f,0f,0f,-1104.0f,1.0f,459.0f,408.0f,-475.0f,-1124.0f,-25,-0.08913566f,0.97224617f,-0.21717733f,-6.7711234f,0f,0f ) ;
  }

  @Test
  public void test1388() {
    TestDrivers.surfaceShade(-751.0f,-494.0f,0f,-247.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-118.340775f,8.195512E-6f,0f ) ;
  }

  @Test
  public void test1389() {
    TestDrivers.surfaceShade(756.0f,271.0f,0f,0f,565.0f,-416.0f,0f,266.0f,0f,0f,0f,0f,0f,-272.0f,560.0f,-841.0f,-691.0f,422.0f,119.0f,430,-52.250595f,54.97931f,53.50841f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1390() {
    TestDrivers.surfaceShade(759.0f,-2440.0f,0f,0f,2.0f,5.0f,0f,-1442.0f,0f,0f,0f,0f,0f,487.0f,1547.0f,1082.0f,0f,0f,0f,-931,0.52098113f,0.10232155f,-0.38078505f,4.0165877f,-90.301956f,0f ) ;
  }

  @Test
  public void test1391() {
    TestDrivers.surfaceShade(764.0f,304.0f,300.0f,0f,37.0f,-543.0f,0f,-875.0f,0f,0f,0f,0f,0f,326.0f,97.0f,540.0f,0f,0f,0f,776,-65.00352f,31.317911f,-79.6819f,-19.379253f,-37.90709f,8.920809f ) ;
  }

  @Test
  public void test1392() {
    TestDrivers.surfaceShade(-770.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,39.20362f,32.70075f,29.805851f,0f,0f,0f,1,-24.095871f,-11.956856f,2.2708752f,73.03756f,0f,0f ) ;
  }

  @Test
  public void test1393() {
    TestDrivers.surfaceShade(-772.0f,0f,459.0f,0f,208.0f,438.0f,0f,-1456.0f,0f,0f,0f,0f,0f,601.0f,212.0f,251.0f,62.0f,-1116.0f,-1993.0f,-36,-28.444798f,-18.229757f,83.5061f,-27.245335f,0f,46.259212f ) ;
  }

  @Test
  public void test1394() {
    TestDrivers.surfaceShade(-772.0f,-733.0f,0f,0f,650.0f,36.0f,0f,39.0f,0f,0f,0f,0f,0f,608.0f,119.0f,-126.0f,512.0f,-327.0f,-990.0f,-388,6.1063905f,-8.51945f,21.419762f,91.78034f,-34.98527f,0f ) ;
  }

  @Test
  public void test1395() {
    TestDrivers.surfaceShade(-780.0f,758.0f,435.0f,0f,201.0f,-1813.0f,0f,-245.0f,0f,0f,0f,0f,0f,-650.0f,556.0f,-356.0f,0f,0f,0f,739,86.94096f,62.16871f,-61.645573f,-53.372658f,-62.391033f,99.99991f ) ;
  }

  @Test
  public void test1396() {
    TestDrivers.surfaceShade(780.0f,-80.0f,-279.0f,0f,482.0f,-1685.0f,0f,197.0f,0f,0f,0f,0f,0f,105.0f,-90.0f,163.0f,-802.0f,-807.0f,-273.0f,89,73.31338f,13.315192f,-39.874462f,-100.0f,-100.0f,-3.9971845f ) ;
  }

  @Test
  public void test1397() {
    TestDrivers.surfaceShade(78.0f,0f,0f,0f,27.089495f,0.0f,0f,-22.966492f,0f,0f,0f,0f,0f,-48.80033f,-32.975426f,-39.468456f,0f,0f,0f,418,-0.08596647f,-0.6094149f,0.615482f,0.38845405f,0f,0f ) ;
  }

  @Test
  public void test1398() {
    TestDrivers.surfaceShade(78.0f,0f,0f,546.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.3480792E-5f,0f,0f ) ;
  }

  @Test
  public void test1399() {
    TestDrivers.surfaceShade(-78.0f,467.0f,0f,0f,21.0f,-994.0f,0f,1500.0f,0f,0f,0f,0f,0f,-123.0f,-822.0f,944.0f,377.0f,-212.0f,10.0f,745,99.187f,100.0f,100.0f,13.1351f,-100.0f,0f ) ;
  }

  @Test
  public void test1400() {
    TestDrivers.surfaceShade(-782.0f,0f,0f,0f,977.0f,65.0f,0f,-109.0f,0f,0f,0f,0f,0f,408.0f,1217.0f,571.0f,148.0f,-1757.0f,322.0f,714,-0.0067485236f,0.007146454f,-1.005454f,23.257698f,0f,0f ) ;
  }

  @Test
  public void test1401() {
    TestDrivers.surfaceShade(-790.0f,115.0f,0f,0f,1704.0f,-5.0f,0f,8.0f,0f,0f,0f,0f,0f,797.0f,176.0f,-26.0f,0f,0f,0f,1248,-4.5636296f,20.93496f,1.8207653f,-1.5451087f,100.0f,0f ) ;
  }

  @Test
  public void test1402() {
    TestDrivers.surfaceShade(79.0f,0f,0f,0f,977.0f,560.0f,50.0f,0.0f,0f,0f,0f,0f,0f,51.0f,1135.0f,-759.0f,-1625.0f,630.0f,-598.0f,-1009,129.23016f,-21.099203f,90.974464f,-17.328259f,0f,0f ) ;
  }

  @Test
  public void test1403() {
    TestDrivers.surfaceShade(-79.0f,-719.0f,-1505.0f,0f,467.0f,2.0f,0f,-551.0f,0f,0f,0f,0f,0f,-515.0f,1156.0f,137.0f,0f,0f,0f,532,44.353622f,-64.57138f,-50.10845f,-95.48719f,117.79016f,-95.24558f ) ;
  }

  @Test
  public void test1404() {
    TestDrivers.surfaceShade(792.0f,0f,0f,0f,12.639323f,-95.50367f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-99.9745f,16.435535f,0f,0f,0f,-775,-0.013051033f,0.540702f,0.83816123f,51.58812f,0f,0f ) ;
  }

  @Test
  public void test1405() {
    TestDrivers.surfaceShade(793.0f,23.0f,0f,0f,617.0f,977.0f,0f,944.0f,0f,0f,0f,0f,0f,326.0f,220.0f,231.0f,-981.0f,-91.0f,-261.0f,350,-69.17906f,89.23972f,7.423733f,-33.233948f,-34.47878f,0f ) ;
  }

  @Test
  public void test1406() {
    TestDrivers.surfaceShade(794.0f,-2328.0f,-35.0f,-258.0f,0f,0f,0f,-92.05551f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-34.968513f,1.10741974E-4f ) ;
  }

  @Test
  public void test1407() {
    TestDrivers.surfaceShade(-794.0f,-251.0f,0f,0f,59.0f,-234.0f,0f,1207.0f,0f,0f,0f,0f,0f,25.0f,790.0f,-313.0f,288.0f,-490.0f,-828.0f,-575,-0.11671993f,-0.667134f,-0.48792648f,-74.56826f,-100.0f,0f ) ;
  }

  @Test
  public void test1408() {
    TestDrivers.surfaceShade(795.0f,-1109.0f,-61.0f,0f,1471.0f,-1719.0f,0f,3.0f,0f,0f,0f,0f,0f,-768.0f,171.0f,605.0f,0f,0f,0f,656,-42.062386f,71.45464f,-73.59116f,3.7170265f,75.02048f,-21.84146f ) ;
  }

  @Test
  public void test1409() {
    TestDrivers.surfaceShade(-802.0f,-1011.0f,-936.0f,0f,224.0f,-267.0f,0f,-755.0f,0f,0f,0f,0f,0f,-938.0f,1563.0f,-475.0f,0f,0f,0f,-765,-0.4178273f,-0.10319114f,0.7155713f,-17.638653f,7.7888236f,-6.168946f ) ;
  }

  @Test
  public void test1410() {
    TestDrivers.surfaceShade(-805.0f,-1393.0f,0f,0f,774.0f,-4.0f,0f,-630.0f,0f,0f,0f,0f,0f,-94.0f,-79.0f,2120.0f,0f,0f,0f,-179,0.5053241f,0.21130769f,-0.55731356f,57.98371f,72.454994f,0f ) ;
  }

  @Test
  public void test1411() {
    TestDrivers.surfaceShade(-808.0f,0f,0f,0f,32.22637f,-76.74294f,0f,4.9303807E-32f,0f,0f,0f,0f,0f,5.6268883f,91.59664f,-68.14275f,0f,0f,0f,-1,100.0f,-6.92102f,50.183517f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1412() {
    TestDrivers.surfaceShade(813.0f,0f,0f,-622.0f,0f,0f,0f,-46.17664f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,99.16293f,0f,0f ) ;
  }

  @Test
  public void test1413() {
    TestDrivers.surfaceShade(-819.0f,0f,0f,0f,16.4819f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,47.461906f,27.311644f,37.88975f,0f,0f,0f,-1520,-0.11392465f,-0.4475966f,-0.8630808f,-20.227211f,0f,0f ) ;
  }

  @Test
  public void test1414() {
    TestDrivers.surfaceShade(-822.0f,-311.0f,0f,0f,1046.0f,-17.0f,0f,752.0f,0f,0f,0f,0f,0f,-1498.0f,-874.0f,762.0f,-657.0f,-2395.0f,402.0f,-159,0.51400477f,-0.03771639f,0.059878845f,51.07771f,7.5941687f,0f ) ;
  }

  @Test
  public void test1415() {
    TestDrivers.surfaceShade(-823.0f,-715.0f,0f,0f,369.0f,126.0f,0f,-295.0f,0f,0f,0f,0f,0f,-657.0f,844.0f,574.0f,255.0f,471.0f,-746.0f,387,-100.0f,-100.0f,-25.93108f,-43.100037f,-20.126083f,0f ) ;
  }

  @Test
  public void test1416() {
    TestDrivers.surfaceShade(827.0f,1849.0f,543.0f,0f,1757.0f,-341.0f,0f,476.0f,0f,0f,0f,0f,0f,273.0f,915.0f,750.0f,23.0f,161.0f,-325.0f,-925,-2.6314883f,12.981179f,-14.879177f,63.69348f,100.0f,0.5788181f ) ;
  }

  @Test
  public void test1417() {
    TestDrivers.surfaceShade(-828.0f,-333.0f,-2249.0f,0f,2650.0f,1178.0f,0f,-1330.0f,0f,0f,0f,0f,0f,-1183.0f,104.0f,123.0f,102.0f,1774.0f,-2195.0f,1053,0.08418991f,0.066298105f,-0.38211077f,98.740654f,65.947914f,100.0f ) ;
  }

  @Test
  public void test1418() {
    TestDrivers.surfaceShade(828.0f,397.0f,-672.0f,-33.0f,0f,0f,0f,-44.29069f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-62.70119f,-7.633005E-5f,100.0f ) ;
  }

  @Test
  public void test1419() {
    TestDrivers.surfaceShade(832.0f,1545.0f,0f,0f,224.0f,0.0f,0f,-877.0f,0f,0f,0f,0f,0f,-431.0f,467.0f,321.0f,0f,0f,0f,-797,5.306052f,-100.0f,32.722443f,100.0f,-24.76323f,0f ) ;
  }

  @Test
  public void test1420() {
    TestDrivers.surfaceShade(833.0f,0f,0f,0f,63.28752f,-57.22014f,0f,0.0f,0f,0f,0f,0f,0f,53.54517f,-17.565048f,-27.369513f,0f,0f,0f,-131,-0.66183007f,-0.62496996f,0.3870145f,-28.737318f,0f,0f ) ;
  }

  @Test
  public void test1421() {
    TestDrivers.surfaceShade(833.0f,-216.0f,918.0f,0f,373.0f,1.0f,0f,-212.0f,0f,0f,0f,0f,0f,-329.0f,987.0f,51.0f,0f,0f,0f,-486,-19.97732f,-42.06687f,65.01408f,58.96561f,13.979136f,-12.003143f ) ;
  }

  @Test
  public void test1422() {
    TestDrivers.surfaceShade(835.0f,11.0f,2401.0f,0f,344.0f,-108.0f,0f,961.0f,0f,0f,0f,0f,0f,-1489.0f,1991.0f,-57.0f,-668.0f,-423.0f,559.0f,-1410,-0.1371298f,-0.14637855f,-0.51936513f,72.400475f,-1.6509424f,97.63231f ) ;
  }

  @Test
  public void test1423() {
    TestDrivers.surfaceShade(-835.0f,-22.0f,-14.0f,0f,1592.0f,-1082.0f,0f,647.0f,0f,0f,0f,0f,0f,351.0f,-1418.0f,460.0f,-1007.0f,1063.0f,1109.0f,-464,-0.936308f,-0.08900763f,0.44006807f,96.098694f,-100.0f,-21.950739f ) ;
  }

  @Test
  public void test1424() {
    TestDrivers.surfaceShade(839.0f,347.0f,0f,-418.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,77.64835f,-39.75486f,0f ) ;
  }

  @Test
  public void test1425() {
    TestDrivers.surfaceShade(-841.0f,273.0f,-835.0f,0f,515.0f,-473.0f,0f,-517.0f,0f,0f,0f,0f,0f,-911.0f,-773.0f,631.0f,0f,0f,0f,-652,-61.484898f,34.927605f,-45.980515f,-39.344704f,26.225452f,-25.104198f ) ;
  }

  @Test
  public void test1426() {
    TestDrivers.surfaceShade(-846.0f,1223.0f,0f,0f,912.0f,-4.0f,0f,5.0f,0f,0f,0f,0f,0f,340.0f,-177.0f,-747.0f,0f,0f,0f,952,2.1996238f,93.07802f,-21.053463f,-43.479965f,5.8052444f,0f ) ;
  }

  @Test
  public void test1427() {
    TestDrivers.surfaceShade(-855.0f,-44.0f,1930.0f,0f,20.0f,194.0f,0f,33.0f,0f,0f,0f,0f,0f,-554.0f,-653.0f,315.0f,55.0f,1022.0f,436.0f,1855,-0.66116285f,0.53590703f,-0.05186511f,-15.4432535f,-2.0437942f,-35.453587f ) ;
  }

  @Test
  public void test1428() {
    TestDrivers.surfaceShade(-859.0f,911.0f,0f,0f,32.0f,-350.0f,0f,228.0f,0f,0f,0f,0f,0f,135.0f,624.0f,-130.0f,-10.0f,196.0f,-177.0f,514,15.034211f,6.2441206f,45.58423f,-16.797716f,15.838892f,0f ) ;
  }

  @Test
  public void test1429() {
    TestDrivers.surfaceShade(86.0f,0f,0f,0f,41.49096f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-20.105333f,117.02246f,17.975391f,0f,0f,0f,1035,0.7769297f,-0.23016135f,2.2305014f,-46.10692f,0f,0f ) ;
  }

  @Test
  public void test1430() {
    TestDrivers.surfaceShade(-86.0f,12.0f,-937.0f,-550.0f,0f,0f,0f,-65.37989f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,23.538868f,-1.5151515E-4f,-89.84391f ) ;
  }

  @Test
  public void test1431() {
    TestDrivers.surfaceShade(862.0f,500.0f,717.0f,0f,85.0f,-105.0f,0f,190.0f,0f,0f,0f,0f,0f,-230.0f,860.0f,249.0f,-1420.0f,-464.0f,1119.0f,918,57.6572f,35.75245f,-70.2247f,4.645729f,-73.94496f,38.468914f ) ;
  }

  @Test
  public void test1432() {
    TestDrivers.surfaceShade(864.0f,316.0f,0f,0f,403.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-806.0f,531.0f,765.0f,0f,0f,0f,-1724,16.07945f,68.00372f,-30.261358f,20.906837f,67.66626f,0f ) ;
  }

  @Test
  public void test1433() {
    TestDrivers.surfaceShade(-865.0f,-1574.0f,6.0f,0f,24.0f,-34.0f,0f,84.0f,0f,0f,0f,0f,0f,136.0f,-412.0f,-811.0f,235.0f,999.0f,-886.0f,125,-88.38379f,79.793884f,-55.357925f,26.2036f,-6.285237f,60.70609f ) ;
  }

  @Test
  public void test1434() {
    TestDrivers.surfaceShade(865.0f,-2631.0f,-762.0f,0f,372.0f,-726.0f,0f,-931.0f,0f,0f,0f,0f,0f,889.0f,-925.0f,-749.0f,0f,0f,0f,-696,77.532455f,16.712471f,71.38493f,42.38151f,21.773397f,-72.81035f ) ;
  }

  @Test
  public void test1435() {
    TestDrivers.surfaceShade(869.0f,0f,0f,0f,2.4731654E-7f,-57.25085f,0f,-20.415401f,0f,0f,0f,0f,0f,8.504009f,100.0f,-66.63985f,0f,0f,0f,1840,0.5703341f,-0.66429085f,0.32184628f,56.041412f,0f,0f ) ;
  }

  @Test
  public void test1436() {
    TestDrivers.surfaceShade(-869.0f,0f,0f,0f,729.0f,533.0f,0f,943.0f,0f,0f,0f,0f,0f,-403.0f,-217.0f,265.0f,865.0f,320.0f,-856.0f,423,49.390583f,48.67647f,-2.892563f,79.1083f,0f,0f ) ;
  }

  @Test
  public void test1437() {
    TestDrivers.surfaceShade(874.0f,553.0f,0f,0f,611.0f,1895.0f,0f,-462.0f,0f,0f,0f,0f,0f,332.0f,159.0f,485.0f,1963.0f,896.0f,892.0f,-1513,-41.02472f,-5.895596f,30.015682f,89.839966f,38.505733f,0f ) ;
  }

  @Test
  public void test1438() {
    TestDrivers.surfaceShade(-878.0f,1153.0f,0f,0f,903.0f,993.0f,0f,305.0f,0f,0f,0f,0f,0f,-234.0f,371.0f,776.0f,167.0f,1005.0f,967.0f,-423,-36.032166f,4.147006f,-12.848022f,10.073757f,39.294014f,0f ) ;
  }

  @Test
  public void test1439() {
    TestDrivers.surfaceShade(-88.0f,0f,0f,0f,21.00308f,-60.58189f,0f,0.0f,0f,0f,0f,0f,0f,-85.23951f,51.15621f,-33.299206f,0f,0f,0f,724,55.952328f,92.42827f,-1.2333183f,-14.730069f,0f,0f ) ;
  }

  @Test
  public void test1440() {
    TestDrivers.surfaceShade(882.0f,245.0f,0f,0f,1490.0f,-1.0f,0f,4.0f,0f,0f,0f,0f,0f,-1190.0f,-815.0f,-72.0f,0f,0f,0f,123,0.37113515f,-0.01940512f,0.2557194f,-33.582558f,-62.15639f,0f ) ;
  }

  @Test
  public void test1441() {
    TestDrivers.surfaceShade(884.0f,492.0f,0f,0f,245.0f,-1509.0f,0f,1180.0f,0f,0f,0f,0f,0f,870.0f,-1501.0f,1173.0f,705.0f,1231.0f,-517.0f,-431,1.7252069f,-0.7222981f,-2.2038357f,-76.09162f,4.66994f,0f ) ;
  }

  @Test
  public void test1442() {
    TestDrivers.surfaceShade(-888.0f,49.0f,0f,695.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.6203254E-6f,100.0f,0f ) ;
  }

  @Test
  public void test1443() {
    TestDrivers.surfaceShade(-89.0f,0f,0f,0f,2549.0f,-195.0f,0f,93.0f,0f,0f,0f,0f,0f,1180.0f,-394.0f,629.0f,-892.0f,-521.0f,29.0f,-1179,-0.96220315f,0.23356082f,0.14005171f,6.1180406f,0f,0f ) ;
  }

  @Test
  public void test1444() {
    TestDrivers.surfaceShade(-89.0f,0f,0f,432.0f,0f,0f,0f,11.389798f,0f,0f,0f,0f,0f,-76.53161f,25.632738f,54.532974f,379.0f,-1315.0f,509.0f,0,0f,0f,0f,-2.6009155E-5f,0f,0f ) ;
  }

  @Test
  public void test1445() {
    TestDrivers.surfaceShade(-894.0f,438.0f,-833.0f,86.0f,0f,0f,0f,-80.70984f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,69.72719f,-1.3959072E-5f ) ;
  }

  @Test
  public void test1446() {
    TestDrivers.surfaceShade(-895.0f,-1392.0f,144.0f,0f,141.0f,488.0f,0f,-355.0f,0f,0f,0f,0f,0f,-96.0f,-527.0f,425.0f,1270.0f,1218.0f,-1165.0f,17,-33.497578f,73.08241f,83.05568f,51.903755f,-61.275333f,99.99938f ) ;
  }

  @Test
  public void test1447() {
    TestDrivers.surfaceShade(90.0f,-641.0f,393.0f,0f,105.0f,-1421.0f,0f,1200.0f,0f,0f,0f,0f,0f,1152.0f,-502.0f,-747.0f,-1800.0f,1633.0f,-431.0f,874,-0.41688114f,0.042906027f,-0.052564263f,25.814953f,-0.63743436f,83.61672f ) ;
  }

  @Test
  public void test1448() {
    TestDrivers.surfaceShade(901.0f,-386.0f,0f,0f,24.0f,-291.0f,0f,2759.0f,0f,0f,0f,0f,0f,713.0f,392.0f,-1391.0f,308.0f,-322.0f,696.0f,856,-0.557378f,-0.49211904f,0.6686917f,-24.24933f,-0.704239f,0f ) ;
  }

  @Test
  public void test1449() {
    TestDrivers.surfaceShade(-902.0f,1490.0f,-390.0f,0f,505.0f,1582.0f,0f,765.0f,0f,0f,0f,0f,0f,2442.0f,1341.0f,736.0f,-992.0f,700.0f,-335.0f,-81,-0.0279939f,-0.8961759f,-0.4341124f,-71.04103f,47.945457f,33.55088f ) ;
  }

  @Test
  public void test1450() {
    TestDrivers.surfaceShade(-905.0f,0f,0f,0f,688.0f,-1136.0f,0f,1007.0f,0f,0f,0f,0f,0f,1651.0f,397.0f,-727.0f,-576.0f,-378.0f,457.0f,1198,-0.37102357f,-0.63618743f,-0.29028952f,19.865051f,0f,0f ) ;
  }

  @Test
  public void test1451() {
    TestDrivers.surfaceShade(906.0f,903.0f,-661.0f,0f,303.0f,610.0f,0f,-265.0f,0f,0f,0f,0f,0f,-773.0f,380.0f,-358.0f,433.0f,190.0f,-340.0f,-633,32.86105f,-28.282745f,-2.527704f,-29.727633f,-76.160286f,-25.96116f ) ;
  }

  @Test
  public void test1452() {
    TestDrivers.surfaceShade(9.0f,257.0f,0f,-54.0f,0f,0f,0f,-8.804514E-15f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.002057613f,100.0f,0f ) ;
  }

  @Test
  public void test1453() {
    TestDrivers.surfaceShade(-913.0f,1302.0f,545.0f,0f,228.0f,810.0f,0f,-2046.0f,0f,0f,0f,0f,0f,-496.0f,865.0f,623.0f,-17.0f,-55.0f,-628.0f,1224,-77.987366f,-67.68411f,31.886072f,-76.15975f,12.676346f,30.284332f ) ;
  }

  @Test
  public void test1454() {
    TestDrivers.surfaceShade(-913.0f,81.0f,1473.0f,0f,845.0f,225.0f,0f,882.0f,0f,0f,0f,0f,0f,-145.0f,742.0f,891.0f,1856.0f,-97.0f,256.0f,371,-9.1161995f,-89.487495f,73.03898f,89.85447f,100.0f,7.5475307f ) ;
  }

  @Test
  public void test1455() {
    TestDrivers.surfaceShade(-914.0f,476.0f,0f,0f,542.0f,1336.0f,0f,-831.0f,0f,0f,0f,0f,0f,323.0f,94.0f,977.0f,886.0f,-233.0f,496.0f,994,-61.262177f,13.137524f,18.989483f,14.309704f,100.0f,0f ) ;
  }

  @Test
  public void test1456() {
    TestDrivers.surfaceShade(-916.0f,595.0f,18.0f,0f,20.0f,-2701.0f,0f,2142.0f,0f,0f,0f,0f,0f,-502.0f,-865.0f,41.0f,-141.0f,-192.0f,-376.0f,172,-0.37786755f,0.8413001f,0.3764416f,-100.0f,58.516933f,-3.9333077E-5f ) ;
  }

  @Test
  public void test1457() {
    TestDrivers.surfaceShade(-918.0f,0f,0f,0f,-76.0f,-386.0f,599.0f,-758.0f,0f,0f,0f,0f,0f,66.0f,-904.0f,-375.0f,251.0f,-901.0f,-462.0f,-468,5.1698194f,-12.293036f,52.80738f,-77.71499f,0f,0f ) ;
  }

  @Test
  public void test1458() {
    TestDrivers.surfaceShade(919.0f,-698.0f,422.0f,0f,298.0f,-1263.0f,0f,19.0f,0f,0f,0f,0f,0f,-929.0f,593.0f,15.0f,1013.0f,-1369.0f,982.0f,-1412,-30.517132f,-47.808258f,-0.007960033f,71.33979f,-63.5051f,-36.42244f ) ;
  }

  @Test
  public void test1459() {
    TestDrivers.surfaceShade(924.0f,0f,0f,0f,67.831924f,0.0f,0f,-50.71219f,0f,0f,0f,0f,0f,-94.795494f,-71.99154f,-84.62099f,0f,0f,0f,142,40.090454f,-43.4539f,21.656734f,56.565117f,0f,0f ) ;
  }

  @Test
  public void test1460() {
    TestDrivers.surfaceShade(927.0f,49.0f,0f,0f,62.0f,-352.0f,0f,-5.0f,0f,0f,0f,0f,0f,959.0f,156.0f,-804.0f,0f,0f,0f,-519,-0.47275344f,-0.34727514f,-0.6222719f,-49.14823f,-0.5353383f,0f ) ;
  }

  @Test
  public void test1461() {
    TestDrivers.surfaceShade(-927.0f,-596.0f,0f,0f,1696.0f,-522.0f,0f,-811.0f,0f,0f,0f,0f,0f,306.0f,33.0f,278.0f,0f,0f,0f,-148,-16.046227f,-25.350206f,20.671589f,-99.97848f,-99.98486f,0f ) ;
  }

  @Test
  public void test1462() {
    TestDrivers.surfaceShade(-928.0f,496.0f,-666.0f,0f,64.0f,-475.0f,0f,-35.0f,0f,0f,0f,0f,0f,867.0f,-362.0f,-620.0f,0f,0f,0f,-857,43.01455f,-23.639372f,73.95333f,55.224854f,95.81053f,-0.23728338f ) ;
  }

  @Test
  public void test1463() {
    TestDrivers.surfaceShade(-931.0f,-439.0f,394.0f,0f,190.0f,995.0f,0f,-2399.0f,0f,0f,0f,0f,0f,1415.0f,1912.0f,1479.0f,-809.0f,-210.0f,126.0f,1070,0.094693616f,-0.7057333f,0.626078f,-121.681725f,33.464314f,-100.0f ) ;
  }

  @Test
  public void test1464() {
    TestDrivers.surfaceShade(934.0f,932.0f,0f,0f,114.0f,341.0f,0f,687.0f,0f,0f,0f,0f,0f,597.0f,106.0f,-1060.0f,-674.0f,-1215.0f,1723.0f,512,-18.349882f,77.92857f,-2.5419352f,63.680458f,63.817043f,0f ) ;
  }

  @Test
  public void test1465() {
    TestDrivers.surfaceShade(936.0f,-1123.0f,-37.0f,0f,870.0f,-1006.0f,0f,-543.0f,0f,0f,0f,0f,0f,475.0f,-1134.0f,585.0f,0f,0f,0f,354,-0.054005556f,0.280094f,0.56361234f,62.056797f,-22.925556f,-63.651237f ) ;
  }

  @Test
  public void test1466() {
    TestDrivers.surfaceShade(-936.0f,546.0f,-189.0f,0f,1107.0f,-749.0f,0f,487.0f,0f,0f,0f,0f,0f,66.0f,-188.0f,-996.0f,-167.0f,-1490.0f,162.0f,116,100.0f,-71.679756f,93.560036f,173.48218f,-100.0f,63.451035f ) ;
  }

  @Test
  public void test1467() {
    TestDrivers.surfaceShade(-939.0f,58.0f,0f,0f,103.0f,0.0f,0f,-7.0f,0f,0f,0f,0f,0f,1407.0f,-2033.0f,-284.0f,0f,0f,0f,1470,-13.746055f,-8.583882f,-6.653752f,44.753696f,19.360588f,0f ) ;
  }

  @Test
  public void test1468() {
    TestDrivers.surfaceShade(-94.0f,-161.0f,0f,423.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-38.143246f,-10.567659f,0f ) ;
  }

  @Test
  public void test1469() {
    TestDrivers.surfaceShade(945.0f,0f,0f,0f,73.31557f,-55.608982f,0f,-24.89803f,0f,0f,0f,0f,0f,71.06716f,-97.57176f,-40.38421f,0f,0f,0f,-987,-13.526773f,80.43986f,-51.988888f,16.45574f,0f,0f ) ;
  }

  @Test
  public void test1470() {
    TestDrivers.surfaceShade(949.0f,-689.0f,0f,0f,420.0f,431.0f,103.0f,-432.0f,0f,0f,0f,0f,0f,695.0f,-899.0f,980.0f,125.0f,817.0f,68.0f,-276,-7.0025873f,-15.136054f,91.73191f,-55.83098f,-12.72679f,0f ) ;
  }

  @Test
  public void test1471() {
    TestDrivers.surfaceShade(-950.0f,-27.0f,-1427.0f,0f,186.0f,1449.0f,0f,-657.0f,0f,0f,0f,0f,0f,42.0f,-80.0f,527.0f,-543.0f,283.0f,-514.0f,-318,69.98149f,19.965239f,-2.5464962f,-5.279342f,-54.18175f,100.0f ) ;
  }

  @Test
  public void test1472() {
    TestDrivers.surfaceShade(953.0f,-378.0f,0f,0f,1574.0f,380.0f,-859.0f,-376.0f,0f,0f,0f,0f,0f,-529.0f,-1367.0f,-461.0f,-317.0f,-1351.0f,226.0f,269,0.09045983f,-0.13599212f,0.9333547f,-20.45161f,-57.04915f,0f ) ;
  }

  @Test
  public void test1473() {
    TestDrivers.surfaceShade(-961.0f,-806.0f,1711.0f,0f,228.0f,-577.0f,0f,-1479.0f,0f,0f,0f,0f,0f,-179.0f,308.0f,970.0f,0f,0f,0f,193,-67.21779f,-19.10208f,-6.338704f,-112.09947f,-7.5373054f,3.5551636f ) ;
  }

  @Test
  public void test1474() {
    TestDrivers.surfaceShade(962.0f,-1109.0f,198.0f,0f,1626.0f,-173.0f,0f,581.0f,0f,0f,0f,0f,0f,-833.0f,-496.0f,426.0f,-1.0f,1123.0f,926.0f,-2044,-0.23059896f,0.18770923f,-0.8577746f,83.8309f,-8.195512f,-100.0f ) ;
  }

  @Test
  public void test1475() {
    TestDrivers.surfaceShade(-964.0f,0f,0f,0f,802.0f,738.0f,0f,333.0f,0f,0f,0f,0f,0f,-417.0f,-52.0f,-452.0f,224.0f,-1664.0f,-1021.0f,-977,-78.95452f,-11.827412f,74.20146f,62.358017f,0f,0f ) ;
  }

  @Test
  public void test1476() {
    TestDrivers.surfaceShade(968.0f,519.0f,0f,0f,205.0f,-7.0f,0f,-493.0f,0f,0f,0f,0f,0f,84.0f,1736.0f,-423.0f,0f,0f,0f,8,26.284061f,13.63959f,61.199783f,-2.4111261f,-0.3987937f,0f ) ;
  }

  @Test
  public void test1477() {
    TestDrivers.surfaceShade(-969.0f,-998.0f,-53.0f,0f,117.0f,662.0f,0f,-544.0f,0f,0f,0f,0f,0f,-521.0f,-626.0f,-50.0f,963.0f,-160.0f,396.0f,857,0.26461437f,0.8878332f,0.07751328f,44.948578f,-17.685118f,7.975565f ) ;
  }

  @Test
  public void test1478() {
    TestDrivers.surfaceShade(-97.0f,-322.0f,-2538.0f,0f,204.0f,-1077.0f,0f,-1195.0f,0f,0f,0f,0f,0f,-422.0f,-375.0f,-130.0f,0f,0f,0f,520,-18.031921f,-2.898695f,66.89601f,-55.57935f,29.204224f,16.238737f ) ;
  }

  @Test
  public void test1479() {
    TestDrivers.surfaceShade(972.0f,843.0f,0f,0f,1470.0f,451.0f,0f,690.0f,0f,0f,0f,0f,0f,-946.0f,1411.0f,-955.0f,1064.0f,407.0f,682.0f,-28,-0.41793352f,-0.17760853f,0.775065f,44.943043f,90.12029f,0f ) ;
  }

  @Test
  public void test1480() {
    TestDrivers.surfaceShade(973.0f,1851.0f,0f,1182.0f,0f,0f,0f,-29.469332f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.57753f,-2.9470997f,0f ) ;
  }

  @Test
  public void test1481() {
    TestDrivers.surfaceShade(-974.0f,-258.0f,0f,0f,74.0f,-1.0f,0f,-1179.0f,0f,0f,0f,0f,0f,408.0f,347.0f,1077.0f,0f,0f,0f,639,0.59499705f,-0.44461846f,-0.082150586f,-78.03127f,-7.918335f,0f ) ;
  }

  @Test
  public void test1482() {
    TestDrivers.surfaceShade(979.0f,-573.0f,0f,0f,318.0f,-1445.0f,0f,-3.0f,0f,0f,0f,0f,0f,-459.0f,-559.0f,-80.0f,0f,0f,0f,1087,-61.082394f,45.143585f,91.44892f,-53.543114f,77.01409f,0f ) ;
  }

  @Test
  public void test1483() {
    TestDrivers.surfaceShade(980.0f,0f,0f,0f,159.0f,1363.0f,0f,1107.0f,0f,0f,0f,0f,0f,382.0f,1073.0f,1294.0f,-1604.0f,-324.0f,239.0f,-853,-0.07070859f,-0.26912898f,-0.28210464f,9.998051f,0f,0f ) ;
  }

  @Test
  public void test1484() {
    TestDrivers.surfaceShade(98.0f,117.0f,77.0f,0f,229.0f,-614.0f,0f,1274.0f,0f,0f,0f,0f,0f,766.0f,-1401.0f,799.0f,-634.0f,769.0f,-1132.0f,-761,0.6813169f,0.5308632f,0.27765924f,-67.44694f,-50.739902f,0.0672027f ) ;
  }

  @Test
  public void test1485() {
    TestDrivers.surfaceShade(-982.0f,-52.0f,467.0f,0f,260.0f,-989.0f,0f,856.0f,0f,0f,0f,0f,0f,-525.0f,-745.0f,370.0f,-365.0f,-761.0f,-739.0f,682,82.377266f,28.15943f,5.237643f,-82.77393f,34.042152f,30.18019f ) ;
  }

  @Test
  public void test1486() {
    TestDrivers.surfaceShade(982.0f,-549.0f,926.0f,0f,564.0f,-158.0f,0f,-794.0f,0f,0f,0f,0f,0f,796.0f,125.0f,882.0f,0f,0f,0f,788,-98.11994f,-80.772194f,100.0f,100.0f,100.0f,98.754875f ) ;
  }

  @Test
  public void test1487() {
    TestDrivers.surfaceShade(985.0f,165.0f,689.0f,0f,356.0f,-528.0f,0f,292.0f,0f,0f,0f,0f,0f,612.0f,357.0f,-72.0f,357.0f,-566.0f,631.0f,-874,-70.21626f,-94.51823f,-34.297653f,50.820187f,-20.9025f,78.984146f ) ;
  }

  @Test
  public void test1488() {
    TestDrivers.surfaceShade(-986.0f,0f,548.0f,0f,970.0f,-1614.0f,0f,-308.0f,0f,0f,0f,0f,0f,457.0f,-165.0f,-112.0f,0f,0f,0f,-1115,-0.7204017f,-2.5336204f,0.79306954f,-30.932163f,0f,52.478153f ) ;
  }

  @Test
  public void test1489() {
    TestDrivers.surfaceShade(-986.0f,869.0f,0f,0f,513.0f,-1.0f,0f,-655.0f,0f,0f,0f,0f,0f,-122.0f,-31.0f,61.0f,0f,0f,0f,-43,0.0053173467f,0.14499512f,0.011696756f,-91.89087f,41.54253f,0f ) ;
  }

  @Test
  public void test1490() {
    TestDrivers.surfaceShade(-988.0f,0f,0f,0f,100.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,46.66124f,-45.292713f,100.0f,0f,0f,0f,765,-38.60309f,100.0f,-100.0f,-45.947544f,0f,0f ) ;
  }

  @Test
  public void test1491() {
    TestDrivers.surfaceShade(988.0f,718.0f,1104.0f,0f,4932.0f,706.0f,0f,-674.0f,0f,0f,0f,0f,0f,369.0f,-891.0f,-681.0f,-790.0f,-1039.0f,-703.0f,745,82.71658f,22.725044f,15.087231f,100.0f,67.9714f,100.0f ) ;
  }

  @Test
  public void test1492() {
    TestDrivers.surfaceShade(991.0f,0f,0f,0f,-751.0f,-423.0f,376.0f,-562.0f,0f,0f,0f,0f,0f,630.0f,829.0f,-436.0f,-674.0f,549.0f,108.0f,-450,-65.1226f,-76.56696f,13.228249f,90.51551f,0f,0f ) ;
  }

  @Test
  public void test1493() {
    TestDrivers.surfaceShade(-991.0f,-119.0f,35.0f,0f,923.0f,-909.0f,0f,368.0f,0f,0f,0f,0f,0f,978.0f,-226.0f,-117.0f,-509.0f,709.0f,-236.0f,209,-163.52065f,-21.153313f,19.361303f,-57.935295f,-25.870354f,76.08124f ) ;
  }

  @Test
  public void test1494() {
    TestDrivers.surfaceShade(-991.0f,-814.0f,589.0f,0f,732.0f,558.0f,0f,-646.0f,0f,0f,0f,0f,0f,923.0f,-104.0f,329.0f,-29.0f,-570.0f,-538.0f,457,-19.615538f,-15.147959f,24.54079f,-61.52601f,-92.570724f,83.50739f ) ;
  }

  @Test
  public void test1495() {
    TestDrivers.surfaceShade(995.0f,729.0f,712.0f,0f,1019.0f,-521.0f,0f,-414.0f,0f,0f,0f,0f,0f,-383.0f,-189.0f,-222.0f,0f,0f,0f,-571,2.9159389f,-2.6756098f,-2.752767f,36.547707f,38.40326f,51.030712f ) ;
  }

  @Test
  public void test1496() {
    TestDrivers.surfaceShade(-997.0f,-372.0f,0f,925.0f,0f,0f,0f,-47.193115f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-67.233154f,-55.91753f,0f ) ;
  }

  @Test
  public void test1497() {
    TestDrivers.surfaceShade(-997.0f,413.0f,-376.0f,0f,790.0f,-318.0f,0f,807.0f,0f,0f,0f,0f,0f,673.0f,-276.0f,-855.0f,336.0f,-802.0f,-251.0f,-965,-86.401215f,-33.397453f,79.140434f,-54.453846f,-7.3997755f,69.91518f ) ;
  }

  @Test
  public void test1498() {
    TestDrivers.surfaceShade(998.0f,-789.0f,69.0f,0f,428.0f,-241.0f,0f,141.0f,0f,0f,0f,0f,0f,963.0f,499.0f,-872.0f,1535.0f,614.0f,-366.0f,883,-6.271871f,-43.08206f,42.38103f,-46.18941f,-19.812767f,-75.11603f ) ;
  }

  @Test
  public void test1499() {
    TestDrivers.surfaceShade(-999.0f,-186.0f,-163.0f,-86.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,35.308907f,6.251563E-5f,7.133685E-5f ) ;
  }
}
