import org.junit.Test;

public class JpfTargetSphereShadeTest {

  @Test
  public void test0() {
    TestDrivers.sphereShade(-0.0019567646f,0f,0f,5.1104765f,0f,0f,0f,-2.7105054E-20f,0f,0f,-47.377235f,127.3232f,16.605778f,0f,-45.688824f,-100.0f,-100.0f,1.0595363f,1.4990755f,-0.14204988f,0,-0.19214024f,-0.6535063f,-0.64381236f,-100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereShade(0.0025077185f,-49.2874f,0f,21.935f,0f,0f,0f,-95.49333f,0f,0f,-6.0725784f,35.22327f,-60.075184f,0f,-5.612724f,35.274075f,-60.18883f,0.9719395f,-0.062097404f,0.21264344f,0,42.91179f,6.3432026f,30.902592f,18.179531f,-66.84328f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereShade(0.0109777935f,0f,0f,-1.4860442f,0f,0f,0f,-35.14443f,0f,0f,0.33979213f,34.474075f,-77.82237f,0f,0.36589035f,35.2538f,-77.41308f,-0.11813132f,-0.7842197f,0.37836182f,0,-14.720842f,27.087236f,98.73428f,-61.298977f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereShade(0.04376507f,89.71245f,0.006154883f,-4.642419f,0f,0f,0f,-91.069695f,0f,0f,23.211805f,44.747845f,14.97241f,0f,22.853245f,43.834854f,15.058191f,0.0784896f,-0.07884982f,0.23992509f,0,-100.0f,-100.0f,100.0f,-4.921789f,64.14769f,-34.997406f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereShade(0.13060251f,-17.174984f,0f,-53.66939f,0f,0f,0f,-86.6899f,0f,0f,95.149376f,-83.44556f,-99.926735f,0f,72.891846f,-27.58557f,68.344635f,-8.155335E-4f,-0.81763095f,-0.35476735f,0,0.7003337f,-0.19885068f,-0.66297346f,-0.14266643f,-86.93858f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereShade(0.54532665f,-100.0f,-1.0687903f,75.726974f,0f,0f,0f,0.0f,0f,0f,99.31576f,1.6936446f,-42.584244f,0f,-80.41241f,100.0f,40.281097f,0.08896133f,-0.67423546f,-0.4488826f,0,-0.115981705f,0.20166366f,-0.21640097f,21.909094f,22.134396f,94.773346f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereShade(-0.8328685f,-90.86169f,0f,63.68831f,0f,0f,0f,-99.9961f,0f,0f,-99.506134f,-13.688713f,-8.169491f,0f,-99.3638f,-13.17871f,-8.540271f,0.79780185f,0.3054263f,0.08499773f,0,-31.484198f,38.44913f,-74.528465f,-0.018852279f,94.97146f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-581.0f,322.0f,-891.0f,-44.0f,503.0f,-372.0f,443.0f,768.0f,553.0f,-537.0f,-111,-0.38438252f,-0.37208745f,-0.030745067f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0104292175f,0f,0f,-98.37362f,-46.489227f,100.0f,55.447243f,-100.0f,-100.0f,-15.288682f,0.22465648f,1.1554921f,1.2492368f,0,99.95842f,59.23827f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,-100.0f,82.46189f,-49.152164f,0f,-100.0f,82.2831f,-48.859432f,0.47484487f,0.83313715f,0.06689507f,0,49.18101f,-100.0f,34.304134f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,100.0f,95.23164f,-100.0f,0f,100.0f,100.0f,66.87207f,-0.15497291f,-0.8793275f,0.31585205f,0,-0.042319093f,0.33396718f,-0.09787571f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,12.814425f,2.1306565f,33.959892f,0f,57.20698f,-3.3887873f,-100.0f,-0.45844844f,0.5623751f,-0.50926185f,0,39.231712f,-37.944023f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,-371.0f,-2516.0f,-528.0f,-781.0f,851.0f,1129.0f,767.0f,374.0f,1900.0f,186.0f,809,0.18940608f,0.24678439f,0.45692775f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.016945131f,0.609929f,-0.48223144f,0,-55.975002f,-53.560146f,68.57796f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.018499438f,-0.1261687f,0.07408291f,0,3.9616036E-5f,-5.948624E-6f,1.1114616E-5f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,0.0f,-1.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,0.0f,-1.0f,767,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,-1.0f,0.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,1.0f,0.0f,-163,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,1.0f,0.0f,2157,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.1263126f,-0.9181543f,0.1368479f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.18909775f,-0.30321974f,0.08977686f,0,-0.018861894f,-0.3113769f,-0.9500993f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.27962714f,0.47592098f,0.1173763f,0,0.59807855f,-0.3604728f,0.15471677f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.32763264f,-0.44430146f,0.1959351f,0,60.492073f,45.187363f,94.9309f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.37146473f,0.14349148f,-0.5196882f,0,58.338276f,100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.48160315f,0.6073021f,0.63185644f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.5047374f,0.49428475f,-0.557931f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.62135774f,-0.1315644f,-0.42953855f,0,-0.0024063606f,1.2685073E-4f,0.021907203f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.68857497f,-0.068419136f,0.41834676f,0,-0.110584155f,-0.90307385f,0.41066402f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.79025286f,0.048988428f,0.2777038f,0,-0.07631684f,-0.12473048f,-0.31607717f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.81141895f,-0.49251267f,0.009612759f,0,0.99610734f,-0.0839149f,0.026990475f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.0f,0.0f,0.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.0f,0.0f,0.0f,-1206,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.0f,0.0f,0.0f,3,-38.104042f,166.49826f,-57.638134f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1387.0f,44.0f,-570.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,150.0f,438.0f,973.0f,1,-42.8299f,60.44481f,-50.73102f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-180.0f,2327.0f,-675.0f,1,0.010812862f,0.017668132f,0.012703423f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1961.0f,-465.0f,-493.0f,-2,0.2622809f,-0.5405146f,-0.62809443f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,20.0f,-17.0f,-4.0f,1,-0.6345276f,1.4016446f,0.26015007f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.0330324E-4f,-1.0178328E-4f,1.2542854E-6f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,212.0f,1198.0f,-1499.0f,1,-0.16657622f,-0.8516114f,0.49700147f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.2727757f,44.745506f,93.34624f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,405.0f,883.0f,1065.0f,1,-0.38073924f,0.59926444f,-0.7042157f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,433.0f,-272.0f,584.0f,3,-45.862488f,51.812523f,-48.757717f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-433.0f,-501.0f,609.0f,183,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,587.0f,1331.0f,-2864.0f,2,-0.19145957f,-0.0025805125f,0.01615232f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,6.260584E-5f,1.1802554E-4f,4.1603667E-4f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,62.746403f,-14.199845f,42.61652f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.439102E-10f,2.33832E-10f,-7.021947E-11f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,76.89095f,-47.747925f,63.208805f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,890.0f,314.0f,794.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,9.0f,-39.0f,-24.0f,-1,0.95919555f,0.03487521f,-0.5251779f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-914.0f,-149.0f,33.0f,1,54.965023f,35.615265f,-80.2952f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-914.0f,231.0f,96.0f,-283,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,24.025723f,0f,-100.0f,-100.0f,24.0f,6.0f,7.0f,7.0f,-4,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-41.0f,0f,-100.0f,-100.0f,-41.0f,-68.0f,49.0f,675.0f,-260,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-4.28458f,0f,-52.602848f,-45.59628f,100.0f,0.73558635f,0.57907647f,0.20237446f,0,-0.16702454f,0.41134405f,0.6328375f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,14.472947f,-69.48761f,0f,-100.0f,14.472937f,-69.48754f,0.474917f,-0.1614254f,-0.84579337f,0,99.56507f,92.54252f,-76.35456f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,52.297993f,-97.89917f,0f,-100.0f,53.736725f,-98.0f,1.0f,0.0f,4.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-54.438515f,-16.501919f,0f,100.0f,-54.438526f,-16.50192f,0.27931866f,-0.35342816f,-0.13169296f,0,0.20273942f,0.49921116f,0.56948787f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-78.72875f,-79.97456f,0f,100.0f,-78.50464f,-79.0f,-175.0f,-2157.0f,488.0f,-807,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-103.0f,-778.0f,418.0f,0f,176.0f,495.0f,-323.0f,-191.0f,939.0f,553.0f,447,85.48133f,-63.10204f,-26.08709f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-10.500069f,100.0f,100.0f,0f,100.0f,-79.73592f,30.341675f,-0.31043723f,-0.3989706f,0.6712034f,0,-17.3731f,100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.47923f,-65.91553f,-222.41585f,0f,10.538111f,-68.76685f,-223.0f,8.0f,-5.0f,8.0f,-1103,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1200.0f,2338.0f,677.0f,-1129.0f,-196.0f,-709.0f,-466.0f,580.0f,775.0f,629.0f,1176,0.32184583f,-0.9077462f,2.7025685f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1327.0f,165.0f,-702.0f,-479.0f,361.0f,-674.0f,188.0f,-345.0f,895.0f,280.0f,1554,-0.0020642565f,0.075784855f,-0.5560607f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.70343f,-54.939495f,-15.737726f,0f,-14.180487f,-55.635624f,-14.45572f,-0.08351175f,-0.15078765f,-0.23124066f,0,0.46950704f,-0.9976368f,0.031158874f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-15.394463f,95.55999f,-26.385365f,0f,-15.420359f,96.315956f,-26.0f,666.0f,-84.0f,-51.0f,1062,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.580252f,80.00678f,81.42375f,0f,-96.67456f,12.990277f,637.0f,879.0f,143.0f,114.0f,6,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,170.0f,1036.0f,-1228.0f,0f,198.0f,1416.0f,-423.0f,6.0f,0.0f,4.0f,37,-117.13728f,-71.86369f,17.087425f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-183.0f,53.0f,-484.0f,0f,-195.0f,51.0f,-452.0f,1525.0f,147.0f,1389.0f,6,-0.33268553f,-1.4493226f,0.18590586f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,189.0f,622.0f,-492.0f,0f,-2425.0f,2492.0f,-620.0f,9.0f,22.0f,-27.0f,1247,0.5749331f,0.12401277f,0.31795472f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-194.98427f,-175.99171f,-226.78183f,0f,78.70656f,59.65101f,-874.0f,2.0f,1.0f,1.0f,-1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,216.0f,141.0f,328.0f,0f,209.0f,182.0f,323.0f,-32.0f,2.0f,18.0f,-1706,-22.791748f,-180.19104f,-126.72546f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-218.0f,214.0f,74.0f,0f,-217.0f,214.0f,73.0f,1199.0f,178.0f,717.0f,-1556,-79.314865f,-78.77186f,26.18594f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.674091f,68.0589f,-15.154193f,0f,22.544586f,67.98773f,-15.0f,-330.0f,1793.0f,1277.0f,-3317,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-25.079578f,34.429157f,34.88458f,0f,37.191948f,12.206553f,-131.0f,-587.0f,-665.0f,-212.0f,176,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33.128902f,-46.942165f,-2.7367313f,0f,100.0f,-28.098036f,-61.776855f,-0.15873905f,-0.024666643f,-0.71086437f,0,-0.35294202f,-0.44537693f,0.06138592f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,35.21819f,36.183403f,-43.871014f,0f,34.426064f,35.604656f,-43.677128f,0.18009934f,0.010930838f,-0.05370441f,0,-100.0f,-99.83995f,-31.946114f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,354.0f,-2205.0f,279.0f,0f,-1514.0f,2818.0f,885.0f,299.0f,1236.0f,1609.0f,1206,-0.89594966f,-0.014318694f,-0.44399595f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.21374f,97.73747f,-51.735527f,0f,15.4154005f,60.653572f,-487.0f,-520.0f,-962.0f,795.0f,326,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,404.0f,-1010.0f,-614.0f,387.0f,679.0f,287.0f,125.0f,151.0f,1593.0f,594.0f,-1758,-0.32858476f,-0.2735571f,-0.07586387f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,415.0f,950.0f,898.0f,0f,405.0f,963.0f,892.0f,-5.0f,-12.0f,17.0f,18,73.868576f,-79.48231f,244.2315f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.95937f,-33.07848f,-75.99539f,0f,41.620525f,-33.857944f,-76.0f,1593.0f,-500.0f,-1543.0f,127,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-428.0f,1132.0f,-1974.0f,0f,-890.0f,319.0f,-1044.0f,650.0f,-369.0f,-163.0f,-2,0.94550824f,-0.32516226f,0.01684231f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-43.993904f,6.688138f,-32.124493f,0f,96.551796f,25.854729f,-874.0f,-994.0f,330.0f,400.0f,-485,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-44.408844f,17.005262f,-37.873417f,0f,-45.40602f,16.954237f,-38.25542f,-0.3644309f,0.083567165f,-0.26043227f,0,-0.19613148f,0.049696986f,-0.49402592f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-494.0f,-635.0f,393.0f,0f,361.0f,484.0f,952.0f,-547.0f,182.0f,-98.0f,878,-41.19902f,-10.25918f,-20.268738f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-511.0f,845.0f,-637.0f,1539.0f,62.0f,1020.0f,-869.0f,196.0f,55.0f,-623.0f,-885,-0.0035400726f,0.5298458f,0.0074775447f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,51.895073f,100.0f,-40.930225f,0f,22.911623f,78.41382f,-10.845201f,-0.67628324f,0.44912335f,0.18605366f,0,0.9789969f,-0.1855112f,0.0845583f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-52.363003f,-25.620283f,131.56253f,0f,-52.64498f,-25.70405f,132.0f,528.0f,-1752.0f,-665.0f,-272,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,53.064404f,-58.979527f,8.8028145f,0f,0.7265397f,-57.234528f,-89.92871f,0.1881935f,-0.20505384f,0.6310563f,0,46.781498f,100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,54.346836f,12.01757f,64.59598f,0f,52.640854f,-0.9763501f,-608.0f,1.0f,-1.0f,0.0f,1941,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,562.0f,-1320.0f,754.0f,0f,909.0f,1710.0f,363.0f,-331.0f,-195.0f,-177.0f,-138,0.2763683f,-0.3429565f,0.707961f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-57.705666f,-63.53974f,-22.799173f,0f,-57.87558f,-63.051956f,-24.007063f,0.29557812f,-0.43771458f,0.19845176f,0,0.16207089f,0.5013425f,-0.82397676f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5.7719283f,-93.01162f,-51.961582f,0f,-5.843238f,-93.321175f,-52.0f,-561.0f,-743.0f,46.0f,2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-593.0f,874.0f,1370.0f,-722.0f,-682.0f,962.0f,-339.0f,1687.0f,-545.0f,-70.0f,-355,-0.3642381f,0.10840575f,-0.32024413f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-61.064022f,99.98751f,13.442867f,0f,-61.851105f,100.0f,13.106722f,-0.020463165f,-0.093648314f,0.005922001f,0,40.40221f,-11.7945175f,-28.566757f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.25258f,18.62018f,-44.0948f,0f,62.50299f,18.083027f,-44.48104f,-0.1252355f,0.53082484f,0.11478715f,0,0.5383972f,-0.5189427f,0.54798496f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,65.0f,-267.0f,-80.0f,-420.0f,285.0f,-607.0f,1181.0f,-795.0f,-1047.0f,-1087.0f,91,-0.27262476f,-0.45538065f,-0.12734185f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-680.0f,-50.0f,963.0f,0f,-683.0f,-75.0f,950.0f,-847.0f,671.0f,-974.0f,-9,0.976871f,-0.7422162f,0.16137107f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.24465f,99.99663f,-87.988235f,0f,-69.96251f,100.0f,-87.29205f,-0.06174553f,-0.83171684f,-0.24583064f,0,99.99311f,-100.0f,-36.729603f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,69.65853f,44.540092f,92.09858f,0f,70.003334f,44.73977f,93.0f,1221.0f,-600.0f,222.0f,700,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,702.0f,542.0f,-1895.0f,0f,660.0f,482.0f,381.0f,360.0f,-3746.0f,-1112.0f,-620,-1.4429281E-5f,0.0057184473f,0.23220244f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,71.76379f,-100.0f,34.93441f,0f,71.763176f,-100.0f,35.0f,-975.0f,-1304.0f,1001.0f,-1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,71.87114f,23.843727f,66.50662f,0f,-31.464684f,71.193634f,-960.0f,-244.0f,870.0f,-199.0f,3,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.18853f,-99.9954f,-49.96959f,0f,-72.17995f,-99.993484f,-49.961864f,0.20210063f,0.10611264f,-0.03974404f,0,52.21044f,3.0177133f,-51.57951f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,74.94266f,-99.99689f,99.989555f,0f,74.7621f,-99.98949f,100.0f,-0.31094956f,-0.50139475f,-0.80456734f,0,31.057224f,-59.304672f,-99.99724f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-77.556015f,28.60769f,-99.82821f,0f,26.85626f,-39.179176f,441.0f,-938.0f,-419.0f,479.0f,-953,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,79.47313f,-100.0f,-64.581955f,0f,80.35474f,-100.0f,-65.0f,962.0f,-102.0f,-1840.0f,113,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,795.0f,186.0f,-508.0f,0f,785.0f,186.0f,-509.0f,-2331.0f,-829.0f,-2005.0f,1516,-0.02989934f,0.3755821f,-0.3021938f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-803.0f,-15.0f,790.0f,174.0f,-2494.0f,226.0f,-948.0f,-573.0f,-1522.0f,642.0f,-482,-0.6075399f,0.7508715f,0.18372118f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.03101f,68.206566f,-20.179743f,0f,7.9247875f,68.253426f,-19.761944f,0.16004072f,0.42817822f,-0.36935768f,0,0.38579947f,-0.2817705f,-0.31077287f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,811.0f,322.0f,1224.0f,0f,-649.0f,1222.0f,1246.0f,-2.0f,31.0f,-6.0f,13,-0.0114753f,0.027663881f,-2.8439518E-4f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,82.46368f,39.533028f,-55.872955f,0f,82.538124f,39.836864f,-56.0f,3.0f,7.0f,-5.0f,425,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,826.0f,909.0f,644.0f,760.0f,826.0f,392.0f,-748.0f,-1159.0f,695.0f,-579.0f,-200,-0.31047422f,0.8214623f,0.39284372f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-829.0f,-686.0f,496.0f,0f,1392.0f,-955.0f,498.0f,-13.0f,13.0f,5.0f,4,208.44911f,160.09854f,-57.3406f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,831.0f,-618.0f,435.0f,-795.0f,119.0f,38.0f,594.0f,-811.0f,-1447.0f,-1200.0f,-897,2.0133638f,-2.114588f,-5.8332953f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,84.682816f,-25.43576f,100.0f,0f,6.6228466f,70.47404f,40.58505f,-0.42939764f,0.6817255f,0.1343536f,0,32.483917f,5.827094f,-27.49807f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.59219f,71.20989f,26.765882f,0f,-4.006321f,65.63756f,-981.0f,336.0f,-215.0f,242.0f,-216,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,891.0f,-723.0f,539.0f,0f,-1067.0f,305.0f,-490.0f,-598.0f,1069.0f,-1319.0f,345,0.07451419f,0.55913645f,-0.2077332f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,89.93844f,-2.8514826f,19.478577f,0f,90.27597f,-2.562875f,20.352577f,-0.31471562f,0.20492285f,0.20434043f,0,99.787766f,-59.904194f,99.85504f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-918.0f,-785.0f,-1186.0f,0f,-921.0f,-770.0f,-1186.0f,-1724.0f,632.0f,867.0f,-1270,-0.33247125f,0.0071453303f,0.1392541f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,920.0f,985.0f,594.0f,0f,-874.0f,26.0f,481.0f,-712.0f,779.0f,-978.0f,901,-0.02199897f,-0.22790636f,-0.008156461f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,9.672625f,-90.89081f,-43.13752f,0f,-10.201309f,-100.0f,60.62207f,0.470067f,-0.2177522f,0.8442804f,0,0.8733331f,0.4160021f,-0.12247947f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.76556f,-98.33168f,-14.984177f,0f,99.9953f,-98.61458f,-16.152033f,-0.003979527f,0.0286408f,-0.7391798f,0,-0.14462627f,1.2658437f,0.6910686f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,100.0f,-100.0f,-100.0f,0f,-24.44584f,-81.34814f,100.0f,-0.021264553f,-0.28508496f,0.027348274f,0,100.0f,68.92778f,92.79165f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-100.0f,16.316317f,3.6497874f,-100.0f,100.0f,2.5800965f,40.409588f,-0.08109935f,0.2899397f,-0.9463672f,0,0.16423292f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-100.0f,24.141148f,-100.0f,0f,32.069267f,-99.145676f,98.20514f,-0.1583962f,0.20640488f,-0.7857486f,0,0.02512644f,0.8063747f,0.2535452f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,100.0f,-69.98364f,97.31201f,-100.0f,-18.966894f,-100.0f,100.0f,0.6740945f,-0.1858032f,0.4013222f,0,46.18223f,-21.725769f,29.791458f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,24.93393f,42.31111f,82.269966f,0f,24.68227f,41.648514f,82.61475f,-0.59158695f,0.6468432f,0.19512787f,0,96.124405f,1.7422987f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-25.13541f,-8.328687f,-66.01212f,0f,-99.970604f,23.735317f,-89.6629f,2.0501072f,0.50187784f,0.32829046f,0,33.24363f,12.121082f,73.76712f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-28.737278f,100.0f,100.0f,0f,100.0f,-100.0f,-100.0f,-0.11742605f,-0.012832936f,-0.5384643f,0,100.0f,-83.188934f,39.9399f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,41.18439f,-78.23671f,-3.884215f,-68.03895f,39.121155f,-79.49553f,-3.9857485f,2.7799623f,-0.41093785f,0.3990015f,0,40.1161f,100.0f,89.395424f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-61.092606f,-69.52271f,-99.69371f,-4.207298f,-60.86208f,-66.13787f,-100.0f,0.823103f,0.39267522f,0.32170776f,0,-29.842405f,66.19417f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-66.134705f,-22.374264f,99.985504f,0f,-65.92772f,-22.388443f,99.98991f,-0.30903724f,-0.7339782f,0.43545896f,0,75.805f,-62.22438f,-91.87187f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,82.526695f,1.6700845f,100.0f,0f,45.556236f,-63.174625f,-100.0f,0.41511002f,-0.34821358f,0.7951755f,0,-45.68204f,-100.0f,-52.416744f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-99.89883f,99.99967f,47.426662f,0f,-100.0f,99.99979f,46.449814f,0.2960056f,-0.33794042f,-0.71391106f,0,-100.0f,-51.03565f,77.30279f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,10.1248255f,0f,0f,5.2704415f,27.203657f,-27.730814f,51.766037f,39.330944f,91.65074f,-93.211105f,0.27605534f,-1.1371405f,-0.4286877f,0,62.96095f,-99.995895f,-65.79953f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,10.200655f,0f,0f,50.765694f,47.190453f,15.181338f,14.145723f,60.161316f,24.466492f,-4.370256f,-0.19416566f,2.9054544f,5.6536446f,0,-100.0f,15.37269f,54.388424f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1252.0f,0f,0f,329.0f,-417.0f,-2022.0f,-557.0f,-2222.0f,-616.0f,561.0f,808.0f,-322.0f,-264.0f,1259,-0.15558492f,0.047035344f,-0.012524215f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1.300949f,0f,0f,-100.0f,100.94791f,103.61132f,0f,100.0f,-100.0f,100.0f,-0.24544367f,-0.13439648f,0.8505281f,0,100.0f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1307.0f,0f,0f,101.0f,1873.0f,-773.0f,996.0f,-1914.0f,-158.0f,-1400.0f,511.0f,-14.0f,1850.0f,1302,-0.21986692f,-1.2201804f,1.5554302f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1381.0f,0f,0f,-409.0f,894.0f,933.0f,836.0f,902.0f,-553.0f,398.0f,-474.0f,1106.0f,-1363.0f,607,0.10849537f,-0.19631702f,0.59938943f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,14.858135f,0f,0f,-36.262547f,99.99931f,82.14195f,0f,-70.770454f,21.101345f,-21.216637f,0.979036f,-16.762928f,12.468983f,0,-3.9307914f,-91.16176f,99.968315f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,18.382542f,0f,0f,73.86344f,17.697073f,29.334875f,0f,18.114052f,-82.3367f,81.35362f,0.485911f,0.33248606f,-0.4477037f,0,21.915611f,-67.84206f,-46.70078f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,200.0f,0f,0f,-1256.0f,1753.0f,5.0f,-927.0f,972.0f,93.0f,-944.0f,-261.0f,1685.0f,-1059.0f,-807,0.0889808f,-1.0060607f,0.6407974f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,205.0f,0f,0f,-970.0f,-945.0f,-389.0f,-37.0f,-152.0f,-439.0f,-812.0f,-306.0f,-286.0f,1103.0f,947,0.70548457f,0.040770665f,-0.6851634f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,21.313564f,0f,0f,-100.0f,96.538765f,-100.0f,0f,-100.0f,96.32188f,-100.0f,0.6556518f,0.2014096f,0.18550442f,0,-1.0792828f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,21.714045f,0f,0f,2.6520472f,-13.265382f,-11.779625f,0f,1.019528f,-12.953286f,-11.013663f,0.9212042f,-1.017474f,-1.8811172f,0,-99.29328f,-57.531147f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,30.473461f,0f,0f,-1.7411454f,51.30313f,-84.865074f,-29.40678f,-1.8401058f,51.06392f,-84.48769f,0.16741137f,0.10412125f,-0.5176981f,0,-40.910362f,-100.0f,-19.977997f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,34.434532f,0f,0f,-14.139812f,2.3641527f,-100.0f,-40.076717f,-100.0f,-26.968084f,-31.743273f,0.054181535f,0.21676406f,0.014565842f,0,66.524536f,-68.78741f,-95.280136f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,351.0f,0f,0f,721.0f,-648.0f,413.0f,-3201.0f,-2257.0f,818.0f,661.0f,611.0f,670.0f,-476.0f,667,-0.82145405f,-1.8333066f,1.1299038f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,37.48616f,0f,0f,56.28445f,-56.74324f,1.5921259f,0f,-59.957054f,-17.749979f,83.07575f,0.26259533f,0.23323388f,-0.4529557f,0,100.0f,47.909096f,14.083048f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,37.640526f,0f,0f,-98.10965f,45.728687f,-100.0f,-63.41833f,-52.2306f,-48.977413f,-47.001392f,-0.01594037f,0.8326217f,0.20550807f,0,-92.081764f,-19.462671f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,3.9983299f,0f,0f,33.010574f,25.34783f,52.92484f,97.08938f,33.215034f,25.571774f,52.54809f,-0.5228535f,-0.70313495f,-0.04932563f,0,91.471344f,67.63857f,-9.8113985f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,41.22411f,0f,0f,38.000973f,-31.415329f,-42.160137f,0f,43.44838f,-19.099655f,-5.398704f,1.9511931f,15.521711f,-5.4891567f,0,-48.180187f,86.424194f,27.117777f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-45.969692f,0f,0f,-100.0f,-74.055885f,-21.804144f,0f,-98.492355f,-85.99307f,-44.78116f,-0.5580617f,0.55108404f,0.04673206f,0,0.073294565f,0.021404386f,0.8224859f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,47.268112f,0f,0f,-98.04673f,-26.485735f,4.8159504f,0f,-98.45395f,-27.096144f,4.5917954f,-0.38071328f,-0.14033821f,0.8439668f,0,-55.83218f,100.0f,-53.440346f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-47.9189f,0f,0f,-43.00777f,-59.611336f,-59.06823f,0f,-43.256237f,-59.351463f,-58.940742f,-0.102885514f,0.80369896f,0.5808966f,0,-94.649284f,15.404138f,35.080223f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,48.471107f,0f,0f,-99.42137f,-30.72235f,-100.0f,65.89276f,-100.0f,-31.52275f,-100.0f,-0.12362753f,-1.4280965f,0.22984932f,0,-100.0f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,496.0f,0f,0f,599.0f,-273.0f,615.0f,-71.0f,-2891.0f,-1781.0f,1877.0f,808.0f,-93.0f,-1257.0f,503,-0.7046366f,-0.35527137f,-1.639469f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,50.791576f,0f,0f,16.880379f,100.0f,-100.0f,77.096725f,16.384768f,100.0f,-100.0f,1.0957955f,-2.8199995f,-0.7063082f,0,-100.0f,99.194115f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,509.0f,0f,0f,1963.0f,-787.0f,-217.0f,228.0f,-1055.0f,35.0f,1969.0f,952.0f,52.0f,-995.0f,175,-0.014370451f,0.15777364f,-0.042999897f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,52.832767f,0f,0f,-73.094086f,99.98925f,100.0f,-100.0f,-72.56451f,99.97904f,100.0f,-1.3437853f,0.16536856f,-1.0886261f,0,100.0f,23.899872f,99.45948f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,5.3745303f,0f,0f,100.0f,31.380205f,100.0f,-100.0f,-100.0f,-100.0f,100.0f,0.012177766f,0.80767226f,-1.0543584f,0,100.0f,100.0f,-45.605373f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,55.415527f,0f,0f,-43.827656f,-12.054521f,4.0913086f,0f,-44.141895f,-12.253064f,4.870463f,-0.07360533f,-0.29454428f,-0.38498512f,0,99.10558f,-9.553666f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,615.0f,0f,0f,-541.0f,186.0f,-1225.0f,-365.0f,860.0f,84.0f,360.0f,-837.0f,-140.0f,651.0f,-289,0.5435762f,0.54201853f,0.53563267f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,62.341446f,0f,0f,13.522366f,100.0f,61.073124f,0f,100.0f,-100.0f,100.0f,-0.4504584f,-0.21305373f,-0.461903f,0,100.0f,23.517426f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,64.48652f,0f,0f,14.595453f,78.74847f,-100.0f,0f,14.252069f,78.2967f,-99.99144f,-0.27504402f,-0.8766107f,0.15125857f,0,13.191955f,73.19281f,-29.573538f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,66.98748f,0f,0f,-96.52127f,-33.084187f,-52.78872f,0f,51.591637f,85.791145f,-30.455654f,-16.776218f,19.353052f,8.39615f,0,1.4198061f,-2.9791777f,-4.1456223f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,69.17506f,0f,0f,-100.0f,-18.288439f,-100.0f,0f,-135.61475f,-54.434586f,-100.0f,0.19535731f,0.2610315f,-0.026797628f,0,100.0f,-10.888836f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,69.47806f,0f,0f,-15.196921f,-35.68082f,100.0f,100.0f,-84.470505f,-95.3747f,26.723118f,-0.013037892f,-0.4446998f,0.8944078f,0,-72.80128f,18.289927f,-4.849859f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,7.1054274E-15f,0f,0f,57.92035f,62.946266f,50.00371f,0f,57.629524f,62.94824f,49.17596f,0.7751704f,-0.05515548f,0.20762788f,0,78.48579f,-18.758883f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,71.07899f,0f,0f,5.235168f,23.718018f,-64.736275f,0f,-99.70864f,2.4309125f,-97.39873f,-0.101455964f,-0.052831106f,0.69941014f,0,11.860632f,-39.236958f,-99.90726f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,74.08506f,0f,0f,99.64121f,-28.444927f,-36.7166f,0f,100.0f,-28.77714f,-37.571136f,0.58495164f,-0.26586124f,-0.33369014f,0,-63.60577f,20.30622f,11.226366f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,764.0f,0f,0f,196.0f,459.0f,-259.0f,1744.0f,-557.0f,-466.0f,1649.0f,1362.0f,373.0f,-1522.0f,-271,0.21479547f,0.025634466f,0.16966796f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,789.0f,0f,0f,1054.0f,-790.0f,772.0f,97.0f,-898.0f,-574.0f,80.0f,294.0f,-2.0f,-829.0f,-321,2.6904116f,2.0875306f,-9.002411f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-80.0f,0f,0f,391.0f,-708.0f,831.0f,1238.0f,-1998.0f,-1702.0f,130.0f,-1223.0f,-49.0f,1019.0f,-784,0.0010762714f,1.4396686E-5f,-0.0056392653f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,80.122955f,0f,0f,-48.075726f,-99.95698f,52.730244f,2.1204686f,-45.868114f,-100.0f,53.121784f,-0.13363118f,0.8562065f,-1.2959841f,0,54.288162f,-33.659878f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,8.0f,0f,0f,-826.0f,-471.0f,-741.0f,134.0f,-732.0f,210.0f,-1315.0f,-738.0f,247.0f,734.0f,996,-0.009095456f,0.37797537f,-0.7101314f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,8.526513E-14f,0f,0f,35.005795f,100.0f,100.0f,0f,35.78182f,100.0f,100.0f,0.5855672f,0.8241907f,1.0579677f,0,100.0f,-36.17006f,-27.308659f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,87.0f,0f,0f,835.0f,1575.0f,-600.0f,-566.0f,911.0f,-903.0f,-342.0f,705.0f,-439.0f,929.0f,53,-0.515256f,-0.2750916f,-0.025541821f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,89.94599f,0f,0f,45.27791f,-100.0f,-100.0f,0f,-100.0f,95.88283f,89.55652f,-0.3054266f,-0.7703716f,-0.11847763f,0,100.0f,34.361324f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,90.038956f,0f,0f,-133.09248f,-88.69147f,92.99794f,0f,-61.933598f,100.0f,-100.0f,-0.14180803f,-0.49265677f,-0.24158297f,0,80.13301f,-100.0f,61.718327f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,90.82209f,0f,0f,-0.5842009f,10.316112f,52.124397f,0f,0.78852797f,78.95187f,-12.470781f,0.15064761f,0.117847234f,0.44689524f,0,12.1113205f,-96.005356f,29.090734f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,918.0f,0f,0f,-688.0f,-1241.0f,609.0f,-484.0f,-607.0f,549.0f,-573.0f,-755.0f,-1157.0f,948.0f,194,0.4358385f,0.4407173f,0.69728166f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,92.30299f,0f,0f,-60.13507f,39.13234f,80.794815f,0f,-59.44907f,38.74953f,81.80518f,0.256979f,0.14616689f,-0.10550161f,0,-100.0f,90.20574f,-70.54393f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,92.48439f,0f,0f,-90.5034f,100.0f,66.76584f,0f,-98.955635f,100.0f,-75.49505f,1.0353503f,0.28070146f,0.29052186f,0,0.155762f,-0.94061655f,-0.28347158f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,944.0f,0f,0f,826.0f,-243.0f,-1863.0f,-142.0f,-119.0f,901.0f,-626.0f,3145.0f,-843.0f,-33.0f,1256,0.27259386f,0.09831786f,0.49308807f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,96.44021f,0f,0f,-58.897053f,-28.29073f,24.630896f,0f,-58.881523f,-27.334522f,24.453537f,0.0981294f,-0.24304079f,-0.5257857f,0,73.923836f,75.7157f,-1.5481493f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,98.41834f,0f,0f,69.939835f,-72.90601f,100.0f,0f,15.462761f,100.72882f,-57.720627f,-0.23067127f,-0.4095185f,0.83750474f,0,-66.94416f,97.09862f,7.288836f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,98.93622f,0f,0f,-84.16434f,-99.300255f,26.304249f,0f,-15.062005f,-99.99792f,99.99706f,-0.11479167f,-0.8339237f,0.45930696f,0,1.3910859f,0.061619937f,0.3464574f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,99.9732f,0f,0f,-20.204634f,99.183266f,47.98034f,100.0f,-18.949242f,100.0f,48.22654f,0.3728729f,-2.0614176f,1.5122036f,0,77.33492f,-85.23413f,-74.484634f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1023.0f,-796.0f,0f,1337.0f,0f,0f,-579.0f,-2981.0f,-24.0f,469.0f,-530.0f,426.0f,-752.0f,-271.0f,52.0f,711.0f,-1496,0.9528527f,-0.8820502f,0.0359188f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1050.0f,-34.0f,0f,170.0f,0f,0f,-994.0f,981.0f,-1034.0f,565.0f,35.0f,-828.0f,946.0f,-826.0f,93.0f,-515.0f,-874,-0.37737545f,-0.03198169f,-0.21956919f,0f,0f,0f,-35.599438f,47.369324f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1055.0f,-2023.0f,0f,390.0f,0f,0f,-1327.0f,-1851.0f,170.0f,-875.0f,-1549.0f,-542.0f,-139.0f,-28.0f,-733.0f,338.0f,-1826,-0.4349485f,-0.4345379f,-0.7227814f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1084.0f,-642.0f,0f,2424.0f,0f,0f,1344.0f,610.0f,31.0f,-529.0f,1474.0f,-501.0f,-560.0f,600.0f,928.0f,955.0f,331,-0.41710493f,-0.4374406f,0.7522176f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1118.0f,-68.0f,0f,622.0f,0f,0f,762.0f,88.0f,-154.0f,31.0f,896.0f,-1730.0f,-1367.0f,-15.0f,1029.0f,383.0f,-781,-0.03439248f,0.02643464f,-3.3323854E-4f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1153.0f,-464.0f,0f,335.0f,0f,0f,-796.0f,-774.0f,-762.0f,-208.0f,-1978.0f,-232.0f,26.0f,367.0f,-1458.0f,43.0f,1762,0.58616924f,0.110709734f,-0.009618674f,0f,0f,0f,-46.051853f,0f,1.1068732f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1169.0f,-910.0f,0f,-1441.0f,0f,0f,-258.0f,880.0f,807.0f,897.0f,-1213.0f,23.0f,2227.0f,18.0f,912.0f,-701.0f,-1042,0.013108202f,0.34755707f,-0.20108661f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1273.0f,-316.0f,0f,740.0f,0f,0f,1348.0f,-1114.0f,-705.0f,-532.0f,-301.0f,562.0f,-234.0f,519.0f,-1358.0f,-1389.0f,942,0.98545957f,0.13952106f,0.0146330735f,0f,0f,0f,2.6525836f,-91.97662f,0.34459534f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1276.0f,-1097.0f,0f,999.0f,0f,0f,546.0f,-885.0f,773.0f,-328.0f,694.0f,317.0f,-1582.0f,2184.0f,-1648.0f,805.0f,995,0.008068504f,0.06883539f,0.4395365f,0f,0f,0f,-79.79864f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-133.0f,-1190.0f,0f,195.0f,0f,0f,-1073.0f,-340.0f,-2185.0f,-116.0f,-1882.0f,206.0f,1024.0f,2787.0f,310.0f,200.0f,1389,0.42466226f,0.008734596f,-0.90278536f,0f,0f,0f,1.3076952f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1353.0f,-1346.0f,0f,832.0f,0f,0f,-302.0f,690.0f,-1286.0f,498.0f,-2.0f,152.0f,1729.0f,1873.0f,452.0f,-2572.0f,-887,0.6520769f,-0.5880374f,-0.2956805f,0f,0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1435.0f,-1772.0f,0f,1008.0f,0f,0f,613.0f,304.0f,-2762.0f,490.0f,-1183.0f,-1942.0f,517.0f,-325.0f,-667.0f,-1023.0f,-1071,-0.035813347f,0.1289867f,0.0053210026f,0f,0f,0f,46.758083f,100.0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1445.0f,-276.0f,0f,97.0f,0f,0f,792.0f,-227.0f,147.0f,981.0f,-945.0f,1252.0f,991.0f,1304.0f,310.0f,-587.0f,-955,-0.10175869f,-0.3873177f,0.41466773f,0f,0f,0f,-22.497566f,0f,2.6288717f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1452.0f,-1475.0f,0f,-2.0f,0f,0f,-68.0f,-835.0f,838.0f,464.0f,-298.0f,960.0f,-2072.0f,-864.0f,-889.0f,-41.0f,164,-0.15995534f,-0.13485642f,-0.019201366f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1480.0f,-623.0f,0f,746.0f,0f,0f,789.0f,473.0f,920.0f,215.0f,-808.0f,-970.0f,-150.0f,1223.0f,-476.0f,10.0f,-19,0.31042606f,0.49153107f,0.7251602f,0f,0f,0f,61.624535f,-87.86897f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1556.0f,-249.0f,0f,1278.0f,0f,0f,-407.0f,-822.0f,2161.0f,-1589.0f,-435.0f,176.0f,-27.0f,517.0f,-565.0f,1032.0f,564,-0.0019392059f,-0.6454173f,-0.09829665f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-16.0f,10.0f,0f,0f,0f,0f,771.0f,347.0f,-837.0f,1516.0f,-918.0f,213.0f,24.0f,257.0f,-1883.0f,205.0f,74,0.5721311f,-0.78189886f,0.23554988f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1658.0f,-822.0f,0f,40.0f,0f,0f,-289.0f,190.0f,-2079.0f,-973.0f,-729.0f,-820.0f,1113.0f,873.0f,191.0f,-946.0f,1453,1.00723f,-0.5136147f,-1.2856808f,0f,0f,0f,99.4579f,6.375014f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-194.0f,-462.0f,0f,295.0f,0f,0f,-363.0f,-1283.0f,-4145.0f,1536.0f,-1506.0f,688.0f,-632.0f,-667.0f,-167.0f,748.0f,-1704,-0.030723572f,-0.11532539f,0.018733276f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-1993.0f,-1852.0f,0f,1398.0f,0f,0f,1210.0f,-829.0f,2545.0f,719.0f,-1152.0f,1135.0f,647.0f,883.0f,-618.0f,867.0f,1296,0.06381626f,0.12773052f,0.07980554f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-2119.0f,-1275.0f,0f,757.0f,0f,0f,861.0f,-259.0f,548.0f,859.0f,479.0f,-1974.0f,1042.0f,-831.0f,870.0f,-952.0f,-832,-0.05964261f,0.02550569f,0.0043265037f,0f,0f,0f,82.09741f,40.95429f,62.272896f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-2184.0f,-234.0f,0f,39.0f,0f,0f,-40.0f,1072.0f,-572.0f,906.0f,-1441.0f,-1130.0f,-1551.0f,1597.0f,509.0f,-349.0f,2132,-0.9939948f,0.07317932f,1.5173018f,0f,0f,0f,100.0f,46.461536f,6.538476f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-231.0f,-1976.0f,0f,729.0f,0f,0f,-277.0f,536.0f,348.0f,579.0f,57.0f,62.0f,241.0f,-1817.0f,759.0f,-540.0f,867,0.669745f,0.4622518f,0.4286254f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-2313.0f,-718.0f,0f,386.0f,0f,0f,-536.0f,-363.0f,-101.0f,28.0f,1309.0f,-401.0f,-517.0f,-1257.0f,1.0f,275.0f,-1073,-1.7426112f,-1.3795717f,0.6890462f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-2461.0f,-54.0f,0f,678.0f,0f,0f,627.0f,1377.0f,35.0f,-91.0f,-1543.0f,1452.0f,626.0f,913.0f,13.0f,-725.0f,-578,0.089758396f,-0.9872791f,0.035955854f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-254.0f,-844.0f,0f,0f,0f,0f,-97.0f,215.0f,555.0f,484.0f,-488.0f,-902.0f,-470.0f,-27.0f,305.0f,601.0f,-324,-0.29607f,0.5621519f,0.10849824f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-3.0f,-395.0f,0f,102.0f,0f,0f,-284.0f,73.0f,-855.0f,1644.0f,-3028.0f,-195.0f,395.0f,840.0f,-118.0f,523.0f,437,0.46788195f,-0.26822147f,0.7266419f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-327.0f,-510.0f,0f,84.0f,0f,0f,-724.0f,215.0f,629.0f,416.0f,611.0f,1970.0f,-404.0f,-1145.0f,-506.0f,1434.0f,-1293,-0.099587455f,-1.5539547f,-0.655673f,0f,0f,0f,3.035721f,3.035721f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-357.0f,-1348.0f,0f,2553.0f,0f,0f,566.0f,1354.0f,-36.0f,60.0f,-875.0f,-852.0f,-947.0f,449.0f,-351.0f,974.0f,-139,-0.55623776f,0.14759502f,0.7343785f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-408.0f,0f,0f,0f,0f,0f,121.0f,-136.0f,574.0f,56.0f,-266.0f,-9.0f,-288.0f,-1064.0f,-529.0f,643.0f,459,0.5772465f,0.29522973f,-0.10463426f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-416.0f,-670.0f,0f,27.0f,0f,0f,72.0f,-1101.0f,-964.0f,-295.0f,1751.0f,570.0f,-1063.0f,-1295.0f,540.0f,-683.0f,-547,-0.7638315f,0.08451647f,-0.4608525f,0f,0f,0f,69.65611f,-22.487984f,-39.51449f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-592.0f,-581.0f,0f,1315.0f,0f,0f,2366.0f,732.0f,-2094.0f,144.0f,1902.0f,-963.0f,744.0f,-849.0f,1782.0f,-2616.0f,-1155,0.24761456f,-0.34837332f,-0.65001166f,0f,0f,0f,9.797413f,-8.720708f,41.400867f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-669.0f,-1626.0f,0f,348.0f,0f,0f,-443.0f,-623.0f,-1492.0f,139.0f,-456.0f,-13.0f,-232.0f,1100.0f,24.0f,-41.0f,363,-0.8158905f,0.023901293f,-0.42061588f,0f,0f,0f,-68.39813f,0f,-47.88406f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-700.0f,-2276.0f,0f,1140.0f,0f,0f,496.0f,1643.0f,392.0f,1154.0f,550.0f,-231.0f,451.0f,686.0f,217.0f,267.0f,-1268,-0.6749557f,0.35079557f,0.22086573f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-710.0f,-1359.0f,0f,20.0f,0f,0f,949.0f,-230.0f,-1600.0f,10.0f,-397.0f,-1014.0f,746.0f,1523.0f,765.0f,-1166.0f,-1254,1.6915431f,2.2014177f,0.18044119f,0f,0f,0f,12.750753f,12.750028f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-718.0f,-186.0f,0f,45.0f,0f,0f,1381.0f,-1050.0f,614.0f,-793.0f,-1074.0f,586.0f,1411.0f,1579.0f,-156.0f,-1025.0f,1056,0.43170968f,-0.45441908f,-2.0453253f,0f,0f,0f,5.666679f,74.719734f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-728.0f,-1190.0f,0f,774.0f,0f,0f,-620.0f,665.0f,-261.0f,-685.0f,-822.0f,-82.0f,-1092.0f,735.0f,718.0f,484.0f,784,-0.89831084f,0.25254285f,-0.00865311f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-734.0f,-145.0f,0f,100.0f,0f,0f,-2178.0f,632.0f,1490.0f,840.0f,1901.0f,245.0f,-441.0f,-1102.0f,50.0f,-1813.0f,-1071,0.24889155f,0.73979414f,0.62767935f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-740.0f,-1188.0f,0f,993.0f,0f,0f,520.0f,-910.0f,836.0f,597.0f,-2424.0f,-772.0f,1717.0f,617.0f,-1887.0f,830.0f,-2939,-0.016330885f,0.13524751f,-0.5669308f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-740.0f,-24.0f,0f,1933.0f,0f,0f,-814.0f,-210.0f,-841.0f,-537.0f,-1267.0f,1130.0f,6.0f,-1379.0f,-486.0f,-1614.0f,-1664,1.0121353f,-0.5107558f,-0.9052191f,0f,0f,0f,-100.0f,0.085073814f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.sphereShade(0f,0f,0f,0f,746.0f,0f,0f,0f,0f,0f,1567.0f,115.0f,860.0f,-746.0f,698.0f,-535.0f,981.0f,-395.0f,453.0f,1304.0f,320,-0.13317804f,0.32901034f,-0.27834797f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-798.0f,-714.0f,0f,306.0f,0f,0f,1640.0f,0.0f,-296.0f,-699.0f,-1528.0f,321.0f,461.0f,-443.0f,-666.0f,-992.0f,-376,0.7966522f,-0.43075f,-0.28317758f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-803.0f,650.0f,0f,0f,0f,0f,664.0f,363.0f,904.0f,-214.0f,-296.0f,-481.0f,687.0f,158.0f,53.0f,522.0f,343,0.07943991f,-0.27062353f,0.8324012f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-812.0f,-1722.0f,0f,340.0f,0f,0f,-1115.0f,1224.0f,688.0f,196.0f,1668.0f,-219.0f,-235.0f,-588.0f,995.0f,-1691.0f,1841,0.2655981f,0.047608126f,0.7263932f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-827.0f,-1414.0f,0f,160.0f,0f,0f,-1108.0f,989.0f,629.0f,-768.0f,794.0f,-87.0f,-122.0f,-1180.0f,566.0f,-860.0f,989,-0.9106228f,-0.47519845f,-0.487063f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-84.0f,-96.0f,0f,812.0f,0f,0f,1076.0f,63.0f,-855.0f,299.0f,-658.0f,1142.0f,-597.0f,-102.0f,220.0f,-1605.0f,839,-1.238072f,-2.9866457f,-4.6237965f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-880.0f,-319.0f,0f,416.0f,0f,0f,550.0f,720.0f,717.0f,998.0f,397.0f,-134.0f,204.0f,-1118.0f,1513.0f,-1516.0f,-342,12.296907f,-2.0374534f,2.7585611f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-929.0f,-780.0f,0f,780.0f,0f,0f,-143.0f,1020.0f,269.0f,-1357.0f,160.0f,-501.0f,856.0f,327.0f,485.0f,-188.0f,1146,0.00934818f,0.39643326f,0.73485976f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-980.0f,-1013.0f,0f,979.0f,0f,0f,-1219.0f,163.0f,-1451.0f,124.0f,1581.0f,-2885.0f,1436.0f,-842.0f,226.0f,-45.0f,-1566,0.009016314f,0.053264983f,-0.06455298f,0f,0f,0f,81.996475f,100.0f,-20.26058f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.sphereShade(0f,0f,0f,0f,-98.0f,-1113.0f,0f,5.0f,0f,0f,1721.0f,259.0f,1566.0f,-794.0f,-742.0f,1167.0f,-78.0f,-420.0f,-1038.0f,713.0f,-809,0.7442237f,1.1895819f,-0.15718439f,0f,0f,0f,-36.249893f,49.76376f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.sphereShade(100.0f,0.03378732f,23.65826f,-70.80461f,0f,0f,0f,0.0f,0f,0f,45.458214f,100.0f,98.216225f,0f,76.28275f,84.67231f,-84.95069f,0.5679461f,-0.4596365f,0.1840189f,0,-43.31302f,-100.0f,-67.080734f,-63.624016f,-100.0f,26.785374f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.sphereShade(100.0f,0f,0f,0.0043989653f,0f,0f,0f,0.0f,0f,0f,-100.0f,97.50873f,-24.821169f,0f,100.0f,100.0f,-5.984413f,-0.52801234f,0.15111293f,-0.1794146f,0,42.16686f,41.243275f,96.295334f,2.2732618f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.sphereShade(-100.0f,0f,0f,-100.0f,0f,0f,0f,100.0f,0f,0f,-100.0f,-72.507225f,64.0718f,100.0f,100.0f,100.0f,100.0f,-0.049403857f,-0.71674925f,-0.3898129f,0,-58.39841f,-66.309296f,100.0f,-100.0f,0f,0f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.sphereShade(100.0f,0f,0f,100.0f,0f,0f,0f,-100.0f,0f,0f,-73.66618f,100.0f,100.0f,0f,98.76827f,-76.74513f,-93.904274f,-0.06480924f,0.052137706f,-0.350172f,0,-0.07043253f,-0.28160164f,-0.43480256f,50.008247f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.sphereShade(-100.0f,0f,0f,1.4156013E-4f,0f,0f,0f,100.0f,0f,0f,-54.532356f,100.0f,-100.0f,0f,100.0f,-100.0f,-100.0f,-0.52641815f,-0.66465867f,-0.04545114f,0,-16.680555f,-100.0f,-100.0f,-70.641365f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.sphereShade(100.0f,0f,0f,-9.166085f,0f,0f,0f,199.80441f,0f,0f,82.98921f,-100.0f,80.89816f,-5.9707766f,-3.3167834f,6.4593716f,-100.0f,0.4569998f,-0.083017655f,1.0579544f,0,-100.0f,100.0f,-92.65918f,-100.0f,0f,0f,-63.33568f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.sphereShade(100.0f,100.0f,0f,1.0E-4f,0f,0f,0f,58.523254f,0f,0f,100.0f,-51.97096f,49.450718f,0f,-100.0f,66.47926f,-46.27558f,-0.7389021f,-0.1790537f,-0.043426793f,0,-135.66309f,-43.121864f,100.0f,139.80293f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.sphereShade(100.0f,-100.0f,0f,73.560555f,0f,0f,0f,-44.781734f,0f,0f,-66.13783f,-22.33308f,-100.0f,0f,2.5971365f,45.518375f,100.0f,-0.09916797f,-0.6010835f,-0.38052613f,0,-96.056496f,16.528418f,100.0f,7.373504f,-78.85916f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.sphereShade(100.0f,-100.0f,100.0f,100.0f,0f,0f,0f,0.0f,0f,0f,100.0f,50.77678f,86.67833f,0f,98.21442f,80.6703f,-100.0f,0.40645102f,0.52608407f,0.29040074f,0,-17.878227f,36.445637f,-96.07669f,-40.596382f,-46.84431f,-63.891655f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.sphereShade(100.0f,100.0f,100.0f,100.0f,0f,0f,0f,0.0f,0f,0f,97.50855f,83.92216f,-88.772675f,0f,-39.51845f,-100.0f,78.507484f,0.6780523f,-0.2867519f,0.6615322f,0,-50.238358f,-2.594572f,83.361275f,-20.337137f,84.13397f,1.0E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.sphereShade(-100.0f,100.0f,-2.7104053f,6.3359323f,0f,0f,0f,-64.41816f,0f,0f,9.2483f,100.0f,100.0f,0f,49.998222f,-61.93745f,87.57734f,-0.634555f,0.46254018f,-0.12672272f,0,0.37464353f,0.45564348f,0.37883607f,75.72438f,-29.522478f,12.667383f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.sphereShade(-100.0f,100.0f,-32.36448f,-13.749068f,0f,0f,0f,0.0f,0f,0f,-71.5177f,-100.0f,60.776962f,0f,-100.0f,16.76507f,72.86823f,0.31551197f,-0.4073016f,0.45885792f,0,-73.84048f,-100.0f,-95.88997f,94.453255f,100.0f,-13.997282f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.sphereShade(100.0f,100.0f,-35.524357f,14.534466f,0f,0f,0f,-50.476402f,0f,0f,-12.038495f,100.0f,-100.0f,0f,100.0f,-15.614441f,100.0f,0.2893143f,0.64594865f,-0.4647071f,0,0.032425143f,0.19859333f,-0.296296f,-100.0f,88.00253f,-93.6323f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.sphereShade(100.0f,-100.0f,38.742622f,-6.440604E-4f,0f,0f,0f,0.0f,0f,0f,6.3718786f,70.81078f,-93.56936f,0f,24.28354f,73.58854f,-18.229372f,-0.6464715f,-0.49410647f,-0.013339774f,0,80.39924f,46.002514f,-35.569565f,-17.677614f,15.526495f,-40.076004f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.sphereShade(-100.0f,-1.5090389f,0f,-0.077493675f,0f,0f,0f,33.475998f,0f,0f,-100.0f,-100.0f,57.7173f,0f,-99.5404f,-51.79132f,-100.0f,-0.3490011f,0.71074855f,0.17675081f,0,-100.0f,-100.0f,100.0f,-42.265373f,8.551323f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.sphereShade(-100.0f,-16.791222f,-12.141346f,-0.0015465287f,0f,0f,0f,-35.19785f,0f,0f,-9.894387f,-39.555428f,-85.9561f,0f,-50.100662f,-6.6794467f,-80.2743f,0.28265092f,0.7079458f,-0.47793984f,0,76.16442f,26.62561f,-33.936096f,-56.78664f,38.50878f,38.140205f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.sphereShade(-100.0f,-1.6862439f,-18.114931f,-0.0012731899f,0f,0f,0f,-100.0f,0f,0f,75.882355f,-26.043716f,8.987895f,0f,99.57764f,-66.3142f,100.0f,-0.63840026f,0.3640941f,0.5866404f,0,-100.0f,7.6168504f,-83.7362f,-100.0f,41.392796f,43.35809f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.sphereShade(-100.0f,18.916183f,-23.799892f,-0.002754976f,0f,0f,0f,0.0f,0f,0f,-100.0f,-15.491233f,-100.0f,0f,-94.994125f,-40.54597f,100.0f,0.85466623f,5.283181E-4f,0.24012166f,0,-96.96825f,-99.24917f,100.0f,100.0f,-19.188837f,12.785511f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.sphereShade(-100.0f,-20.503149f,0f,-0.0015336559f,0f,0f,0f,-56.0089f,0f,0f,98.5743f,-100.0f,-19.747076f,0f,1.4477612f,-45.29428f,99.44854f,0.11723974f,0.25070965f,-0.70642495f,0,14.162103f,50.261f,-100.0f,28.430916f,31.801785f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.sphereShade(100.0f,25.097593f,-40.861656f,97.221756f,0f,0f,0f,0.0f,0f,0f,34.237453f,100.0f,-100.0f,0f,82.291466f,-29.51841f,-67.691666f,0.89209753f,0.12332853f,-0.1907617f,0,1.1033269f,0.9373353f,-0.16718908f,27.7386f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.sphereShade(100.0f,26.604347f,71.0955f,-0.0010198845f,0f,0f,0f,-2.2540839f,0f,0f,-51.1972f,40.064613f,-37.33322f,0f,100.0f,-100.0f,100.0f,0.1176702f,-0.20650373f,-0.45973432f,0,28.172955f,100.0f,62.91886f,-60.303215f,-42.4705f,-13.791355f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.sphereShade(-100.0f,33.628445f,0f,-4.8512983f,0f,0f,0f,0.0f,0f,0f,-100.0f,0.2611313f,-8.847854f,0f,-99.94675f,0.85599685f,-8.281463f,-0.49596265f,-1.2280703f,0.4024526f,0,100.0f,-98.59035f,-4.9873595f,-68.50534f,84.8771f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.sphereShade(100.0f,-34.69128f,-65.48943f,100.0f,0f,0f,0f,0.0f,0f,0f,-70.708206f,-52.44381f,-89.49571f,0f,-9.732998f,99.61292f,66.48887f,0.79566437f,-0.25464037f,-0.2594755f,0,100.0f,-1.9014769f,-27.2547f,-28.910936f,-100.0f,-11.793419f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.sphereShade(100.0f,-49.321f,13.721834f,-1.0798698E-4f,0f,0f,0f,-100.0f,0f,0f,3.0855944f,-39.84115f,-6.8890133f,0f,3.6268148f,-40.16851f,-7.0722656f,0.17975283f,0.20105353f,0.5155423f,0,42.94329f,87.30582f,-99.30835f,-92.60375f,-100.0f,60.719376f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.sphereShade(100.0f,5.3909497f,0f,-100.0f,0f,0f,0f,-68.4439f,0f,0f,-100.0f,-32.639248f,-100.0f,0f,37.673138f,-30.690031f,38.066814f,-0.16537116f,-0.036077525f,0.23819013f,0,-0.3673508f,-0.5586282f,0.28160983f,21.020111f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.sphereShade(100.0f,-61.38579f,0f,0.0039171847f,0f,0f,0f,-80.464554f,0f,0f,0.45222598f,71.440735f,16.735077f,0f,1.3308576f,71.258865f,17.059544f,0.23906775f,-0.81786054f,-0.17776404f,0,-14.344485f,58.7795f,100.0f,17.139248f,-58.974392f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.sphereShade(100.0f,69.78013f,-57.8013f,-4.9723074E-4f,0f,0f,0f,-1.1368684E-13f,0f,0f,100.0f,-41.14482f,-6.339509f,0f,100.0f,-40.97343f,-6.7386065f,-0.72627366f,0.20734671f,0.33467576f,0,-48.698544f,83.593666f,-61.01776f,21.425278f,-38.879143f,-10.088789f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.sphereShade(-100.0f,86.53338f,-100.0f,-1.1710616E-4f,0f,0f,0f,5.971033E-7f,0f,0f,6.3476534f,-100.0f,19.365282f,0f,6.152457f,-100.0f,19.3867f,0.4118466f,0.5197637f,-0.13461445f,0,64.47707f,-100.0f,-47.223785f,89.42285f,-100.0f,33.238125f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.sphereShade(100.0f,90.978806f,-20.26052f,4.9357075E-4f,0f,0f,0f,72.03632f,0f,0f,-100.0f,100.0f,-1.7303818f,0f,-37.91412f,100.0f,-100.0f,-0.24540967f,0.67913926f,-0.21216626f,0,-32.566307f,86.47321f,8.3283415f,33.062534f,-98.508354f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.sphereShade(10.154647f,53.31235f,-49.23193f,0.0011984961f,0f,0f,0f,-6.1205144f,0f,0f,-100.0f,93.27498f,-62.02788f,0f,-100.0f,92.96929f,-62.871166f,-0.008328887f,-0.32935664f,0.43352515f,0,100.0f,47.94177f,-54.150734f,82.167206f,14.117533f,-63.98071f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.sphereShade(10.33229f,0f,0f,8.972407f,0f,0f,0f,86.683464f,0f,0f,-100.0f,100.0f,100.0f,-72.7466f,-96.326004f,100.0f,-55.478813f,0.41630864f,1.156343f,0.2991168f,0,-66.44075f,59.18704f,100.0f,-0.57290024f,0f,0f,62.672367f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.sphereShade(10.676458f,49.04213f,0f,-0.0021955138f,0f,0f,0f,0.0f,0f,0f,47.85735f,90.69634f,47.287933f,0f,-79.303505f,58.499252f,-1.6366756f,0.22180504f,-0.32494307f,0.6369316f,0,98.04179f,37.052376f,-66.2574f,-76.762085f,-9.287407f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.sphereShade(-10.968031f,0f,0.0029544719f,31.65912f,0f,0f,0f,0.0f,0f,0f,14.945978f,-38.491936f,68.7285f,0f,-99.914825f,25.877804f,-91.81423f,0.4956333f,0.1458348f,-0.18898425f,0,0.57748437f,0.8958963f,0.60223514f,58.34435f,0f,14.345462f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.sphereShade(-11.224675f,-85.19608f,62.944813f,6.818755f,0f,0f,0f,84.86477f,0f,0f,-62.245037f,100.0f,9.689493f,0f,100.0f,-10.365339f,100.0f,0.032634143f,-0.5193035f,-0.059709415f,0,-48.215343f,40.44148f,100.0f,34.252876f,-49.112633f,-7.786751f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.sphereShade(11.662851f,0f,0f,9.3225975f,0f,0f,0f,0.0f,0f,0f,58.350838f,-7.7383423f,-46.87994f,0f,59.04436f,-7.531816f,-46.474564f,-0.59472495f,-0.041892674f,-0.72471106f,0,33.525326f,60.596924f,-10.764357f,58.449978f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.sphereShade(12.125273f,-70.13433f,-90.90288f,73.979034f,0f,0f,0f,-71.42872f,0f,0f,16.261555f,100.0f,-6.3522573f,0f,-18.085203f,-8.853749f,70.22588f,-0.17453733f,0.3684191f,0.44775102f,0,34.214336f,-41.066055f,-62.292168f,-66.26457f,-100.0f,-12.296106f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.sphereShade(13.070066f,-7.7678256f,0f,0.0032421562f,0f,0f,0f,0.0f,0f,0f,-62.26269f,46.997368f,-65.25287f,0f,-0.8042886f,-57.8213f,-99.295654f,0.8849685f,0.3920099f,-0.2167381f,0,2.0759964f,-0.021580568f,0.28979662f,23.59871f,-19.54992f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.sphereShade(-13.351404f,0f,0f,-0.014340292f,0f,0f,0f,0.0f,0f,0f,94.133804f,-100.0f,100.0f,0f,-64.17541f,52.901485f,-160.62766f,-0.30230448f,-0.5342139f,0.54556596f,0,0.01101617f,0.27303576f,0.8785614f,-31.318678f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.sphereShade(14.124485f,77.11911f,-19.142809f,8.767253E-4f,0f,0f,0f,-26.517418f,0f,0f,-2.2726886f,2.4983726f,19.252272f,0f,96.71642f,72.773796f,-81.535995f,0.53258574f,0.23620974f,0.7027148f,0,-0.3903514f,-0.041565895f,-0.124548204f,80.75396f,-13.590393f,27.269405f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.sphereShade(-14.16073f,-69.15973f,0f,-35.152035f,0f,0f,0f,0.0f,0f,0f,33.73165f,31.281038f,75.51157f,0f,38.968792f,38.24059f,36.011787f,0.8118595f,0.2736638f,-0.43057442f,0,0.33855855f,0.2870123f,0.1083073f,-10.152293f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.sphereShade(-14.772181f,-100.0f,45.962166f,5.297149E-4f,0f,0f,0f,-0.3798826f,0f,0f,-4.9122214f,-49.055294f,95.34621f,0f,-70.9879f,98.79046f,99.282425f,0.3468618f,0.1058275f,-0.15635371f,0,-99.99719f,2.6743622f,-88.91374f,-59.841774f,-100.0f,41.073082f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.sphereShade(-1.5612162f,-42.27618f,0f,-0.009708769f,0f,0f,0f,-42.18825f,0f,0f,18.644228f,-98.420555f,-34.05844f,0f,17.96925f,-98.91219f,-33.96641f,-0.38658795f,0.13390383f,-0.56160027f,0,-41.451283f,6.3370953f,51.477993f,65.97399f,2.4363523f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.sphereShade(-157.3033f,-100.0f,112.11456f,1.4759123E-4f,0f,0f,0f,-161.52872f,0f,0f,-19.818075f,46.928234f,-62.746212f,0f,-68.98259f,-53.81478f,28.9846f,-0.19009992f,-0.42499956f,0.5692727f,0,11.285915f,167.12642f,72.045555f,-51.25444f,-67.75471f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.sphereShade(16.138102f,-29.973902f,0f,-9.569145E-4f,0f,0f,0f,-100.0f,0f,0f,86.668236f,-100.0f,-76.12906f,0f,-60.677277f,-62.782345f,46.583996f,-0.119911276f,0.5561352f,-0.098146886f,0,-1.9552611f,-100.0f,37.259644f,100.0f,34.864513f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.sphereShade(16.86353f,100.0f,-62.832558f,0.002814649f,0f,0f,0f,35.985046f,0f,0f,-100.0f,100.0f,-100.0f,23.56344f,11.416568f,80.67571f,96.105545f,-0.009659285f,-0.7103173f,-0.40427327f,0,35.8002f,42.588814f,100.0f,-95.49068f,-100.0f,21.260406f,19.570578f,-55.850636f,33.730305f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.sphereShade(-17.434898f,100.0f,41.901566f,87.11082f,0f,0f,0f,-63.669132f,0f,0f,-100.0f,-102.16018f,100.0f,0f,-100.0f,44.43939f,-156.57169f,-0.870786f,0.26463985f,0.13172252f,0,-0.37510267f,-1.1333928f,0.49180114f,-19.580257f,60.162254f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.sphereShade(1.7436408E-4f,0f,0f,66.44692f,0f,0f,0f,0.0f,0f,0f,-17.131767f,13.158471f,5.1299005f,0f,-16.664604f,13.734195f,5.2715287f,0.052684102f,-0.6321505f,0.5207731f,0,-33.478306f,86.94376f,-86.21048f,35.977306f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.sphereShade(17.617f,23.744528f,-5.136567f,-8.146017f,0f,0f,0f,-88.989235f,0f,0f,-63.11279f,16.18948f,-100.0f,0f,-62.93716f,16.512785f,-100.0f,-0.40497783f,0.25980124f,0.7883273f,0,-23.871542f,-50.926483f,-100.0f,-5.961206f,7.073377f,-12.782798f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.sphereShade(-1.7680607f,74.271805f,0.16756226f,-0.20516835f,0f,0f,0f,0.0f,0f,0f,100.0f,86.73758f,100.0f,0f,55.439026f,-96.508835f,-99.74067f,0.2876901f,-0.8343156f,-0.06315811f,0,0.47512951f,0.0010242385f,-0.4040098f,45.947315f,34.014572f,-29.08797f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.sphereShade(-18.39403f,0f,99.765495f,7.0908012f,0f,0f,0f,8.885479E-16f,0f,0f,100.0f,-35.640003f,13.247707f,0f,99.22293f,-19.971659f,-100.0f,-0.39274657f,-0.5795102f,0.42560327f,0,0.41789395f,0.8462793f,-0.33033496f,62.177357f,0f,-91.212524f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.sphereShade(18.400484f,-18.177622f,0f,10.490719f,0f,0f,0f,-64.23105f,0f,0f,-98.70404f,30.457298f,-36.034386f,0f,13.641616f,100.0f,-100.0f,0.0966009f,0.17836668f,-0.58836776f,0,15.185154f,-34.517548f,-23.671188f,8.914575f,97.34642f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.sphereShade(-18.48574f,-36.65441f,0f,-0.0150010185f,0f,0f,0f,-19.738434f,0f,0f,100.0f,13.533295f,-100.0f,0f,99.99997f,11.037095f,98.72632f,-0.5122889f,0.42334643f,0.63593155f,0,-0.6872834f,66.98023f,100.0f,3.6061382f,1.8186662f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.sphereShade(-18.495949f,99.99941f,99.999405f,-93.559456f,0f,0f,0f,-49.37548f,0f,0f,95.09173f,73.72812f,-13.673089f,0f,-22.378815f,98.5826f,97.03471f,-0.6178453f,0.052359384f,0.5870899f,0,0.24649408f,0.8921215f,-0.21088946f,-21.048851f,-20.310143f,-1.0688454E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.sphereShade(-1.8722937f,1.7076907f,-4.3129425f,0.013612844f,0f,0f,0f,-12.122191f,0f,0f,53.767914f,11.556679f,34.857224f,0f,53.669178f,11.157419f,34.48581f,0.43587986f,-0.78316844f,0.37508842f,0,-27.965538f,36.360703f,100.0f,-40.83568f,-7.7310095f,-79.024254f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.sphereShade(-19.203154f,-6.5590177f,4.447238f,-0.08817829f,0f,0f,0f,0.0f,0f,0f,-35.62846f,-20.108452f,77.22838f,0f,-28.190823f,-20.087555f,-42.52578f,0.05930839f,0.08001455f,0.8568779f,0,97.15643f,-4.5416126f,55.480183f,12.402074f,62.70183f,-2.5500455f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.sphereShade(1.9377729f,-58.838264f,-82.56216f,-8.87332f,0f,0f,0f,-32.159058f,0f,0f,26.848185f,-25.301144f,12.59197f,0f,76.584175f,-96.4213f,-100.0f,0.17857166f,0.54569215f,0.34427693f,0,15.679442f,-95.3717f,88.576836f,-22.494896f,-46.22265f,0.0013650006f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.sphereShade(19.911446f,-99.398315f,0.41856346f,-100.0f,0f,0f,0f,84.72047f,0f,0f,-100.0f,-99.83651f,43.648262f,0f,-38.831287f,100.0f,-100.0f,0.025400149f,-0.3927075f,-0.91836077f,0,67.81687f,10.956065f,-4.8775215f,-70.44853f,-6.344784f,70.81597f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.sphereShade(21.833225f,-55.15556f,-74.75606f,-16.003256f,0f,0f,0f,70.955315f,0f,0f,-100.0f,66.78784f,-50.970165f,0f,-59.76138f,18.690918f,2.637288f,-0.1660141f,-0.48395342f,-0.29660308f,0,100.0f,-49.723118f,100.0f,83.91602f,-16.833454f,-24.508482f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.sphereShade(22.499773f,60.240795f,0f,54.184265f,0f,0f,0f,-3.5401333E-15f,0f,0f,100.0f,-46.324448f,-8.392367f,0f,10.017557f,9.117711f,18.749598f,0.15555477f,0.43307784f,1.0368178f,0,-0.8542932f,-0.040039245f,-0.5181395f,-13.939192f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.sphereShade(-22.699196f,2.9624238f,10.440524f,0.03236005f,0f,0f,0f,-18.379505f,0f,0f,20.83505f,-5.591981f,-42.062004f,0f,-15.584964f,-15.556276f,-20.85913f,-0.41242862f,-0.6079464f,0.48649803f,0,-0.21558352f,-0.70954704f,0.060934447f,-57.129597f,10.431425f,2.959842f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.sphereShade(-23.291624f,-63.98244f,68.89292f,-58.703564f,0f,0f,0f,-27.720373f,0f,0f,41.930187f,-39.216026f,14.587708f,0f,-38.453465f,53.34678f,53.763435f,-0.097224236f,-0.68027747f,-0.3433184f,0,0.38283932f,0.3629991f,0.5206191f,10.124033f,-82.950676f,4.313459f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.sphereShade(-23.649742f,-65.42844f,45.044807f,2.2200117E-4f,0f,0f,0f,0.0f,0f,0f,6.193267f,78.64816f,-70.57572f,0f,100.0f,-17.646654f,49.7192f,0.09489444f,0.438404f,-0.20557977f,0,-93.49526f,-67.62032f,-23.747461f,-41.793312f,-68.84592f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.sphereShade(-23.763819f,99.45408f,9.050448f,91.184586f,0f,0f,0f,-2.6695635f,0f,0f,66.65319f,-71.81722f,-100.0f,0f,94.093765f,-87.774376f,-42.136417f,-0.35115865f,0.73366517f,0.41995913f,0,-0.47382218f,0.036529828f,-0.22853138f,-27.977648f,-19.460337f,33.758354f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.sphereShade(2.4061687f,0f,0f,-19.57963f,0f,0f,0f,0.0f,0f,0f,38.120132f,-24.637684f,61.411793f,0f,-35.212624f,20.706253f,-58.47927f,-0.42210582f,0.12389539f,-0.12938254f,0,0.051053684f,0.12922072f,-0.79019976f,-20.892769f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.sphereShade(-24.1931f,100.0f,0f,0.086647f,0f,0f,0f,0.0f,0f,0f,0.194846f,-87.573845f,56.38178f,0f,0.24773006f,-86.74067f,56.60699f,-0.5446252f,-0.2896002f,-0.26606232f,0,-75.84743f,100.0f,-77.348724f,-82.242836f,0.11541081f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.sphereShade(24.855251f,86.84823f,4.327603f,-23.267668f,0f,0f,0f,-2.3027177f,0f,0f,23.138931f,94.70319f,-36.711502f,0f,22.490547f,95.08706f,-36.839012f,-0.12727024f,0.04775404f,-0.0080783125f,0,44.287712f,-61.15465f,-69.74136f,78.409035f,-99.998985f,-49.873962f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.sphereShade(28.302822f,-100.0f,0f,-8.358469f,0f,0f,0f,-100.0f,0f,0f,-4.9975305f,100.0f,-48.494896f,0f,-100.0f,-8.591058f,-22.362688f,0.54427636f,-0.36725768f,0.74098843f,0,0.008421626f,-0.2563668f,-0.020451127f,-72.48134f,0.46894372f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.sphereShade(29.026812f,-63.937897f,-42.012814f,8.2921644E-4f,0f,0f,0f,60.67278f,0f,0f,92.20702f,4.951652f,19.540936f,0f,-8.270625f,86.465385f,-55.396683f,-0.9208265f,-0.23681134f,0.13025251f,0,73.19834f,-100.0f,9.999127f,-59.82232f,-18.861393f,-66.11454f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.sphereShade(2.957207f,14.311768f,0f,-71.49491f,0f,0f,0f,-43.277645f,0f,0f,65.33773f,19.194895f,-45.507004f,0f,65.86395f,19.573008f,-45.32653f,-0.43476143f,-0.39674947f,0.43403918f,0,-15.908882f,-63.61351f,68.53067f,2.1516259f,16.610157f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.sphereShade(-29.849928f,-32.58949f,0f,5.902899E-4f,0f,0f,0f,-100.0f,0f,0f,48.118763f,-16.567156f,-100.0f,0f,14.202754f,42.296116f,-45.01585f,0.06422095f,-0.739091f,-0.009349764f,0,0.07901994f,0.8248149f,-0.5127455f,-71.69128f,-51.982494f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.sphereShade(-29.856565f,-72.92821f,0f,-3.8450517E-4f,0f,0f,0f,-7.1054274E-15f,0f,0f,3.9892595f,99.6653f,-64.79925f,0f,-98.87669f,-99.60855f,63.039238f,-1.1378161f,-0.0071672774f,-0.50293684f,0,0.030773943f,-0.6614157f,-0.3532378f,86.486946f,-33.585697f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.sphereShade(-30.072853f,99.351814f,0f,10.810306f,0f,0f,0f,0.0f,0f,0f,79.849464f,-30.58168f,-100.0f,0f,-48.320198f,7.0190682f,10.218415f,0.23611262f,0.93788195f,-0.17721134f,0,-100.0f,-26.423868f,36.28472f,6.3571653f,63.690292f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.sphereShade(3.019363f,7.144108f,-8.270081f,-0.0035736004f,0f,0f,0f,-30.548145f,0f,0f,100.0f,-9.209658f,100.0f,0f,-100.0f,-37.57831f,66.667725f,0.55334383f,-0.21699122f,-0.52836746f,0,31.805492f,-75.88202f,-27.367922f,-92.67843f,-39.169315f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.sphereShade(31.462414f,99.89389f,99.99976f,2.1413418E-4f,0f,0f,0f,4.440892E-16f,0f,0f,17.266788f,2.320393f,-4.912704f,0f,17.24646f,70.70855f,3.0712729f,-0.11436436f,0.06396991f,0.8610627f,0,-3.8025913f,-64.199554f,-21.997852f,-100.0f,46.749294f,46.699802f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.sphereShade(31.702236f,-7.4566107f,46.244255f,-46.497112f,0f,0f,0f,0.0f,0f,0f,-26.514332f,98.632355f,80.20482f,0f,-45.991062f,-51.135574f,-31.429413f,-0.2001416f,0.13549598f,-0.49547487f,0,-14.274659f,-39.702374f,10.15362f,-76.81654f,-18.800495f,-32.246033f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.sphereShade(31.98908f,-4.1982756f,-88.374405f,0.004624049f,0f,0f,0f,-100.0f,0f,0f,96.16502f,-58.136013f,-44.61333f,0f,-69.86682f,94.04469f,-100.0f,-0.27295613f,0.01299296f,0.007927602f,0,83.209145f,67.29035f,63.907207f,97.07987f,-51.511787f,91.27475f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.sphereShade(-31.992771f,91.59008f,5.623101f,0.0018694472f,0f,0f,0f,-99.38989f,0f,0f,21.528028f,-5.9596686f,-42.674564f,0f,22.024616f,-6.6237154f,-40.782627f,-0.1559553f,-1.0617015f,1.0527359f,0,72.73614f,-5.872777f,98.468f,-17.832722f,97.40998f,95.128555f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.sphereShade(32.308895f,79.025536f,-65.39363f,-3.0924997E-4f,0f,0f,0f,-8.4904593E-7f,0f,0f,-5.0996895f,45.62543f,25.554228f,0f,-3.8236837f,44.29685f,25.21236f,-0.04162357f,0.9458131f,-0.31478903f,0,-51.631485f,71.801956f,-11.025529f,-100.0f,31.7776f,57.427677f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.sphereShade(-3.3782315f,100.0f,0f,-0.0038545227f,0f,0f,0f,95.48011f,0f,0f,52.79074f,-37.424755f,-11.669498f,-100.0f,17.097094f,100.0f,99.14606f,0.38747936f,-0.10395997f,-3.392655f,0,100.0f,-37.6003f,83.66625f,72.49833f,-99.73505f,0f,-38.81518f,-100.0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.sphereShade(-3.3911312f,99.99514f,14.933738f,6.776632E-5f,0f,0f,0f,-25.843052f,0f,0f,-2.3676937f,-47.153088f,-35.294147f,0f,-2.1995778f,-47.393383f,-36.575512f,0.3070737f,-0.87084365f,0.21724315f,0,-27.82045f,-2.9821072f,-100.0f,-99.984634f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.sphereShade(-34.674706f,100.0f,-46.690495f,0.00152646f,0f,0f,0f,-88.46155f,0f,0f,-100.0f,31.724983f,100.0f,0f,32.345234f,-99.77488f,100.0f,-0.3349231f,0.054526895f,0.047443926f,0,0.46224675f,0.019268619f,-0.44292015f,37.365128f,-100.0f,-17.34199f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.sphereShade(34.848972f,100.0f,0f,-3.7170298E-4f,0f,0f,0f,-14.198256f,0f,0f,-100.0f,-99.71797f,-100.0f,0f,100.0f,100.0f,68.22887f,-0.06454776f,-0.4858072f,0.10726518f,0,-33.182266f,-82.949554f,100.0f,-77.19942f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.sphereShade(35.46377f,27.01411f,80.09195f,-0.0034568885f,0f,0f,0f,-15.29358f,0f,0f,-2.73124f,-46.93277f,17.345182f,0f,8.73657f,61.29539f,16.703987f,-0.47807556f,0.10564448f,0.023167135f,0,-0.19941217f,0.51606166f,-0.6470699f,33.782555f,-11.038722f,55.775467f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.sphereShade(35.89832f,-100.0f,43.15254f,25.691545f,0f,0f,0f,-100.0f,0f,0f,15.783465f,97.01115f,-47.20247f,0f,100.0f,-29.148804f,95.12666f,0.5293323f,0.061034616f,0.15303603f,0,4.534515f,1.9684674f,38.960182f,6.8852167f,-55.47448f,69.42622f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.sphereShade(-36.733288f,-89.365486f,-88.391075f,-47.333305f,0f,0f,0f,-37.100018f,0f,0f,32.653008f,-57.092525f,-83.854675f,0f,14.841109f,44.655556f,96.313705f,-0.7377784f,0.50319403f,0.08186045f,0,37.88065f,-84.21261f,96.77733f,-2.0268528f,-53.35957f,-56.663166f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.sphereShade(-3.674382f,0f,0f,99.80551f,0f,0f,0f,0.0f,0f,0f,-2.2136405f,95.68354f,75.890854f,0f,77.18166f,97.95861f,100.0f,0.44345945f,0.6448504f,0.44618177f,0,-93.35292f,93.352844f,-33.003098f,4.266893f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.sphereShade(382.44894f,51.422474f,-13.6891575f,3.6053016E-4f,0f,0f,0f,-179.94185f,0f,0f,-107.0275f,-135.17052f,70.33401f,0f,54.91169f,-78.311676f,19.143671f,0.46070322f,-0.7865846f,0.39094332f,0,102.6314f,-48.936207f,-56.40567f,7.495322f,53.939316f,-175.3138f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.sphereShade(38.594917f,0.0024838208f,-99.99661f,4.1434f,0f,0f,0f,-99.00261f,0f,0f,44.914555f,30.008251f,-100.0f,0f,45.37313f,29.627546f,-100.0f,-0.27163035f,0.55682355f,0.77956384f,0,99.86389f,-25.953653f,85.05589f,24.230625f,97.167915f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.sphereShade(39.439224f,11.254787f,-19.31169f,0.00267341f,0f,0f,0f,-59.686253f,0f,0f,100.0f,-99.99999f,-98.82224f,0f,-63.216377f,12.089658f,6.0100083f,-0.17147902f,-0.27308765f,-0.5056611f,0,-58.93626f,-4.918739f,66.56127f,9.484317f,-76.19668f,-19.369308f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.sphereShade(-3.9568598f,0f,0f,0.04511887f,0f,0f,0f,-32.134373f,0f,0f,64.90784f,18.004255f,-96.70404f,0f,46.750694f,-36.316414f,37.37844f,0.05018789f,-0.600883f,0.15793994f,0,-0.32425794f,0.73053473f,-0.39161f,-5.60133f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.sphereShade(3.9928418E-4f,86.1657f,0f,-39.161907f,0f,0f,0f,-39.482765f,0f,0f,20.958254f,18.723764f,-96.529144f,0f,-100.0f,100.0f,61.211143f,0.694475f,0.4455289f,-0.17158322f,0,62.696964f,-82.67093f,100.0f,-63.95199f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.sphereShade(40.487953f,0f,0f,-100.0f,0f,0f,0f,-100.0f,0f,0f,64.58421f,98.75048f,25.330685f,0f,-42.80297f,-100.0f,-53.73103f,-0.49800122f,0.013879958f,-0.06738468f,0,-41.95598f,-100.0f,41.166935f,-0.02725353f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.sphereShade(-40.631126f,0f,0f,-47.019238f,0f,0f,0f,0.0f,0f,0f,11.501296f,-53.366512f,-90.997025f,0f,83.71941f,-21.76692f,-100.0f,0.66318953f,0.42046082f,-0.25727573f,0,-39.23421f,99.56606f,-57.65092f,4.7276797f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.sphereShade(40.73715f,-55.42387f,35.706978f,-0.0069362223f,0f,0f,0f,-58.708626f,0f,0f,-42.94621f,-38.552628f,34.212418f,0f,-57.517536f,100.0f,70.49848f,-0.17607415f,-0.5723061f,0.0044101407f,0,0.35865143f,0.34272736f,0.30263224f,-3.5390475f,2.6012385f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.sphereShade(-41.73075f,0.0042508063f,90.040375f,-100.0f,0f,0f,0f,-93.20305f,0f,0f,39.93458f,100.0f,8.735117f,0f,42.275795f,5.8363557f,-54.27597f,0.088308096f,-0.52399284f,0.15420043f,0,-83.43374f,-98.14288f,-4.8423514f,66.23105f,83.63819f,-16.948967f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.sphereShade(-42.452206f,-12.59953f,0f,17.4427f,0f,0f,0f,0.0f,0f,0f,44.24079f,31.53584f,-100.0f,0f,44.66298f,31.678308f,-100.0f,0.4674012f,-0.6894315f,-0.48836342f,0,6.454292f,-18.802038f,-56.65439f,-64.795715f,-56.07258f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.sphereShade(-42.582134f,25.857647f,0f,-8.1583613E-4f,0f,0f,0f,0.0f,0f,0f,100.0f,-7.6862187f,32.643776f,0f,-64.35873f,-85.452095f,-100.0f,0.11212969f,-0.004573494f,0.10677991f,0,-67.42463f,-14.827759f,-57.492767f,-24.19251f,-47.403244f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.sphereShade(43.010326f,-73.8876f,-40.797955f,2.451868E-4f,0f,0f,0f,-91.85797f,0f,0f,-72.3574f,0.74229014f,66.373886f,0f,-71.77566f,0.9336014f,65.62758f,-0.7789392f,0.14037295f,-0.32892138f,0,28.447645f,97.27969f,17.667778f,-59.370266f,-14.290433f,-99.96882f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.sphereShade(43.097393f,2.5862372f,0f,0.023992809f,0f,0f,0f,-37.44484f,0f,0f,-55.62279f,-10.907193f,-3.7339778f,0f,-55.98386f,-10.9712515f,-2.9492726f,0.13583395f,0.42958125f,-0.59843415f,0,75.08065f,93.65178f,-55.726498f,4.043735f,16.115751f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.sphereShade(-43.42001f,99.08615f,0f,-0.0036311357f,0f,0f,0f,-3.5260654E-15f,0f,0f,-100.0f,100.0f,72.2763f,0f,-100.0f,44.953705f,57.87484f,0.16367263f,-0.30933335f,-0.71672153f,0,-0.6648611f,0.88115597f,-0.72385633f,7.2153525f,-56.203033f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.sphereShade(44.073456f,8.248737f,0.54908997f,-2.189585f,0f,0f,0f,0.0f,0f,0f,9.410453f,30.94998f,-20.945635f,0f,8.959293f,31.656954f,-20.555534f,-0.12804428f,-0.4089931f,0.5211066f,0,-34.479286f,-63.410534f,74.68932f,-17.159143f,-15.291962f,-0.8317427f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.sphereShade(44.10183f,33.384205f,-38.060028f,-22.786364f,0f,0f,0f,100.0f,0f,0f,34.323383f,-21.831024f,-0.6187234f,0f,-92.791084f,-29.50804f,69.63834f,-0.09833022f,0.25995353f,-0.013608446f,0,73.31739f,26.759382f,82.08201f,-81.073364f,-100.0f,-93.09107f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.sphereShade(-4.4305315f,-0.5160408f,-2.526418f,0.032174964f,0f,0f,0f,-6.456498f,0f,0f,-89.41894f,-92.45767f,5.8555074f,0f,83.217125f,-15.629968f,11.612831f,-0.62944543f,-0.22446825f,-0.26937252f,0,54.606205f,-5.2025685f,-84.46144f,-1.3416138f,-60.227924f,-12.302029f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.sphereShade(45.011055f,36.97097f,90.00212f,9.6413365E-4f,0f,0f,0f,-100.0f,0f,0f,99.98009f,99.98815f,29.540442f,0f,11.6992f,-9.956635f,-100.0f,0.82668597f,-0.053422768f,-0.43861303f,0,19.152027f,95.965485f,-19.529703f,25.038595f,-88.10517f,11.513412f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.sphereShade(-45.082867f,100.0f,44.21334f,2.26577E-4f,0f,0f,0f,-100.0f,0f,0f,94.77206f,-98.87436f,-100.0f,0f,100.0f,-100.0f,-89.17269f,-0.032412183f,-0.80704767f,-0.5255129f,0,-42.8398f,97.76429f,28.765598f,-97.897736f,44.190395f,99.82305f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.sphereShade(45.559547f,-58.582256f,-45.18161f,-5.5885057f,0f,0f,0f,0.0f,0f,0f,49.944935f,-38.989006f,73.42862f,0f,-83.48642f,97.21228f,-100.0f,-0.91249573f,-0.21884353f,-0.10336273f,0,-63.006416f,-43.617855f,-13.574655f,-27.675617f,66.46144f,32.494534f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.sphereShade(-45.777f,13.4853f,-100.0f,-7.415482E-4f,0f,0f,0f,-100.0f,0f,0f,62.076374f,-100.0f,10.061417f,0f,41.726574f,-100.0f,97.58107f,-0.18647103f,0.23131062f,0.6714043f,0,-0.2599261f,-0.16685015f,1.5856808f,-85.9429f,-100.0f,46.330223f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.sphereShade(46.328407f,82.68801f,43.775944f,-42.540527f,0f,0f,0f,-61.038017f,0f,0f,33.891403f,-100.0f,46.02942f,0f,34.32036f,-100.0f,46.444283f,0.20155956f,-0.41743058f,0.105394855f,0,15.850606f,-99.42918f,-100.0f,-61.810097f,-52.06667f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.sphereShade(-4.7745147f,4.197688f,81.81379f,13.409654f,0f,0f,0f,93.48149f,0f,0f,-79.80459f,100.0f,-2.4644141f,100.0f,-74.04045f,-51.204163f,92.62346f,-4.260069f,-2.2600784f,-4.0740123f,0,-24.134298f,45.68943f,-33.02586f,100.0f,-100.0f,-43.036324f,77.25782f,-70.35634f,-94.79416f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.sphereShade(48.338123f,-5.9822645f,59.72606f,-0.0016716077f,0f,0f,0f,-12.950494f,0f,0f,100.0f,-100.0f,-96.968094f,0f,-57.566315f,-78.2319f,100.0f,0.21009897f,0.042925786f,0.21746388f,0,-79.189285f,-100.0f,34.411488f,-12.375873f,100.0f,74.327736f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.sphereShade(-50.424625f,-100.0f,0f,82.37655f,0f,0f,0f,24.771694f,0f,0f,65.746254f,-96.54395f,-65.275566f,-100.0f,-73.41956f,4.214375f,-21.374464f,-0.26516092f,-2.2031953f,0.04092982f,0,94.926254f,-32.679657f,-40.433052f,83.34584f,-31.188381f,0f,-100.0f,50.66545f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.sphereShade(-50.436234f,0.37585625f,97.64766f,9.713422f,0f,0f,0f,84.58357f,0f,0f,30.750252f,19.489588f,100.0f,0f,-26.242891f,100.0f,99.26841f,0.03854326f,0.37355873f,-0.20362702f,0,-98.72395f,-100.0f,98.244316f,-99.18761f,95.900055f,31.477642f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.sphereShade(-50.52451f,-87.5509f,60.79655f,1.4849435f,0f,0f,0f,-53.942787f,0f,0f,-100.0f,75.61839f,41.870056f,0f,-91.74676f,100.0f,8.808847f,-0.09704861f,0.5932287f,-0.43607724f,0,-0.18014885f,-44.121933f,96.90502f,27.871716f,-0.0076918257f,0.92019206f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.sphereShade(-51.493374f,-48.61211f,100.0f,-2.1399016E-4f,0f,0f,0f,-97.93618f,0f,0f,-100.0f,-100.0f,100.0f,0f,-100.0f,-7.7751727f,26.536972f,0.19112206f,-0.26629317f,-0.71388435f,0,0.65596503f,-0.105833426f,0.3641962f,90.75172f,96.13061f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.sphereShade(-5.442346f,-1.5394373f,0.054137602f,-38.123978f,0f,0f,0f,-42.042633f,0f,0f,31.65934f,-16.06677f,89.19908f,0f,-53.555054f,-48.664913f,100.0f,-0.12733515f,0.5715813f,0.79005086f,0,100.0f,-8.551859f,69.94968f,-86.14174f,64.8486f,75.37153f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.sphereShade(56.48182f,3.6019578f,-19.863283f,55.791878f,0f,0f,0f,0.0f,0f,0f,-43.76971f,100.0f,21.351133f,0f,-76.01824f,-24.439247f,-100.0f,-0.7303542f,0.26810032f,-0.42701825f,0,35.61711f,-97.70773f,-93.03785f,-1.3042185f,0.004976115f,92.23966f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.sphereShade(-57.059372f,-55.05757f,0f,-22.04733f,0f,0f,0f,-85.30634f,0f,0f,85.88193f,-100.0f,97.9491f,0f,100.0f,-89.81384f,47.782394f,0.00980842f,-0.5205499f,0.8048079f,0,-100.0f,-47.139294f,57.89211f,-8.919124f,8.238097E-4f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.sphereShade(57.094704f,-35.544106f,-53.160698f,2.8134062E-4f,0f,0f,0f,-51.40596f,0f,0f,-100.0f,79.911674f,18.878145f,0f,-100.0f,100.0f,-21.732819f,-0.065411426f,-0.4837918f,-0.47403526f,0,-0.66827816f,-0.12318799f,0.0661344f,62.254642f,-100.0f,-66.86162f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.sphereShade(-57.87518f,5.0600696f,0f,0.010529181f,0f,0f,0f,-50.15387f,0f,0f,-29.319582f,6.9034395f,62.61853f,0f,-21.22819f,15.367189f,63.995144f,0.030373098f,0.73462915f,-0.0049242103f,0,-0.49856004f,-0.09063289f,0.29099616f,-1.6410168f,18.769337f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.sphereShade(-59.077168f,24.868444f,0f,37.155884f,0f,0f,0f,0.0f,0f,0f,1.9578636f,100.0f,-80.1834f,0f,87.82777f,-58.81436f,-2.9353771f,0.5182981f,0.5285396f,0.20752786f,0,-100.0f,27.18611f,-30.79407f,-1.2942777f,-48.568928f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.sphereShade(-59.88021f,98.05045f,98.788216f,-0.09468551f,0f,0f,0f,100.0f,0f,0f,-98.63024f,-72.765625f,18.323599f,0f,-18.539732f,93.831535f,99.19909f,-0.69540614f,0.55707675f,-0.33380565f,0,100.0f,74.791916f,-5.914482f,34.42655f,63.88355f,-64.707596f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.sphereShade(-59.95499f,100.0f,-15.295132f,-43.22319f,0f,0f,0f,-86.74088f,0f,0f,100.0f,7.875554f,85.166115f,0f,100.0f,-17.09324f,37.32923f,0.13999544f,0.12857741f,0.5711375f,0,-0.22346917f,-0.74273217f,-0.39150006f,5.7282553f,-100.0f,-5.163309f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.sphereShade(60.904568f,-8.05503f,-2.908572E-4f,-100.0f,0f,0f,0f,0.0f,0f,0f,6.4089828f,-84.280876f,91.02934f,0f,100.0f,27.435179f,96.78071f,0.1845619f,0.3607205f,0.6259707f,0,-100.0f,-4.4992647f,100.0f,-100.0f,-7.267848f,34.381134f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.sphereShade(62.347103f,-62.347103f,-100.0f,1.6039237E-4f,0f,0f,0f,-100.0f,0f,0f,-1.1591728f,-7.8671026f,-80.34316f,0f,-0.96302474f,-8.475097f,-80.40006f,0.42489976f,0.2814489f,0.2783161f,0,-0.0072148647f,88.35556f,-75.80617f,100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.sphereShade(62.485508f,-48.593937f,0f,2.0588592E-4f,0f,0f,0f,-20.17535f,0f,0f,100.0f,-100.0f,-87.27552f,0f,100.0f,-100.0f,-86.84901f,0.4715311f,0.2134193f,0.71318614f,0,91.287766f,39.302944f,49.569187f,88.78761f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.sphereShade(-62.626797f,7.5846105f,0f,100.0f,0f,0f,0f,100.0f,0f,0f,-51.492085f,100.0f,16.902443f,0f,-100.0f,100.0f,-100.0f,0.094991654f,0.43807665f,-0.06374602f,0,100.0f,17.414385f,98.412094f,50.63807f,97.67515f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.sphereShade(62.989964f,35.225193f,0f,-19.610874f,0f,0f,0f,-0.93418473f,0f,0f,100.0f,44.122883f,-72.628876f,0f,-71.44815f,5.9518685f,-1.2016572f,-0.11429905f,-0.38375515f,-0.21140034f,0,-64.95347f,-30.713535f,-61.288387f,0.0017161823f,28.950945f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.sphereShade(-64.16201f,-99.553474f,-44.17591f,-4.7747622E-4f,0f,0f,0f,0.0f,0f,0f,-45.521862f,41.349556f,-49.132824f,0f,99.98813f,-99.86386f,50.87387f,-0.60159546f,-0.32370806f,-0.032511182f,0,-62.891174f,100.0f,48.108063f,99.94521f,21.037388f,95.52873f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.sphereShade(65.42095f,100.0f,71.53956f,1.982524E-4f,0f,0f,0f,0.0f,0f,0f,73.4416f,-85.777565f,-67.70356f,0f,-23.919828f,20.048935f,-28.675158f,-0.8569607f,0.084775984f,0.14111699f,0,13.521835f,-51.450264f,-15.119858f,-1.6964344f,50.440754f,76.188126f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.sphereShade(-65.459526f,0f,0f,11.572097f,0f,0f,0f,-100.0f,0f,0f,39.280483f,-98.13436f,-100.0f,0f,-100.0f,-50.828674f,100.0f,-0.2075247f,-0.8209603f,0.49796414f,0,0.68129206f,-0.04459844f,0.32354173f,13.47789f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.sphereShade(6.5911875f,-98.268326f,0f,60.39713f,0f,0f,0f,-99.63796f,0f,0f,-15.159602f,64.908676f,93.241234f,0f,91.582504f,92.68241f,-100.0f,-0.4921435f,0.4076496f,-0.42241284f,0,-0.9422927f,0.24524952f,0.07723967f,-23.879618f,95.162056f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.sphereShade(66.15092f,-100.0f,10.981267f,-5.705785E-4f,0f,0f,0f,-1.67033f,0f,0f,33.417526f,28.462482f,92.15434f,0f,-30.352182f,48.173927f,71.291595f,-0.11055029f,0.48448423f,0.17970301f,0,15.668182f,89.192604f,45.72628f,-26.494072f,89.68575f,24.380589f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.sphereShade(66.41073f,100.0f,8.462372f,-37.109177f,0f,0f,0f,0.0f,0f,0f,-100.0f,100.0f,-77.95698f,0f,-56.470127f,100.0f,13.73623f,-0.12025687f,-0.94370544f,-0.1368462f,0,-100.0f,-92.348976f,-60.368637f,100.0f,48.790627f,-14.247607f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.sphereShade(6.668982f,-43.01794f,-77.272575f,3.0199785E-4f,0f,0f,0f,100.0f,0f,0f,-100.0f,-100.0f,39.762936f,0f,-40.418655f,55.004616f,-57.35026f,0.5199775f,-0.4442403f,-0.46779f,0,79.5408f,-43.311436f,76.33489f,-79.4277f,-100.0f,-42.851967f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.sphereShade(-67.955315f,100.0f,-24.520763f,1.4715553E-4f,0f,0f,0f,-99.99968f,0f,0f,89.66216f,100.0f,-91.27499f,0f,99.998314f,100.0f,-100.0f,-0.4159608f,-0.30015883f,-0.574589f,0,22.31371f,-100.0f,-32.879826f,-100.0f,-100.0f,61.44781f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.sphereShade(-68.56977f,-42.89665f,-48.79092f,-3.2446976E-4f,0f,0f,0f,-100.0f,0f,0f,96.789795f,23.00631f,99.5245f,0f,-55.85189f,-68.71419f,-52.4634f,-0.83019876f,0.010864622f,0.39381507f,0,0.29046664f,-0.9135586f,-0.12797114f,44.94621f,-51.271976f,75.31541f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.sphereShade(69.37119f,0f,0f,110.416985f,0f,0f,0f,-71.046974f,0f,0f,-44.31022f,7.518335f,-37.858788f,0f,-44.46115f,7.434552f,-37.62659f,0.42602277f,-0.42234728f,-0.78253114f,0,-72.979225f,36.874176f,-96.86737f,-2.8646836f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.sphereShade(-69.68082f,0f,0f,68.089035f,0f,0f,0f,63.330677f,0f,0f,-100.0f,-88.22826f,-28.704878f,0f,-95.434296f,12.108839f,-227.42236f,-0.16962303f,-0.4693045f,-0.24654688f,0,-100.0f,-141.77739f,-70.80199f,0.072063036f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.sphereShade(69.702705f,-9.496695f,0f,-35.93109f,0f,0f,0f,-21.177496f,0f,0f,-11.854119f,-14.302701f,2.2583067f,0f,-12.010472f,-14.466197f,1.4427155f,-0.68650854f,-0.6103135f,0.33766955f,0,-12.818833f,-62.80614f,-4.2898064f,-53.778503f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.sphereShade(-71.938866f,-100.0f,-100.0f,-9.5705494E-5f,0f,0f,0f,-2.7755576E-17f,0f,0f,-85.21111f,27.512203f,-51.635883f,0f,-85.913f,28.86793f,-51.211246f,0.25445214f,-0.898007f,0.06142486f,0,58.276474f,-51.56934f,-100.0f,56.63604f,-28.605688f,51.19109f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.sphereShade(72.26089f,10.72315f,0f,1.3760599f,0f,0f,0f,-14.872041f,0f,0f,-100.0f,-23.385515f,-4.2808795f,0f,-38.755146f,-100.0f,100.0f,0.22903788f,0.37393114f,-0.08351432f,0,-0.43340987f,0.05257857f,0.65381676f,66.135735f,-10.666277f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.sphereShade(72.36158f,0f,0f,54.631615f,0f,0f,0f,-38.618713f,0f,0f,-100.0f,45.65723f,99.596695f,0f,-100.0f,45.708866f,100.0f,0.6109891f,0.5109373f,-0.3827843f,0,3.7839193f,92.949745f,-100.0f,38.937683f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.sphereShade(-72.95084f,0f,0f,-5.8600187f,0f,0f,0f,0.0f,0f,0f,14.90566f,-47.361256f,16.116894f,0f,15.144747f,-47.45094f,15.406286f,0.25740328f,-0.119200684f,0.9189394f,0,35.457283f,84.254684f,-16.272907f,-60.59376f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.sphereShade(72.989265f,100.0f,-62.915104f,69.07094f,0f,0f,0f,-55.04958f,0f,0f,-44.888527f,-94.41868f,52.889324f,0f,-73.22675f,-100.0f,99.576645f,0.16759689f,0.35522225f,-0.38693094f,0,-46.260036f,-3.2017722f,49.131786f,70.89842f,0.873199f,56.06198f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.sphereShade(74.1072f,86.05981f,0f,9.461026f,0f,0f,0f,97.88999f,0f,0f,2.3438146f,-2.6437893f,87.687515f,0f,-9.331818f,9.518513f,-69.05272f,-0.5773807f,-0.184578f,-0.102878764f,0,-87.48907f,-100.0f,-79.344666f,84.15459f,-16.681479f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.sphereShade(-76.75732f,100.0f,-20.614985f,-2.6781732E-4f,0f,0f,0f,-51.668377f,0f,0f,-8.526442f,-44.45809f,99.743126f,0f,-62.130863f,-45.386436f,-67.34693f,-0.3676324f,-0.5191416f,-0.71211964f,0,-0.122801654f,0.2529338f,-0.55921316f,67.35505f,-37.338886f,37.10843f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.sphereShade(-77.36821f,0f,0f,-4.2424074E-4f,0f,0f,0f,-81.16048f,0f,0f,-100.0f,22.055151f,-25.110844f,0f,100.0f,84.730125f,-62.392075f,0.04404142f,-0.8665171f,-0.139986f,0,-36.166435f,100.0f,48.3561f,30.466677f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.sphereShade(-77.68908f,-52.13458f,-100.0f,1.8389223E-4f,0f,0f,0f,-33.424397f,0f,0f,-63.40483f,45.029217f,-94.63135f,0f,-16.452477f,-100.0f,93.06328f,0.96319693f,-0.33795008f,-0.27481443f,0,-0.35062727f,0.7208884f,0.5807436f,-71.07632f,79.816055f,21.18583f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.sphereShade(79.05758f,-0.00572383f,2.3015864f,-50.377224f,0f,0f,0f,-53.327965f,0f,0f,-30.378918f,-49.393787f,60.90468f,0f,-30.460737f,-49.264683f,61.53834f,0.4536236f,-0.38865685f,0.056889944f,0,99.11554f,-17.100306f,51.444813f,-0.42940247f,96.72985f,-45.807743f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.sphereShade(79.278534f,44.49835f,-34.10577f,2.88661E-4f,0f,0f,0f,-86.70861f,0f,0f,100.0f,-97.30179f,-100.0f,0f,-58.739357f,43.39046f,100.0f,0.3553317f,-0.026659248f,-0.48122838f,0,0.8186213f,0.813925f,-1.7798058f,-99.45743f,97.221725f,41.317974f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.sphereShade(-79.71294f,61.786304f,3.2012322f,-0.068115965f,0f,0f,0f,5.9476533f,0f,0f,35.394173f,92.94496f,-99.630035f,22.50106f,-15.701238f,-99.9994f,5.29193f,-0.13629685f,0.8800296f,0.23310956f,0,-44.978027f,18.899574f,-43.37551f,0.4960002f,99.99979f,-30.592325f,-72.78348f,-96.17901f,67.226364f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.sphereShade(7.9802923f,-32.84655f,100.0f,-45.547638f,0f,0f,0f,100.0f,0f,0f,-100.0f,-99.251f,100.0f,0f,-100.0f,-99.893364f,22.4561f,-0.3944544f,-0.2526733f,-0.5258036f,0,98.09913f,-63.218376f,100.0f,100.0f,-6.507627f,-34.94523f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.sphereShade(-80.459465f,67.4273f,0f,-38.806f,0f,0f,0f,0.0f,0f,0f,-23.502834f,64.410194f,89.50522f,0f,72.42123f,-47.81784f,-100.0f,-0.5576739f,0.3280517f,-0.6229868f,0,62.143597f,27.557068f,-45.781082f,100.0f,-46.362152f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.sphereShade(81.44698f,-100.0f,0.008258153f,-100.0f,0f,0f,0f,0.0f,0f,0f,99.98762f,98.85976f,-100.0f,0f,-100.0f,-34.401634f,-36.6982f,-0.46173254f,-0.45147496f,0.46732715f,0,-17.808142f,-37.617603f,8.569536f,47.88256f,-17.070591f,-1.2109245f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.sphereShade(81.98546f,3.554882f,83.61504f,-98.00161f,0f,0f,0f,0.0f,0f,0f,52.65845f,-21.299969f,62.901863f,0f,53.241123f,-21.138044f,63.173637f,-0.09470709f,-0.24890722f,0.66102254f,0,71.31071f,-99.99481f,57.280334f,-48.885784f,62.943775f,-66.3373f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.sphereShade(-82.019066f,-8.44854f,100.0f,3.141985E-4f,0f,0f,0f,-35.44945f,0f,0f,69.071335f,40.2215f,-100.0f,0f,-93.85109f,-100.0f,14.163628f,0.55338997f,0.24675529f,-0.54264563f,0,-0.49767345f,-0.4286248f,-0.61673f,-38.80441f,-97.87916f,32.090088f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.sphereShade(84.4486f,10.716548f,0f,0.019119686f,0f,0f,0f,-93.1355f,0f,0f,-99.977844f,9.073576f,-93.866104f,0f,-99.99866f,8.5739975f,-93.72072f,0.4643363f,-0.4409062f,0.15597647f,0,2.293984f,64.87834f,41.10559f,-19.281542f,4.8757668f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.sphereShade(84.93866f,26.601992f,-28.514362f,3.9060766E-4f,0f,0f,0f,0.0f,0f,0f,-100.0f,-24.049692f,-40.190426f,0f,-100.0f,-24.699291f,-39.97109f,0.14237382f,-0.7655565f,-0.32655972f,0,141.29735f,100.0f,9.237264f,-51.869823f,-57.652233f,-77.58389f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.sphereShade(85.891754f,28.23591f,100.0f,-100.0f,0f,0f,0f,-94.223564f,0f,0f,100.0f,-100.0f,-40.31833f,0f,56.07527f,-100.0f,100.0f,0.23024857f,-0.7016294f,0.16425705f,0,58.344593f,-97.14149f,-68.488335f,100.0f,32.632416f,-72.90055f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.sphereShade(-86.27701f,-100.0f,99.82896f,32.74154f,0f,0f,0f,-61.301315f,0f,0f,7.4158926f,-19.985928f,21.778223f,0f,7.9397206f,-19.493126f,21.224901f,-0.53558767f,0.37391198f,0.53098017f,0,85.03703f,100.0f,-34.51121f,100.0f,4.513515f,-98.96693f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.sphereShade(-88.27931f,-100.0f,99.99959f,-0.0013022143f,0f,0f,0f,100.0f,0f,0f,4.9040728f,7.9649076f,28.753704f,0f,18.813753f,90.84572f,74.14967f,-0.09807982f,0.26344168f,-0.119113706f,0,-100.0f,-100.0f,100.0f,-19.95402f,99.99998f,-7.6792593f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.sphereShade(-88.802284f,0f,0f,75.30906f,0f,0f,0f,64.51976f,0f,0f,37.072887f,100.0f,100.0f,0f,-24.86593f,-100.0f,86.718f,-0.46172705f,0.06519275f,0.09816489f,0,100.0f,-100.0f,-36.630352f,-45.374844f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.sphereShade(-89.55437f,0f,0f,-100.0f,0f,0f,0f,-96.896095f,0f,0f,100.0f,71.30402f,-9.340726f,0f,49.697163f,-34.169933f,20.832201f,-0.22442976f,0.8938821f,0.26896456f,0,-28.68442f,1.6680778f,-53.772133f,-100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.sphereShade(89.757225f,2.1830568f,0f,100.0f,0f,0f,0f,0.0f,0f,0f,100.0f,16.106428f,63.234856f,0f,2.4334779f,-41.854633f,16.185871f,-0.46660656f,-0.2271519f,-0.1940684f,0,-0.09824262f,-0.7945475f,0.47812667f,73.23761f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.sphereShade(-90.96275f,70.917625f,0f,-3.3531208f,0f,0f,0f,3.5527137E-15f,0f,0f,-29.27937f,-85.69202f,-100.0f,-60.379944f,100.0f,-100.0f,25.48094f,-0.3093981f,-0.9271436f,0.0038626064f,0,63.46032f,2.7209277f,-100.0f,-69.446526f,23.409597f,0f,-100.0f,-57.861664f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.sphereShade(91.140915f,55.10151f,-69.600685f,1.4367675E-4f,0f,0f,0f,-51.950893f,0f,0f,52.998856f,-2.298516f,-15.131087f,0f,53.4116f,-2.8595653f,-14.903345f,-0.8600459f,0.26630822f,0.26585305f,0,25.508211f,-19.135307f,-64.649574f,100.0f,-90.53046f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.sphereShade(-91.534615f,0f,-59.828556f,2.28832f,0f,0f,0f,0.0f,0f,0f,17.762754f,-37.452465f,-54.97666f,0f,-95.94609f,-58.599754f,44.719303f,0.40092617f,0.13895437f,-0.78076965f,0,0.034292582f,-0.6801461f,-0.25066316f,96.26355f,0f,-41.029625f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.sphereShade(-91.743706f,-96.533134f,57.763157f,-0.0021861077f,0f,0f,0f,-53.637135f,0f,0f,12.312265f,-72.085205f,100.0f,0f,76.74519f,31.169506f,-96.90301f,0.0039686123f,0.53074384f,-0.4570798f,0,-0.3688543f,-0.4753187f,-0.63707614f,84.480225f,82.605576f,-7.919131f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.sphereShade(92.055275f,41.35082f,-20.099781f,-28.033207f,0f,0f,0f,-12.795463f,0f,0f,-100.0f,50.303608f,99.59379f,0f,-100.0f,50.5789f,99.50799f,0.5750323f,0.49080196f,0.3582097f,0,-100.0f,48.221107f,17.339752f,-29.81787f,-9.000905E-4f,-5.9981585f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.sphereShade(-92.26195f,-0.12786138f,0f,100.0f,0f,0f,0f,0.0f,0f,0f,97.43238f,-100.0f,-100.0f,0f,81.20905f,-99.405525f,-100.0f,0.71100384f,0.028091693f,0.120808266f,0,88.030785f,100.0f,-100.0f,100.0f,2.3135166f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.sphereShade(-9.232467f,-85.41228f,0f,4.09837f,0f,0f,0f,0.55875134f,0f,0f,-28.102524f,91.73248f,66.401474f,0f,-100.0f,100.0f,27.614346f,-0.100326635f,0.8728567f,0.00965682f,0,-100.0f,84.40066f,-76.81546f,2.760299f,85.92885f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.sphereShade(93.89946f,-100.0f,0f,-100.0f,0f,0f,0f,100.0f,0f,0f,100.0f,-56.784412f,17.699905f,0f,-100.0f,90.412506f,59.998703f,-0.6203544f,-0.2433326f,0.12527287f,0,100.0f,-81.239586f,-55.076683f,-100.0f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.sphereShade(-95.2817f,94.94582f,-0.21065308f,-0.071965426f,0f,0f,0f,76.27933f,0f,0f,97.1521f,-56.637146f,98.47204f,0f,100.0f,33.759148f,69.57741f,-0.3565942f,0.7518268f,-0.4203853f,0,-100.0f,100.0f,-68.393875f,100.0f,-27.923193f,65.9642f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.sphereShade(-95.76682f,-34.68036f,0f,11.520535f,0f,0f,0f,0.0f,0f,0f,41.275616f,-60.546356f,-30.278893f,0f,41.15876f,-60.23071f,-30.685368f,-0.08700126f,-0.02979083f,0.1800452f,0,-75.361496f,79.27532f,-36.218925f,-0.7904655f,8.891264f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.sphereShade(96.84493f,-86.06316f,11.528746f,0.001194229f,0f,0f,0f,-100.0f,0f,0f,58.478363f,32.691887f,-38.485813f,0f,16.100094f,-100.0f,70.94355f,0.83279854f,-0.21358687f,-0.11775528f,0,100.0f,-100.0f,64.58785f,11.694377f,-9.729602f,72.632385f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.sphereShade(-97.12443f,-5.022725E-4f,0f,-98.69001f,0f,0f,0f,1.110223E-16f,0f,0f,24.69303f,-26.011005f,-5.814769f,0f,24.603043f,-25.101286f,-4.801906f,-0.05470327f,-0.1228867f,0.30602205f,0,-100.0f,92.4747f,70.330246f,-99.18919f,16.776981f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.sphereShade(97.20013f,49.49226f,-3.721743f,0.0012005529f,0f,0f,0f,78.61113f,0f,0f,-22.656748f,-8.425731f,61.565945f,0f,37.853374f,73.57049f,-15.834918f,0.09824706f,-0.0032185977f,0.0097093405f,0,88.249855f,99.551735f,-36.05593f,-53.00566f,16.829895f,16.161175f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.sphereShade(-9.721144f,46.558464f,-36.69742f,0.0010286856f,0f,0f,0f,-62.7824f,0f,0f,-9.626952f,-40.38181f,100.0f,0f,-100.0f,-15.654797f,100.0f,0.12699576f,0.4312046f,0.15013066f,0,100.0f,-0.8765177f,100.0f,-100.0f,25.208336f,-26.489994f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.sphereShade(97.3163f,29.23739f,97.32852f,4.7028688E-4f,0f,0f,0f,-67.44315f,0f,0f,-80.21517f,69.40092f,52.83208f,0f,100.0f,-100.0f,100.0f,-0.14888057f,0.16030523f,0.36917788f,0,11.571858f,-55.42056f,49.584343f,21.850004f,-43.552658f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.sphereShade(-97.65459f,19.919416f,-147.22589f,-0.0013015943f,0f,0f,0f,98.554596f,0f,0f,-98.6523f,6.6898437f,-48.590565f,0f,150.79735f,3.4473548f,114.17049f,0.029241197f,-0.2050911f,0.66454875f,0,-99.880844f,-26.715986f,-118.90462f,-87.2619f,45.50599f,5.2408266f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.sphereShade(-98.186905f,63.40316f,-22.741018f,2.4781708E-4f,0f,0f,0f,0.0f,0f,0f,-21.183975f,-99.99998f,100.0f,0f,-21.183971f,-100.0f,100.0f,-0.61029315f,-0.2630759f,-0.39759892f,0,19.66743f,99.39155f,-15.158168f,-43.66255f,63.64167f,-99.98295f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.sphereShade(98.72779f,90.74497f,-100.0f,-4.224443E-4f,0f,0f,0f,-30.612633f,0f,0f,-72.17286f,-77.51545f,35.291786f,0f,-72.115616f,-78.09877f,35.47413f,-0.07084551f,-0.657694f,0.6409227f,0,99.11396f,-100.0f,35.424915f,-41.671047f,-25.138178f,23.671759f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.sphereShade(98.8279f,4.3502984f,0f,5.3379073f,0f,0f,0f,2.7755576E-17f,0f,0f,52.863228f,61.616104f,54.578747f,0f,-34.583855f,-100.0f,26.083511f,0.85309404f,-0.5420152f,0.5227706f,0,-0.30176187f,0.773122f,-0.26808476f,0.13907781f,0.043063562f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.sphereShade(99.047485f,0.0017146299f,0f,26.56075f,0f,0f,0f,-70.91908f,0f,0f,-72.47634f,100.0f,73.91677f,0f,-72.829895f,0.8677344f,95.77355f,0.07356558f,0.17904806f,0.3839999f,0,0.05971934f,0.4503056f,-0.65458286f,-76.021385f,21.957823f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.sphereShade(-99.09982f,-100.0f,3.5467317f,-6.0138593f,0f,0f,0f,-8.639278f,0f,0f,7.675044f,7.886889f,41.024773f,0f,7.211783f,8.332356f,41.205902f,-0.093174785f,0.08536151f,0.42034703f,0,70.66617f,79.64551f,-91.919044f,-99.98657f,-100.0f,-3.6253996f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.sphereShade(99.351265f,-61.49448f,-100.0f,-15.6911335f,0f,0f,0f,0.0f,0f,0f,-100.0f,85.78186f,-100.0f,0f,100.0f,-70.05904f,100.0f,0.30890507f,-0.2525067f,-0.6673728f,0,85.04446f,100.0f,-56.61387f,0.7166628f,-100.0f,-62.73494f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.sphereShade(-9.940053f,-23.642595f,-0.3554664f,0.059076484f,0f,0f,0f,-100.0f,0f,0f,33.427483f,-70.57139f,-64.53527f,0f,33.554157f,-70.29161f,-64.09589f,0.73821574f,0.38002393f,-3.1215302E-4f,0,-32.274704f,32.838436f,-76.97253f,-1.7029294f,99.89115f,-47.619717f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.sphereShade(99.57651f,99.997475f,-100.0f,3.686914E-4f,0f,0f,0f,-11.035797f,0f,0f,56.30404f,-66.00956f,-100.0f,0f,62.66683f,46.206882f,14.594656f,-0.4461399f,0.19052197f,-0.02227349f,0,0.34678584f,0.7288689f,-0.3210282f,8.632697f,-51.474224f,-27.122955f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.sphereShade(99.5897f,-83.73127f,-22.38312f,0.002126661f,0f,0f,0f,-56.66893f,0f,0f,12.504208f,-38.052425f,-49.47277f,0f,82.13177f,-11.58031f,42.816822f,0.35870832f,-0.33138233f,-0.665396f,0,0.23924005f,0.035725933f,-0.515854f,-61.683987f,-5.6158314f,-21.007828f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.sphereShade(-99.91575f,60.651283f,0f,23.37347f,0f,0f,0f,-1.8579555E-15f,0f,0f,32.235706f,-53.278564f,37.123207f,0f,31.985758f,-53.060028f,37.452625f,0.018031359f,1.0854224f,0.95497966f,0,-96.63227f,-29.68919f,-73.46482f,34.219902f,48.084023f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.sphereShade(99.936714f,5.623895f,-58.576828f,-0.058539484f,0f,0f,0f,-70.43604f,0f,0f,-81.01845f,100.0f,-100.0f,0f,100.0f,100.0f,-20.402517f,0.8947542f,0.026900802f,-0.004811583f,0,-0.65289265f,-0.6700782f,0.14844635f,-82.25292f,-3.0374832f,31.256165f,0f,0f,0f ) ;
  }
}
