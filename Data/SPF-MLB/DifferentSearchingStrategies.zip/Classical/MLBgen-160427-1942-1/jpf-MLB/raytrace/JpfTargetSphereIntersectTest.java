import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.06722405f,-0.013258073f,-0.34083688f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.4445046f,0.19639952f,-0.2707243f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.49115315f,-0.21253866f,-0.84474605f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.87284505f,0.42561367f,-0.2387353f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.1607485E-9f,-1.5598124E-9f,-5.042112E-10f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.4362278E-4f,-6.963645E-4f,-4.0404493E-4f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.421646f,-58.94726f,-75.09878f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-44.87486f,-38.297474f,-3.3125257f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,49.952713f,70.17621f,47.964252f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.02545E-5f,1.3313208E-5f,2.7705802E-4f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,96.813446f,-100.0f,-90.84843f,100.0f,-0.76225525f,0.29297736f,0.5557371f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,31.664272f,-98.516655f,5.1895723f,20.478971f,-100.0f,0.083915755f,-0.29554456f,-0.95163625f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-96.33116f,7.7481203f,31.18897f,-100.0f,-71.24031f,0.26173523f,-0.7608524f,0.3408114f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-29.413694f,-96.327774f,-100.0f,100.0f,8.93f,-100.0f,-0.41762334f,-0.8806936f,0.22353865f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,5.798498f,-0.051179007f,-13.553383f,3.3300133f,-78.5402f,-78.39113f,-0.26383236f,0.35070026f,-0.8985554f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,5.943872f,100.0f,97.9113f,74.39448f,-88.55691f,100.0f,-0.1709633f,0.9589851f,-0.22609532f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-96.461754f,100.0f,-86.60831f,-95.510506f,100.0f,-100.0f,0.84406054f,0.21598591f,0.19016375f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,18.754911f,-90.61855f,80.099205f,88.32125f,73.81088f,-24.726284f,59.418488f,0.037792683f,-0.08320651f,0.44654587f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.157682f,-11.309008f,-9.652498f,-80.24681f,48.352386f,-88.74208f,-39.270977f,2.389617f,-88.38145f,-71.52262f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,20.761053f,110.51005f,-89.76357f,118.8134f,-79.38648f,16.011421f,-78.864784f,-0.46334174f,-0.34943888f,-0.81437516f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,21.30162f,69.72058f,79.70802f,47.077667f,37.39814f,65.15469f,65.15752f,-12.561165f,36.107704f,8.669651f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.625744f,-8.096602f,49.266994f,91.61597f,-4.2525387f,-93.37259f,66.22387f,40.06252f,117.185165f,-23.416462f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.88067f,48.61502f,-59.25136f,26.62261f,-14.522829f,38.999752f,-37.72013f,-15.854652f,57.066776f,-22.126934f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-30.612864f,-3.1877956f,32.81136f,56.574837f,10.090805f,19.536472f,64.866486f,0.18358053f,-0.27565292f,-0.8503237f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,31.968456f,98.42643f,100.0f,86.73421f,36.910694f,71.2746f,75.288864f,-0.4530739f,0.48012614f,0.75113446f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-32.065384f,1.650355f,-53.65697f,93.41154f,100.0f,-30.537079f,71.58004f,5.831523f,2.3682327f,3.8653471f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.3705099f,-46.089867f,76.476685f,61.693535f,88.38958f,-45.850544f,9.858578f,-7.5374007f,-58.171986f,85.21022f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.708427f,-30.984566f,5.6833506f,-44.834427f,68.97189f,-45.859585f,30.847649f,90.44572f,-28.127466f,59.780052f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.76828f,90.379166f,-62.251083f,91.00578f,49.27349f,36.473312f,-100.0f,0.17070025f,0.6841395f,0.25479412f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.597583f,66.60252f,10.291191f,80.34603f,-41.488594f,19.0113f,62.77768f,39.71202f,47.018032f,-53.748245f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,37.682335f,-79.888275f,99.999916f,77.55062f,18.148218f,-82.47752f,-100.0f,0.8550426f,-0.17364529f,-0.48862004f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.7905f,-20.98613f,93.03109f,87.910835f,-47.077404f,-40.753014f,58.84627f,87.71021f,87.77702f,32.295166f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.410732f,-60.813015f,76.00852f,73.969475f,-13.119923f,-31.144129f,37.180874f,73.69018f,-81.751465f,92.03422f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.783752f,-25.57129f,-36.22295f,58.881115f,-85.50958f,-36.52363f,2.7642465f,0.73600817f,0.62146693f,-0.26845974f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-45.967205f,88.72067f,-28.346346f,-44.253807f,-22.664501f,55.271175f,8.007811f,83.27147f,-77.8738f,14.944111f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-48.61397f,13.009329f,-34.963066f,40.374653f,3.069701f,26.83107f,-31.670406f,-75.04876f,-89.326645f,40.129444f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,48.667854f,-62.51636f,-26.026964f,50.71083f,-1.4589403f,-65.31233f,-33.173687f,0.392859f,0.9613762f,-0.05398428f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-49.683903f,-53.523293f,-92.83259f,-66.93325f,-60.666866f,93.67845f,-87.36083f,-16.913536f,48.991436f,-19.479979f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-52.232834f,-65.890724f,-4.4276505f,-92.95651f,34.737732f,-27.782238f,100.0f,0.04922142f,0.14421605f,0.92050785f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,54.651394f,67.44614f,-90.26557f,69.42807f,64.23005f,-1.1230652f,-85.09149f,-0.17184556f,1.2313718f,0.10907705f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.682465f,-6.979094f,-88.1937f,100.0f,100.0f,-7.8870645f,12.297861f,-0.08475136f,0.59489876f,-0.79738915f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.5675864f,64.78275f,52.04408f,-72.07457f,31.584105f,-67.304214f,-11.909351f,96.16482f,67.3733f,-1.0783294f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-65.930984f,34.547646f,-78.09815f,-68.10283f,-100.0f,77.69306f,47.902733f,-0.8875263f,-0.063338645f,0.4563828f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.31458f,54.88284f,-78.006584f,35.47538f,100.0f,5.1360245f,100.0f,0.26746204f,-0.26162076f,0.45853278f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,66.41183f,-45.957676f,100.0f,107.87694f,35.783596f,-149.43066f,100.0f,0.9924035f,-0.01422511f,-0.11850643f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.26702f,16.01036f,-75.3515f,96.77177f,-12.683988f,-33.33299f,-94.766525f,76.61243f,-55.227184f,-125.13807f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-70.124916f,-46.513638f,-9.516071f,74.00823f,-6.21266f,-15.342967f,-30.03026f,-66.19796f,-32.674328f,20.870956f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.322014f,-39.672184f,0.20245153f,89.42515f,-48.577217f,-44.61714f,85.39118f,100.0f,-0.9086234f,-100.0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.56772f,-2.913989f,-51.487106f,95.11941f,-49.790936f,77.31518f,-91.46748f,18.504232f,65.2454f,76.31638f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,75.610176f,77.948044f,-4.953486f,76.91748f,53.78212f,0.9376327f,-30.141497f,-39.304676f,-39.84528f,31.787197f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.7680974f,45.749847f,-87.32804f,-85.00776f,-74.57019f,99.99503f,-42.321335f,-0.67064464f,0.7417786f,-6.8154227E-4f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-80.54612f,2.5269985f,81.2737f,78.93585f,94.25725f,-27.0394f,12.835963f,33.824055f,-0.4196399f,-8.33849f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-83.135605f,30.909378f,45.13807f,-61.970207f,-81.12909f,70.96624f,-3.911642f,31.266125f,80.76147f,-97.97776f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-8.9188175f,-61.528137f,-29.49451f,36.061382f,2.7654433f,-31.950575f,-46.49652f,-1.003614f,-0.124433614f,-0.21274051f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-92.38276f,39.060368f,84.75005f,-86.40011f,79.91092f,-79.570045f,74.20122f,73.31313f,-14.103158f,24.603472f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-92.78136f,-100.0f,30.741611f,69.11582f,-65.11887f,-79.987564f,-29.352371f,0.30099425f,-0.49908847f,0.92783874f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-94.50405f,-27.142641f,-18.87379f,72.99606f,-13.82054f,31.001806f,-86.552795f,-7.0538116f,-1.4814758f,-1.6957496f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,95.05685f,-11.463798f,-36.015816f,69.134964f,78.16614f,53.90392f,-50.895634f,36.715416f,-6.9235854f,83.470604f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-97.64698f,-46.076176f,73.42713f,90.38831f,-94.75375f,28.696526f,22.724878f,100.0f,10.081544f,63.787186f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-98.447464f,-46.012775f,66.72721f,98.73873f,-9.0570755f,14.0688505f,-22.144783f,-1.0585896f,-90.00869f,55.6803f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.90163f,94.347115f,-100.0f,-52.22832f,60.63211f,63.45799f,79.27871f,-0.019701347f,0.0048183245f,0.9997943f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.97504f,-64.77178f,67.999626f,100.0f,100.0f,-30.936455f,-50.98722f,0.5461926f,0.018508513f,0.8374551f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99952f,-100.0f,7.923902f,100.0f,-100.0f,-72.65684f,-100.0f,-0.33733335f,0.73564273f,-0.58739763f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99991f,-61.213604f,-35.06694f,-5.2218018f,-45.701843f,-80.57279f,-64.09153f,0.46123254f,-0.25170174f,0.8508295f ) ;
  }
}
