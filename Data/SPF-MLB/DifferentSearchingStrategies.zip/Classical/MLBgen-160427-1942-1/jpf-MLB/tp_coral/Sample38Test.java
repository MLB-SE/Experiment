import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(37.20998221777728,-93.59125118297501 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(58.694257415237196,37.68714928407264 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(79.03993105510935,73.3752440477428 ) ;
  }
}
