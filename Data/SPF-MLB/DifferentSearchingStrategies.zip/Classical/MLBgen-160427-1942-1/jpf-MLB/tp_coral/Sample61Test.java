import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.6820451221319672 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,8.081085536549935 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.5021607687523257,74.41905466803632,52.735800070255024,-66.66073079358546 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(1.297904602750009,-0.7104840864145778,31.632713156409267,53.850201477039036 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(2.306471465043586,-1.9467177638862437E-208,100.0,-72.049535328941 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(30.159281182370734,-32.890898062819886,69.68910860953139,-17.03134151313641 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(31.364931417960207,-1.5304030693764412,17.993537758825138,-80.89787066698257 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(44.93580168362911,27.60266737874113,-5.115991253567927,-29.365969512954464 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(-48.632704435425445,-83.94790528614936,-87.98889876402241,-47.7548524497061 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(49.1028082194897,-16.75741644282958,99.45189202018727,75.1211100714165 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(56.93624889938681,-46.05273771517211,98.53064255479694,-1.2363271267720772 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(59.092026178559166,-33.18412614490765,75.0935624421231,-55.24534008541251 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(60.92900427162223,-43.55335855587017,-51.23833231171806,68.61397802747013 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(67.15262236283837,-0.3449521196982488,92.08726822516613,-60.157576164482094 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(69.48887885388454,0.0,100.0,-32.33480199659212 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(71.17528521506298,-54.11731793223946,22.741283010924377,42.02340952069795 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(74.0554205915274,14.052792030739084,10.901626612599145,-56.45110500983659 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(85.83093205595421,90.75705231318932,16.42247595236232,-73.11073772502459 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(92.05849080266927,-26.164197525993544,-41.458984786315554,6.367056181978754 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(95.95114073861592,-7.7108155024237846,-93.01780169072704,64.230252651288 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(96.35221615771783,-73.76678934588321,32.72992791187065,-0.9700608765131875 ) ;
  }
}
