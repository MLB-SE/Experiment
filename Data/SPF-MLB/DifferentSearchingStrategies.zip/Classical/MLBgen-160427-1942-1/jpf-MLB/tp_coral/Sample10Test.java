import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-34.338816544711605,60.69238668042749,95.58996379251937 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-47.48415866868675,31.982808103380734,1.495277739968956 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-8.572103304763502,3.021570957843039,67.9815569154861 ) ;
  }
}
