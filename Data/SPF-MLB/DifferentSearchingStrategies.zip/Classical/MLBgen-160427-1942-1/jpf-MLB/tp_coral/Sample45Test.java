import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-21.585969307892594,-56.16629178216199 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,1.000000000000007,-99.69859919050836 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(11.20963193273981,-86.04475912094162,74.0985113660563 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(11.727379855094313,22.60302624828128,11.58324539994915 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(21.631826715816757,80.64147557361119,70.43929827663365 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(21.937011819097634,75.98659577725942,70.55893636092577 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(2.465190328815662E-32,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-36.85911402496676,3.222186731940994,73.98570989032956 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-395.1605683635852,-309.1224457499023,28.89756500755871 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(58.74141342708191,60.74141342708191,18.708266155014087 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(58.77536623257831,14.71755319806303,76.14067177572818 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(59.50076029835895,1.0,10.219395733976299 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(8.885588863599423,48.4232172438289,72.72639995820771 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-92.77833650366316,-17.622775681870877,0.7211139932241224 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(97.94941539278966,-76.30493689115795,46.28270513492117 ) ;
  }
}
