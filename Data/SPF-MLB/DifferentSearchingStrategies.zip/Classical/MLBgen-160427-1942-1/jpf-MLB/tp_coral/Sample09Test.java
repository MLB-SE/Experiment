import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(0.8538936804064292,55.10222886366739 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(19.928940978223153,-94.61859126303489 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(73.42316168914832,23.11467829048965 ) ;
  }
}
