import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-3.9129439403706243,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,59.99285432180764,-86.02412419977077,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(2.1684043449710089E-19,99.99653966140073,1.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(26.414802664663572,0.9998814303851903,25.57549801879593,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(30.672106751022454,21.966901768347526,5.076842647861966,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(42.44322879828165,1.0000000000000002,65.91796310847141,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(47.76206757700601,15.492174590552537,22.507174012963915,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(-49.170277804288574,0,1.5663064880828728,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(60.92610290738233,90.09588019035812,88.19584904599981,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(65.9211712690318,1.0,93.96456295554495,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(-661.108307698242,0,2.6044632894961666,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(68.73168857786888,0,34.23714402176242,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(-69.6321177353285,0,2.8006437151699686,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(79.03972002379388,-84.47190058211933,35.933453231401955,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(87.85095816116657,0,16.365814675911267,0 ) ;
  }
}
