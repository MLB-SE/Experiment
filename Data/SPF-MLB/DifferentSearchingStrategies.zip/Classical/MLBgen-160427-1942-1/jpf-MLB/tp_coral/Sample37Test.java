import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(19.722841592867454,-17.58610335944681,38.87864022509237 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(40.84068495671392,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(45.518490493648414,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-72.32550346801597,-0.5592509151490357,-52.35786994177809 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-91.19074575438924,-2.468654082606065,-86.84114452631748 ) ;
  }
}
