import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(2.5981273605424538E-6,-93.68534219597363,-100.0,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-6.354112719649346E-15,32.98479306349956,-90.67847770921668,-63.56330825546109,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-7.558048866038263,75.74331303465468,-11.052154295986739,-74.66833567008206,0 ) ;
  }
}
