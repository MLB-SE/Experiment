import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(-1.9352977763939236,-69.75929010648923 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(2.1726666621439916,23.96251472204721 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(33.82245364725023,99.20750571285646 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(3.980247333953372,15.842368839442925 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(57.34800797317385,86.65229901874551 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(68.31125375780977,78.65324543901232 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(-82.47356310346998,12.648527449379628 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(84.63738240945844,84.45746731436623 ) ;
  }
}
