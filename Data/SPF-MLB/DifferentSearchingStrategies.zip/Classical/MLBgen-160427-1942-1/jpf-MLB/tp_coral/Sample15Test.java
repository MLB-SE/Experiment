import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(41.94356108879822,53.79533595762251,95.77876824239726,84.22417190866648 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(83.41432455944911,-47.88132365206887,40.30969533969923,96.7787551733592 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-94.45701472053732,73.58723248490085,-48.172263321376164,80.007254549594 ) ;
  }
}
