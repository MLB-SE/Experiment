import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,58.15240432212014,-82.16115603227097,0,-94.31366008711085 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-22.882310870285565,1.3735375967457166,-33.6589836109883,135.40059236335293,19.796179377806304 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-41.568378901618864,37.658939958732276,97.48842436262092,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-43.74516573356673,40.956665064846106,-63.44030292313543,-6.275066493232757,-62.48227167335833 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-45.578423954429105,-50.128315035436884,-58.01834592382169,-5.86716693614602,68.38705404401267 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-46.57882674500762,67.26613692001706,-59.076333197289266,0,-31.772958871102674 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(51.31214904080007,-93.31577161223369,-48.74946577817387,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-59.72402269894528,36.79279748877081,71.72108383108241,79.24697790993018,-10.615279189145623 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(63.60440657655647,-52.35333447388105,-76.04437334165655,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(64.40930848079486,-1.5447503272537375,12.922677860899341,36.13016459319368,-68.96385548008814 ) ;
  }
}
