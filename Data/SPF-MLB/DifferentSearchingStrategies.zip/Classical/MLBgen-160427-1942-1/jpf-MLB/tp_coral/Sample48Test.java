import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-42.86269875721507,59.177222529591745,16.314523772376674 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(78.27252532962677,83.04418367395306,37.64340430967539 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-92.49797447907766,-14.154970438925261,29.62633391546032 ) ;
  }
}
