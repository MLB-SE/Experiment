import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-13.462995144991368,-38.014231382887445,-28.17643328688348 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(52.811165677668185,-95.86241977213766,79.27767609093175 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(72.61914968950131,-86.39166947977644,-63.72900729053315 ) ;
  }
}
