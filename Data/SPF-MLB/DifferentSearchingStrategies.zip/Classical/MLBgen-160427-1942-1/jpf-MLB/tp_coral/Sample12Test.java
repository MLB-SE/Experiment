import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-49.38404633409898,-64.32820004733207,-79.07903744162766,79.73061795586696 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-56.12927931569889,-98.7804949383416,-72.17652067059319,-1.5365920424177375 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(72.51905471027445,-5.105323873202266,-58.64334559772839,-85.47334912754737 ) ;
  }
}
