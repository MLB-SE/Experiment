import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-88.69619195007175 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(27.214461217212687,0.8337282304170657 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(3.3130867611296573,10.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(46.38265456355873,71.03665315635084 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(47.52921165472691,84.82842757322072 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(-54.475895065822975,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(57.74416540769653,85.30862257819268 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(73.40055569467694,39.27311977780198 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(-97.8147258137625,-93.75978619122805 ) ;
  }
}
