import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(100.0,-71.7144850462958,3.5707322339830108 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(-11.746052647807687,0,0 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(31.80702619317252,-24.45918634035248,4.464853188189923 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(3.1871983894874205,4.665806603091596,-92.14971380690741 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(45.379276413199136,-100.0,-0.8491150129033941 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(-49.240823660198444,23.239251333426065,1.8553040967652379 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(-50.07455702826049,53.537354021531854,-14.5815464151015 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(-52.29698396818587,49.62738355467165,19.21522925622392 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(6.391239125788445,0,0 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(-71.88934423618116,77.02095860373981,-13.814238397244662 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-74.93660188468031,85.181206799862,-7.217125745387429 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-76.70181036333538,-66.70769240256622,-61.61345384525849 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-79.04966096004966,-43.14036803127963,66.99569041356145 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(-93.95242247324592,50.75875607122455,2.1519919519704387 ) ;
  }
}
