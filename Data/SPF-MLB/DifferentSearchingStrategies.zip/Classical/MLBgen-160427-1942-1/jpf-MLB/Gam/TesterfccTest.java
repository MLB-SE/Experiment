import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(12.217377792906277 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(-29.309200425079823 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(-30.19381330434487 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-34.1479083570964 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(-4.0E-323 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(4.9E-324 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(52.942046263545365 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(59.15962766479109 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(77.9738760032844 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(9.860761315262648E-32 ) ;
  }
}
