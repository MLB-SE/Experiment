import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(0.5647998310036542 ) ;
  }

  @Test
  public void test1() {
    gam.erff(-0.647357310865563 ) ;
  }

  @Test
  public void test2() {
    gam.erff(1.0223786153216565 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-1.224744871391589 ) ;
  }

  @Test
  public void test4() {
    gam.erff(1.224744871391589 ) ;
  }

  @Test
  public void test5() {
    gam.erff(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test6() {
    gam.erff(13.138481522258942 ) ;
  }

  @Test
  public void test7() {
    gam.erff(16.862582876366858 ) ;
  }

  @Test
  public void test8() {
    gam.erff(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test9() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-1.9259299443872359E-34 ) ;
  }

  @Test
  public void test11() {
    gam.erff(-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test13() {
    gam.erff(3.469446951953614E-18 ) ;
  }

  @Test
  public void test14() {
    gam.erff(-37.47967126921499 ) ;
  }

  @Test
  public void test15() {
    gam.erff(3.944304526105059E-31 ) ;
  }

  @Test
  public void test16() {
    gam.erff(-42.44984212764036 ) ;
  }

  @Test
  public void test17() {
    gam.erff(70.60761687469991 ) ;
  }

  @Test
  public void test18() {
    gam.erff(-73.04409765031849 ) ;
  }

  @Test
  public void test19() {
    gam.erff(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    gam.erff(97.97124590700236 ) ;
  }
}
