import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(0.8685662849663487 ) ;
  }

  @Test
  public void test1() {
    expint.ei(1.5E-323 ) ;
  }

  @Test
  public void test2() {
    expint.ei(23.056496064258283 ) ;
  }

  @Test
  public void test3() {
    expint.ei(27.707537379460035 ) ;
  }

  @Test
  public void test4() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test5() {
    expint.ei(-36.28984819990626 ) ;
  }

  @Test
  public void test6() {
    expint.ei(-3.8694759736820856 ) ;
  }

  @Test
  public void test7() {
    expint.ei(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test8() {
    expint.ei(46.665845547825796 ) ;
  }

  @Test
  public void test9() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test10() {
    expint.ei(4.930380657631324E-32 ) ;
  }

  @Test
  public void test11() {
    expint.ei(7.709245819195473 ) ;
  }

  @Test
  public void test12() {
    expint.ei(-81.55333084473332 ) ;
  }

  @Test
  public void test13() {
    expint.ei(8.673617379884035E-19 ) ;
  }

  @Test
  public void test14() {
    expint.ei(8.881784197001252E-16 ) ;
  }

  @Test
  public void test15() {
    expint.ei(9.415035732366334 ) ;
  }

  @Test
  public void test16() {
    expint.ei(98.47380381350965 ) ;
  }
}
