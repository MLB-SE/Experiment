import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(0.33583043138303026 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(0.7137929755912609 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.232595164407831E-32 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(1.7290327071306454E-223 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(3.1936305492679935 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(4.440892098500626E-16 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(-5.403227209783267E-225 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(-55.63807249802619 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-68.62475587666903 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-77.66413204030948 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-77.77630542631707 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(82.85268610160722 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(91.09954673816472 ) ;
  }
}
