import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-19.464565929053194 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,1.69759663277E-313 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-43.58534849694283 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-54.57867256114662 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-89.220070750522 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,-100.0,1.0308053002506684E-16,0,0,0,90.0 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,17.817261460941346,44.2148432139236,0.3155325879031402,-1.9749529579134657,58.08868522918418,-48.0944565692041 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-21.994019360263152,-49.62595980879642,0,0,0,22.897328907668026 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,59.6574823877976,65.10696835155201,17.015012044586467,-28.72006229302212,-84.72040530664957,-69.18154410813858 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,75.37528478774192,-44.52668067940439,-51.566339956804576,-56.61092729217722,7.604360338254963,-25.585679407499114 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,9.097360870926735,0,0,0,0,-8.80352084509775 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(-0.12212857134038191,122.0282453433079,-11.85808238004141,994.4783463616327,-181.7097847170122,24.114186834081266,83.42460374218973 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.1688844029897482,-98.04327711383853,1.8348764564455257E-13,0,0,0,-90.0 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.17630465933863437,243.33579163249013,159.51365962987376,988.3579115878074,-145.44126678590453,99.1191571865854,-142.27912923768892 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(-1.1102230246251565E-16,0,0,0,0,0,40.67186055269593 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(-12.239272381561108,0,0,0,0,0,89.62173546820193 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(-1.295163E-318,0,0,0,0,0,-57.55071270361545 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(1.3322676295501878E-15,0,0,0,0,0,14.649791493773165 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(133.99256238589402,-7.838178285235784,-68.6613708732757,-0.08005487712583204,-0.9670723264085694,81.38562336331017,-1.5699024685195866 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(-15.480322432777198,86.5459604939723,-50.5441375860651,-0.2084979961795858,-1.9840929026993652,-43.86466335711713,-96.26997845474426 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(15.489705792356078,0,0,0,0,0,-2.53E-321 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(-15.603962778290594,98.83598358363798,44.813303492942026,0,0,0,27.600708232565793 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-1.58E-322,0,0,0,0,0,-54.59610095970399 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(188.0514660613768,116.38703085481671,46.6840755067566,1022.5057937055699,-99.43459090394799,-14.307947077216596,37.99788716737643 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(-21.220735791069927,-46.389614390948644,0,0,0,0,-84.99992850417206 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(2.590327E-318,0,0,0,0,0,27.6457080386254 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(27.32277084317039,0,0,0,0,0,-80.46986410124369 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(-29.71192070298821,0.0,0,0,0,0,6.4234811089381765 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(-4.208412977973257,-59.97038372324767,-100.0,-49.2259777271479,7.0271656564196325,-32.22477426291604,0.005419114543350359 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(5.087327796396195,-50.1579033937638,-35.75006177700119,53.63447645200509,-88.31803863047436,-90.82502865836022,-88.58639732670107 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(-55.30515651888295,-69.87347799537568,14.767640803145472,0.72182807167599,-1.8205762812784916,83.68941501202251,59.81427509467675 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(5.604231865642646,31.59631331532202,-61.224617315307086,84.93030154389362,-3.6732214745508287,-5.701003399878218,-28.83158263715005 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(-63.30890423045532,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(63.98219955761047,0,0,0,0,0,-70.56484437926215 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(6.47582E-319,0,0,0,0,0,-90.96965917480605 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(67.7666436864873,93.08818101286883,-64.61042837589663,0,0,0,-84.93421408824291 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(69.2913129858907,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(74.16875122588515,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(-82.47191174837087,0,0,0,0,0,95.25375332816682 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(-85.4535318830175,99.32562071742697,262.1439339888101,-991.8696810791164,121.02997213394357,-1.931733348730293,-60.44579233026422 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(-88.81009465245462,22.19727039147601,44.50135553041926,-44.39149645137341,49.988251341090006,-43.98681686747574,-53.09606508494609 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(-89.54161574838034,0,0,0,0,0,27.262912102085934 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(-91.1042006271667,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(91.67900893339241,0.0,0,0,0,0,1.383667598921303 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(-95.6492262598171,0,0,0,0,0,2.0E-322 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(-97.02624596019855,-16.27031212748564,-91.38016212731206,-37.19932379895392,77.7366931286152,74.09994734291797,-74.79462800393736 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(-97.45211712278602,39.13421919142482,192.7510937813658,106.12971374158633,-1000.9732141633501,97.7275195066228,-9.917056752132908 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(98.2867548066381,0,0,0,0,0,-30.368917103615175 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(9.918601696691429,68.87364682771424,7.630716890962034,994.7068678193019,92.52736054787668,-4.900472671193171,49.473735357950545 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(99.40084662849688,-52.92073187248274,0,0,0,0,-53.66541058813987 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(-99.85639976968268,-100.0,3.674762453653642E-13,0,0,0,-90.0 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(99.99999999999994,-89.54053487919407,53.87774720656553,-1.7217855791501484,1.0627584802996293,34.40192560133691,-79.35002979234247 ) ;
  }
}
