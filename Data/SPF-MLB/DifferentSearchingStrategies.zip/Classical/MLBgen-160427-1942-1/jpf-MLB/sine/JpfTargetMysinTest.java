import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.4438360232251597 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.5838402656627187 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(-0.7191361815227566 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(0.8574431570681709 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-1.2419998929487714E-29 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(1.3061966854313738 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-1.4984807168487804E-4 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(-17.28311005697188 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(2.176896048554042 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(22.892419742478026 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-2.441406250000197E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(2.441406250000696E-4 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(-2.4487771560625747E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(2.4940808056416955E-4 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(-257.0261232533573 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(263.58030277190215 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(26.978067440993 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(-3.662680324373126E-17 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(46.33849164044945 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-49.056769704809476 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(56.661868495632405 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(58.099345758982736 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(-63.61725123519331 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(-65.50652219832494 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-66.7588438887831 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(68.12023921281559 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(69.04163013922218 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(7.0685834705770345 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(-79.03542192086002 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(-92.00532436974203 ) ;
  }
}
