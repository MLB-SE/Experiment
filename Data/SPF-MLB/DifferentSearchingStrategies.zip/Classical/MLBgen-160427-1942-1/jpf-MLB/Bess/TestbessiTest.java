import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(123,-18.932624669916848 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(139,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-202,61.517720989009604 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(-216,2.9725869537717676E-9 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(222,0.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(-305,-3.165589828326687E-34 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(354,55.61581683361564 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(445,-1.8775197278147465E-32 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(647,78.30585138663929 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-671,-98.43866321933095 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(-700,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(-877,-96.23116017348381 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(883,-2.7663971747204744E-9 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-912,0 ) ;
  }
}
