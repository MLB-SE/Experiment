import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,6.4E-323 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(1,-0.5343244417505417 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1234,6.480399681378562E-162 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(135,-47.34857963969017 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(142,2.0E-323 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(-1437,2.2227587494850775E-162 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(1,4.440892098500626E-16 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-153,0.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-158,0 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-160,-1.3892242184281734E-163 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-162,25.276542814884877 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(165,55.5062402080529 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(-187,53.14228665788826 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(279,0.0 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(29,-4.445517498970155E-162 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(-30,-15.070041550884312 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(3,3.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(35,46.54240408737712 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(-383,0.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(391,0.0 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-395,0.0 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(478,0 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(481,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(54,-76.21017140099758 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(-560,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(568,51.442290547256505 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(-633,3.469446951953614E-18 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(71,0.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(717,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(72,-72.0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(7,-60.05724134736179 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(-762,-48.05268979027477 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(-769,2.8451311993407858E-160 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(-860,-10.880835823793305 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(86,46.031416262849575 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(-981,81.23667985231754 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(985,-54.98108697235698 ) ;
  }
}
