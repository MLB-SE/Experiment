import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(1082,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(-112,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(112,0 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(-1172,-2.2784756311113742E-305 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(142,-70.03478027222462 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(-163,62.167430193940476 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(166,19.34293426364171 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(-193,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(-207,80.32119256745588 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(279,0.4744708918270817 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(347,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-381,0.136930885966148 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(437,2.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(452,-99.65837591345634 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-51,0.0 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-522,2.0 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(-604,-50.309197146239384 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(-622,2.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(640,2.5555162101637936E-15 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(77,2.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(780,54.86179739039429 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(-816,2.220446049250313E-16 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(-819,-12.145831320653585 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(887,-1.4E-322 ) ;
  }
}
