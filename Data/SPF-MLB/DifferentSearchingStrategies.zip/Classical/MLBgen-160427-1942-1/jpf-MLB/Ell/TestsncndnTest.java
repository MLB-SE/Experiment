import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.18556317789700616 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.5158579125375464 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.7530064898056992 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.999999992725943 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000016018669 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,-15.565901531230026 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,16.56585352261868 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,1.9259299443872359E-34 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,-6.503796632824276 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,84.00622192199688 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,8.671592659888617 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,-8.676300048233983 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,91.99277462408935 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,9.860761315262648E-32 ) ;
  }
}
