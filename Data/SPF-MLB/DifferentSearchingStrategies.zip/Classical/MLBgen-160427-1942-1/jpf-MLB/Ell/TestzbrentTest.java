import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-100.0,18.84955592153876,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-100.0,-28.27433388230814,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-100.0,84.82300164692442,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(13.266710686914106,-72.25663103256524,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(-15.7035460199386,-62.83185307179587,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(-15.707963267948967,100.0,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-15.91118662149566,87.96459430051422,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-17.23916254385071,-85.9478586092039,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-26.436376162841086,40.840704496667314,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(28.27433388230814,-75.95090498004303,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(31.41592653589793,0,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(-32.628604151746515,-11.498407706128447,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(-32.99701575724778,-21.07438408719706,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(-35.497379802907076,-29.769079868612238,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(37.23756190620995,0,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(-4.595449296900036,-21.991148575128555,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(50.11782931129818,0,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-5.621513952164165,-7.077363927662233,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(5.623093155667874,91.106186954104,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(69.23781332397039,-62.926733781299646,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(72.04101450277739,0,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(7.509284064773453,-34.21318412452085,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(75.39822368615505,0,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(-75.9294809438505,-78.53981633974482,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-76.12423266504965,-1.1689288902146444,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(80.04464298090956,59.690260418206066,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(81.68140899333463,0,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(89.81387488445296,-4.301155247036576,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(-98.33336901405364,65.97344572538566,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(9.942086335270389,19.41213592588595,0 ) ;
  }
}
