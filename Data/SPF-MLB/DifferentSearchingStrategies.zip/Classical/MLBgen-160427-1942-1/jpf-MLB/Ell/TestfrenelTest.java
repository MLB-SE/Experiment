import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.362594313811897 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-0.5753762793852402 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(-0.6389757245620018 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(0.9538490487476281 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(-12.153896909150347 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(1.426927078602942 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(1.8036331520596747 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(-20.023387061825247 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(2.220446049250313E-16 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(2.465190328815662E-32 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(3.469446951953614E-18 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(40.633875525592146 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(4.633836378419744 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(4.770991460629361 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(-65.82178763881325 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(81.82490985459495 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(83.10741046196117 ) ;
  }

  @Test
  public void test20() {
    frenel.frenel(-9.860761315262648E-32 ) ;
  }
}
