import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(-2.1422821614436316E-6,-46.67919184493066 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(-21.98515739694915,20.254519795192678 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(38.951830737745865,27.834142785197002 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-4.403629121702622,-2.2708542712456206E-5 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-4.6373492405253245,-2.156404333883464E-5 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(5.567180631160795E-6,17.96241340549953 ) ;
  }
}
