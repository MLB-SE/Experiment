import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.35721698f,-259.57425f,0f,-14.2640915f,-40.542797f,-53.75865f,-16.272507f,-50.891487f,-145.51971f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.6263517f,-92.65491f,0f,18.993412f,79.43841f,0f,-17.23039f,-87.91498f,-39.870945f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(0.6516946f,87.0442f,11.949515f,23.348755f,14.390806f,-44.800034f,78.352516f,-8.029695f,35.972023f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.7842849f,-90.72497f,0f,-19.67799f,14.650743f,0f,8.974575f,55.57629f,-70.273636f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(0.7999373f,-100.0f,0f,-10.891989f,-34.391785f,40.55402f,-9.976108f,-29.012442f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(100.0f,-18.33331f,0f,53.912277f,92.39842f,-63.379196f,23.250689f,39.09048f,41.00171f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,71.70573f,0f,-59.016586f,2.2856264f,8.15412f,-15.370175f,-2.4641144f,3.228091f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(105.00376f,56.301144f,-56.05241f,33.52422f,16.9169f,-36.538155f,12.110525f,14.438808f,28.72781f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(10.516657f,-10.830711f,-1.0100563f,-2.7873704f,-14.996461f,-22.476429f,-6.669676f,-23.891333f,-73.89919f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(11.672547f,29.4697f,6.023073f,-82.77951f,0.1831815f,-173.88342f,-12.59612f,32.39503f,-56.82961f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.693362f,-1.5944506f,-53.659203f,-51.632103f,-64.411964f,-40.056446f,7.2378435f,80.58347f,-0.20384744f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(-12.032294f,100.0f,0f,14.062151f,54.847713f,-70.77166f,13.433185f,39.67059f,90.40146f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-12.1369915f,-133.74904f,32.932133f,-14.900673f,-39.542854f,22.670687f,-7.062099f,-12.30699f,-3.0257828f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(122.878426f,-2.919231f,0f,12.003261f,-171.54942f,-81.47375f,-7.6468353f,-42.590603f,8.851004f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-12.52611f,40.896694f,0f,-26.15257f,-5.261371f,0f,-2.8533435f,14.739198f,-67.630516f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(12.910427f,64.59628f,0f,-60.20433f,-66.688f,0f,-25.655338f,-42.417023f,-77.324745f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(12.964859f,-89.43058f,68.32456f,41.290016f,23.461342f,0f,-72.889694f,0f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-13.098665f,-73.68203f,54.731785f,-78.71263f,49.956936f,0f,-68.99667f,100.0f,0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(1.3274715f,-95.412025f,34.385067f,0.72190815f,-27.716318f,-11.283214f,29.27648f,-4.891946f,-51.8016f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(13.673113f,-64.72451f,98.90868f,19.416964f,-27.302275f,36.098454f,91.29701f,-100.0f,72.52835f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(136.97491f,40.179672f,215.66954f,47.14695f,32.88197f,26.284977f,18.714062f,17.92383f,10.581223f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(13.73969f,-100.0f,-48.972397f,54.95876f,19.048248f,0f,3.5360062f,45.229786f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(13.861111f,42.59549f,0f,-24.16355f,-67.65601f,88.59188f,-42.859295f,-38.890415f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(13.926738f,66.63552f,11.193039f,14.259075f,27.118975f,1.0310718f,15.990588f,26.550228f,-34.187725f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(14.233789f,-2.612493f,-58.609222f,-40.45235f,-66.07454f,-29.115664f,-46.946655f,36.454544f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(14.345624f,26.124321f,82.13509f,-68.74182f,-91.98344f,-45.555687f,-39.27509f,-29.708704f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(14.346368f,-18.104057f,-97.764626f,-24.510464f,-100.0f,73.931206f,-12.387982f,-25.041464f,12.222435f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(14.353694f,-42.494057f,0f,-2.233685f,-35.127346f,-100.0f,11.838912f,49.589333f,-13.158942f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(14.674594f,-34.808167f,0f,-3.6756618f,-27.811735f,64.03453f,-1.5655061f,-2.5863628f,19.03179f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(14.729831f,-46.1001f,-58.081482f,5.0194254f,-12.273131f,-75.737144f,17.621002f,65.464584f,100.0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(-14.907401f,-2.889915f,0f,-23.59196f,4.866769f,-29.309128f,-84.32722f,-20.098782f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(15.242704f,-16.670624f,14.56978f,3.3629365f,-1.3431395f,11.136241f,-0.44781914f,-3.201112f,31.318323f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(15.59311f,-53.13601f,-100.0f,15.508452f,45.502968f,37.95146f,0.9377292f,-11.757535f,0f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(156.56223f,-203.27425f,-213.0977f,32.618423f,-33.646843f,35.01763f,8.691406f,1.2111651f,31.944487f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(15.814399f,19.70344f,-41.47878f,-56.445847f,4.4781427f,98.01612f,-9.529068f,18.329573f,78.36922f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(-16.254187f,-71.34924f,-98.89856f,-93.6675f,-14.697514f,28.526356f,-25.627241f,-8.841458f,4.958919f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(16.531445f,-91.60652f,0f,-8.998505f,-30.111183f,0f,-8.080332f,-23.32282f,-51.906845f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(16.546824f,33.33832f,16.789265f,-67.151024f,0.017190328f,-32.887436f,-24.047167f,-29.037642f,-92.12059f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(17.232536f,13.899698f,-90.47416f,-44.969555f,-98.78425f,0f,29.047369f,-53.23452f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(17.600815f,55.898243f,16.839361f,-85.49498f,89.152794f,-88.5408f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(17.716064f,-37.887257f,39.971546f,8.751512f,-11.093811f,29.771902f,28.383793f,-45.011402f,90.20988f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(17.748789f,-0.7623487f,-21.190767f,-27.03541f,-99.91699f,-212.25218f,-19.547213f,-48.73125f,-32.561966f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(17.849892f,-98.72698f,0f,30.820127f,89.17984f,91.02202f,16.250772f,34.182964f,31.301245f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(17.914991f,-16.6814f,-9.960537f,-11.65863f,-37.04915f,-35.737263f,-27.500364f,-84.1193f,-95.93936f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(18.003918f,-23.91557f,51.01199f,-4.0687637f,-11.695977f,0.96342313f,-22.582994f,-19.762999f,-34.41672f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(18.232153f,-56.356113f,21.937674f,29.284725f,47.408127f,-66.695625f,51.49862f,-56.538235f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(18.676384f,-61.797565f,14.744133f,36.503105f,29.380257f,0f,-4.555634f,-54.72564f,-27.076237f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(18.68191f,-41.85492f,-10.746378f,16.58256f,47.429146f,11.287315f,0.2191787f,81.33177f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(18.787127f,8.579782f,-42.59307f,-33.431274f,-41.87493f,8.004345f,-45.597f,0f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(19.077267f,9.288469f,18.076609f,-32.979404f,-100.0f,-36.982033f,0.37801164f,34.49145f,0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(-19.356987f,-140.50684f,-88.88231f,-36.921f,-31.914442f,138.51663f,-96.440445f,-81.28362f,0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(19.484196f,-56.36359f,0f,28.80628f,80.02936f,78.95212f,15.711565f,34.039978f,40.41899f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(19.523458f,100.0f,0f,-2.1693103f,-20.994286f,54.14766f,-7.206414f,-26.656345f,-28.439209f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(19.597736f,20.47779f,0f,-92.65027f,-70.723885f,-4.851891f,-29.955383f,-27.171263f,-8.005789f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(19.701942f,-45.958652f,-88.444084f,24.766424f,48.56789f,0f,6.766739f,2.3005326f,-46.1325f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(20.001081f,13.096701f,55.2846f,-33.092377f,10.692566f,0f,11.368151f,78.56498f,15.658877f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(20.034283f,-6.0488067f,16.075552f,-13.814063f,6.7054195f,0f,-15.542673f,-48.35663f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(20.208815f,-6.9844875f,-100.0f,-12.180255f,-54.30306f,-10.860552f,-14.626774f,-46.32684f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(20.68193f,-15.927449f,-85.08887f,-1.4974314f,-3.169564f,-5.129451f,-23.502092f,9.876076f,-32.917236f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(20.879948f,-26.470617f,-100.0f,9.990407f,-10.185921f,33.239857f,29.267603f,-57.50333f,-100.0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(21.10026f,-31.708258f,0f,14.6706915f,21.322437f,-20.99327f,16.260067f,50.369576f,100.0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(2.1588025f,-72.30838f,-35.79851f,-19.056683f,-67.28688f,-66.527596f,-11.098656f,-25.338213f,-22.966454f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(21.69697f,-18.64167f,-57.869507f,5.42955f,28.447823f,-1.7708958f,3.4547079f,8.389281f,1.6545964f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(22.200756f,24.084826f,-8.294342f,-38.568436f,-17.576271f,23.036886f,-158.80107f,-78.81145f,0f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(22.540337f,-36.628124f,-43.319344f,26.789474f,21.101416f,-4.6531f,14.96648f,33.076447f,96.23789f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(22.945213f,-7.0647063f,100.0f,-1.1544418f,-7.06786f,60.539112f,-20.495121f,-80.5914f,-100.0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(22.96292f,-1.4806706f,-72.08351f,-6.143247f,-56.81478f,-300.52533f,9.266539f,-27.313477f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(23.061869f,50.03473f,0f,24.536047f,-42.07169f,-76.403f,9.132795f,11.995135f,80.91943f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(23.066011f,94.00168f,0f,16.963406f,37.080357f,47.234592f,7.707259f,13.86563f,10.674908f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(23.081116f,11.266277f,99.98475f,-18.94181f,-99.98187f,100.0f,1.1335127f,23.475863f,77.26195f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(23.10702f,-13.402145f,-25.363033f,5.830227f,-1.9997464f,-3.4513714f,2.2136328f,3.0243046f,33.377712f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(23.161404f,13.201536f,29.644894f,-20.555922f,-100.0f,5.378264f,-5.385084f,-0.9844807f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(23.353664f,-9.432601f,0f,-5.765507f,-46.57448f,0f,0.15878442f,6.400645f,72.01827f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(23.401148f,15.291486f,34.075916f,-21.686893f,-96.31113f,-44.550365f,-13.837599f,-33.6635f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(23.602499f,-15.828806f,3.9439576f,1.8947675f,-13.30079f,-24.543291f,-2.7226386f,-14.725831f,-88.81633f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(23.728138f,24.163393f,49.516533f,-29.254635f,-78.050285f,169.41154f,-10.357661f,-11.866718f,38.83477f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(2.3852177f,-72.305885f,95.03123f,-18.153242f,-95.45988f,60.686512f,20.461689f,100.0f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(24.035227f,-100.0f,0f,5.9135084f,100.0f,-72.6619f,1.5769356f,0.3942339f,-100.0f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(-24.288393f,29.103643f,0f,-32.465702f,-31.968843f,0f,5.676099f,55.1701f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(24.31875f,-1.912857f,-98.67998f,-0.8121392f,-33.290203f,-47.68079f,5.7228966f,0f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(-2.435916f,-84.13124f,-34.362034f,-25.612427f,-81.41977f,-89.83043f,-18.594023f,-64.570404f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(-24.380548f,-84.14411f,0f,37.075912f,37.73203f,0f,54.56706f,21.31722f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(24.658575f,-9.641566f,-61.04002f,-1.3355156f,-24.693628f,-48.275425f,-5.3070097f,-39.522003f,-82.95258f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(24.953402f,23.80135f,-8.619236f,-23.987743f,-57.84624f,-2.0237825f,-63.058132f,-12.882982f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(25.098555f,-34.57186f,-162.41025f,34.96608f,108.11548f,91.61704f,6.6286597f,-8.451442f,-24.82125f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(25.27679f,50.466778f,53.005856f,-49.35961f,23.584457f,-98.67169f,20.251398f,29.789787f,0f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(25.715935f,13.809114f,29.151987f,-10.945373f,-99.63147f,-0.14646801f,-3.922371f,-54.93237f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(25.838753f,5.3173223f,-78.986046f,-1.9623119f,-25.583422f,-82.349144f,-8.104579f,-30.456003f,0f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(25.861963f,-100.0f,0f,-17.835142f,-87.81462f,93.06254f,-9.387912f,-19.716507f,18.336508f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(2.589198f,-53.30938f,0f,-42.737366f,57.28585f,0f,-5.1832514f,22.004358f,35.914833f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(26.3153f,15.358102f,30.836975f,-10.096904f,-63.04217f,-77.95916f,-3.6607428f,-4.546067f,48.518646f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(26.564077f,67.07863f,58.035133f,-60.822315f,83.715294f,-78.33037f,-6.0802636f,36.50126f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(26.740522f,8.903362f,-100.0f,-1.9412763f,-22.703703f,-52.510456f,-11.801929f,-45.26644f,-88.22771f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(26.927122f,30.000528f,-34.62145f,-22.292044f,27.696442f,17.724874f,-2.5430741f,12.119747f,24.767561f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(27.199018f,-41.134f,-0.357467f,49.930073f,-8.343016f,0f,35.779404f,93.18754f,45.80589f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(27.254108f,59.0657f,101.59177f,-50.06769f,-71.920944f,0f,43.636333f,224.49527f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(27.972437f,30.632837f,18.43443f,-18.74309f,-23.875519f,-56.89512f,-45.32714f,-75.49675f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(-28.114304f,73.69182f,0f,-6.566774f,83.75144f,0f,-81.904236f,0f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(-28.323301f,10.458694f,0f,-55.92613f,43.58423f,38.44533f,-13.031424f,3.8004332f,-15.351072f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(-28.626398f,60.149372f,0f,-75.98676f,-37.414036f,0f,-52.23966f,0f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(28.680471f,-50.96886f,-75.08035f,-5.5206833f,-29.9035f,14.793684f,-20.859705f,-77.91814f,44.64559f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(29.047232f,21.12361f,24.845137f,-4.934684f,-69.39793f,-21.743067f,20.61196f,-58.616276f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(29.09829f,17.386023f,-23.1676f,-0.99286425f,-36.386597f,-42.702374f,3.3164704f,14.258746f,-99.3776f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(29.134531f,-9.349403f,-100.0f,25.88753f,100.0f,0f,19.326483f,51.418404f,86.34712f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(29.170847f,18.183735f,-95.32327f,-1.5003462f,-27.184422f,-25.421143f,-7.98781f,-99.99993f,20.823128f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(-29.46336f,40.812435f,0f,0.38122696f,29.060698f,68.13743f,1.9275703f,7.3290544f,-1.6720508f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(29.700628f,33.698795f,84.62469f,-15.97888f,-79.735756f,-64.6989f,-19.753424f,-63.3055f,-153.82236f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(29.82089f,27.32543f,10.872691f,-8.041309f,-31.39095f,-83.83466f,-30.595177f,-61.012775f,0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(29.934525f,26.415625f,-47.66627f,-6.67753f,-63.088696f,27.913532f,6.444053f,32.453743f,-66.96894f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(30.018843f,16.304964f,-76.02956f,3.7704058f,11.230567f,30.532503f,-26.167786f,-6.62924f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(30.050615f,34.42613f,99.9712f,-14.223827f,-92.3173f,-14.2307f,-10.658173f,-28.408863f,-10.659891f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(30.080803f,16.101482f,-67.498566f,4.2217293f,1.823695f,-88.39757f,-15.017582f,-64.29205f,19.706728f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(-30.474329f,-99.99975f,-32.261345f,-18.57527f,-39.03814f,-36.998367f,-4.7886095f,-0.5791695f,41.51007f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(30.487852f,8.3043f,0f,13.648256f,20.265305f,-70.75247f,3.8398676f,1.7112141f,-17.260315f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(30.549423f,35.88516f,27.571753f,-13.687462f,-14.580545f,-25.59815f,-63.993755f,0f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(30.889786f,27.686989f,26.529184f,-4.1278443f,-46.671013f,-21.570255f,27.290312f,14.555848f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(31.002142f,71.22965f,0f,-21.113932f,-16.50911f,0f,-23.2301f,69.56581f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(31.16897f,26.10586f,7.214247f,-1.4299793f,-24.47134f,-50.4582f,-12.417547f,-72.10304f,-29.847643f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(31.669788f,20.26646f,85.79645f,6.41269f,2.3222933f,22.387938f,-8.341307f,-39.777916f,1.4330019f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(31.739782f,15.492753f,-76.35837f,11.46748f,6.590006f,39.009274f,7.541223f,18.697412f,60.659103f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(31.863358f,38.898697f,35.444977f,-11.445267f,-11.713552f,2.8812118f,-100.0f,-3.1455762f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(31.916975f,36.803013f,-92.37745f,-9.135112f,19.062601f,65.51601f,-87.52003f,-16.9335f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(32.10154f,84.72792f,86.35471f,-56.32177f,-100.0f,0f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(32.497166f,30.648018f,-28.049345f,-0.65935177f,-19.250147f,-44.11091f,-15.884424f,-62.878345f,-99.99776f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(32.61415f,17.414156f,-87.42742f,13.04245f,24.469894f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(32.72793f,38.58204f,90.99934f,-7.670324f,-69.39911f,-97.630875f,6.598856f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(32.744804f,5.425714f,68.04303f,25.553497f,-22.068062f,0f,91.537254f,0f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(32.877804f,31.467466f,-24.369137f,0.04374101f,17.361204f,81.16407f,4.0771866f,16.265005f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(33.011627f,45.905445f,31.44691f,-13.858928f,-1.1874701f,59.59395f,-87.25987f,-96.39034f,4.5231633f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(33.09372f,9.823921f,4.1525183f,22.550959f,-75.639626f,0f,27.318592f,86.72341f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(33.507183f,20.686169f,-81.40472f,13.342569f,19.655443f,-44.69991f,0.20765007f,-12.511969f,-66.520226f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(33.58345f,22.165546f,49.729004f,12.168247f,-94.65026f,36.903152f,-2.0048697f,-20.187725f,15.904231f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(33.71023f,36.982822f,87.58562f,-2.1418865f,-73.36457f,64.007484f,31.086788f,0f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(33.757374f,34.91898f,-15.258081f,0.11051121f,21.17662f,5.6817274f,-54.491947f,15.00258f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(33.8779f,34.602604f,7.8836904f,0.90899533f,-3.6877356f,8.106165f,-26.554182f,-58.368706f,28.228704f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(-34.190434f,-49.20627f,0f,73.72322f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(34.401524f,24.871756f,-73.6863f,12.734344f,2.5499544f,-72.9211f,13.985897f,43.209244f,18.511171f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(34.541504f,20.827291f,-99.58808f,17.338724f,36.494255f,-96.02706f,-1.6808627f,-24.062174f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(34.77978f,38.524944f,-42.228554f,0.5954248f,-24.082888f,-180.32219f,-8.315194f,-33.27472f,-100.0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(34.970833f,8.65894f,-46.07123f,31.2244f,-54.26384f,-10.374661f,4.302428f,-14.014688f,-6.0973372f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(35.211773f,37.36497f,43.594475f,3.482109f,-29.346363f,37.012917f,3.6049988f,10.937884f,69.4929f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(35.262234f,-0.9126411f,-100.0f,41.961582f,-48.181385f,-27.415401f,7.3313446f,-12.636204f,-9.694777f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(35.266037f,21.259203f,-38.897274f,19.80494f,-11.331952f,-22.351831f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.3637f,38.52348f,28.992392f,2.931324f,-10.262169f,-54.296238f,-63.889885f,0f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(35.39047f,35.559963f,-49.347622f,6.001917f,-28.946014f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.823284f,20.876865f,-99.80499f,22.41627f,38.622612f,76.29799f,15.219179f,38.46045f,100.0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(-36.3465f,-215.61644f,-116.19687f,-22.211271f,-44.58029f,64.7893f,-7.467576f,-4.943404f,4.715723f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(36.604687f,27.740503f,-56.90004f,18.678242f,31.257366f,99.99999f,6.8509154f,8.72542f,28.742138f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(36.66553f,39.880363f,32.572033f,6.7817607f,-9.71611f,98.10546f,0.17762205f,-2.995082f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(36.724014f,48.853718f,53.874435f,-1.9576637f,-24.377449f,14.137493f,-20.17722f,-78.75121f,71.49732f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(36.81246f,49.25727f,44.98971f,-2.0074148f,15.226901f,-79.12621f,-60.069023f,-78.40423f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(36.88735f,37.64915f,37.2476f,9.900238f,-23.53834f,11.341251f,26.251944f,99.758934f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(37.181145f,22.794065f,65.985756f,25.930511f,5.80738f,42.437096f,60.73352f,-11.847078f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(37.319286f,39.819416f,99.91916f,9.45773f,-1.8039062f,-34.105946f,2.3155422f,-0.1955617f,-1.2938828f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(37.652916f,34.05527f,-20.85832f,16.556393f,19.426483f,-4.5907106f,9.146168f,20.02828f,-86.06267f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(-3.773755f,-100.0f,100.0f,-15.09502f,-42.708965f,100.0f,-13.897363f,-40.49443f,100.0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(37.829308f,-25.129128f,0f,60.102608f,22.41413f,0f,73.36641f,-46.0713f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(37.837727f,34.60188f,-31.321976f,16.749035f,21.636835f,77.47953f,7.4154f,12.912564f,22.598024f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(38.184246f,45.641502f,43.807037f,7.09549f,0.5747177f,-43.318382f,-10.377005f,22.936806f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(38.311245f,18.46425f,35.545753f,34.78073f,-100.0f,23.265057f,18.934381f,40.95679f,-14.558956f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(38.36865f,15.557464f,-93.62929f,37.917137f,17.490494f,58.710323f,95.8094f,100.0f,0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(38.483093f,36.790108f,36.24391f,17.142262f,-27.566568f,8.185532f,13.24515f,35.838337f,-93.41803f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(38.576397f,42.36942f,-45.450443f,11.936167f,55.02172f,24.423616f,-45.85345f,83.303444f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(3.8584707f,1.3609171f,0f,-6.564823f,8.322989f,19.861101f,-38.44075f,18.63476f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(-38.73141f,16.10178f,0f,57.005367f,-95.30807f,0f,5.453352f,-35.19196f,-50.913116f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(38.79985f,46.40168f,148.74689f,8.864415f,-101.91413f,-137.4212f,98.7403f,-166.94598f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(38.983562f,54.28662f,11.371596f,1.647633f,-37.47223f,0f,5.0791993f,0f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(39.434376f,66.09117f,0f,-8.517175f,-60.52984f,-100.0f,-12.973236f,-43.375767f,-100.0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(39.474735f,49.000553f,33.29607f,8.898386f,23.231401f,-17.497032f,-27.11259f,52.5237f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(39.47539f,39.24258f,11.999145f,18.658981f,5.495789f,-15.037212f,29.664745f,100.0f,-88.18779f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(39.626995f,7.169618f,0f,26.743473f,-63.511856f,0f,11.404683f,18.87526f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(39.6528f,46.491848f,12.84546f,12.119361f,33.469135f,68.38251f,-24.644493f,57.636093f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(39.790607f,48.096313f,22.553793f,11.066113f,0.4861787f,-87.194824f,3.9876685f,29.977108f,-35.927135f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(39.94741f,44.79742f,58.571396f,14.992221f,-10.33282f,-18.395342f,30.354294f,-82.72558f,-22.835127f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(40.075512f,44.6572f,0f,12.7326355f,33.578743f,43.08072f,-22.723713f,33.84441f,0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(40.38859f,74.068436f,71.306725f,-12.514064f,-78.43297f,21.121391f,-12.011882f,-35.533466f,-51.68901f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(40.46527f,20.285625f,3.4627714f,41.57545f,-62.785538f,-99.99993f,8.920655f,-5.8928328f,30.293549f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.466026f,57.80135f,25.233114f,4.062755f,65.506256f,-59.351845f,6.9907227f,23.900137f,23.103569f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(40.49285f,49.57621f,50.824783f,12.39519f,6.9872046f,64.29629f,2.1007056f,-3.9923673f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(40.625652f,14.978976f,-76.855156f,47.52363f,74.92399f,0f,81.00096f,-94.14326f,0f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(40.69164f,55.110374f,1.3496343f,7.656179f,29.695759f,89.833984f,-39.76268f,-33.8175f,-22.18757f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(40.872936f,52.90618f,59.864574f,10.5855665f,10.887215f,42.098175f,-9.417884f,-48.257103f,-0.9696013f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(-40.87561f,-38.790154f,-16.370092f,-21.007414f,-30.443485f,-32.141556f,-12.710558f,-29.834818f,-81.75264f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(-41.162994f,-9.650849f,34.015564f,-11.6621275f,-3.2958872f,5.225822f,-2.1896303f,2.9036064f,16.541739f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(41.257984f,65.396515f,40.45652f,0.92826176f,80.21823f,-15.832891f,-117.68763f,-3.339556f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(41.343933f,44.404568f,-44.2614f,20.97116f,23.785488f,-24.283379f,18.755169f,54.049606f,-76.65769f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(41.370975f,42.728928f,-8.983368f,22.754969f,46.283302f,78.28369f,5.100115f,-2.3545103f,-60.80146f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(41.38405f,47.510143f,11.406242f,18.026052f,3.4315634f,-29.5317f,27.288597f,-22.27824f,-37.45826f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(41.4558f,36.795536f,14.21046f,29.027666f,-8.484114f,-79.9537f,83.13898f,-100.0f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(41.625908f,49.86582f,42.518715f,16.637814f,15.318677f,-25.99051f,9.606685f,21.788929f,48.97168f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(42.038284f,15.034637f,-15.506772f,53.1185f,-66.39296f,-52.56978f,1.1407267f,-48.55559f,-42.864105f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(-4.247737f,-99.999405f,0f,-18.078352f,-60.41385f,-91.821686f,-7.651819f,-12.528926f,17.949966f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(42.900566f,58.1971f,73.45758f,13.405162f,16.430262f,-24.975973f,-5.710181f,-36.245888f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(-42.973103f,79.56657f,-40.31014f,-26.59687f,17.556913f,-75.92039f,-80.97129f,93.178345f,58.466118f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(42.99861f,50.124386f,-12.85126f,21.870064f,70.35019f,-29.814457f,16.990042f,46.0901f,97.02017f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(43.2411f,63.993866f,81.936424f,15.213764f,20.531599f,29.8031f,-2.9176428f,-26.884336f,16.744379f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(-4.334543f,-99.87668f,-71.530235f,-17.461496f,33.93131f,-85.90811f,-99.44275f,-100.0f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.492157f,70.834465f,-27.406464f,3.134164f,-29.72095f,-64.33471f,-1.2345518f,-8.0723715f,-1.333985f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(43.75563f,12.360242f,-91.946686f,62.662277f,-2.3679752f,-100.0f,-3.466915f,0f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(43.75929f,56.542202f,60.69662f,18.494959f,76.59764f,0f,4.912918f,1.1567146f,59.09821f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(43.809666f,16.937708f,-46.116344f,58.300957f,-29.942492f,-100.0f,14.644388f,0.276595f,16.404484f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(43.81656f,71.952415f,13.000044f,3.3138137f,-52.564693f,93.66529f,22.003393f,33.798386f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(44.25312f,98.555435f,0f,33.782898f,100.0f,100.0f,-9.121526f,-70.269005f,-100.0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(45.326553f,23.712734f,30.115288f,57.593475f,-80.590904f,-3.2515821f,15.403552f,0f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(45.34835f,47.1785f,17.503498f,34.21491f,25.862154f,-4.219388f,8.724161f,0.6817348f,-31.859377f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(45.385067f,56.968864f,86.45077f,24.571405f,-3.96037f,37.7503f,56.86092f,57.661224f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(45.696117f,67.54981f,-51.999664f,15.234664f,94.01686f,0f,-98.50751f,91.14912f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(45.72686f,-13.417376f,8.650034f,96.324814f,-56.2034f,-82.23124f,20.318346f,-15.05143f,-24.320667f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(-4.584118f,-98.633514f,85.87817f,-19.702955f,-72.55297f,0f,-18.718987f,-55.17299f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(45.877125f,-84.39238f,0f,-5.629931f,-63.721992f,33.181896f,-4.0031652f,-10.38273f,26.194242f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(-46.011368f,120.72881f,-61.00099f,-13.728372f,-0.6823132f,-90.58496f,-8.219805f,-19.150848f,9.411236f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(46.122612f,65.374954f,0f,24.389303f,30.293f,46.81579f,21.141598f,60.17709f,-96.51718f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(46.129276f,48.43252f,12.196888f,36.084576f,35.403923f,-99.644966f,62.80511f,0f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(46.130726f,53.87028f,38.546185f,30.652626f,30.804207f,24.885496f,22.971188f,61.232124f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(46.319843f,44.088013f,11.586633f,41.191357f,18.445581f,-99.9333f,100.0f,-51.18555f,0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(-46.861774f,-33.266052f,0f,2.2336562f,-91.78803f,0f,17.194439f,0f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(47.725796f,21.014578f,-100.0f,69.8886f,-71.0596f,0f,12.845837f,-18.50525f,-72.54713f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(48.02478f,63.00873f,57.695457f,29.090387f,46.31469f,73.92011f,82.09901f,25.6034f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(48.26393f,27.310778f,12.378159f,65.74494f,92.63632f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(48.273914f,68.694664f,0f,37.94821f,93.62512f,39.89038f,9.893808f,1.6270243f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(48.749203f,59.16013f,86.859695f,35.836685f,29.141342f,-56.824642f,9.381744f,1.6902944f,-31.76191f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(4.885736f,-69.0119f,-59.780045f,-13.914285f,-50.21892f,-90.56797f,-10.323954f,-27.381529f,100.0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(49.19215f,76.537964f,52.775745f,20.230639f,9.788565f,-59.493412f,21.94184f,-59.653545f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(49.23194f,93.83663f,-9.308762f,3.0911322f,21.704626f,43.54142f,-58.572037f,25.092348f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(49.43526f,-98.041115f,0f,22.414711f,-116.95581f,29.456928f,-1.8242521f,-29.71172f,-0.06369795f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(-4.959888f,-5.8010306f,68.253105f,-5.482714f,-19.408476f,8.652602f,2.4375076f,-75.00276f,-43.500248f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(50.00673f,64.98605f,29.144918f,35.04088f,80.792564f,87.83407f,9.364223f,2.4160118f,-80.49274f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(50.311497f,35.70136f,13.088979f,65.544624f,-20.595036f,-100.0f,1.318099f,-60.272232f,26.77748f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(50.45447f,60.462757f,28.330477f,41.35512f,29.473202f,52.52003f,85.49281f,-36.445103f,-69.6082f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(50.501f,60.13118f,31.83928f,41.87282f,58.184437f,-32.774063f,58.80585f,99.96105f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(50.51816f,5.1071997f,-72.502594f,96.96545f,-57.586765f,69.85195f,46.933453f,-53.500626f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(50.883854f,74.34689f,-17.095997f,12.883918f,10.347946f,-8.115704f,-9.696129f,-37.72332f,-76.3019f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(51.184437f,80.30228f,0f,19.414528f,-9.622205f,-89.728775f,36.095882f,-42.079994f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(51.311974f,-38.122158f,-52.1012f,29.85925f,36.501663f,57.635387f,31.623358f,96.63418f,62.330982f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(-51.512493f,-57.82952f,0f,-47.12309f,17.452208f,-83.11387f,-12.859846f,-4.3162947f,-21.857542f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(51.558804f,58.590973f,82.102585f,47.64424f,0.7025004f,14.180621f,18.928106f,40.420223f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(51.910248f,45.622047f,39.592052f,62.018944f,-9.014104f,47.993492f,-22.410093f,33.051857f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(51.962334f,-19.145168f,-11.508425f,17.841583f,6.3784585f,-7.443152f,13.025538f,34.26057f,66.14225f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(-52.41909f,-56.482784f,99.958694f,-7.9070506f,-19.672228f,10.164674f,40.463116f,-24.463749f,-39.627777f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(52.42246f,42.89539f,12.530915f,66.79445f,6.6281834f,-92.91482f,21.372446f,18.69534f,46.780727f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(53.69398f,57.572514f,34.845917f,57.203407f,41.750153f,-18.188848f,18.940367f,18.55806f,99.29413f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(54.29631f,84.18829f,18.644316f,30.238182f,45.846355f,15.956856f,20.810066f,53.002083f,-0.66324544f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-54.661613f,41.516895f,22.159327f,-4.303516f,21.972586f,-15.5264f,15.474962f,66.20337f,-48.28077f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(-54.96101f,-100.0f,0f,9.417178f,84.22585f,9.022095f,8.403868f,24.198294f,4.163449f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(55.362938f,-23.328054f,-52.25896f,15.194923f,0.3222745f,4.239225f,5.094482f,5.183004f,68.893585f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(-55.8315f,-51.908733f,36.10184f,-10.915948f,7.379742f,-2.8371897f,4.7879634f,95.18084f,24.974634f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-56.36086f,5.7958355f,0f,63.794754f,-17.305637f,0f,33.501003f,70.20925f,-55.63153f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(56.40349f,65.70481f,-71.175545f,59.90914f,64.79597f,0f,73.86186f,0f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(-5.6651807f,5.039738f,0f,97.070114f,74.41289f,0f,-27.453587f,-32.374958f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-56.679703f,-27.367834f,0f,-96.66407f,80.75472f,0f,62.285713f,-69.7834f,0f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(56.690617f,99.82953f,-71.23406f,26.932938f,35.515793f,-15.1051655f,15.525341f,30.40588f,69.93898f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(56.817154f,60.390312f,-80.75334f,66.87831f,-4.777372f,-73.37819f,14.750479f,-7.8763947f,-41.478687f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(56.921444f,26.431252f,0f,100.0f,76.76729f,0f,10.578492f,-57.68603f,37.531643f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(56.944115f,151.29535f,96.11419f,27.323988f,41.09724f,-27.91436f,9.620844f,12.406826f,-3.6556585f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(57.07142f,97.59f,100.0f,30.695683f,27.805931f,0f,19.18803f,46.05644f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(57.2192f,-72.34158f,0f,41.350853f,43.35834f,13.696531f,11.860154f,6.089764f,-30.859438f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(57.37451f,54.0947f,-83.43929f,75.40335f,-75.292984f,0f,33.463688f,37.22026f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(57.655804f,30.663057f,49.221146f,99.96016f,-84.224724f,66.22152f,22.985607f,-8.017734f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(57.78693f,-16.188955f,0f,16.115145f,-3.5733907f,78.53315f,10.247037f,24.873005f,100.0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(58.064648f,44.967873f,31.564482f,87.29072f,-9.757634f,-18.70995f,42.359962f,-9.820394f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(58.30377f,36.820473f,41.91348f,96.3946f,-52.935352f,-72.741974f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(58.62652f,66.23681f,0f,-66.799164f,81.67423f,0f,-69.152855f,-21.21154f,0f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(58.80553f,35.222122f,41.245716f,100.0f,-59.16276f,4.8873234f,7.57875f,-69.685f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(59.01035f,132.39409f,21.897625f,3.6287746f,34.3489f,-1.6958224f,-78.844154f,-7.3662114f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(59.791874f,70.358f,63.79316f,68.8095f,11.604548f,0f,4.3251143f,-51.50904f,100.0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(59.909935f,-34.76289f,0f,23.854696f,-90.166466f,0f,-48.49621f,-14.891131f,0f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(60.368355f,89.557274f,-3.6371033f,51.916153f,47.29733f,13.117493f,99.99892f,34.598404f,8.809743f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(60.56615f,73.61293f,96.49015f,68.651665f,37.395428f,4.480918f,16.667297f,-1.9824806f,-61.99265f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(61.4794f,75.64856f,43.00866f,70.26905f,21.010065f,0f,19.193232f,6.503872f,-14.187808f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(61.672356f,100.0f,57.926468f,24.487446f,13.78316f,30.645197f,22.494267f,-100.0f,-63.58768f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-62.611088f,83.863335f,0f,-22.23897f,-17.364136f,-99.875496f,-8.980653f,-13.683643f,-28.389784f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-62.679672f,-62.088535f,0f,-1.517372f,-24.323837f,-34.495384f,80.93402f,0.73395926f,0f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(-6.277711f,-174.5387f,0f,-4.9085665f,-11.028839f,-139.55188f,-0.9838192f,-0.10386935f,11.570201f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-63.351704f,-49.508522f,0f,-19.426819f,-10.736053f,-45.388958f,-3.6195223f,4.94873f,34.051796f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(-63.68257f,-47.537838f,-38.130775f,-15.957729f,6.148924f,89.42603f,-6.2972713f,-1.3347702f,-30.655499f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-64.293915f,-9.7249775f,-79.977325f,-19.303009f,-33.944836f,-13.492899f,21.026714f,-93.25845f,57.827946f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-64.60566f,-3.2456932f,0f,-13.647605f,-20.194176f,28.474022f,30.209415f,-64.87551f,0f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-66.08678f,-61.664005f,0f,-2.8037016f,-65.46726f,0f,9.260621f,39.846188f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(66.70408f,-2.9694374f,0f,12.35846f,82.72976f,-95.02154f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(67.350746f,-63.64224f,0f,32.09964f,72.72345f,-11.246491f,-11.67563f,-78.802155f,0f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(68.36636f,-22.562609f,0f,17.783014f,-8.100093f,7.685297f,10.865787f,25.680132f,99.954834f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-69.59329f,17.964697f,69.482124f,0.26121598f,45.572853f,64.065506f,25.065304f,100.0f,-42.805027f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(7.1982822f,-89.8078f,7.6904616f,18.60093f,-10.1334505f,19.974857f,77.33888f,10.698212f,0f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(72.0269f,-49.858486f,0f,-52.5178f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(-7.3661585f,-66.99895f,0f,-56.818104f,-26.669336f,0f,-17.912996f,-14.8338785f,19.170477f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(73.71416f,95.38725f,43.444202f,44.219837f,72.38964f,71.06912f,30.775549f,78.88236f,14.261461f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-74.67503f,-20.198744f,0f,11.041191f,92.551476f,62.60871f,26.288324f,-4.234886f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(75.39345f,-73.8706f,0f,41.45267f,18.174726f,-25.067429f,72.242516f,-19.052267f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(-75.91541f,99.26586f,0f,74.98008f,94.36481f,-33.416607f,26.227568f,29.930193f,-0.87160295f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(7.6188188f,72.69233f,-29.855837f,6.878649f,15.162678f,-30.974016f,4.7330995f,12.053748f,28.319218f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(76.22678f,111.279205f,105.64085f,43.67752f,76.26988f,31.708078f,22.21342f,118.441605f,76.34643f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(76.471405f,71.686005f,-5.722874f,9.153383f,-12.157687f,-29.47014f,-27.700182f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(76.60274f,-39.514854f,0f,38.782658f,36.639214f,0f,41.888676f,0f,0f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(78.50384f,-81.42296f,0f,40.597054f,5.235362f,78.459404f,78.64902f,-94.772995f,0f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(79.099144f,-8.596765f,-65.30102f,28.893768f,16.558033f,-21.025978f,19.917896f,66.961105f,-35.360928f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(79.15781f,-27.512627f,0f,36.376316f,74.5929f,0f,68.42994f,90.99535f,0f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(-79.78523f,39.258392f,0f,-35.240658f,-49.354534f,-20.725204f,-11.8228655f,-12.050803f,0f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(79.84445f,66.123474f,0f,-61.013386f,-51.049923f,0f,48.61728f,0f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(79.874306f,-55.03154f,0f,10.738548f,-58.00758f,-11.92519f,21.087465f,78.67805f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(8.069535f,30.024576f,-11.941757f,-97.74644f,23.970528f,0f,-37.86987f,49.09805f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-83.582886f,-54.866352f,0f,-26.235205f,-14.368057f,-7.3261995f,-6.989875f,-1.724294f,14.460755f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(-83.90178f,28.96926f,0f,59.750168f,-37.98609f,-4.7208023f,7.1352816f,-31.20904f,-93.98535f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(85.11091f,42.159214f,-26.885311f,28.62789f,19.910574f,-0.47723782f,9.49008f,9.332429f,7.9290605f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(8.535878f,-13.563759f,82.10542f,-52.29273f,91.54741f,0f,54.295475f,0f,0f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(86.712364f,-10.350747f,-35.24951f,33.850555f,22.016441f,-8.27715f,26.673416f,72.84311f,-19.875532f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(-88.67382f,-100.0f,-57.332302f,-29.402987f,-28.120022f,-9.207689f,-0.8181004f,26.130585f,48.621567f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(-8.940747f,-100.0f,99.95424f,-35.76299f,-82.95927f,-99.68042f,-51.151947f,-96.39365f,89.73512f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(90.245964f,24.481384f,0f,57.820076f,27.631094f,0f,37.29169f,91.346695f,62.041355f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(9.139677f,-23.54095f,0f,-39.900345f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(94.02937f,-69.58559f,0f,-31.143517f,50.972065f,0f,-14.010285f,-24.897625f,0f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(-94.68132f,95.56478f,0f,-8.720299f,-22.812248f,60.288254f,82.61237f,-10.581587f,0f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(95.33446f,1.2232462f,0f,54.38178f,28.749321f,0f,-21.87862f,0f,0f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(95.68483f,-20.850985f,0f,6.9015803f,-71.507515f,45.863598f,3.4290009f,-78.38796f,0f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(9.568748f,-48.66439f,63.541943f,-13.060616f,-48.45887f,-98.79434f,-13.352339f,-40.34874f,-99.58374f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(95.749535f,-41.4186f,61.28401f,20.69061f,-12.54793f,-7.016469f,-0.43916318f,-22.447264f,-76.801956f ) ;
  }

  @Test
  public void test315() {
    color.laplace.solve(9.658855f,-64.82978f,-19.737852f,-7.0542593f,-32.814255f,-46.18921f,-5.0587764f,-13.180845f,-14.843284f ) ;
  }

  @Test
  public void test316() {
    color.laplace.solve(99.0047f,-56.330715f,-55.778923f,14.300363f,-38.904438f,-87.69178f,-2.8988128f,-25.895615f,-100.0f ) ;
  }

  @Test
  public void test317() {
    color.laplace.solve(-99.9998f,-23.09582f,99.05583f,-39.431805f,-42.51645f,-86.12613f,-15.210963f,-21.412046f,-27.920774f ) ;
  }
}
