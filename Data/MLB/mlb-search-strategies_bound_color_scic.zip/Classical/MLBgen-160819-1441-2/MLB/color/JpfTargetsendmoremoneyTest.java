import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(2,0,5,-425,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(252,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(-313,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(3,1,3,7,-578,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(3,2,0,2,2,-964,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(4,127,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(4,3,1,83,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(4,3,9,8,204,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(4,7,2,3,8,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(504,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(5,5,9,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(6,2,3,6,413,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(6,9,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(7,1,8,13,9,233,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(7,5,3,617,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,5,-72,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,8,7,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(8,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,-234,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(8,258,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(8,7,584,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,9,418,0,0,0,0,0 ) ;
  }
}
