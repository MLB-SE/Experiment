import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(1,-930 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(257,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(2,716 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(3,5 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(4,0 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(4,840 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(-541,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(824,0 ) ;
  }
}
