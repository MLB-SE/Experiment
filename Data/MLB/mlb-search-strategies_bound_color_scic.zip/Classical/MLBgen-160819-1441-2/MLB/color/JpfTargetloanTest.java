import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-27.632355f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(69.26249f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(85.572975f ) ;
  }
}
