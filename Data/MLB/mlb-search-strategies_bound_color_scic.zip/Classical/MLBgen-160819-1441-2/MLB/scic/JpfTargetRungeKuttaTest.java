import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2724.628638785543 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2735.0615690137242 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2736.2827909208163 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(-55.7785878217333 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(56.74438105479808 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(-66.98446371302991 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(-71.32618226912955 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-74.4718096168499 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(76.22837546126661 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(7.916152319594389 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(84.37465883190862 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(84.79639063322472 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(84.88581893182331 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(87.98600923168149 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(91.39065131471565 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.7779350335635 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(93.31171636389342 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(99.52303308702801 ) ;
  }
}
