import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-15.249999981041706,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-19.146707898313807,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-27.3115228883634,0.06084085906451975 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-41.25000000000001,70.84765595784565 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(42.45401713657421,49.15765741275936 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(60.62375516491221,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-62.84580189766056,79.50304769350146 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-70.25,-90.45931882591024 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-73.66528679335292,75.47282312099745 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-86.03542210873725,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-86.19059994766278,0.06646297031922188 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-93.75,0.0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-94.4431140234643,-98.9434088995216 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(99.47488038589184,0 ) ;
  }
}
