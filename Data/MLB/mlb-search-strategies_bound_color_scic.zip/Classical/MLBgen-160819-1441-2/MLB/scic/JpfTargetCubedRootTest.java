import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.998540136119132 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(53.20858409815588 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(6.85703276230187 ) ;
  }
}
