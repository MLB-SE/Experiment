import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-1.9946221946070222 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-4.397408352788901 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(6.63830497288987 ) ;
  }
}
