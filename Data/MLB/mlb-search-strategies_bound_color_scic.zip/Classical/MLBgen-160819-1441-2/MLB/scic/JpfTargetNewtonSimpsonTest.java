import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.7709538162153251,-85.10484871996383 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.8160314467606327,-97.60569269047699 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.220539650584925,-60.20884756710336 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448549811217827,-1.5661772980735122E-6 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(19.523604717671688,55.493192331172594 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.9525707972649116,-43.889029850448225 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(34.729496726702365,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-3.9348186334441095,93.1770243262718 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-6.383846875471065,-87.23851296509957 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-7.67209562141322,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-8.855257861600151,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-9.354685386834618,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(93.89378202079129,0 ) ;
  }
}
