import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(10.03779550961184,20.276594655450168 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-26.26549486628302,3.7057904837600546 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-31.44148774366328,67.2924344709329 ) ;
  }
}
