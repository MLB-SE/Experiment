import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(106,238,358,9 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(144,555,384,699 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(150,346,7,208 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(2,16,924,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(234,500,569,-972 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(305,501,61,217 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(400,1115,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(403,597,18,967 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(411,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(47,141,632,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(517,0,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(558,301,332,207 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(581,-105,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(642,499,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(643,40,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(660,148,-387,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(67,296,249,99 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(681,541,230,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(68,255,319,69 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(-686,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(798,0,0,0 ) ;
  }
}
