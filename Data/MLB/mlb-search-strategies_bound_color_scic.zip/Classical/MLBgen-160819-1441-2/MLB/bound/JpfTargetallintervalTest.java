import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,1,152,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,1,2,721 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,1,4,4 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,2,4,-788 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,3,2,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(1,3,2,4 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(1,-881,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,1,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(3,1,1,779 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(3,1,-205,0 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,1,2,2 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(3,2,460,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(3,751,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,44,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(586,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(803,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(-890,0,0,0 ) ;
  }
}
