import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(102,-923 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-327,640 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-908,563 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-946,-4 ) ;
  }
}
