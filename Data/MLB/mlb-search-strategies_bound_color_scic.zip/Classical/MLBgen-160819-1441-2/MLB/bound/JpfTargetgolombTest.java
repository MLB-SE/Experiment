import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,6 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,1,223 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,1,-25 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,1,6 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,219,0 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,4,0 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,5,6 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(0,6,2 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,0,352 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,1,6 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,2,5 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,3,4 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(1,3,6 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(2,3,3 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(3,1,2 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(3,313,0 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(-360,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(3,6,6 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(4,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(4,1,1 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(4,-383,0 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(5,2,3 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(745,0,0 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(961,0,0 ) ;
  }
}
