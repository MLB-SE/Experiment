import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-485,-859,170,-35,-961,-626 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(815,284,690,803,703,-767 ) ;
  }
}
