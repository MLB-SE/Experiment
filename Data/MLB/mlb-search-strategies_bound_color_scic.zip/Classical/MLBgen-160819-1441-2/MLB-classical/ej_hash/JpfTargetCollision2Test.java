import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-503,755,-449,1468 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-863,-326,74,749 ) ;
  }
}
