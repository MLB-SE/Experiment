import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(151,493 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision5(6,-25663 ) ;
  }
}
