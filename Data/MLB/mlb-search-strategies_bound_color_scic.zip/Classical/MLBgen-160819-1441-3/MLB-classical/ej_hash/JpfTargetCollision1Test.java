import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(262,-193,-82,230,-1178,135 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(356,-544,203,592,-245,43 ) ;
  }
}
