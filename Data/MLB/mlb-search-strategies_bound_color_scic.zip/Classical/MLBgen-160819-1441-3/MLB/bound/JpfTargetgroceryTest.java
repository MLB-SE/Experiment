import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(105,607,865,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(123,-261,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(133,271,292,15 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(134,241,613,980 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(175,377,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(200,285,-887,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(225,674,615,803 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(384,986,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(387,187,84,53 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(-457,0,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(480,125,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(494,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(5,193,91,422 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(558,446,465,-934 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(571,472,198,335 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(599,395,137,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(667,113,287,621 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(804,0,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(864,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(92,545,882,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(95,164,219,233 ) ;
  }
}
