import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,186,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,2,4,0 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,4,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,4,1,176 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(1,644,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(2,1,1,4 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(2,3,-388,0 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(2,4,1,4 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(2,-635,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(3,1,2,-976 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,3,1,790 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(3,3,82,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(3,4,949,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(374,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(397,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(4,4,2,2 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(-883,0,0,0 ) ;
  }
}
