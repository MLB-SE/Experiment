import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-117,964 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-710,-191 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-819,845 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-864,-50 ) ;
  }
}
