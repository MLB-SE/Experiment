import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.14855507f,-93.06958f,0f,-5.0408673f,-32.208668f,40.827732f,12.193755f,53.815887f,0f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.24234372f,-93.25722f,44.856583f,-9.107736f,-28.03185f,13.756803f,-8.156747f,-23.519253f,38.20248f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(0.7235078f,-25.873173f,-21.225615f,-71.232796f,64.326996f,0f,4.8161526f,0f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.7840583f,3.136233f,-13.997276f,-100.0f,22.003149f,26.147835f,-26.97599f,-7.9039617f,-26.643003f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(100.0f,100.0f,0f,-82.50152f,37.63496f,47.3057f,-18.565664f,8.238859f,13.88614f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(100.0f,-23.866364f,87.21175f,42.52676f,35.69731f,62.476334f,34.409725f,61.65251f,-20.957552f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,-25.156815f,0f,-51.206184f,-100.0f,0f,-23.782578f,-43.92412f,-51.91391f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-10.080004f,43.417633f,0f,0.35755703f,10.099577f,50.062614f,1.4106547f,5.2850614f,9.630014f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-10.249231f,-73.04439f,52.10344f,-67.95254f,-63.937614f,0f,-11.893305f,54.369247f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-103.55611f,87.08808f,0f,43.222202f,-180.46724f,35.19683f,-0.6889326f,-45.977932f,-2.6741621f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(10.412628f,-32.667576f,78.17914f,-25.681911f,-99.99534f,-99.5235f,-13.144937f,-26.897837f,5.5489287f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(10.799797f,-72.75667f,90.78162f,15.955857f,2.0640938f,-7.3612614f,50.959538f,100.0f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(11.066838f,-85.17644f,18.660187f,29.443789f,16.455948f,96.613434f,11.624275f,17.05331f,40.13302f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(111.21738f,-42.99674f,0f,92.81279f,-13.263679f,0f,6.6218967f,-66.3252f,14.319757f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-1.1587025f,-88.154434f,-48.92572f,-16.48038f,8.883921f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-11.660046f,-43.631866f,0f,12.343569f,-30.649538f,6.1218987f,91.68386f,-98.1108f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(-11.913258f,42.30715f,-72.406715f,-12.057207f,33.91591f,40.04947f,-70.23148f,65.36422f,-72.87618f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(12.000434f,7.6436353f,18.574106f,-59.6419f,-100.0f,-67.83052f,-23.028955f,-32.473923f,-6.8667293f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(12.646882f,-88.44287f,0f,-4.246129f,21.259235f,0f,0.29246366f,5.415983f,-31.822914f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(-12.675739f,-28.861025f,0f,16.662626f,75.42972f,0f,99.1837f,-88.367226f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(12.950934f,-33.648064f,-32.077984f,-14.548199f,-64.25038f,38.705513f,-6.893352f,-13.025209f,23.640657f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(12.99726f,33.85737f,20.14069f,-81.86833f,2.2915251f,-53.294613f,53.84748f,-76.81166f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(131.98944f,-92.212975f,50.00336f,32.864555f,-5.141992f,53.960213f,4.5494456f,-14.785459f,-83.53677f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(13.346373f,45.30035f,43.506653f,-91.91486f,24.348385f,3.8352034f,-99.93134f,-75.11238f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(135.06038f,30.965508f,-66.61727f,36.47441f,-2.5734873f,-51.305172f,13.41193f,-26.428694f,26.136005f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(-13.837961f,-38.479893f,3.5309923f,-19.673853f,-28.268387f,-23.777798f,-36.58906f,-31.142004f,-70.373795f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(14.209147f,-26.529018f,41.680004f,-16.634392f,-69.4684f,-60.59372f,-11.843494f,-30.739588f,-41.646458f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(14.70155f,20.77916f,23.612957f,-61.97296f,-63.04362f,12.454618f,-22.649012f,-28.623083f,-28.7997f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(14.740975f,8.293143f,-82.06398f,-49.329243f,-0.92229956f,21.284172f,-12.898994f,-2.2667334f,4.7543597f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(-14.864504f,-140.31175f,-0.15654506f,-19.111069f,-41.628094f,-89.68277f,-18.93925f,-57.266953f,-52.9707f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(-14.870198f,-70.42432f,-73.96241f,-89.05647f,18.123335f,0f,-31.399307f,-36.540756f,-86.47306f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(14.889321f,-74.230896f,0f,1.8463274f,-8.235088f,100.0f,0.7310773f,1.0779817f,11.815938f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(15.027579f,-32.22328f,0f,-56.674194f,16.006699f,0f,-14.851351f,-2.7312098f,-12.080187f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(-15.438756f,-74.71088f,0f,-2.7071168f,15.311558f,0f,11.272869f,47.79859f,-19.108398f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(15.526776f,31.73481f,-0.41033617f,-69.62771f,11.822799f,-88.64478f,-27.204222f,-39.18918f,0f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(15.566509f,6.96159f,12.278356f,-44.695553f,-99.99833f,-61.498127f,-20.21292f,-36.15621f,-24.413599f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(16.044409f,55.78249f,3.6941724f,-91.60485f,54.446697f,0f,-9.681575f,52.878555f,-29.09167f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(16.090696f,-62.79327f,8.811654f,27.156052f,4.351112f,81.17798f,88.182396f,27.191479f,0f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(16.614944f,-27.11811f,70.39085f,-6.8035994f,-22.514101f,22.322672f,-21.31524f,-78.45737f,-82.80829f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(16.80306f,-99.99996f,0f,-3.4886765f,-27.084648f,-45.02587f,-3.673118f,-11.203795f,-14.057416f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(-168.32083f,146.39526f,0f,-45.786217f,27.71097f,-121.61348f,-42.647728f,-124.75109f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(17.164495f,-26.17657f,-60.721386f,-5.568875f,-34.047077f,-87.77311f,-5.392919f,-16.398659f,-26.189001f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(1.7335314f,-91.51027f,-7.7296925f,-1.555608f,-16.136663f,19.000412f,8.1807f,34.278408f,-44.634846f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-1.7338233f,35.665527f,0f,42.040974f,32.501343f,0f,59.745136f,0f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(17.385973f,18.969645f,99.07283f,-49.42575f,-69.18655f,1.4713693f,-18.154663f,-23.192898f,-5.430382f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(-17.532995f,-4.7041473f,0f,16.856377f,-9.358218f,0f,90.97805f,-11.044786f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(17.604801f,-22.051147f,-3.6823757f,-0.24792111f,-14.567008f,-20.098972f,-4.0294776f,-15.869988f,-44.88347f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(18.261814f,-11.9492035f,-70.59945f,-15.003538f,-95.45918f,57.584f,17.183214f,-40.067116f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(18.410994f,20.449902f,33.283222f,-46.80593f,-69.894615f,12.682991f,-21.20378f,-27.960873f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(18.538532f,-15.363365f,-85.16502f,-10.482506f,-94.82697f,62.465958f,-3.0317848f,-1.6446332f,91.28022f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(18.601748f,38.00459f,-4.646759f,-63.5976f,38.06337f,3.5534675f,-78.75678f,27.33508f,0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(-18.977806f,-83.37242f,74.0983f,4.220522f,13.089022f,44.645016f,22.770872f,86.86297f,32.927708f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(19.059319f,-30.07188f,-79.03558f,-4.453171f,-30.810226f,-68.92192f,-6.0617757f,-19.793932f,-100.0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(-1.9365367f,-3.3000252f,-61.95514f,23.231224f,13.187166f,0.15341231f,81.67426f,32.66405f,11.579413f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(19.682152f,11.177318f,24.919075f,-32.448708f,-99.89196f,-11.501015f,-58.242863f,0f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(19.954746f,38.101448f,-57.79203f,7.3494835f,19.198364f,0.1572666f,-9.7551775f,31.185259f,39.222733f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(20.226034f,-26.515022f,-44.705463f,7.4191556f,-35.134106f,0f,1.7541511f,-23.857508f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(20.374731f,46.082497f,44.51457f,-64.58357f,19.161968f,0f,-36.96057f,-83.258705f,-3.0568023f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(20.644077f,-27.480595f,-93.38263f,10.056906f,-25.661299f,0f,-20.087683f,-90.40763f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(20.649609f,-47.647186f,-81.89033f,30.245619f,29.681662f,84.98364f,70.65121f,51.144573f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(2.0936248f,-56.616405f,8.03626f,-35.009094f,-76.85904f,-17.306833f,-65.270966f,-1.1007619f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(20.970526f,-22.71222f,40.033222f,4.9923315f,-5.9905486f,-21.207367f,4.989348f,14.965061f,-100.0f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(22.011663f,3.0828438f,-77.42275f,-15.036191f,-32.257534f,-82.472f,-49.898895f,-87.779755f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(22.097492f,52.711594f,41.986897f,-64.321625f,46.761993f,36.423035f,-17.209188f,-4.5151286f,-47.61332f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(22.118172f,0.9078527f,-46.404793f,-12.435164f,-72.08197f,12.076085f,8.76536f,47.496605f,-2.3282058f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(22.152164f,20.274832f,48.830452f,-31.666176f,-89.883286f,75.046974f,-18.755295f,-43.355003f,-45.497536f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(22.355446f,2.377942f,-99.99929f,-12.956161f,-12.844385f,-55.219643f,-61.335705f,14.42032f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(22.546661f,-19.56112f,63.85978f,9.747765f,1.252257f,23.135828f,15.192139f,-8.313446f,27.431278f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(22.65511f,27.347324f,-97.47154f,8.384884f,12.065115f,25.63589f,-1.1806879f,-13.1076355f,-63.314972f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(23.039017f,43.037064f,40.504143f,-50.881f,8.605094f,18.97951f,-11.489244f,4.924021f,-85.09597f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(23.115076f,-11.577958f,-17.948046f,4.0382605f,-9.047181f,-32.951355f,2.0851471f,4.3023276f,-39.91856f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(23.261938f,14.24208f,-93.1239f,-21.194324f,-97.20956f,-100.0f,-10.8296795f,-22.124393f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(23.340645f,21.895525f,0f,-15.811793f,-67.79237f,-70.572784f,-18.795439f,-20.695536f,0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(23.453869f,-31.10297f,58.960117f,24.918446f,-53.07845f,0f,13.969738f,52.500946f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(23.508099f,16.888361f,-59.798557f,-22.855967f,2.0640774f,0f,15.77055f,85.93816f,0f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(23.59657f,9.297448f,5.9712176f,-14.911172f,-92.37799f,-85.412575f,9.136737f,38.713486f,0f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(23.772259f,5.3254085f,-28.571062f,-10.236374f,-73.89956f,-2.4101274f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(24.109783f,-0.08904157f,-99.99805f,-3.471838f,-25.318663f,-50.471924f,-12.678417f,-47.241844f,-76.57098f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(24.165228f,-4.732147f,12.954364f,1.3930575f,-17.769562f,59.099277f,-0.82343674f,-4.6868043f,-0.15421942f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(24.210997f,-28.42178f,0f,17.653563f,-94.99656f,0f,3.4669216f,-3.785877f,76.38613f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(24.510649f,-9.474484f,100.0f,7.51708f,7.593363f,43.156063f,-2.035692f,-15.659847f,-68.19706f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(24.739204f,-67.95813f,0f,-8.46988f,-52.1819f,38.447506f,-6.4368234f,38.8735f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(24.762697f,-48.74081f,-32.404766f,47.791595f,25.55062f,0f,38.78217f,0f,0f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(24.947235f,36.778355f,-45.201267f,-36.989418f,67.367455f,99.99057f,-5.711719f,14.142541f,-5.0855684f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(25.112787f,14.332139f,29.410994f,-13.880993f,-97.19522f,3.3118362f,16.558466f,0f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(2.537051f,-80.239334f,54.715096f,-9.612526f,-30.233377f,2.3209605f,-10.753777f,-33.402615f,-15.197877f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(25.463985f,9.811679f,40.547962f,-7.9557385f,-3.2038028f,0f,-8.4866295f,-25.99078f,-92.27269f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(25.577885f,100.0f,100.0f,-97.68846f,-80.47197f,0f,-26.495155f,-8.292161f,73.798485f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(25.667433f,7.1618023f,9.151059f,-4.4920707f,-9.728639f,10.91613f,-33.907078f,-52.500416f,46.263653f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(25.948015f,5.610612f,-61.50337f,-1.8185529f,-42.002197f,100.0f,8.779972f,36.93844f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(25.956764f,-2.0874069f,92.37098f,5.9144654f,-76.318695f,27.769663f,-3.3712165f,-19.399332f,2.0925825f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(26.026667f,63.037857f,-61.07011f,-58.931187f,52.490524f,0f,16.054081f,-82.37153f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(26.263302f,39.546936f,19.577486f,-34.493725f,12.346953f,11.825459f,-8.1462965f,1.9085389f,3.4334993f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(-26.4589f,52.78455f,0f,60.172665f,10.063782f,38.83301f,14.84423f,-0.79574764f,-28.091002f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(26.766527f,70.00525f,13.815753f,-61.495674f,139.2708f,-68.45942f,-40.084457f,-98.8407f,-30.029778f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(26.874477f,19.510447f,13.328563f,-12.012535f,-62.161255f,-66.1962f,-10.305692f,-29.210234f,-44.37399f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(26.975952f,4.6796646f,-99.64551f,3.22396f,-10.654277f,-100.0f,-3.4262736f,-16.929054f,-53.636105f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(-27.055706f,28.162045f,0f,-34.396454f,-95.06725f,-28.76698f,-15.462865f,-27.455006f,-9.15186f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(27.190235f,17.95935f,-48.309612f,-9.198411f,-7.0432186f,30.80615f,-0.69132185f,6.433124f,33.467037f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(27.883572f,-49.941467f,100.0f,8.428481f,5.5033827f,70.64712f,0.32697052f,-7.1205993f,100.0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(27.929308f,9.358466f,-100.0f,1.9431398f,-13.145142f,-33.89261f,-7.011606f,-29.989563f,-99.801506f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(27.968475f,-6.5591016f,-25.330778f,18.433f,32.538765f,93.91378f,13.224767f,34.466064f,92.10072f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(27.976852f,11.327685f,-99.99991f,0.57972646f,-5.107213f,50.446396f,-20.550734f,-82.78267f,-15.276568f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(28.089113f,20.0642f,28.625208f,-7.707742f,-76.45753f,-7.7401075f,17.537443f,40.818607f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(28.215876f,40.51635f,39.453865f,-27.652847f,-5.6043463f,9.142919f,-5.890018f,4.092775f,58.476448f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(2.8271842f,68.26863f,0f,-21.243664f,29.01334f,28.87786f,-7.208981f,-7.5922604f,-52.1734f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(28.346575f,32.64044f,60.269497f,-19.254145f,-58.0543f,100.0f,-47.308857f,33.434776f,0f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(28.363369f,9.649216f,-55.410458f,3.8042612f,-34.35605f,-6.6529465f,-3.4343762f,-17.541765f,-32.37664f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(28.51948f,-100.0f,0f,1.0658342f,-18.349564f,42.253876f,-5.9065795f,-24.692152f,-74.51247f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(28.613234f,26.342686f,0f,-11.436592f,-42.02734f,91.77299f,-3.7814739f,-3.6893032f,31.0516f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(28.787327f,30.429731f,59.30303f,6.7298126f,28.393576f,10.927934f,-30.26165f,65.486824f,-12.736515f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(28.93711f,29.356977f,37.337082f,-13.608538f,-48.84628f,-38.61752f,-34.524982f,-97.93834f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(29.07953f,6.628744f,-100.0f,9.689375f,-2.5645525f,100.0f,12.242522f,39.280716f,-54.59658f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(29.253782f,18.489227f,-28.927181f,-1.4741017f,-31.368378f,-99.59181f,-3.7818108f,-13.653142f,-19.46238f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(29.41422f,19.333628f,-100.0f,-1.6767417f,-36.737095f,-20.407597f,0.6159076f,4.1403723f,100.0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(2.9582381f,58.07289f,-71.72134f,4.346341f,5.544958f,-71.42173f,8.882169f,31.182333f,-38.37414f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(29.978111f,24.615505f,61.09088f,-4.7030573f,-92.60697f,-33.688065f,-14.274899f,-52.396534f,70.89805f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(-30.21219f,15.9126425f,0f,-19.646189f,25.316223f,0f,-1.6178976f,13.174599f,29.000067f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(30.636118f,35.091568f,17.436811f,-12.547092f,-7.706661f,-100.0f,28.10884f,0f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(30.64261f,25.114355f,100.0f,-2.543911f,2.783583f,37.328636f,-43.601837f,-48.764748f,46.530956f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(31.088425f,14.389354f,-100.0f,9.964347f,6.105746f,-24.747314f,2.6632175f,0.6885236f,-6.014869f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(-31.287846f,70.5764f,0f,0.042571716f,27.186201f,71.24505f,4.271933f,17.04516f,36.722507f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(31.41315f,37.951332f,95.159096f,-12.298732f,-74.76673f,16.53475f,-5.8411584f,-11.065485f,36.345947f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(31.469244f,-8.059311f,-73.830154f,33.936283f,-89.876335f,66.741714f,31.175505f,-13.932563f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(31.485706f,-58.63553f,0f,-2.1371493f,-45.472202f,-75.64333f,5.437897f,-39.134293f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(31.719881f,62.12215f,18.315527f,-35.24263f,98.4532f,-88.86005f,47.71434f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(31.811792f,9.198346f,-24.616438f,18.048824f,26.742065f,18.065325f,13.641441f,36.51694f,-88.852104f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(31.893034f,5.3431287f,-82.74591f,22.229008f,-28.487328f,35.617767f,85.51032f,-56.49405f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(31.90902f,-100.0f,0f,19.023504f,58.1282f,0f,3.394681f,-5.4447813f,-61.68155f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(31.93096f,31.382847f,6.8980155f,-3.6590047f,-13.297589f,-48.094147f,-33.26939f,-7.4605193f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(31.9513f,30.16582f,-10.506662f,-2.3606193f,-1.52636f,-3.4719474f,-39.867416f,-30.438692f,-1.8547674f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(31.972534f,19.167244f,-62.05152f,8.722896f,1.3418022f,-80.73917f,1.5772438f,-2.41392f,-12.574726f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(31.99123f,23.03308f,37.423534f,4.9318414f,-77.28245f,2.9124975f,15.194551f,1.5216277f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(32.052956f,39.780773f,0f,11.02141f,-39.791668f,-57.455246f,51.82435f,-68.4733f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(32.229794f,32.687046f,47.28157f,-3.7678673f,-48.76318f,-30.186167f,1.461915f,9.615527f,-20.602806f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(32.34284f,80.12735f,0f,32.356724f,-94.143906f,0f,-13.354153f,-85.77334f,38.679375f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(32.837063f,0.74215364f,96.82187f,30.606094f,5.2647257f,20.441095f,84.322586f,-30.730442f,58.258095f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(32.86466f,32.629128f,33.93741f,-1.1704959f,-36.285553f,-73.22155f,-1.2610888f,-3.8738594f,36.354633f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(33.028263f,42.6102f,85.215576f,-10.497151f,-47.803047f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(33.115627f,63.292953f,-78.82554f,4.284256f,-1.988749f,-15.288538f,-13.989853f,-60.243668f,-38.18221f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(33.138027f,36.14245f,11.315544f,-3.5903356f,-44.54476f,66.57617f,-2.9546084f,-8.228087f,14.587021f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(33.23633f,37.257805f,29.487461f,-4.3125033f,-13.692578f,-19.30795f,-36.793762f,-68.40766f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(33.554768f,29.869623f,-75.224556f,4.3494534f,61.148277f,-100.0f,-77.30523f,3.140949f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(-34.024105f,-22.556013f,83.92809f,-21.999258f,-30.638153f,-6.6575203f,-23.33477f,-71.33982f,-78.16902f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(34.096897f,27.174702f,-81.20706f,9.212891f,3.104513f,0f,73.74205f,0f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(34.124863f,16.03605f,2.2945085f,20.463398f,-72.27517f,-12.767792f,-7.1789155f,-49.179058f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(34.270123f,34.324722f,33.81891f,2.7557764f,-30.790144f,0.95091176f,-3.323287f,-16.048923f,-30.08226f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(34.33663f,42.507698f,90.20785f,-5.161168f,-54.513687f,-91.35747f,-25.319925f,-96.11853f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(34.361694f,39.15773f,-30.101725f,-1.7109567f,-5.6150813f,-51.39472f,-35.59044f,-8.512381f,51.182465f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(34.443054f,17.410986f,-100.0f,20.361408f,35.200893f,36.911713f,11.801686f,26.84551f,60.37946f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(34.72861f,-36.891434f,-74.1902f,75.805885f,13.727359f,0f,23.081322f,16.519403f,43.379936f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(35.258415f,37.981987f,16.47527f,3.0516827f,0.19425482f,-72.08091f,1.1797601f,1.6673578f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(35.451252f,36.010307f,16.73747f,5.7947035f,-8.147493f,-69.060425f,-4.1249456f,2.6200807f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(35.45455f,31.331154f,100.0f,11.332456f,18.666172f,78.49715f,-8.790902f,-46.496063f,100.0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(35.459904f,-10.742059f,0f,-6.683255f,41.296513f,-36.50599f,-2.8912897f,-4.8819036f,-57.93284f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(35.665264f,45.40938f,-100.0f,-2.7483253f,-44.242996f,0f,-2.415569f,0f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(35.707832f,61.588573f,71.97581f,-18.75725f,38.67066f,55.661125f,2.564817f,29.016518f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(36.199753f,25.923897f,96.54108f,18.875118f,13.887226f,-27.496948f,25.413494f,82.778854f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(36.44916f,53.821297f,85.532646f,-8.024649f,-41.728237f,-100.0f,-26.819523f,94.12956f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(36.45852f,8.426877f,-66.43715f,37.407192f,-36.313858f,-35.32911f,-1.9761316f,-45.311718f,-100.0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(36.59967f,32.192833f,-25.05036f,14.205856f,17.222015f,-24.960464f,3.001736f,-2.198912f,24.352398f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(36.61245f,64.51271f,0f,7.1064873f,4.250475f,-97.56192f,-12.436975f,42.944622f,0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(36.795692f,52.702633f,-40.313393f,-5.5198693f,41.102467f,24.466675f,-99.97764f,92.76043f,97.07762f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(36.884277f,5.1218348f,11.366852f,16.922575f,15.012186f,-8.248426f,15.793834f,46.25276f,-59.372746f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(36.950768f,43.119427f,44.207294f,4.6836405f,-8.680357f,17.734255f,-9.535849f,0f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(37.111115f,27.86826f,39.947235f,20.576202f,-74.20894f,0f,11.70443f,26.241518f,41.239468f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(37.17382f,60.727783f,100.0f,-12.032504f,7.119888f,31.493847f,-92.42372f,-51.709576f,18.855501f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(37.24958f,67.17295f,70.84225f,-18.174633f,60.599964f,66.91844f,3.9555724f,33.99692f,71.43215f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(37.519367f,40.914066f,25.239185f,9.163503f,0.8977092f,-47.314247f,-1.7630482f,-16.215588f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(37.530087f,91.076294f,0f,-76.03259f,98.553f,0f,-63.663868f,-71.9838f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(37.57519f,-13.076106f,0f,19.39475f,47.45465f,-67.514885f,-7.450844f,-49.198124f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(37.771935f,38.238125f,11.891343f,12.849619f,-10.462835f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(37.784348f,20.694534f,-89.461815f,30.442856f,68.05068f,0f,12.735054f,20.49736f,-81.81154f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(38.078995f,23.538965f,-33.675224f,28.77702f,-10.24791f,100.0f,4.8794827f,-9.259088f,-31.667923f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(-38.104954f,38.885983f,0f,-21.951124f,-39.4496f,-86.93163f,-10.249945f,-19.048655f,-26.495073f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(38.269333f,41.32735f,16.202755f,11.749984f,10.837311f,-76.516335f,-2.1067078f,58.679077f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(38.340015f,47.50762f,59.106876f,5.8524475f,-21.515644f,-96.842804f,6.792943f,21.319324f,100.0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(38.408955f,40.35885f,36.672253f,13.276968f,-13.645819f,6.330168f,28.344738f,0.52417374f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(38.43635f,28.588303f,-62.805557f,25.157099f,-30.614244f,0f,21.71388f,-55.362335f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(3.849491f,-53.71063f,0f,54.243114f,-32.32667f,0f,-10.570432f,-12.918443f,0f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(38.509216f,34.731716f,20.331802f,19.305141f,94.58924f,0f,6.0478954f,4.8864393f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(38.586292f,50.082134f,27.27115f,4.2630324f,34.471096f,-82.76641f,-56.00526f,100.0f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(38.820393f,41.351925f,-100.0f,13.92965f,30.206448f,40.273228f,-13.308242f,25.270987f,99.99201f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(38.878147f,47.488106f,45.92955f,8.024489f,70.46224f,0f,-77.24243f,0f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(39.22659f,49.57456f,30.209644f,7.331802f,28.862f,-91.31126f,23.481447f,86.59399f,-23.506044f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(39.24696f,30.406729f,0f,26.580278f,28.493408f,33.895702f,38.58074f,23.09092f,0f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(39.416622f,43.625553f,-244.43315f,14.185718f,-21.351137f,-189.68655f,38.404922f,46.647915f,-51.036274f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(39.47815f,28.084433f,0f,23.930502f,42.662254f,100.0f,13.581604f,30.395914f,65.3398f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(39.551643f,39.71627f,-37.742355f,18.490297f,18.91561f,8.119308f,15.493938f,9.336562f,-57.519234f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(39.71155f,46.897263f,17.855083f,11.948943f,30.02241f,-75.47692f,-21.938189f,-99.99907f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(39.826984f,54.124992f,-4.215348f,5.182942f,80.88834f,-30.408379f,-99.98356f,0f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(-39.87239f,-30.332031f,0f,-32.927334f,-54.88341f,0f,-36.953533f,0f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(39.89669f,0.3442218f,-39.179527f,59.242535f,-99.34027f,-99.66356f,66.756615f,0f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(-40.103767f,43.683346f,0f,44.059265f,-72.96078f,-31.128489f,10.151408f,-3.4536319f,48.99484f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(40.17724f,83.01166f,-41.831455f,-22.302698f,-61.879517f,0f,-48.97206f,57.500267f,0f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(40.21206f,46.43639f,-57.392193f,14.411844f,10.630323f,-33.558228f,6.804994f,15.231288f,10.815472f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(40.4276f,27.243095f,-80.79205f,34.46731f,32.513702f,-28.000166f,64.92795f,5.4310856f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(40.444588f,47.82034f,58.927307f,13.958019f,-8.090541f,87.888885f,1.874522f,-6.459931f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(40.455704f,54.418583f,78.62855f,7.4042344f,-1.4099236f,48.22332f,-1.3844726f,-12.942125f,-48.974102f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(40.71554f,48.223785f,36.93019f,14.638389f,10.468928f,-4.8560705f,7.369084f,-16.13039f,-66.8234f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(40.853928f,62.816353f,-61.58481f,0.5993603f,-23.952467f,66.58065f,-14.50402f,-9.299336f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(41.116337f,39.99655f,16.23673f,24.468794f,2.6331358f,-78.56381f,54.125698f,-89.42019f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(41.245033f,6.520317f,51.547417f,19.570217f,31.666426f,4.5337296f,5.3694043f,96.04144f,4.603655f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(41.478992f,51.53812f,-5.206112f,14.377846f,11.535735f,-23.381813f,4.496658f,3.6087859f,-99.76392f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(41.654816f,47.77134f,27.084593f,18.847925f,22.345945f,-39.432987f,11.390933f,26.715809f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(42.093227f,38.032265f,5.4870453f,30.34065f,4.548781f,-65.60888f,9.702718f,8.47022f,17.877699f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(-42.197556f,12.029114f,0f,-52.603348f,64.73313f,0f,-8.529812f,18.4841f,83.69725f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(42.75457f,41.1013f,-100.0f,29.916983f,54.827744f,-100.0f,22.085615f,58.425476f,-100.0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(42.796158f,6.896791f,-22.441265f,64.28784f,-92.76773f,-27.717255f,10.098741f,-23.892881f,-12.902534f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(42.986496f,-45.150276f,0f,84.51171f,68.73398f,76.97397f,28.921171f,31.17297f,27.036734f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(43.436703f,77.60526f,-38.62764f,-3.858458f,-51.877483f,0f,-76.21105f,0f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(43.46558f,56.01045f,21.789787f,17.85188f,43.998375f,82.3287f,-16.056444f,-82.07766f,47.075428f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(43.5107f,59.50769f,82.950264f,14.53511f,11.569799f,50.941578f,3.0599406f,-2.2953475f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(43.588963f,61.259033f,-84.526f,13.096809f,22.36789f,9.50544f,-13.569613f,-59.45314f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(44.103542f,27.163889f,-89.89329f,49.250282f,1.6231871f,-60.422108f,19.757648f,29.780317f,97.74043f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(44.12497f,4.306021f,-30.244541f,18.694029f,40.097237f,79.82085f,-9.446094f,57.56805f,-31.8906f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(44.58825f,72.40914f,45.048313f,5.943853f,100.0f,-5.926857f,79.24581f,-84.39175f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(44.801678f,36.50281f,19.697176f,42.703896f,-18.487604f,-57.714108f,68.01207f,-78.01672f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(45.302464f,61.19735f,3.078452f,20.012506f,23.005436f,41.738228f,11.742126f,26.956f,73.07644f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(45.45369f,49.34208f,83.543884f,32.472683f,24.068808f,0f,89.89308f,-20.049797f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(45.51522f,84.71782f,67.92603f,41.846992f,45.051136f,24.511854f,76.82162f,29.127876f,-14.929753f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(45.67518f,41.321766f,-51.015957f,41.37895f,54.2198f,72.69144f,65.62082f,61.48704f,11.90308f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(45.73153f,56.508892f,38.206745f,26.417221f,42.09729f,-3.6819053f,9.004806f,9.602002f,-44.752216f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(45.799164f,35.70131f,63.210556f,47.49534f,-66.204475f,-58.740654f,20.567408f,34.774292f,18.181768f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(46.184433f,55.300102f,2.968917f,29.437622f,62.95359f,-41.14809f,8.612468f,-33.462772f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(46.21978f,73.831406f,100.0f,11.0477085f,49.105854f,100.0f,-51.1348f,11.544305f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(46.668457f,44.510895f,-100.0f,42.16293f,87.0149f,0f,21.602211f,44.245914f,0f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(4.683003f,-92.18655f,100.0f,10.918556f,16.98619f,7.002325f,22.005032f,77.10157f,0f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(47.232273f,-69.82706f,0f,5.305f,-68.1563f,-5.9670253f,42.14403f,96.94165f,0f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(47.294773f,53.040047f,44.916916f,36.139038f,19.948498f,-36.55864f,77.31289f,27.07682f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(47.37278f,-0.35551122f,0f,36.05305f,-70.92815f,-73.177055f,4.4075885f,-18.422697f,-7.170227f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(47.620045f,-69.09566f,26.391611f,4.3897333f,-29.05082f,-43.06646f,-1.0102919f,-8.430901f,48.66631f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(47.765247f,66.20525f,54.277378f,24.855728f,62.778393f,50.904255f,-11.120724f,-20.035088f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(48.065495f,63.436512f,20.322628f,28.825472f,85.35793f,96.80426f,-75.60872f,-70.51663f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(48.635437f,66.228546f,54.516846f,28.313192f,70.887f,67.44395f,-6.269663f,41.57362f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(4.9075623f,-96.611946f,51.287685f,16.242191f,51.02812f,59.88074f,9.033082f,-73.68301f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(49.196426f,87.07212f,15.599493f,9.713579f,67.14578f,73.923965f,-77.48789f,97.87347f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(49.264347f,58.121372f,-10.108182f,38.936016f,57.217655f,0f,20.752691f,44.074745f,98.328636f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(49.54041f,100.0f,0f,14.394719f,4.1792774f,-66.22492f,3.8591907f,1.0420433f,53.66452f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(-50.046448f,12.058032f,0f,8.872103f,76.382866f,0f,-15.353532f,-70.28623f,0f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(50.284447f,72.146324f,98.80318f,28.991457f,40.040413f,8.335752f,25.640968f,50.68812f,49.46883f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(50.45438f,-66.065704f,0f,1.6748934f,38.387875f,5.826634f,-82.142685f,100.0f,0f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(50.8917f,-16.539614f,0f,9.915194f,-7.2753773f,0f,-3.955549f,0f,0f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(51.17113f,64.642746f,-100.0f,40.041775f,-41.186924f,5.5751143f,7.883108f,-8.509343f,-0.7335572f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(51.24551f,20.075916f,64.47227f,8.477283f,31.411333f,53.781155f,-48.747715f,43.31098f,-58.83536f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(51.281216f,70.792465f,67.680305f,34.332397f,64.208336f,99.92876f,21.840033f,53.027737f,0f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(52.105865f,83.364845f,86.577354f,25.058615f,49.55894f,-53.188705f,-1.4303479f,-30.780006f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(52.436543f,86.325424f,0f,23.420738f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(52.7772f,72.670044f,199.62036f,38.43875f,30.643797f,81.301094f,70.33513f,-69.80069f,82.04237f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(52.830826f,17.02405f,-38.69368f,94.299255f,20.652657f,0f,21.710562f,-7.457013f,-72.19127f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(52.93843f,98.490456f,18.960556f,25.119692f,28.902473f,-17.868954f,18.637861f,9.868696f,49.785507f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(54.084255f,54.345665f,54.25394f,61.991352f,9.04447f,-15.877853f,-45.283962f,72.35395f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(54.38f,22.998827f,11.153183f,94.52119f,-73.53788f,-78.99045f,22.222986f,-5.629239f,28.797937f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(54.778988f,-13.148063f,0f,16.901596f,7.1503773f,10.828037f,5.6770225f,5.8064938f,10.398575f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(54.818954f,67.81096f,0f,33.021156f,51.591663f,0f,-81.89765f,0f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-54.907944f,20.163061f,0f,-33.05958f,-63.36223f,9.532506f,-13.968156f,-22.813042f,-13.921783f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(5.4922967f,-31.496323f,96.94279f,-46.53449f,-2.842427f,-99.23322f,-14.274994f,-10.565488f,-25.14453f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(55.02469f,0.3539495f,0f,19.533453f,18.97594f,65.33775f,4.1331797f,-3.000733f,-35.112053f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(55.124638f,100.0f,100.0f,20.49855f,8.296162f,99.99991f,18.573402f,53.795063f,99.033585f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(56.491646f,59.902863f,99.23815f,66.06371f,-16.118341f,43.76602f,-35.081257f,0f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(57.0931f,99.99016f,20.989555f,28.38224f,51.08277f,15.644609f,5.3530946f,-6.9698625f,-84.315315f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(57.61888f,34.221264f,23.167297f,96.254265f,-43.901123f,-41.55208f,27.951654f,15.552356f,99.99282f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(58.051968f,44.72306f,-65.82272f,87.48481f,81.23626f,0f,7.795836f,37.24849f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(58.89631f,100.0f,6.7682376f,35.58523f,38.6743f,100.0f,9.676491f,3.1207342f,-35.867855f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(-5.934629f,22.026503f,-24.851887f,-26.263912f,-25.831226f,-86.11896f,-73.289795f,-12.968534f,-96.39838f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(-60.919376f,99.99579f,-82.58644f,-10.799858f,18.168394f,-25.5284f,-0.44845203f,9.00605f,99.944855f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(61.522633f,107.64134f,-48.97067f,41.580887f,83.794174f,275.2358f,18.425867f,28.994104f,8.750549f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(62.794327f,92.23747f,82.24421f,58.93984f,68.80116f,0f,22.2712f,30.144958f,87.306175f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-62.97243f,-10.624477f,0f,-12.723465f,50.029366f,-15.908371f,-37.950798f,-43.061375f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(63.662975f,64.91551f,20.189693f,89.7364f,75.80937f,-84.15674f,-86.04885f,97.87873f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(65.51813f,66.78051f,2.472274f,95.29199f,99.13165f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(66.56297f,-49.92127f,18.973995f,11.431227f,-14.193142f,19.728392f,-6.644923f,-38.010918f,74.13271f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(67.96393f,-74.14009f,0f,4.8966746f,-29.943674f,-100.0f,-18.433558f,-78.630905f,-15.10402f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-68.08832f,-64.41968f,0f,-71.1036f,-19.487059f,0f,-32.65562f,-59.518887f,0f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(-68.39519f,44.85058f,0f,-74.70627f,61.58165f,0f,70.18392f,0f,0f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(70.678764f,100.0f,0f,76.77803f,-100.0f,0f,13.979209f,-55.50072f,0f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(71.47306f,84.4721f,0f,21.85557f,32.87654f,0f,-19.26573f,-98.91849f,0f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(72.42762f,14.988088f,0f,6.4945307f,-43.4213f,-93.31194f,-3.0281997f,-18.60733f,-27.979818f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(73.32728f,15.172953f,0f,12.10822f,-30.786774f,89.9362f,5.892379f,11.461295f,0f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(-74.1751f,55.038807f,0f,-31.36578f,-20.279493f,-35.130642f,-31.008524f,-17.933935f,0f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(-74.61573f,-12.6296835f,0f,-23.337603f,-17.452911f,-59.99001f,-1.2817658f,-43.44229f,0f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(74.97005f,-51.17007f,0f,38.542175f,60.094944f,-0.8306567f,19.103712f,37.872673f,72.29203f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(75.258255f,-99.87673f,0f,50.246105f,33.984596f,0f,7.4050226f,-20.626013f,-195.12863f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-7.6139727f,-100.0f,-54.895863f,-30.45589f,-25.627007f,-66.74983f,-88.58258f,85.856544f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(76.92615f,-0.95753264f,0f,-46.49692f,-35.119312f,0f,-12.954836f,-16.345877f,0f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(7.7747345f,2.0624683f,-52.79336f,-70.96353f,-46.7315f,-15.902499f,-40.415424f,0f,0f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(79.45316f,19.729101f,33.93216f,19.064789f,-37.306335f,-95.351654f,34.112328f,-92.66757f,-57.11442f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(80.03419f,-11.331095f,-23.1387f,19.099209f,-5.4812317f,-17.969349f,1.8438785f,-11.723703f,-43.257465f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(80.794014f,-3.2795978f,0f,-4.7219615f,15.676154f,0f,-69.64544f,0f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-8.115902f,-61.985107f,0f,-57.072067f,100.0f,-30.824112f,-8.694734f,22.29313f,-2.1327453f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(8.286559f,13.135028f,-83.578064f,-79.98879f,27.83162f,45.800995f,21.054869f,20.184353f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-8.363884f,-53.954956f,-61.527565f,-79.50058f,-65.58889f,0f,-21.918009f,-8.17146f,50.12866f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(83.94312f,-99.67519f,65.35452f,8.188857f,-44.573063f,-52.158543f,-6.6146297f,-34.647377f,-87.40181f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(84.349556f,100.0f,0f,47.643635f,73.56477f,100.0f,32.660213f,-100.0f,0f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(85.539444f,32.918083f,-49.90308f,-3.3807588f,-21.204605f,-14.355744f,-77.85787f,-100.0f,13.6847105f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(87.11608f,66.31637f,0f,0.7906825f,-49.19411f,0f,-58.671276f,-7.5251145f,0f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(87.36958f,79.26535f,0f,39.820236f,54.19776f,99.98201f,17.713596f,31.034151f,52.2593f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(88.33419f,26.715271f,0f,44.147015f,23.069044f,-88.63921f,65.184814f,-53.61247f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(88.572334f,79.39224f,0f,-96.15269f,16.117405f,46.80692f,-19.076578f,19.84638f,82.34469f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(-88.74794f,30.632559f,0f,77.24458f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-89.91132f,-59.453583f,0f,-86.025894f,-99.23033f,0f,-85.14355f,56.278088f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(-90.27434f,34.280613f,-53.74593f,-13.728937f,-0.82896215f,-9.23912f,36.187553f,-14.628406f,-100.0f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(91.240814f,-36.480743f,-20.848747f,24.545544f,0.66506326f,19.717457f,6.2763004f,-5.122003f,99.053505f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(-92.44492f,-99.999985f,-35.90426f,-34.0253f,-34.640285f,-2.4972317f,-9.015983f,-2.038632f,60.55562f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(-92.59994f,-43.59127f,0f,9.343306f,-100.0f,0f,20.977621f,74.56718f,-6.6230993f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(93.89993f,-52.84169f,0f,42.21085f,47.936855f,-48.252716f,27.00661f,65.81559f,79.89726f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(9.401447f,11.940006f,26.86384f,-74.33422f,-88.505264f,-4.484645f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(94.03737f,100.0f,-8.131124f,6.742819f,7.749645f,-16.471737f,-74.815735f,-59.272503f,-65.50547f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(9.63119f,-95.73565f,0f,3.4631724f,-6.798989f,43.12762f,11.020489f,40.618782f,-100.0f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(97.39672f,71.33559f,0f,84.18797f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(99.38077f,-92.5064f,0f,-53.948605f,1.87975f,0f,-8.710455f,19.106785f,0f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(99.75345f,70.08876f,0f,26.816444f,-27.51999f,68.071335f,4.0410743f,-10.652147f,-19.129671f ) ;
  }
}
