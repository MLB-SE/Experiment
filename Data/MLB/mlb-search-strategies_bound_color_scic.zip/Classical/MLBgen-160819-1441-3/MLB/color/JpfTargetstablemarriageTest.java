import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(-136,0 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(307,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(344,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(3,-989 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(4,143 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(4,4 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(4,773 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(5,0 ) ;
  }
}
