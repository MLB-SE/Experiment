import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,5,-909,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,5,9,1146,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(4,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(4,3,4,-892,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(5,-3,3,3,-1,1,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(5,4,6,8,3,-294,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(5,567,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(5,76,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(6,0,6,4,424,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(6,1,4,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(6,-21,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(6,2,5,8,5,134,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(6,4,9,4,1,427,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(6,9,6,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(7,5,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,6,0,627,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,7,0,6,-248,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(783,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,8,876,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(9,1,5,2,8,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(-916,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,1,7,4,206,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(931,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,3,740,0,0,0,0,0 ) ;
  }
}
