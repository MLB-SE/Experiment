import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-59.423508f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(65.50413f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(94.943794f ) ;
  }
}
