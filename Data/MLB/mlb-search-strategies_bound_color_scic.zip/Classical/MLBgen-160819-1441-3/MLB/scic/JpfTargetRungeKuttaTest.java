import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2703.400348646392 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2740.164485865435 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2743.613001933091 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(-44.57032965333547 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(-47.0054003452623 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(54.89967664451686 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(-73.40562636518149 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(81.70406820612922 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(85.89407287373257 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(85.94561386731095 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(86.94109344540121 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(91.64027967736047 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(94.37515220747412 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(-95.06448571071881 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(95.882981694281 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(97.48132311664449 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(98.41077310700959 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(98.74095798004262 ) ;
  }
}
