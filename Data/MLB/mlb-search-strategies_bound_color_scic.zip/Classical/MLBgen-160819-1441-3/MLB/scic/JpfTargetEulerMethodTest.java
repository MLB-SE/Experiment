import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-14.098317824043889 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070235 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(70.13786979523115 ) ;
  }
}
