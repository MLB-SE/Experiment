import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.3119662011198159,-8.026200543448738 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(11.762292767524897,6.528868043596361 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-12.171039459891134,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535047031603,-51.965197005270895 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(19.668275934998675,-4.048794816943911 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-2.1945398210891085,-83.86743670954566 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(2.219422073250257,-50.94961265265772 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(22.553974951906426,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-24.518252164396472,32.61147381345239 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(32.97967732626475,98.13750294365477 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-36.79805056687287,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(37.50048836488111,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-87.40149399188843,0 ) ;
  }
}
