import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-10.972119747747527,92.21858204098064 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-30.165306547462727,7.435226747682746 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(38.392464897296236,-47.30668816352694 ) ;
  }
}
