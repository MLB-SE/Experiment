import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-20.75000000007748,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-22.786475964395308,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-25.050090423660734,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(4.137061183671591,78.94208889479387 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-49.042501702478546,1.3909033159088509 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-5.437632122838082,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-56.75000000000001,-93.28948157014011 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-5.750253213629863,8.881784197001252E-16 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-59.407301036260684,0.19460801249964987 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-65.94493423766889,79.21907328920724 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(66.69605619738158,-40.00898613804311 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-92.13303416066037,-63.51185734493845 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-95.25,100.0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(97.47488038589157,0 ) ;
  }
}
