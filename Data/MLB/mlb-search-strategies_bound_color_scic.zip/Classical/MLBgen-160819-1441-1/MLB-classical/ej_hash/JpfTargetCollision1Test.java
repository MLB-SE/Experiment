import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-808,554,895,-796,265,-1678 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-922,991,-489,-992,222,636 ) ;
  }
}
