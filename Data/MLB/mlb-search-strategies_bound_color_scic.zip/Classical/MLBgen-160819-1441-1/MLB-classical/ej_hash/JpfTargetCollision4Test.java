import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-26582,563,-449 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(488,864,889 ) ;
  }
}
