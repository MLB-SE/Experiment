import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-858,882,-879,-730 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(875,900,366,-408 ) ;
  }
}
