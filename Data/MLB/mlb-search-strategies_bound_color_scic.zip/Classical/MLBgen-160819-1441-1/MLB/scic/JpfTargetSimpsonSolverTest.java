import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-14.40612075050327,52.27240503131248 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-18.274546542839886,73.18997465006015 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-64.67737419384233,2.628533912351287 ) ;
  }
}
