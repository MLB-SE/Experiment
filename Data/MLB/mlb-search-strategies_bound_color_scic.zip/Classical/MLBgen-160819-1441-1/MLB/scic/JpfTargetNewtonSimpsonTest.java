import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.07496270412683259,-80.78740792473678 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.28368748547475775,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.35625850747173615,28.813063882161885 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-1.224780573640571,98.14008820254332 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.6443475242848622,8.448107236769013E-7 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.6448535061215064,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-1.6980076676703248,-18.95914512823525 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-1.7118596000921684,69.26829410481338 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-1.726872043015561,-75.6140250891167 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(18.71335527633677,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(2.161295474493258,0.29644007139634976 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-2.2137922812371187,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-22.998421761493333,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(-24.850759063128564,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(2.54227895677424,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(3.0889678197918613,93.42751004123696 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(37.629420465659564,11.007556605172226 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(-5.906330705552733,0 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(-6.607381191023649,43.318752693581416 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(-89.34168535236856,0 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(9.69696906510309,0 ) ;
  }

  @Test
  public void test21() {
    scic.NewtonSimpson.newton(-9.76059286109674,-58.23653999589815 ) ;
  }
}
