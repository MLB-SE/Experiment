import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(0.23685863776982785 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119132 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(36.11728432769914 ) ;
  }
}
