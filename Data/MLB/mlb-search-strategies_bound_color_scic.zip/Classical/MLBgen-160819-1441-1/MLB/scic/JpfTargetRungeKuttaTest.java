import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(-12.303467364445012 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-12.906377846247665 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2705.2443752127683 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2713.0581931603 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2733.268334007059 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2747.454145875647 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(52.64681096501391 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-59.81624570952992 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(62.406823208242145 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(69.40599795998494 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(72.68860197527854 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(74.79630059845786 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(77.10333843018023 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(-85.26617025459319 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(92.9177309209633 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(96.01136406869105 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(98.38492399878587 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(99.07220082266903 ) ;
  }
}
