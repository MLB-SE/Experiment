import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-11.048090600949251,61.560588030232935 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-11.727832024792022,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-13.75000008496518,-100.0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-19.30409182476805,-55.1788672798861 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-29.75000000000001,0.0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-31.249999999999996,11.593389743165698 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-31.818728451378917,0.0683333747331325 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-3.9490295677428833,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(60.38775758737748,-97.97063270361255 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-63.15474963473271,0.12174019447817841 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(670.0026951152493,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-68.75,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-73.87800146055245,59.287874467353504 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(78.98890890843137,0 ) ;
  }
}
