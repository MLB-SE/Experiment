import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-135,72 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-2,-880 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(527,367 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-891,809 ) ;
  }
}
