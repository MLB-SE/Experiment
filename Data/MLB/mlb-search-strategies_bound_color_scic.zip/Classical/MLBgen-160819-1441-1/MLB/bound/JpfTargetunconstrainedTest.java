import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(-120,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(1,4,2,-87 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(1,4,9,2 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(2,5,8,958 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(2,6,-665,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(286,0,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,3,5,317 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(5,10,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(5,2,2,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(5,2,8,7 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(602,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(6,10,223,0 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(6,7,534,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(7,-495,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(7,7,6,6 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(8,813,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,744,0,0 ) ;
  }
}
