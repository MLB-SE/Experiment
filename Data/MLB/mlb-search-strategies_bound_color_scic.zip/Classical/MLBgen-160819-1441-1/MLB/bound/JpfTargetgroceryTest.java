import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(142,2,395,172 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(159,258,23,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(253,46,440,306 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(25,978,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(284,1,89,337 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(29,534,1387,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(322,134,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(405,12,1,293 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(-414,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(437,342,-130,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(446,739,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(450,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(452,530,71,652 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(47,326,137,201 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(477,248,7,1039 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(489,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(498,-580,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(53,670,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(58,601,323,-995 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(709,455,75,343 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(855,0,0,0 ) ;
  }
}
