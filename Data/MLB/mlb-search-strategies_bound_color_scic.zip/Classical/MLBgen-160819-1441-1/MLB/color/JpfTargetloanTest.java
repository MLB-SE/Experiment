import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(38.71464f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(59.09285f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(97.2731f ) ;
  }
}
