import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(-101,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,777,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(2,1,4,560,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,3,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(3,5,2,9,1,-770,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(3,9,5,4,264,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(3,9,7,-1288,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(4,1,57,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(4,7,1,8,732,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(499,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(5,3,611,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(5,4,6,7,0,848,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(5,615,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(603,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,0,0,161,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(8,1,8,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(8,3,0,4,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,-764,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(8,8,5,3,7,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(8,9,-901,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,4,9,8,-1277,0,0,0 ) ;
  }
}
