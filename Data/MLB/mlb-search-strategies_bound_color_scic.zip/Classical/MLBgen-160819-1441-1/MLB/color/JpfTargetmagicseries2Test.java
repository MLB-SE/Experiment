import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,1,0,428 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,1,1,1 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(1,0,0,3 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(1,0,142,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(1,2,4,-1316 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(1,4,4,788 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(1,946,0,0 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(2,0,1,2 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(2,0,4,2 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(2,1,0,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(3,0,1,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(3,1,2,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(3,2,385,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(3,636,0,0 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(3,-854,0,0 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(4,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(4,1,-160,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(543,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(954,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(-958,0,0,0 ) ;
  }
}
