import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-100.0f,-100.0f,0f,-27.007282f,100.0f,0f,-31.200657f,-97.79535f,-100.0f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(100.0f,-1.2161524f,0f,-80.74948f,-30.60975f,0f,-11.042409f,36.579845f,-48.112225f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(100.0f,77.05344f,0f,34.948914f,76.72018f,65.212036f,16.005829f,29.074404f,23.57161f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-1.0070045f,-78.331566f,-86.296875f,-25.696455f,-92.50503f,49.48607f,-9.273785f,-11.398684f,0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(10.100613f,-99.36516f,0f,5.3993683f,8.801767f,5.8552794f,2.6950922f,5.3810005f,56.406815f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.513624f,45.800014f,0f,-20.817316f,-64.63244f,-9.448407f,-29.15045f,-33.735096f,0f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(10.976396f,-52.90057f,101.95782f,-3.193848f,-29.970964f,0f,-5.7957397f,-19.98911f,-44.18974f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-11.738045f,42.364845f,0f,77.37391f,69.67164f,0f,-14.426957f,-46.371197f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(11.74898f,-56.298363f,32.897766f,3.2942808f,-27.191973f,32.469463f,28.620115f,-88.23328f,35.6421f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(12.009095f,-32.39315f,-56.73266f,-19.570469f,-39.5888f,0f,0.29436317f,20.747921f,-60.148018f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(-12.2511835f,-53.924507f,83.57768f,-95.08023f,-94.926704f,0f,-27.890745f,-39.270985f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(12.729638f,-57.642735f,4.232809f,8.561285f,17.07815f,-16.365387f,4.4373517f,9.188122f,15.236986f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(13.260247f,-68.02026f,25.404863f,21.061258f,-54.20054f,0f,-80.94037f,-10.1535225f,0f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(13.559146f,-40.830914f,44.92682f,-4.9325037f,29.569206f,0f,-62.858368f,0f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-137.33365f,33.42708f,0f,-52.370197f,-59.805458f,81.13639f,-12.340365f,3.0087342f,9.691444f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(139.89519f,-45.995106f,0f,33.132603f,-17.830145f,-56.62472f,10.465603f,8.729809f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(144.58891f,74.78629f,-63.853188f,65.488304f,87.041405f,164.56725f,30.53533f,43.19154f,50.688076f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-1.4663333f,-28.345654f,0f,3.646115f,13.790964f,74.47019f,2.2598293f,5.3932033f,5.52202f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(14.732774f,-33.333466f,-18.15488f,-7.735439f,-41.92431f,100.0f,-3.750221f,-7.2654448f,16.612751f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(15.08238f,-13.925731f,78.52033f,-25.744747f,-54.635284f,0f,-10.431318f,63.114742f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(15.378089f,-11.004161f,-75.89747f,-27.483482f,-100.0f,24.697025f,-25.312016f,-73.76458f,0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(16.118658f,-28.501621f,0f,17.172436f,49.00535f,-52.797253f,3.5657358f,-2.9094925f,-68.056694f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(16.14945f,-57.204006f,48.23285f,21.801805f,-23.07527f,6.6896114f,94.13304f,-63.58849f,1.6008679f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(16.201572f,-28.659388f,-15.6403475f,-6.53432f,-23.249842f,-75.60903f,-19.08901f,-69.82172f,-58.111855f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(17.55661f,-33.38248f,-39.748432f,3.6089256f,2.9758604f,-54.36087f,-6.096769f,96.037865f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(17.929472f,-24.681154f,24.40596f,-3.6009605f,-17.845495f,11.250452f,-14.48782f,-54.35032f,38.44134f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(17.936203f,1.214976f,0f,12.796361f,57.742123f,0f,4.954009f,7.0196757f,-34.617428f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(17.945602f,5.2219286f,-70.30892f,-33.488277f,-135.34346f,12.238746f,-16.809013f,-33.91192f,-87.50847f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(18.10006f,-22.369465f,25.52083f,-5.230297f,-36.58205f,100.0f,-2.439198f,-4.526495f,20.915268f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(-18.395477f,-13.701437f,-54.50247f,-159.88031f,-81.90782f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(18.649466f,-32.721134f,41.34448f,7.3189974f,6.4223666f,42.722588f,4.204158f,9.497634f,57.066357f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(18.940443f,38.03535f,0f,-40.51167f,-98.02713f,-231.22096f,-21.973475f,-47.416897f,-69.814f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(19.155262f,51.8251f,94.488174f,-75.204056f,-47.814957f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(19.53515f,1.5884414f,-65.89569f,-23.447842f,-49.237038f,-81.77276f,-64.08948f,-93.31599f,48.60234f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(19.59897f,-35.753513f,62.815033f,14.149392f,23.071129f,72.32814f,13.927471f,41.560493f,74.21424f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(19.620619f,1.5359588f,51.27752f,-23.053484f,-99.53089f,-50.982826f,-14.1947975f,-33.725708f,-21.177134f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-1.9667394f,99.45702f,0f,3.4424012f,21.747885f,42.90754f,-6.0115414f,-27.488565f,51.126434f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(19.67562f,-3.4270716f,100.0f,-17.87045f,-14.457564f,-100.0f,-76.69985f,73.85944f,0f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(19.794226f,-27.342487f,-11.229188f,6.5193877f,6.274097f,17.674767f,0.009228217f,-6.482475f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(20.321486f,-48.670036f,-78.855f,29.955976f,75.64489f,-15.628717f,23.857529f,-2.2776737f,0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(21.228868f,2.8130875f,-79.64876f,-17.897615f,-68.473656f,11.389078f,-3.5927753f,3.526514f,86.172485f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(21.298359f,17.12372f,-85.28427f,-31.930285f,-93.11885f,0f,-11.31656f,-13.335957f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(21.508514f,3.0432162f,7.637609f,-17.00916f,60.753353f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(21.969202f,44.360355f,0f,0.60548156f,-16.728445f,-100.0f,-2.8185332f,-11.879614f,-27.970041f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(22.24137f,0.38350454f,-8.682972f,-11.418025f,47.271866f,0f,-3.255387f,-1.6035231f,0f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(22.362368f,0.730988f,-19.866179f,-11.281515f,6.9254184f,0f,-9.40322f,-26.331366f,12.848346f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(22.659101f,-26.335312f,-97.092964f,15.452252f,-0.5281358f,-14.867817f,39.678047f,23.638334f,38.149834f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(22.730906f,-52.783188f,100.0f,43.70681f,-11.350085f,0f,-9.206036f,-80.53095f,70.844086f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(23.010159f,-63.73613f,0f,37.233986f,63.43834f,0f,57.22531f,-11.357131f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(23.01833f,-21.412233f,0f,5.883863f,-2.520866f,-3.1343954f,3.037988f,6.2680883f,24.555233f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(23.470106f,46.21623f,-100.0f,-52.335804f,35.718388f,64.29664f,-11.147649f,7.745211f,6.4101067f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(23.627432f,36.83164f,0.19059095f,-42.32191f,18.96586f,0f,-63.357025f,43.64819f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(-23.80614f,-66.72073f,0f,-2.9432015f,74.09794f,0f,-62.0646f,-85.94551f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(23.895494f,19.326452f,0f,34.442642f,96.01863f,26.595837f,17.85645f,36.98316f,34.05755f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(-2.4351628f,-99.70328f,-2.7333546f,-10.037374f,-38.379326f,54.20133f,0.66499454f,12.697351f,88.50374f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(24.648277f,-2.7469103f,40.880238f,1.3400221f,12.66684f,9.355481f,-31.955029f,42.718765f,-16.125153f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(25.030607f,16.057972f,-33.772915f,-15.935539f,-80.48096f,-99.989876f,-8.29181f,-17.231699f,19.84597f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(25.10786f,0.2527248f,60.275326f,0.17872024f,-54.330082f,0f,14.510677f,57.863987f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(25.512028f,-3.9327047f,0f,75.341576f,-72.78487f,0f,93.95674f,9.738914f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(26.277945f,-9.149971f,-67.55038f,14.261748f,0.19793516f,-28.215668f,30.571115f,23.89563f,-27.094082f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(26.75146f,2.0252042f,54.49187f,4.980632f,-7.107393f,-30.648533f,0.27846187f,-3.8642647f,-8.628128f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(26.910442f,77.081245f,0f,-13.840485f,-1.7613574f,46.85281f,-5.2473755f,-7.149017f,-21.587336f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(-27.30857f,-48.809658f,0f,-32.74511f,-89.7348f,-70.99937f,-13.937059f,-23.003128f,11.659355f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(28.024105f,38.038525f,-185.1013f,-25.940006f,-2.9157643f,38.177708f,-128.8656f,-61.947098f,-78.024475f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(28.260538f,7.3972573f,-95.13555f,5.6395373f,-3.5519528f,0.29343215f,-2.146708f,-27.536936f,99.86124f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(28.576965f,30.637249f,-97.0619f,-16.329384f,-3.267595f,21.819092f,-90.62691f,-2.5451248f,0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(28.683517f,12.533212f,-100.0f,2.2008557f,76.905525f,-62.743404f,-96.78562f,94.92601f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(-28.855173f,33.491768f,0f,-32.912727f,-14.494594f,0f,-88.30113f,0f,0f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(28.919167f,8.042831f,-5.7281184f,7.633832f,-0.9388306f,-22.113207f,2.5549924f,2.6812205f,41.531418f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(29.11025f,28.070133f,0f,-26.09083f,-31.471241f,75.913216f,-12.377448f,-23.418962f,-49.82716f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(30.329462f,-18.57458f,100.0f,39.892426f,-20.240622f,0f,22.906214f,51.732433f,74.398506f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(30.416056f,86.27739f,0f,21.681894f,49.062534f,80.9768f,7.248986f,7.3140497f,-27.05532f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(30.834076f,10.719683f,16.986595f,12.60824f,10.619821f,-4.15665f,8.979063f,23.308012f,-10.436406f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(-3.0951686f,-123.2394f,0f,-3.5834699f,-18.419064f,-35.056385f,7.1803527f,32.491684f,100.0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(31.038355f,70.44659f,-66.92502f,-46.293163f,-65.21484f,0f,-21.36949f,-39.18479f,-70.15483f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(31.515144f,35.745815f,-40.1689f,-9.68492f,-42.833584f,-97.39521f,-27.421242f,-100.0f,-84.10238f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(31.631044f,22.093937f,-42.532898f,4.4302406f,-0.72239786f,0f,-12.888929f,0f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(32.320526f,28.73186f,60.598644f,0.55024695f,-14.279561f,-22.490192f,-15.839977f,-63.910156f,55.07617f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(32.36344f,76.58754f,97.15985f,-47.13377f,39.170635f,0f,-3.8994298f,-73.35716f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(32.39916f,11.330113f,6.3788147f,18.266523f,34.74321f,9.377768f,5.923726f,99.998436f,-3.6109543f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(33.848408f,19.16877f,-88.70514f,16.224865f,-9.008907f,-63.096546f,40.05996f,-12.660938f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(33.91865f,19.476484f,18.105633f,16.19812f,14.52694f,37.18095f,16.34689f,-14.747794f,-96.83161f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(34.046032f,-1.259243f,83.87971f,37.443375f,99.91542f,-46.915173f,16.326633f,27.86316f,-4.789419f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(34.14474f,-60.442425f,-30.475025f,22.51289f,-18.95969f,-10.511025f,74.86651f,-27.398197f,-100.0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(34.31533f,36.013588f,-20.48161f,1.2477431f,32.722862f,13.572596f,-62.047222f,80.057526f,-60.444798f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(-3.4807856f,43.10783f,-152.63937f,7.336988f,0.032946855f,-22.278517f,32.79579f,-28.008305f,63.505238f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(34.88434f,-10.397263f,74.776375f,22.086477f,26.984058f,12.423448f,26.477512f,83.82357f,-52.066643f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(34.921734f,-6.9085765f,0f,16.270336f,29.314333f,9.28912f,0.8452762f,-12.889232f,-81.71654f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(-35.02043f,11.577767f,0f,-59.766327f,-55.62833f,0f,-32.058327f,-68.46698f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(3.528917f,-83.76439f,-63.97451f,-32.62597f,-23.225584f,51.652225f,-110.80686f,-28.164198f,-49.47191f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(35.344364f,-13.723849f,-70.477f,55.10131f,51.172146f,64.21525f,14.293451f,2.0724936f,-57.17562f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(35.50241f,-44.095074f,-100.0f,11.524685f,-10.896348f,70.43509f,21.492676f,-81.450096f,-6.055982f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(35.599518f,-212.23557f,-146.26195f,-10.206388f,-60.328175f,19.133886f,-13.689067f,-37.90893f,-79.4222f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(35.65248f,47.345413f,26.899256f,-4.7354846f,-10.659685f,-61.116653f,-43.934734f,-22.807413f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(36.087788f,1.0354046f,-13.794084f,43.31574f,-21.309082f,0f,0.4840407f,-57.007683f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(36.348732f,-4.2316766f,0f,26.476004f,58.48708f,55.072056f,11.068203f,17.796808f,1.631945f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(36.519302f,32.00084f,-13.508865f,14.076365f,12.804015f,96.8268f,6.982147f,20.198387f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(-36.61736f,-17.32393f,0f,-5.7868085f,68.613075f,-54.296665f,-55.142952f,12.612275f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(36.692272f,31.632496f,0f,-8.054729f,-6.7715793f,19.204954f,-62.13961f,-69.86903f,0f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(36.724422f,48.421005f,61.05352f,-1.5233188f,-125.72253f,0f,-2.0584593f,-6.710518f,11.407912f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(3.689755f,-59.346615f,19.32636f,-25.894365f,-99.99995f,-27.886282f,-12.448445f,-23.899416f,16.850729f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(37.04564f,-14.398285f,85.716225f,62.580845f,-59.250713f,0f,-11.079801f,0f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(37.28716f,25.355827f,-92.562996f,23.792803f,50.327793f,50.79438f,7.556261f,6.432241f,-41.52182f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(37.4302f,16.699766f,0f,5.5295296f,14.803189f,-35.93088f,-30.115273f,49.29311f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(37.621304f,-71.38479f,0f,-7.046751f,-90.298744f,0f,-20.735626f,-75.89575f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(-37.970665f,144.40456f,221.85748f,7.1254f,34.76707f,22.864866f,31.705194f,-35.333866f,19.354216f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(38.50393f,-81.24091f,0f,29.071854f,64.88185f,26.886559f,12.901639f,22.5347f,12.355314f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(38.65118f,61.005085f,12.216374f,-6.4003716f,-78.84465f,0f,20.782347f,89.529755f,50.72779f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(39.595375f,-71.71676f,0f,88.59364f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(39.794155f,38.833782f,-61.712624f,20.342844f,26.440845f,4.5720134f,15.136376f,42.014748f,53.559834f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(40.45857f,42.158077f,-43.488316f,19.6762f,7.9778557f,0f,5.8615446f,3.7699785f,16.379913f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(40.620426f,68.13406f,0f,27.147036f,20.77206f,0f,52.17211f,63.578636f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(40.77359f,-54.66193f,0f,-54.334705f,29.452244f,0f,50.095055f,87.034225f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(40.928753f,28.037682f,0f,-68.86672f,37.482563f,0f,-67.65959f,79.30218f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(41.138424f,61.054516f,-99.99865f,3.4991782f,17.365973f,-24.21833f,-44.507683f,29.128529f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(41.345566f,55.647808f,20.764687f,9.734454f,7.617129f,14.91652f,-10.023953f,-49.830265f,31.284267f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(41.75252f,55.61516f,0f,20.796804f,45.665886f,54.575554f,-4.2311883f,-37.721558f,-100.0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(42.462166f,39.155003f,-69.270195f,30.693659f,50.00317f,-62.625946f,30.309301f,90.54355f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(-42.813065f,19.140303f,0f,-25.812162f,-36.677906f,0f,-3.5952835f,11.431028f,-35.31478f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(43.12262f,31.55502f,-131.56163f,40.75402f,-198.82732f,-18.719603f,-3.68436f,-55.41826f,-18.763721f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(43.123722f,33.723896f,15.041418f,38.770996f,44.520996f,12.440689f,67.43926f,100.0f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(4.314526f,-20.594261f,-76.46917f,-62.147636f,-3.8446848f,21.114244f,-15.201267f,1.3425655f,24.416214f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(43.24267f,24.786768f,-100.0f,48.1839f,84.49875f,-13.371343f,64.99418f,3.6934776f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(43.590286f,84.00387f,38.768215f,-9.64272f,-53.756092f,0f,-28.405075f,0f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(43.79965f,71.01842f,38.75863f,4.180172f,6.2943225f,43.784313f,-33.373283f,-100.0f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(-43.90406f,24.9432f,0f,-6.2348676f,-10.820105f,-17.276308f,29.784693f,-44.71244f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(44.146046f,18.784946f,0f,28.681978f,43.611427f,0.54629713f,26.970438f,-23.077612f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(45.203026f,-1.5556629f,-195.23111f,82.367775f,-45.456055f,0f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(45.529552f,50.716118f,-93.4216f,17.363934f,22.98181f,37.433647f,0.9443688f,-13.586458f,-78.27201f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(45.563503f,42.140648f,-95.776764f,40.113358f,99.12045f,0f,17.572582f,30.176973f,75.28962f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(46.14712f,57.038235f,-40.86432f,27.55025f,46.928143f,-99.53333f,17.125736f,40.952694f,99.7569f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(47.67188f,66.712685f,-36.47039f,23.97483f,29.765593f,-11.282882f,18.46185f,39.657738f,-36.004498f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(47.733215f,87.27365f,-51.13256f,3.6592155f,18.798088f,2.936688f,-51.894444f,-18.677202f,44.081226f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(48.003372f,-68.63902f,81.84914f,8.782886f,-8.148644f,54.93719f,-4.723186f,-27.675629f,-19.21459f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(48.213413f,44.584324f,0f,10.326977f,-81.19092f,90.14352f,0.028692033f,-10.212208f,40.313396f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(48.22204f,67.39665f,-100.0f,25.49151f,53.86619f,-44.2464f,-0.12219242f,-25.98028f,-28.147215f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(48.3106f,61.979355f,55.74387f,31.263052f,-24.106915f,0f,5.1465716f,-10.676766f,-23.746723f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(-48.453438f,65.46001f,0f,-22.60364f,20.704992f,-54.107475f,-62.66611f,94.07108f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(49.19182f,70.34753f,-100.0f,26.419752f,0.7949557f,-42.625668f,55.692234f,-50.96179f,4.5458555f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(49.955414f,3.6505203f,0f,-0.49295583f,-45.606693f,0f,-6.3205414f,-24.78921f,-47.229603f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(50.207203f,0.8618108f,0f,99.96701f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(-5.033852f,-72.09083f,14.025078f,-48.04458f,96.56846f,-85.434746f,-7.496957f,18.05675f,-16.8445f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(50.68398f,100.0f,97.22682f,2.7359192f,-34.826187f,-100.0f,-4.9141154f,-22.39238f,100.0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(50.70575f,89.07306f,14.706594f,13.749942f,25.411404f,7.0150743f,5.6233897f,8.743616f,3.9396727f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(50.949593f,4.181891f,0f,-5.7253046f,23.714258f,-100.0f,4.9500313f,25.52543f,73.43743f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(51.092487f,-6.668704f,-0.10613861f,13.646038f,0.57183826f,-2.7232356f,2.9198232f,-1.9667451f,-11.358642f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(-51.350082f,-19.635838f,0f,-18.37389f,39.22371f,44.78418f,-61.36919f,-37.795994f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(-51.353943f,98.94078f,0f,-1.4157691f,48.208656f,-1.5022032f,-2.5177903f,96.81182f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(-51.551777f,-20.43551f,0f,-15.364907f,-4.931463f,62.84516f,-4.97639f,-4.540652f,-8.254753f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(-52.831223f,10.397711f,0f,-16.361767f,-12.115392f,-56.857456f,-0.5004563f,14.359942f,70.05562f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(53.03091f,79.186325f,0f,12.513123f,-32.899902f,0f,29.921484f,0f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(53.27567f,-17.31184f,0f,-81.69893f,-82.156876f,0f,12.480542f,0f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(53.45115f,74.972374f,0f,31.230785f,-78.359726f,0f,-28.55652f,0f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(55.51462f,78.56891f,52.72119f,43.48958f,19.81919f,-8.286426f,98.624504f,-1.102234f,0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(55.84953f,66.82456f,62.517906f,56.573563f,22.970999f,0f,21.909857f,66.3221f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(55.90484f,38.895332f,-5.9584036f,22.419977f,8.740883f,-4.8506784f,25.034187f,-21.5011f,54.064404f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(55.93027f,-99.29768f,100.0f,1.308286f,-47.738678f,-79.82321f,-2.9584522f,-13.142095f,-47.85085f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(56.424717f,-57.08022f,0f,17.119865f,-29.367752f,-10.0302515f,41.422497f,-28.44011f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(-56.78599f,9.7505045f,0f,-26.8745f,-35.90225f,-24.294245f,-14.809762f,-32.364548f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(57.329834f,72.16047f,37.504578f,57.158863f,-88.1135f,0f,12.652891f,-6.547299f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(57.6293f,-41.850613f,-41.442444f,8.009767f,-12.789667f,-43.682503f,-12.800565f,26.36468f,100.0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(-58.65886f,-99.99679f,0f,-19.115503f,-10.171119f,-99.976875f,-7.632034f,-11.412632f,-27.847376f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(-59.01754f,-22.706402f,0f,23.800287f,41.770073f,0f,-11.591888f,-70.16784f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(59.12175f,83.68512f,-65.71546f,52.80188f,84.94949f,-0.7529337f,67.13627f,4.240169f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(59.95573f,36.40984f,0f,36.77519f,57.087456f,-62.81017f,30.057562f,83.455055f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(-60.916058f,20.573793f,0f,-23.35068f,-95.3606f,-14.387009f,62.87394f,70.08215f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(61.001293f,99.999344f,99.40946f,23.784143f,31.19197f,12.995303f,2.9433093f,-12.010906f,-78.62022f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(61.561165f,65.03325f,0.886629f,81.21141f,73.80674f,17.04088f,30.508987f,40.824543f,58.982445f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(-62.32099f,30.002558f,0f,-76.13816f,-16.26174f,65.90157f,-17.533306f,6.0049357f,57.81479f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(63.017323f,-5.1806636f,0f,-87.1474f,-29.701933f,0f,-3.4489336f,73.35167f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(63.794643f,68.21404f,-32.719604f,86.96454f,9.859672f,0f,-15.753658f,0f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(-64.28642f,88.85911f,0f,-39.570633f,-76.30106f,-92.158676f,-17.695044f,-31.20954f,-30.842052f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(-64.43546f,-2.1769664f,0f,-61.355335f,32.273945f,0f,-1.0695524f,0f,0f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(6.4463134f,-74.14848f,41.500206f,-0.06626209f,85.86279f,0f,68.61668f,0f,0f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(64.70805f,31.63936f,0f,41.533146f,-60.83691f,0f,-89.73404f,-92.8803f,0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(-65.43286f,-195.83519f,0f,-27.17437f,-26.422403f,-167.23082f,-16.985586f,-41.11345f,-121.10869f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(65.75484f,-31.01022f,-95.21881f,22.974384f,6.210087f,-23.879898f,19.932617f,56.75608f,-31.332382f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(-65.7896f,17.182247f,0f,0.45666564f,-61.95089f,0f,24.103657f,95.95796f,-19.078138f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(-65.951775f,-85.98034f,0f,-16.255585f,-0.8009509f,-15.242897f,1.7303873f,-78.28682f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(6.621497f,-81.64802f,32.735455f,8.134009f,27.544992f,17.33605f,-1.6304522f,-14.655818f,-93.53795f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(69.638824f,92.00198f,44.214214f,86.55333f,-2.5361106f,56.872265f,17.2066f,-17.726927f,-85.57819f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(69.75377f,-10.156508f,-5.2807536f,24.512352f,12.238268f,-5.400136f,16.057377f,39.99736f,-28.558058f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(71.18684f,-26.717083f,-90.186806f,1.228555f,-42.045055f,-44.552906f,-24.22756f,-98.138794f,-89.034195f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(71.20562f,59.958836f,47.278088f,19.281488f,1.1221546f,-74.66296f,4.798184f,-0.088753864f,-6.275354f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(72.21914f,34.842484f,-2.98398f,9.961562f,-18.636793f,-54.44528f,-13.736094f,-64.905945f,-13.493074f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(74.10323f,-9.812584f,0f,-34.51589f,100.0f,0f,-5.442236f,12.746943f,-43.56999f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(74.19652f,27.177605f,-65.304955f,25.036106f,35.509655f,11.382063f,-9.561743f,78.44284f,75.32355f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(-75.47354f,17.942402f,-78.66896f,9.473882f,24.738943f,-26.170784f,88.63013f,97.71027f,-98.9018f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(7.654763f,-33.131256f,91.44105f,-36.249687f,11.784359f,0f,-15.5476265f,-25.940817f,-100.0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(76.60922f,42.26507f,0f,43.2732f,92.15595f,-64.445854f,4.3276362f,-75.83626f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(-77.176186f,-57.495136f,0f,7.032644f,-78.97035f,0f,-11.804758f,-54.251675f,9.480114f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(77.201584f,30.86235f,0f,-77.2415f,13.263397f,0f,-21.191343f,-7.5238714f,11.780222f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(-77.66864f,70.53422f,0f,32.348213f,48.29195f,66.40282f,10.862237f,11.100734f,-14.751251f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(-80.29849f,-3.5897174f,0f,26.544025f,31.847822f,0f,-7.885871f,0f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(-81.80553f,12.255631f,0f,-25.770155f,-15.705202f,-52.796894f,-5.5698867f,3.490607f,-23.406712f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(-82.261406f,-25.314453f,0f,-27.523964f,-14.08976f,23.934174f,-13.744691f,-27.4548f,68.541916f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(82.44393f,-100.0f,0f,2.127218f,-51.556892f,0f,-22.378168f,-91.63989f,2.6241317f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(82.44976f,77.80845f,0f,66.65183f,56.910305f,0f,37.392597f,82.91855f,22.350887f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(8.807307f,-50.667507f,-23.52439f,-14.103262f,-74.15653f,-15.318155f,8.936174f,49.84796f,-32.33513f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(-88.7007f,-100.0f,0f,52.51829f,-92.862755f,-70.069954f,8.638539f,-17.964136f,12.367674f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(8.877914f,-48.324287f,-20.223207f,-16.164055f,-11.180291f,-8.043817f,-62.353844f,27.810993f,37.82442f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(-88.815926f,-19.885199f,0f,54.372864f,27.542067f,0f,13.244664f,-1.3942077f,-46.36356f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-89.17691f,72.356476f,0f,-4.465412f,49.28235f,-55.462887f,22.03291f,92.59705f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(-89.24256f,2.576139f,0f,45.486958f,-47.896564f,-36.94847f,8.103029f,-13.074841f,-12.505828f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(90.037895f,-16.912163f,0f,90.81202f,-40.49737f,-12.466746f,20.479572f,-8.89373f,-15.55712f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(90.23893f,-55.44243f,27.807114f,26.105814f,4.6294036f,35.740364f,9.55492f,12.113867f,34.27114f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(90.48169f,89.491875f,0f,-12.116754f,-52.22175f,64.978584f,-86.72695f,44.550323f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(91.739975f,-68.42519f,90.418655f,41.373558f,-26.245749f,3.1009722f,100.0f,-81.032326f,7.3874564f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(92.016655f,11.597025f,0f,63.800266f,-14.058159f,-24.5636f,15.646567f,-1.213998f,-6.4444f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(-93.51528f,-92.68772f,0f,-36.903538f,-49.4212f,-86.28643f,-4.6776648f,18.192879f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(-93.88265f,64.908844f,0f,-78.17515f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(-96.34211f,71.28998f,0f,-15.563209f,-1.3638499f,-32.84895f,35.453125f,45.521202f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(-96.39547f,-96.0732f,0f,-22.908537f,7.45629f,100.0f,-2.6949675f,12.128667f,43.753345f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(-97.9411f,74.83904f,0f,-28.962269f,-3.299295f,5.1616406f,-14.608683f,-29.47246f,-99.981865f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(99.160034f,3.6868641f,0f,26.194094f,-91.32994f,55.122875f,96.94628f,97.63491f,0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(99.80041f,63.584984f,68.75738f,43.861485f,48.020267f,17.995058f,27.625257f,66.63954f,-44.797417f ) ;
  }
}
