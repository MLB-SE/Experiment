import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(2,148 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(-25,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(2,918 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(358,0 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(360,0 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(4,0 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(4,2 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(5,-338 ) ;
  }
}
