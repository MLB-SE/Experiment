import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-799,2316,-863,-629 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-808,-115,551,911 ) ;
  }
}
