import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-291,-414,-791,499,672,-183 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(36,-298,-814,7,-1173,-70 ) ;
  }
}
