import org.junit.Test;

public class JpfTargetDartTest {

  @Test
  public void test0() {
    concolic.DART.test(0,0 ) ;
  }

  @Test
  public void test1() {
    concolic.DART.test(1,0 ) ;
  }

  @Test
  public void test2() {
    concolic.DART.test(-142,0 ) ;
  }

  @Test
  public void test3() {
    concolic.DART.test(214,0 ) ;
  }

  @Test
  public void test4() {
    concolic.DART.test(-311,0 ) ;
  }

  @Test
  public void test5() {
    concolic.DART.test(457,0 ) ;
  }

  @Test
  public void test6() {
    concolic.DART.test(605,10 ) ;
  }

  @Test
  public void test7() {
    concolic.DART.test(936,-280 ) ;
  }
}
