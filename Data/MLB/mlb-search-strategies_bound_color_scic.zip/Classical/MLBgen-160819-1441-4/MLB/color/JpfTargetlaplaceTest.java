import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.25653324f,-99.15969f,-55.61563f,-1.8664414f,-47.31021f,-12.724972f,40.10098f,-75.489746f,52.025955f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.46896434f,-29.03848f,25.8973f,-72.83738f,-12.723768f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.5132319f,-83.34505f,0.50000995f,-18.707884f,-58.99824f,0f,-78.58041f,0f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-0.71785957f,-13.347094f,0f,94.35165f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(0.8416925f,1.657545f,0f,4.9557037f,44.341354f,39.039505f,-25.360233f,-47.26459f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-14.531677f,0f,1.4888237f,99.96166f,-84.748856f,5.9936295f,22.485693f,88.25091f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(100.0f,22.420568f,0f,62.619446f,44.72295f,20.2368f,21.227203f,22.289366f,23.20731f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(100.0f,-26.289078f,24.632036f,12.669306f,-9.389565f,3.380564f,-39.933212f,-27.319054f,-1.7202151f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(100.0f,26.618002f,0f,57.40113f,-74.50497f,0f,5.3125463f,-36.150948f,33.932377f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-100.0f,29.24298f,0f,-52.27282f,40.6813f,77.22137f,-9.716887f,13.405269f,22.656658f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(10.336897f,46.268467f,0f,56.027584f,-86.87621f,0f,43.550827f,-96.25793f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(10.641145f,36.22035f,-62.53305f,-93.65577f,96.77331f,-3.6676319f,-15.005803f,33.63256f,52.762737f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-10.894933f,-36.013992f,-100.0f,-12.466151f,-2.554381f,34.898594f,-36.41529f,3.3640237f,34.462208f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(10.948642f,-72.33706f,-52.297405f,16.131626f,-3.916917f,51.752712f,57.49478f,-11.214948f,-18.058187f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(11.035909f,-28.668495f,-15.952256f,-27.187868f,-100.0f,66.60392f,-19.78738f,-51.961235f,-88.057556f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-11.070983f,-40.701965f,-98.80026f,-19.51324f,-42.899395f,-36.008045f,-23.842993f,-75.858734f,-20.423092f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(11.119605f,12.530268f,31.904148f,-68.05185f,-92.90268f,15.086319f,-30.842712f,-55.319004f,-97.530624f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(11.6667f,-51.04754f,-1.5385131f,-2.7518582f,-16.730148f,7.9028907f,-5.9439855f,-21.024084f,-61.422203f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(11.927231f,-64.556465f,4.302946f,3.1805766f,-0.6079894f,56.512245f,1.4030652f,2.4316845f,26.419722f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(-12.396153f,-59.63313f,0f,-32.3302f,-91.19013f,-6.01016f,-25.734516f,64.83675f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(1.253891f,-87.45313f,-8.804442f,-16.345474f,-66.62578f,-88.21414f,-0.010007889f,-74.49036f,-58.035873f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(-12.588107f,59.37826f,0f,-26.079947f,-69.836365f,0f,41.870266f,-83.748825f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(12.605798f,-60.023098f,52.269157f,10.446287f,2.2519412f,52.29335f,26.92741f,6.2912254f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-12.68987f,10.938925f,0f,-63.87835f,-51.056873f,0f,0.84889364f,95.75235f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(12.7997875f,-61.889423f,35.033485f,13.088573f,7.9086957f,37.083874f,31.645813f,6.1469398f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(12.978546f,11.074761f,0f,-95.1821f,42.948483f,0f,-37.122997f,-53.309895f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(13.2428465f,-56.509693f,-36.96943f,9.481077f,22.865044f,0f,7.300629f,19.72144f,48.720085f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(13.384063f,-52.625427f,-100.0f,6.161678f,48.68307f,-100.0f,-37.42042f,7.917363f,0f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(13.422197f,-44.809704f,0f,-4.1589293f,3.3380234f,13.248698f,-33.39594f,49.07203f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(13.820066f,-18.48033f,6.0324078f,-26.239405f,-20.187498f,0f,-13.066952f,-26.028404f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(14.033082f,-100.0f,0f,7.5178075f,12.756508f,19.978703f,3.28164f,5.608753f,6.396864f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(14.078295f,18.596f,6.034643f,-62.28282f,-45.72894f,-41.6267f,100.0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(14.552808f,-20.534727f,-96.69172f,-21.25404f,-100.0f,-42.782734f,-7.984036f,-10.682105f,65.255615f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(14.732219f,58.928875f,78.11237f,-100.0f,21.22479f,0f,-63.358604f,38.79546f,0f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(14.793038f,-3.0889416f,-100.0f,-37.738903f,-38.640858f,0f,-8.092325f,5.3696055f,68.21161f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(14.86317f,17.665043f,45.76871f,-58.212364f,-89.97171f,65.409805f,9.342985f,95.584305f,0f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(14.891929f,-29.012486f,-46.612144f,-11.4198f,-58.418972f,0f,90.76206f,-30.637003f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(-14.894169f,4.188503f,73.52315f,-7.0307827f,-0.064869925f,22.966866f,-13.164092f,-20.384066f,18.409187f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(15.145404f,-31.391634f,-3.5082557f,-8.026763f,-30.670053f,-24.959093f,-16.582403f,-58.302704f,-65.658066f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(16.560139f,-11.365287f,-87.13103f,-22.394157f,-74.89026f,-32.629818f,-30.59854f,-100.0f,-54.596558f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(16.903566f,0.81631076f,-90.14302f,15.4191f,33.378918f,87.123695f,11.393915f,30.15656f,-56.586044f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(17.108608f,23.431606f,32.774025f,-54.99717f,-56.156208f,7.6644893f,-9.531805f,16.86995f,-60.671494f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(-1.7136669f,-90.16247f,-21.44669f,-16.6922f,-81.69414f,-48.046192f,16.639006f,83.24822f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-17.190165f,-70.1755f,-40.31188f,-98.58516f,100.0f,0f,-66.33758f,86.16471f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(-17.518085f,28.663551f,0f,-13.5184355f,12.929613f,0f,6.9420223f,41.286526f,38.766f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(17.86045f,35.827717f,-78.087326f,-64.38592f,16.466156f,0f,42.189854f,0f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(17.87994f,-39.437958f,36.88739f,11.1641035f,8.650743f,1.6146021f,18.110056f,61.262222f,-39.079727f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(19.040897f,42.147045f,64.43346f,-65.98346f,-14.8861685f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(19.661469f,-29.806385f,-31.659403f,8.452257f,10.14469f,56.7981f,4.00287f,7.5592227f,16.08933f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(19.894506f,-37.71687f,-93.79663f,0.039405536f,-18.226925f,-29.15102f,-1.5099514f,-6.079395f,-4.5807023f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(-20.101328f,42.006615f,0f,-2.5621262f,11.277657f,-15.26128f,-1.4248322f,-3.137203f,-22.401636f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(20.107391f,-6.1510344f,5.009315f,-13.419403f,-14.915321f,-99.999344f,-58.86968f,59.908493f,41.6503f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(20.17223f,-4.1057453f,-59.36858f,-15.205405f,-77.226555f,-77.77577f,-3.7672288f,0.13648953f,81.5398f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(20.2181f,69.36588f,72.03397f,-88.493484f,-4.9503617f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(-20.320942f,26.199661f,0f,-61.8233f,-50.081715f,-82.26803f,-24.900293f,-37.77787f,-76.12948f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(-20.32304f,-12.008732f,0f,-23.021324f,-69.62749f,0f,-2.1347716f,0f,0f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(20.494463f,-23.67632f,35.472973f,-0.5831797f,-24.263086f,-79.119644f,1.4359038f,6.326795f,20.208914f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(20.958134f,2.681633f,-25.046701f,14.944606f,-20.76661f,-38.318077f,59.5869f,-62.3746f,-14.342729f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(21.129438f,14.48181f,38.2319f,-30.038637f,-143.89236f,42.432396f,-21.795687f,-57.144108f,-63.453827f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(2.1491983f,-100.0f,100.0f,-12.619284f,-36.60268f,41.900978f,-16.023653f,-75.69241f,98.30184f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(21.700903f,33.429752f,-15.988838f,-46.626144f,-100.0f,0f,-14.680064f,-12.094113f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(2.1968994f,-52.797337f,0f,-71.60229f,70.09454f,0f,-18.547535f,-2.5878525f,89.29056f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(-22.059204f,-91.13283f,-51.245693f,-97.10399f,21.892328f,93.32232f,-17.969152f,25.227383f,96.98635f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(22.380968f,-10.828486f,-49.69231f,0.3523623f,-9.010064f,-7.8411775f,-11.961455f,-17.722956f,27.337667f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(22.40027f,-17.50654f,-218.45381f,7.2938733f,-23.794283f,-15.464762f,28.802792f,-69.25788f,27.18554f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(-22.415014f,-109.28532f,64.95699f,-80.37156f,-6.3744307f,0f,-19.52765f,2.2609503f,100.0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(22.567575f,9.894065f,-81.92869f,-19.623762f,-1.0626243f,55.35841f,-100.0f,-49.87921f,99.773384f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(22.65077f,-92.05933f,0f,-9.917605f,-43.11738f,-54.85072f,-19.203815f,-66.89766f,0f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(22.899508f,-9.101437f,-97.94048f,0.69946563f,-93.758766f,77.503105f,73.65713f,1.7276717f,0f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(23.212189f,4.1003404f,-90.83004f,-11.251586f,-15.980788f,-27.951523f,-52.237743f,-28.820383f,25.93598f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(23.44439f,-0.29292262f,-96.51676f,-5.9295177f,-29.5716f,-66.1526f,-17.590862f,-64.81241f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(23.94476f,16.3746f,41.18017f,-20.595562f,-99.626526f,-62.88968f,-6.9209924f,-7.088409f,78.193886f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(24.050518f,-14.897719f,11.605773f,11.099791f,59.642723f,0f,-41.582314f,-51.140846f,0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(24.072487f,20.325186f,82.11252f,-24.03524f,-49.62162f,-65.24714f,-70.59183f,63.804554f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(24.204111f,1.9916444f,13.745503f,11.652589f,16.552666f,40.804703f,5.85358f,11.76173f,24.640676f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(24.561909f,32.08708f,-4.405108f,-33.839443f,8.191512f,-85.29262f,-3.3733835f,20.34591f,-24.34454f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(24.620949f,50.39843f,0f,-51.91464f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(24.647448f,24.419994f,100.0f,-25.830202f,73.03526f,37.269485f,-2.035349f,17.688807f,-0.24468544f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(24.680166f,-28.444387f,-50.971634f,27.165049f,92.29696f,-84.03973f,-8.316933f,41.194843f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(25.18948f,-7.9197083f,-34.4397f,8.677629f,5.2452626f,3.5400162f,4.2757764f,16.683111f,39.223095f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(-2.522055f,-94.27477f,-4.000527f,-15.813441f,-35.66468f,51.884163f,-25.067028f,-84.45467f,-100.0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(25.576176f,21.503292f,52.822285f,-19.198587f,-92.38529f,80.20095f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(25.646957f,10.7192745f,-6.263324f,-8.131447f,-76.50654f,99.99761f,18.333794f,81.46662f,68.500404f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(25.663689f,2.8491323f,27.986835f,-0.19438103f,-85.970024f,32.921257f,-2.0703542f,-8.087035f,55.692234f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(25.796726f,7.0027494f,-99.896996f,-3.8191376f,-32.150425f,-100.0f,-8.914664f,-31.839518f,-86.300835f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(25.931036f,-64.45238f,-84.839195f,68.17652f,15.666115f,79.85971f,20.781794f,14.95065f,23.354692f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(26.05609f,20.763815f,-69.48166f,-16.539457f,-27.418596f,-18.60768f,-64.79533f,-95.29106f,-42.697205f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(26.437302f,45.186676f,71.14347f,-39.437473f,-16.834068f,32.293835f,-7.1725073f,10.747443f,0f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(26.45277f,21.006865f,-26.61969f,-15.195782f,-17.114042f,-25.249847f,-70.12186f,-49.017403f,-57.265656f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(26.53354f,64.744095f,72.45536f,-58.609932f,-66.477516f,0f,12.881895f,87.60208f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(26.695938f,4.301811f,51.39096f,2.481941f,-13.079568f,-60.58963f,-3.6886058f,1.4876072f,91.97339f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(26.888899f,15.019762f,8.942568f,-7.464166f,-75.75242f,-79.24949f,19.006855f,69.24727f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(2.7240062f,-100.0f,-55.875786f,10.896025f,-54.723255f,0f,12.1543255f,37.721275f,79.4035f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(27.486593f,41.1856f,64.059326f,-31.239231f,-26.803518f,100.0f,85.60061f,0f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(27.514431f,12.81854f,-42.763264f,-2.7608132f,-33.477013f,-69.1274f,-5.080672f,-74.83837f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(27.608608f,12.037672f,-60.920597f,-1.6032381f,-27.917074f,-100.0f,-6.104487f,-22.814709f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(2.7912261f,-77.09769f,-48.399834f,-11.737408f,-57.876965f,32.331432f,8.1361065f,-24.855284f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(27.915712f,17.732374f,-25.099796f,-3.4929535f,-31.411144f,-256.52142f,-10.781196f,-39.631832f,-115.96219f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(27.917234f,1.3103771f,-100.0f,10.358561f,9.666932f,72.17796f,3.8500745f,5.041738f,100.0f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(27.96451f,19.356417f,-12.591931f,-7.4983773f,-37.94691f,-98.315765f,-20.011106f,-51.274406f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(28.165503f,37.472103f,66.66638f,-24.81009f,-44.943474f,-92.31965f,-44.578644f,-49.374046f,0f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(2.8285177f,-89.27976f,-57.367092f,0.59383076f,8.613601f,77.11773f,-9.066795f,46.022602f,70.09205f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(28.337225f,11.308656f,-94.77082f,2.0402431f,11.668219f,-97.41071f,-31.844471f,100.0f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(28.41446f,32.378433f,83.099304f,-18.720596f,-82.00003f,21.881903f,-21.412569f,-66.92968f,-6.527713f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(28.708487f,36.72069f,71.15318f,-21.886747f,72.24953f,0f,-29.91479f,0f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(28.736742f,18.380596f,-5.209344f,-3.4336283f,-50.005013f,-62.12118f,7.533759f,33.568665f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(28.854551f,-43.54843f,0f,17.494139f,32.82888f,96.08573f,8.293126f,15.678365f,21.591454f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(29.657036f,21.204477f,-20.174145f,-2.5763338f,-24.664986f,55.583145f,-15.297385f,-58.61321f,-5.5245223f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(30.349094f,32.308567f,80.62601f,-10.912187f,-81.74084f,25.357939f,7.742991f,62.420578f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(30.435179f,8.443844f,3.3401961f,13.296868f,-100.0f,-100.0f,-0.15662892f,-13.923384f,-24.268597f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(30.552916f,-30.420372f,36.993748f,-6.8152685f,-32.20578f,4.0300984f,-25.608212f,-95.61758f,-46.61906f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(30.619913f,40.504616f,47.913857f,-18.024963f,-16.515305f,38.040028f,-0.5600299f,15.784843f,80.21471f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(30.648514f,0.6691568f,-32.428623f,21.924898f,2.1544168f,26.399029f,54.89666f,-6.953378f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(31.142778f,23.479307f,-10.231068f,1.0918068f,-26.844685f,100.0f,0.069133095f,-0.8152744f,-87.55605f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(31.15408f,36.612526f,26.327555f,-11.996209f,-11.03153f,-53.672092f,-6.845021f,-15.383875f,9.525009f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(31.299433f,32.05167f,23.659836f,-6.8539405f,-26.752594f,-44.50208f,-31.9626f,-84.19144f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(31.72324f,46.058857f,12.346881f,-19.165895f,40.165306f,-67.300446f,-4.128322f,2.6526065f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(31.733692f,41.45713f,-20.272902f,-14.522365f,-47.67937f,0f,-42.14378f,0f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(-31.752232f,2.777684f,0f,-13.8339205f,-16.117147f,65.14688f,-7.466301f,-16.031282f,-40.541683f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(31.764477f,-72.07624f,0f,-51.324364f,15.43222f,0f,-11.557983f,5.0924306f,16.495485f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(32.232815f,17.172989f,-53.36018f,11.758305f,-10.180686f,-30.291245f,24.981087f,-39.362762f,-57.62411f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(32.379925f,43.278923f,139.30217f,-13.7873745f,-98.570244f,-77.893196f,11.359656f,59.226f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(32.411205f,6.758463f,-96.50603f,22.886353f,-12.920115f,-26.33993f,72.05432f,-54.985348f,4.0664215f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(-32.507763f,-67.03459f,-6.042849f,0.7765162f,20.783184f,90.84476f,14.830643f,58.546055f,39.105946f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(32.602745f,7.728122f,-50.110466f,22.412453f,45.219734f,0f,-44.004105f,-198.39696f,97.47516f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(32.66773f,40.64204f,49.16708f,-9.971123f,-19.266645f,56.02627f,-53.285576f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(32.77938f,35.81052f,47.498295f,-4.693003f,-37.035587f,54.18266f,96.24128f,0f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(33.12509f,42.50365f,38.929634f,-10.003291f,-2.0401235f,-5.154263f,-71.09813f,0f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(3.3435073f,-72.562614f,38.453056f,-14.063354f,-55.276566f,-33.79091f,-4.3203573f,-3.218075f,46.72462f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(33.629463f,39.180485f,0f,-4.844009f,-51.926838f,-5.099217f,-1.0786601f,0.5293684f,59.59032f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(33.78112f,19.591509f,23.683712f,15.532972f,-79.0988f,-24.856659f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(33.834072f,24.93225f,31.540606f,10.404045f,-65.64568f,100.0f,-4.947345f,-30.193424f,-63.16302f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(33.906647f,37.54133f,33.920025f,-1.9147428f,-17.66136f,-1.8612348f,-23.904259f,-93.702286f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(34.175014f,27.696579f,-34.280468f,9.003479f,2.5339186f,-100.0f,-0.6950177f,-11.783549f,-10.23849f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(34.57692f,28.960499f,-20.159575f,9.347181f,1.4246529f,-100.0f,0.81975585f,-6.0681577f,-26.51704f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(34.632828f,20.793056f,-78.09556f,17.738256f,19.739704f,-8.156235f,16.5805f,48.58374f,-35.99884f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(34.695763f,45.35331f,32.362778f,-6.570257f,14.354692f,-15.90219f,-75.33148f,17.607328f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(34.83538f,26.006388f,-46.352222f,13.335137f,15.542396f,24.312054f,2.962775f,-1.4840382f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(34.883633f,36.11345f,77.52046f,3.4210784f,-67.9503f,-61.580196f,-16.645338f,-70.002426f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(35.02003f,23.90247f,-55.636036f,16.177654f,16.225885f,58.964924f,13.464699f,-34.36482f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(35.07269f,43.69198f,31.231659f,-3.401215f,5.926316f,-94.2188f,-54.603867f,77.6333f,-48.12344f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(35.23939f,18.277067f,-60.973812f,22.680504f,-5.971996f,-0.36450756f,5.7690616f,0.39574248f,1.7859042f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(35.881557f,46.1746f,33.354298f,-2.895335f,25.526316f,-12.856647f,-73.164474f,71.98075f,-110.35728f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.907433f,21.770634f,-99.715744f,21.859089f,41.534554f,65.65996f,9.994371f,18.118378f,20.944584f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(35.99912f,18.523438f,57.97979f,25.473036f,65.22661f,0f,8.509261f,8.564008f,-48.69252f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(36.069023f,40.943417f,32.960617f,2.7750452f,-8.306456f,-7.5196905f,-16.662386f,-69.42459f,-40.86238f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(36.413815f,37.549442f,-67.3549f,8.105811f,-2.9350119f,-45.06727f,-1.0555556f,-12.328034f,-79.17101f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(36.759182f,4.599004f,53.019566f,41.88796f,-169.67513f,108.62398f,-14.24765f,-99.22493f,144.34242f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(36.810173f,51.4732f,46.957256f,-4.2325025f,22.125376f,37.694252f,-70.718315f,40.395557f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(37.352287f,54.438187f,-19.26255f,-5.029034f,-67.744095f,13.407582f,10.275665f,46.131695f,50.200268f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(37.355137f,30.634056f,-36.297283f,18.78649f,21.478369f,35.642334f,16.312456f,55.593376f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(37.613995f,68.39252f,99.95143f,-17.936533f,-90.243f,87.000916f,-19.11713f,-58.53199f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(37.726902f,19.41143f,33.29956f,31.496172f,1.2121994f,0f,6.428788f,-5.7810197f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(37.841114f,31.427166f,-2.0308774f,19.937292f,-10.101573f,56.77208f,52.00963f,84.922516f,0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(38.140816f,53.046013f,0f,-97.78573f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(38.226315f,44.661457f,53.660503f,8.243802f,-13.240995f,69.98056f,7.7420444f,22.724375f,29.042233f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(-38.395496f,-67.00766f,0f,-54.403088f,-58.513454f,-100.0f,-16.66429f,-12.254072f,26.161453f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(38.459232f,68.10214f,0f,18.43084f,100.0f,0f,8.452384f,15.378698f,-15.4995365f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(38.504078f,42.81768f,13.814111f,11.198623f,18.641869f,3.7120645f,-12.351452f,16.839104f,-17.607721f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(38.594604f,29.596815f,11.944061f,24.781609f,-32.151405f,-81.82057f,-0.55814785f,-27.0142f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(38.91934f,101.743675f,-142.82887f,-46.038635f,-58.289135f,0f,-28.858585f,-69.649124f,-191.47565f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(38.971985f,32.81654f,40.396664f,23.0714f,-58.48482f,48.056778f,2.860509f,-11.629364f,9.1068535f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(-39.013077f,12.252578f,0f,77.65206f,1.7006072f,0f,19.063879f,-1.3965462f,-16.349724f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(39.375317f,49.037056f,60.68933f,8.464204f,-3.9164236f,-99.69149f,-1.6020758f,-14.872507f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(39.500668f,42.038002f,-44.703423f,15.96467f,20.965372f,14.141702f,3.3926418f,-2.394103f,-33.934425f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(39.72756f,62.72577f,47.76401f,-3.8155336f,-50.524918f,0f,-6.9489408f,-23.980228f,-38.447056f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(39.746853f,53.17559f,19.3369f,5.811819f,53.618607f,5.5442734f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(39.85042f,37.817135f,-16.962484f,21.584553f,28.380608f,46.0065f,14.313025f,35.66755f,99.97657f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(39.926975f,37.49762f,-58.767242f,22.210287f,68.83075f,58.99238f,-19.916578f,0f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(39.9699f,-6.8815894f,6.030593f,66.761185f,-92.95798f,0f,4.063049f,-61.34925f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(40.206375f,52.590668f,42.276443f,8.234838f,27.879848f,16.515106f,-16.496613f,-74.22128f,-99.99992f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(40.28784f,41.23049f,60.295853f,19.920881f,-35.661736f,-45.81613f,-98.2779f,87.43559f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(40.30918f,41.261402f,13.272561f,19.975319f,8.856045f,-9.023374f,30.73605f,-16.78917f,-8.938161f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(40.437977f,64.6885f,63.786907f,-2.9365928f,-10.544873f,-77.1758f,-41.639473f,-26.755602f,-34.41559f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(40.6707f,49.71756f,43.270737f,12.965239f,14.928809f,14.90924f,-3.7385566f,-17.876802f,19.233412f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(4.102736f,-99.69458f,0f,8.332726f,38.243652f,-18.722088f,-9.015487f,-44.394672f,36.063206f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(41.132973f,57.12065f,98.32023f,7.4112406f,-10.970595f,-100.0f,-0.51741576f,-9.480904f,-100.0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(41.23226f,53.21809f,28.276571f,11.7109585f,-4.5829296f,15.217439f,10.194499f,-98.47821f,-100.0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(41.235527f,54.149662f,0f,-22.05342f,-63.305428f,-53.277184f,-66.143776f,-12.2669935f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(41.423717f,-16.744053f,0f,4.0044565f,-24.104712f,-37.24371f,-1.3011785f,-9.20917f,-11.430789f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(41.643795f,47.00761f,25.778933f,19.567566f,20.607718f,-45.323086f,16.018753f,61.178776f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(41.970413f,55.518505f,59.3765f,12.363152f,20.727114f,80.36964f,-13.244922f,-65.34283f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(41.997524f,53.660423f,5.961352f,14.329681f,6.3955708f,-9.459765f,8.925628f,22.059855f,0f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(42.02252f,-48.911583f,15.998112f,24.924002f,3.79649f,29.583464f,53.877003f,9.5900755f,-4.195993f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(42.26491f,26.110025f,26.944456f,42.949615f,-64.769264f,-18.332203f,47.369217f,-14.150755f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(42.474308f,50.82956f,33.635403f,19.06768f,24.115726f,-99.693756f,9.680684f,19.655056f,44.823814f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(42.97963f,55.363564f,75.12766f,16.554962f,3.346955f,38.466686f,19.89326f,-100.0f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(43.290222f,58.67149f,-9.349835f,14.489401f,13.722768f,-4.5629363f,0.94461143f,-10.710955f,77.07033f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(43.93992f,-100.0f,18.493416f,23.435905f,-34.736958f,-23.111664f,84.54066f,-39.272076f,-70.103645f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(44.328724f,52.693233f,54.01056f,24.62166f,4.442351f,18.992987f,49.715565f,-78.538475f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(44.366783f,35.420147f,-100.0f,42.046993f,-28.861286f,0f,67.020195f,100.0f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(44.554234f,60.8149f,19.623795f,17.402039f,79.081566f,-82.319725f,-54.027653f,-99.951744f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(44.70092f,66.97292f,63.912968f,11.830753f,59.277817f,88.67895f,-56.655724f,100.0f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(44.745598f,52.567207f,55.967995f,26.415186f,9.555239f,71.30478f,60.95441f,12.46993f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(44.755856f,41.272404f,29.409788f,37.751026f,-9.076032f,5.6982274f,7.3237796f,-8.455907f,-5.5909805f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(44.798027f,82.21411f,0f,-1.7338189f,-7.584408f,-98.96287f,-44.148895f,95.736f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(45.116455f,68.28719f,1.3550631f,12.178627f,44.523026f,85.19063f,-40.924976f,3.14884f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(45.229904f,51.39105f,-3.5589314f,29.52857f,63.893223f,-72.21352f,8.991149f,-3.626939f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(45.341904f,51.758213f,63.008636f,29.609396f,-1.3176821f,-46.523895f,74.41336f,-40.114445f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(45.35781f,71.81015f,2.107655f,9.6210985f,5.921591f,3.0562484f,-12.795009f,-60.801136f,4.1957483f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(45.38299f,66.36483f,96.77671f,15.167135f,23.299623f,16.24296f,-8.014072f,-4.5764346f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(45.77085f,70.89539f,0f,19.206137f,23.65007f,19.075193f,7.4036217f,10.408351f,36.020756f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-46.08126f,44.521915f,0f,12.267668f,12.5190525f,-4.717399f,82.63288f,82.03532f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(46.189148f,98.64506f,68.18397f,2.1266303f,46.586723f,90.28008f,-84.26935f,-4.70487f,-40.153355f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(46.217785f,78.14835f,68.6466f,6.72278f,-16.804115f,38.508583f,-2.5225484f,19.58423f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(46.294533f,73.93239f,88.41695f,11.24574f,36.006f,0f,-49.64461f,13.743833f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(46.792015f,67.39158f,93.67262f,19.776485f,29.101671f,15.635763f,3.212255f,-6.927465f,-24.900145f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(47.101887f,50.864758f,0f,-14.57927f,-92.28699f,19.756641f,-13.131983f,-37.94866f,-46.375675f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(47.128162f,15.613825f,0f,14.296276f,-84.869865f,39.217762f,-1.5324564f,-20.426102f,4.6979156f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(47.229218f,73.57872f,68.93387f,12.93709f,43.64016f,27.992224f,-39.121017f,60.052612f,-0.6051359f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(47.856373f,-6.344677f,0f,1.1607867f,-44.295452f,-34.111942f,1.0822232f,-0.744265f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(48.07273f,28.44866f,-35.99478f,64.20062f,167.72093f,22.059212f,41.139687f,100.0f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(48.12604f,63.42374f,79.48534f,29.08043f,26.083578f,69.80388f,34.566082f,0f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(48.18746f,16.491749f,1.3338714f,76.2581f,-83.55434f,100.0f,8.21643f,-43.392384f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(48.349464f,71.54704f,37.838715f,21.850815f,100.0f,-85.987885f,-60.94621f,97.11269f,0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(48.51398f,24.627892f,-0.6162882f,7.7852597f,-14.407778f,-70.39834f,-2.9651659f,-19.645924f,-61.21075f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(48.68072f,100.02538f,141.92853f,-5.294314f,109.514725f,-254.82935f,14.402318f,62.903584f,50.24842f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(48.700058f,62.169807f,93.99299f,32.630424f,5.9861803f,1.3676379f,75.83546f,-64.030556f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(4.8862987f,-69.11257f,-21.7399f,-11.342234f,-72.63709f,0f,-8.919199f,-24.334562f,-15.781958f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(49.073105f,36.278656f,-4.880226f,60.01376f,0.9217426f,-12.665633f,-11.983575f,32.75805f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(4.908461f,-55.274845f,0f,-47.38302f,-59.835423f,0f,6.111758f,71.83005f,54.136353f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(49.355076f,57.97469f,50.223976f,39.445614f,32.319706f,31.528671f,76.10767f,0.32985157f,30.605066f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(49.417816f,34.812943f,-11.704969f,62.858322f,1.5389161f,-97.99397f,11.967154f,-14.989706f,-73.4649f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(49.58286f,-296.2642f,0f,-11.101692f,-87.72537f,-75.01702f,-6.24572f,-15.269569f,33.441944f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(49.72595f,50.176197f,45.51913f,48.72759f,5.459719f,-11.279626f,41.023914f,13.602338f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(50.067184f,56.806606f,38.2965f,43.46213f,38.862747f,-66.660545f,84.918594f,53.182224f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(51.318542f,82.99797f,100.0f,22.276201f,25.082731f,100.0f,12.703533f,28.537931f,76.36546f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(51.901947f,80.30873f,0f,18.536465f,-45.024437f,0f,2.020384f,-10.454929f,1.1843376f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(51.968555f,96.465f,-78.39899f,11.4092245f,78.94894f,-34.486744f,-85.280594f,52.649773f,0f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(52.80941f,58.757587f,39.629436f,52.48006f,42.591496f,-0.23983899f,-60.932114f,-53.25971f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(52.94616f,117.75332f,-1.4768969f,-5.9689627f,-67.35388f,0f,-6.078324f,-18.344334f,-73.53056f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(53.074203f,-38.29506f,-85.31019f,150.63962f,-18.737686f,-68.14875f,37.413548f,0.4811147f,-16.894087f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(53.367386f,79.96764f,86.7871f,33.501892f,79.716095f,100.0f,75.99004f,28.697325f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(53.47869f,72.73651f,-35.706566f,41.178253f,90.017586f,100.0f,21.216743f,43.688717f,63.520546f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(53.731026f,63.92315f,49.795193f,51.00095f,52.166348f,35.257614f,98.10644f,58.483673f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(54.218025f,49.64656f,0f,27.867987f,40.6114f,124.27104f,14.937297f,23.309616f,36.676193f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(54.42793f,49.36239f,2.033996f,68.34933f,35.536114f,0f,50.53605f,0f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(54.787056f,41.54936f,23.792707f,77.59886f,-12.382325f,-46.378532f,18.894367f,-2.021394f,-14.597619f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(54.88015f,14.046605f,0f,15.155973f,-2.3332698f,82.2635f,8.077013f,17.152079f,62.86457f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(5.4920053f,-98.747345f,0f,13.815661f,33.54222f,-98.230995f,16.228422f,51.098026f,-80.42635f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(-56.542667f,100.0f,0f,-39.412037f,-79.87101f,11.132276f,-21.234467f,-45.525826f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(56.863834f,67.66192f,-86.158676f,59.793423f,-47.28218f,0f,35.871532f,83.69271f,0f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-57.147076f,-84.5106f,0f,-12.442785f,10.408348f,-39.41054f,-3.0324137f,0.31313026f,0f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(57.346844f,-50.42615f,0f,25.131123f,-56.01347f,0f,-94.359985f,0f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(-57.50317f,47.225567f,0f,24.265633f,57.50843f,-52.399685f,97.057274f,-41.32471f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(57.593918f,86.36867f,24.43822f,44.00701f,31.326347f,0f,16.227991f,20.904955f,61.65238f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(57.962402f,46.300083f,-78.39926f,85.54952f,13.865458f,0f,30.935747f,38.19347f,25.945953f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(57.966843f,37.869072f,36.98739f,93.99829f,-43.477936f,96.599434f,1.6264901f,0f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(58.004166f,60.614407f,100.0f,14.745723f,-1.4851682f,18.512434f,2.463895f,-99.81323f,-24.4651f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(58.14573f,-99.77851f,0f,-55.66981f,96.22927f,-67.4487f,-1.7786322f,48.555283f,99.77049f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(-58.380886f,71.34536f,0f,-44.295143f,-42.67833f,0f,79.9451f,0f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(60.07217f,-1.468379f,0f,63.37856f,-0.41193333f,0f,23.80815f,31.854042f,18.944878f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(6.0619993f,-50.066925f,15.796701f,-25.685076f,-8.8023f,-16.043139f,-100.0f,56.585938f,-71.166954f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(60.918247f,24.888859f,-15.978921f,7.557129f,2.4515676f,-51.11148f,-33.141296f,28.471762f,-27.895672f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(61.01464f,70.253944f,20.001143f,73.80463f,100.0f,31.325027f,100.0f,56.031155f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(61.83937f,80.103584f,59.638145f,67.2539f,98.93682f,58.448997f,-34.7783f,0f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(61.869717f,47.16932f,0f,22.317108f,40.30692f,0f,-12.9082f,0f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(-61.900978f,-52.579784f,0f,-87.29651f,50.28758f,0f,-13.839594f,31.938131f,91.30454f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(-62.055656f,-30.792646f,0f,121.19288f,-37.00938f,0f,25.660616f,-18.551243f,-62.85621f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(62.25923f,-37.66208f,0f,30.018545f,8.5028925f,-53.44608f,49.312054f,-61.848995f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(63.656147f,-18.593021f,4.7529445f,22.166908f,9.498299f,-5.466537f,15.513189f,39.885845f,-36.117393f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(-64.062f,28.160671f,0.70970756f,-26.709074f,-27.067358f,-9.816976f,-15.706941f,-99.90405f,-12.9102545f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(66.4637f,-46.091564f,5.3113117f,15.3459f,-8.253108f,0.38710135f,3.1730077f,-2.6538692f,4.490202f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(6.6638637f,-38.41852f,0f,-2.6752145f,-55.395706f,0f,9.026294f,38.780388f,-32.43607f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(-67.10049f,30.603218f,14.49224f,-4.741625f,-2.6591978f,13.501365f,50.793186f,-49.99975f,0.48323122f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(-67.69766f,17.234137f,0f,-14.817582f,10.766177f,35.64629f,-2.3388464f,5.4621964f,13.421453f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(-69.47664f,53.860714f,0f,-24.125204f,-18.828955f,-21.738657f,-8.195224f,-8.655691f,-7.598587f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(-69.67224f,-73.62978f,0f,54.04581f,46.837887f,0f,86.472466f,0f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(6.972803f,-100.0f,-99.648865f,-13.071378f,-49.680862f,-60.629868f,-9.52136f,-25.022205f,-93.51251f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(-7.026662f,-100.0f,5.9655194f,-28.106647f,-92.11361f,15.059245f,-13.286318f,-25.038622f,5.2454386f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-71.57096f,28.243536f,-13.228041f,-35.856636f,-4.973125f,-29.644182f,-66.882454f,17.364782f,-33.462738f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-71.916626f,-41.043686f,0f,-15.677993f,3.531965f,91.959335f,5.6726866f,38.36874f,-24.481707f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(72.850746f,-0.6975075f,0f,-44.398735f,-33.55733f,0f,-38.37614f,0f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(7.290684f,1.5278857f,-1.2861038f,-72.36515f,95.40111f,6.478559f,-12.453469f,22.551273f,7.257458f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(75.27796f,43.87139f,0f,11.536956f,-15.987118f,63.515743f,-13.143024f,-64.109055f,0f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(75.746574f,95.18984f,37.766586f,30.559065f,35.67941f,4.2859445f,10.810503f,12.683038f,4.242239f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(7.5810075f,-10.226753f,23.551762f,-13.482291f,-24.36674f,-9.899248f,-37.143433f,-63.858665f,-18.403772f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(7.6480646f,-85.41875f,53.077538f,16.011007f,-18.842117f,-1.26087f,75.23808f,-4.699856f,-38.476925f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(-76.6636f,55.412956f,0f,-2.802574f,62.793186f,-60.167603f,2.6601167f,13.443041f,-11.681141f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(-7.7748713f,0.86545676f,0f,-24.163137f,2.9745874f,13.458123f,-91.852264f,21.737907f,0f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(78.16568f,-73.78314f,0f,-3.2713866f,-32.345478f,28.710335f,-58.905754f,-8.935554f,0f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(78.509254f,93.74331f,66.40363f,30.166948f,38.270355f,43.7854f,3.8881803f,-14.614227f,70.46761f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(-79.30372f,5.754231f,131.15825f,-46.102436f,-68.56451f,-133.88098f,-36.29133f,-100.0f,186.8669f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-80.90113f,-16.947006f,0f,19.41836f,78.3449f,-61.530743f,80.22967f,69.09654f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(81.219284f,-94.92291f,63.617702f,17.50874f,-1.7173697f,48.62439f,-9.466956f,21.920305f,56.062138f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(8.203094f,-66.16462f,0f,-6.992407f,-31.772491f,40.859634f,-4.779792f,-12.126761f,-11.9547615f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(8.36039f,-45.384533f,0f,48.59179f,93.86394f,0f,10.1746645f,-7.89313f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(83.956245f,29.942152f,0f,23.19367f,-2.6366887f,54.073704f,11.455124f,22.626825f,-61.17072f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(84.18445f,16.969011f,0f,-6.259839f,90.71036f,0f,-52.59863f,-84.6467f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-8.531617f,26.33274f,0f,-2.8721895f,-1.3011839f,-24.601406f,-1.6559573f,-3.7516398f,-12.0494175f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(8.546862f,27.380106f,4.1216993f,-93.1913f,-3.1590204f,-111.004944f,-49.658005f,84.69127f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-85.652695f,35.053875f,0f,-40.55282f,-53.517117f,0f,1.3522396f,45.961777f,0f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(86.84278f,-100.0f,0f,26.087091f,53.76424f,-92.57454f,9.1748f,10.612108f,-20.490608f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(-87.20038f,16.92815f,81.93363f,-26.340702f,1.1088765f,45.760628f,-19.271305f,-31.912569f,100.0f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(8.726438f,-82.45689f,18.53889f,17.362635f,2.317272f,0f,58.406826f,0f,0f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(89.3328f,72.92623f,0f,96.7452f,67.65208f,0f,87.86181f,-43.58715f,0f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(8.937845f,-75.22863f,99.99389f,10.980011f,7.2371955f,-6.802599f,27.745003f,100.0f,97.56248f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(89.783646f,99.5854f,83.165215f,30.569304f,22.150192f,-52.358154f,10.343379f,10.8042145f,44.00915f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(92.80596f,-3.3731513f,0f,37.526936f,66.54126f,0f,-61.319607f,-16.02095f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(-93.8394f,-32.39907f,0f,-26.90005f,-8.401715f,-24.705908f,-5.3590775f,5.46374f,35.615753f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(93.84887f,89.25249f,0f,61.408047f,-23.702915f,0f,10.651037f,-18.803898f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(95.23546f,22.432892f,0f,-60.072533f,50.451523f,4.7590876f,-13.753494f,5.0585575f,-16.4638f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(9.553496f,-69.483894f,0f,10.0452175f,12.526565f,-20.368532f,18.100811f,62.358025f,27.22027f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(95.78955f,-12.56535f,0f,-8.791706f,22.98071f,0f,89.912155f,-72.9131f,0f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(9.658804f,99.43829f,0f,-30.828695f,-96.84537f,0f,-42.64573f,-46.899574f,0f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(97.078606f,21.897472f,0f,39.565083f,57.10537f,-64.306656f,4.076348f,-9.72343f,0f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(9.785801f,100.0f,0f,30.477587f,91.64325f,3.6568952f,20.481293f,51.447586f,93.6658f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(98.457016f,-40.75095f,99.986916f,19.169987f,-24.801826f,-70.55539f,3.024758f,-7.070954f,-6.5067277f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(98.70472f,92.57318f,35.676144f,35.457092f,33.805943f,5.3797636f,9.317708f,1.8137407f,-35.86869f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(9.887767f,-10.444122f,-81.65053f,-50.00481f,-70.013725f,39.211308f,45.873497f,36.758797f,0f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(99.68686f,-33.86853f,0f,53.738922f,97.6461f,76.24236f,17.622723f,28.967999f,0f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(99.73046f,-52.213966f,0f,38.958977f,42.74794f,15.693568f,13.357512f,14.471069f,1.7788278f ) ;
  }
}
