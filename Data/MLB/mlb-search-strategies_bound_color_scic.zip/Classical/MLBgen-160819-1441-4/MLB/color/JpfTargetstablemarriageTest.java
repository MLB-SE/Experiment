import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(1,-681 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(4,787 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(5,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(5,193 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(5,2 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(841,0 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(91,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(-936,0 ) ;
  }
}
