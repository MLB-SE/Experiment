import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(68.81901f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(-70.5176f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(94.59778f ) ;
  }
}
