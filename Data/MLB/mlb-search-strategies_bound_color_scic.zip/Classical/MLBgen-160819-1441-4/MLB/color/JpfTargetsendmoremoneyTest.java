import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,4,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,638,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,8,8,7,1,10,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(2,0,7,438,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,2,0,0,9,25,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(2,2,4,2,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(2,3,9,3,1,132,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,5,8,5,5,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(264,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(2,9,161,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(2,9,5,4,-40,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(3,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(3,9,567,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(4,1,9,526,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(-439,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(4,9,1,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(6,1,-331,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,4,3,-287,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(6,9,5,7,534,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(7,341,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(789,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(7,8,9,6,158,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(8,8,7,7,9,-932,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,-313,0,0,0,0,0,0 ) ;
  }
}
