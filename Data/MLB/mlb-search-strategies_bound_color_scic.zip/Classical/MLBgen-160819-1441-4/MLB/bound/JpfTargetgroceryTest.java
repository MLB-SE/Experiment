import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(103,247,360,1 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(126,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(164,499,11,37 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(182,639,523,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(297,512,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(339,-905,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(382,608,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(407,624,88,891 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(428,118,-14,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(460,714,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(475,656,413,642 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(480,692,363,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(53,48,436,174 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(588,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(598,518,969,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(613,321,273,862 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(638,502,373,630 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(67,14,554,76 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(676,54,19,-290 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(716,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(-749,0,0,0 ) ;
  }
}
