import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,5,9,95 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,3,-281,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(1,526,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(1,6,3,869 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(1,845,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(2,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(-248,0,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,2,1,-476 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(3,2,6,1 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(3,-586,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(3,9,7,6 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(4,2,786,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(44,0,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(505,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(5,1,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(5,2,373,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(6,1,5,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(7,3,7,5 ) ;
  }
}
