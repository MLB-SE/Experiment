import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,1,4,-958 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,1,643,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,2,1,0 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,3,2,861 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,4,1,1 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(1,4,1,1741 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(1,-914,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(2,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(-266,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(2,767,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(309,0,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,1,4,1 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(3,4,350,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(3,655,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,1,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(4,1,3,4 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(4,1,-560,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(749,0,0,0 ) ;
  }
}
