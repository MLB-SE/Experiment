import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-204,-69 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-33,837 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-405,433 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-430,-83 ) ;
  }
}
