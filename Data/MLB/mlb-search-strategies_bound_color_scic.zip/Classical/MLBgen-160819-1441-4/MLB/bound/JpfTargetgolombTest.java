import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,6 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,3,1 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,386,0 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,4,3 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,4,6 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,6,2 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(1,2,3 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,2,6 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,325,0 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,3,4 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,3,6 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,4,0 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(1,4,2 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(2,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(2,6,6 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(3,1,5 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(3,1,6 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(3,2,347 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(3,2,5 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(391,0,0 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(4,4,1 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(4,5,-138 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(4,-777,0 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(6,1,380 ) ;
  }

  @Test
  public void test25() {
    bound.golomb.solve(-862,0,0 ) ;
  }

  @Test
  public void test26() {
    bound.golomb.solve(97,0,0 ) ;
  }
}
