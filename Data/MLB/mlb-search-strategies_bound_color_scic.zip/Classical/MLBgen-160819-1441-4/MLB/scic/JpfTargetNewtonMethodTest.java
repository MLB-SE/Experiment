import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-18.249999999056122,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-21.524826589030567,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-30.699714742934916,-47.7274482595027 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-46.93266106087586,90.79149719846791 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-5.6824933622267935,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-6.6646364934870235,21.58927763272618 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(676.8401468315047,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-73.25,-58.962496224582914 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-79.25,0.0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-85.25000000000001,22.854186094793494 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-85.69952152663794,0.05512175706620326 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(91.77829416224449,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(9.56581285410482,41.927256694586674 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-98.44518122805577,0.30731338893890836 ) ;
  }
}
