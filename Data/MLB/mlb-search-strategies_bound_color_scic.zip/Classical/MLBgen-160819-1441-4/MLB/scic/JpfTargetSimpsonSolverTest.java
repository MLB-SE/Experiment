import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-16.798661581930435,73.82694641037226 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-51.244736664188316,77.69067357424768 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(67.18381527953824,-32.191717433366335 ) ;
  }
}
