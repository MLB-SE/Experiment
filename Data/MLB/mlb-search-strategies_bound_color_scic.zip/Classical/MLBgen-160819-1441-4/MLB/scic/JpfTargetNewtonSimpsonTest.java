import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.11351644495347557,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.24704716440677998,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.6401738902861496,-27.478103380159055 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-10.585478238639709,42.13280622691369 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(12.671093127939528,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-1.369261352045072,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-14.073353479428135,1.2942509338671044 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-1.6465721649424125,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-18.157913443003764,13.536890896901582 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-20.28226718179755,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-26.122326916912627,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-2.7097594019581237,-77.18315704167378 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-27.388627692912948,-28.902251666208926 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(41.27930042267104,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-4.3500559644995604,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-6.346913911901694,0 ) ;
  }
}
