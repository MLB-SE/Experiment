import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.99854013611913 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(3.5555072816758866 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(72.70247101423527 ) ;
  }
}
