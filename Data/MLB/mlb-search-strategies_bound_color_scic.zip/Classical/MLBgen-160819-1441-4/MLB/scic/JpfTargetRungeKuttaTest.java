import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(13.921128130365474 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-14.956926362721006 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(-16.582678867082095 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2700.603954111882 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2716.3831542127355 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2729.06736276025 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2729.4064259123707 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2731.6034324354778 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(29.452583199695823 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(37.959831626534964 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(67.26046428763689 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(71.3046992110095 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(-78.17669811885159 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(81.7164454475953 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(84.00081578464537 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(84.37924266766129 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(92.86837215727022 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(96.63327541680138 ) ;
  }
}
