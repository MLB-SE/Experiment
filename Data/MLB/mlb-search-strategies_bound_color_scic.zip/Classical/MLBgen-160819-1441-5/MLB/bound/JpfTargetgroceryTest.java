import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(117,12,376,206 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(134,123,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(185,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(-224,0,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(224,26,421,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(247,360,73,31 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(29,615,17,257 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(313,837,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(3,19,482,207 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(380,356,637,59 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(40,333,147,191 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(403,374,421,385 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(430,667,-570,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(440,25,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(545,453,74,812 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(556,-552,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(609,562,827,0 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(699,710,971,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(84,638,348,-718 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(861,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(866,0,0,0 ) ;
  }
}
