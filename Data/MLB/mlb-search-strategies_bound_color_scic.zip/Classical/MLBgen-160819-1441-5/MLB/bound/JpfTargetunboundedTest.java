import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-125,-802 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-643,117 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-749,500 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(936,698 ) ;
  }
}
