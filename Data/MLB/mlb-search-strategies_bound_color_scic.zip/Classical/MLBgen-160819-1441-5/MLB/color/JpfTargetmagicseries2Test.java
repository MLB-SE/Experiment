import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,0,1 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,0,2,4 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,1,3,0 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,1,-602,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(0,2,1,0 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(0,4,0,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(0,4,950,0 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(0,975,0,0 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(1,1,2,0 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(1,2,0,1 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(1,2,1,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(1,3,1,394 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(1,4,3,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(166,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(1,823,0,0 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(2,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(2,0,1,1 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(2,0,2,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(2,0,942,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(2,1,0,1 ) ;
  }

  @Test
  public void test20() {
    color.magicseries.solve2(2,1,1,0 ) ;
  }

  @Test
  public void test21() {
    color.magicseries.solve2(2,2,0,694 ) ;
  }

  @Test
  public void test22() {
    color.magicseries.solve2(-293,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.magicseries.solve2(3,0,0,1 ) ;
  }

  @Test
  public void test24() {
    color.magicseries.solve2(3,0,1,0 ) ;
  }

  @Test
  public void test25() {
    color.magicseries.solve2(3,0,2,0 ) ;
  }

  @Test
  public void test26() {
    color.magicseries.solve2(3,2,4,-760 ) ;
  }

  @Test
  public void test27() {
    color.magicseries.solve2(4,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.magicseries.solve2(4,-694,0,0 ) ;
  }

  @Test
  public void test29() {
    color.magicseries.solve2(698,0,0,0 ) ;
  }
}
