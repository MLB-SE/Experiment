import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,0,9,4,6,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,4,6,2,219,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,6,-156,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(168,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(1,7,284,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,868,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,0,6,554,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,2,2,1241,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(2,7,0,-632,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(3,9,6,5,2,-504,-1038,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(4,2,594,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(4,929,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(5,0,1,2,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(5,4,6,0,5,-619,931,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(5,8,3,6,1255,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(585,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,0,9,3,9,1158,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(6,1,9,6,7,-1369,1740,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(6,5,10,11,7,-674,2,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(6,9,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(7,4,2,-1,6,-552,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(7,9,0,8,8,780,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(-810,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(8,3,6,5,-315,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(8,-777,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(9,5,3,0,0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(9,6,2,7,7,-10,0,0 ) ;
  }
}
