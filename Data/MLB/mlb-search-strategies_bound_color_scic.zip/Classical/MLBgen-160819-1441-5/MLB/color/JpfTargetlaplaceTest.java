import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.045179017f,-81.27162f,-62.170116f,-18.547665f,-38.054684f,-4.1881824f,-36.181152f,-48.21126f,83.47207f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.2479964f,81.05793f,0f,49.345375f,-50.037163f,0f,-1.7940946f,-56.52175f,-10.746009f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(0.707457f,100.0f,0f,8.853542f,26.850435f,100.0f,7.8562765f,22.571564f,55.579544f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-0.93528485f,-7.0824594f,-98.18184f,-96.658676f,-29.212715f,11.308577f,-8.083737f,64.32373f,32.47276f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(100.0f,45.503662f,0f,36.308693f,32.41122f,43.843662f,12.823553f,14.9855175f,14.707295f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(100.0f,55.07781f,-99.59722f,24.135307f,-5.303775f,-83.67293f,1.8450041f,-16.755291f,-72.26144f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,-58.669765f,-99.7993f,-31.594345f,-10.95195f,76.563675f,-15.4254265f,-30.107363f,-94.123665f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(100.0f,65.64125f,0f,98.60533f,100.0f,-83.91881f,34.88982f,40.953957f,28.926f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(100.0f,-91.145584f,0f,37.413456f,58.7064f,23.560667f,-9.052576f,-73.623764f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-100.0f,99.65096f,0f,71.07087f,-58.25839f,20.701635f,14.283175f,-13.9381695f,-11.777463f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(-1.0165333f,-99.9336f,0f,-65.38326f,22.484604f,-13.690386f,-16.151802f,0.7760553f,-3.2285826f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(-10.186607f,-72.08205f,-20.577272f,-68.66439f,-58.567993f,0f,-63.726604f,-37.191154f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(10.615327f,-55.8898f,0f,43.32762f,-100.0f,0f,31.05778f,80.903496f,0f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(10.618961f,29.221113f,-72.03182f,-86.74527f,73.36093f,0f,-18.442701f,12.974463f,-2.293821f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-1.1110927f,-100.0f,-26.932793f,-4.4443707f,-20.392658f,3.5240948f,3.726318f,19.349642f,76.058136f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(11.346403f,78.217476f,64.617355f,23.057154f,44.291855f,31.788904f,36.59036f,44.103878f,18.246414f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(11.508265f,-82.78662f,0f,4.551383f,-43.92321f,0f,50.620476f,0f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(11.835139f,22.361246f,26.324518f,-75.02069f,-48.714672f,-37.562702f,21.685493f,0f,0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(11.961588f,-96.32269f,0f,13.333188f,45.380547f,85.7917f,-4.0093822f,-29.370716f,2.9329925f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(12.277583f,-96.840324f,0f,-66.53312f,-19.149933f,-72.986046f,-24.838425f,-32.820576f,-87.29395f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(12.418802f,2.3175f,-99.9232f,9.027525f,13.703709f,12.546987f,9.987587f,30.922825f,100.0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(12.621673f,13.5061035f,-35.501305f,-63.019413f,-23.095951f,57.38361f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(128.41176f,85.19314f,0f,28.917807f,-100.0f,0f,28.74381f,86.05744f,23.745064f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-12.888373f,-91.2068f,0f,10.373436f,-44.3947f,-24.699026f,98.77682f,-72.046394f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(-12.959104f,-74.8404f,-42.928844f,-9.214497f,-20.155233f,9.1940565f,-3.7436488f,-5.7600985f,0.85848963f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(13.009907f,-75.970245f,0f,-14.466514f,-54.357857f,48.82022f,-16.518105f,-51.605904f,93.272736f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(13.135134f,8.397577f,-16.433445f,-55.85704f,-32.24909f,-22.427027f,-17.665697f,-14.805745f,-9.308193f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(-1.3303381f,-30.804405f,-52.492878f,-74.516945f,15.9078f,0f,77.65166f,-69.9402f,0f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(13.33645f,-52.591408f,-70.48663f,5.9372067f,-24.331524f,-14.782673f,34.7439f,-35.88922f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(13.600536f,-32.254944f,5.939867f,-13.342912f,-33.56424f,0.8364386f,-33.407944f,21.83358f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(13.958149f,-8.796664f,56.86712f,-35.35239f,-205.96275f,-170.93307f,-16.681728f,-31.951899f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(14.031632f,20.221434f,26.561209f,-63.89092f,-59.770527f,-14.154155f,-230.99858f,50.70346f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(-148.85735f,106.50263f,0f,61.074844f,48.52804f,34.65965f,31.36479f,64.35065f,177.50288f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(15.478377f,-45.31609f,100.0f,7.2295995f,15.32377f,-100.0f,-1.8837487f,-14.764594f,17.573978f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(15.617759f,-35.56298f,-8.982123f,-1.9659811f,-21.495707f,-84.99115f,-1.9859769f,-5.9779267f,-0.430023f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(15.84434f,-39.05051f,-18.597954f,2.4278605f,-8.143493f,-1.5658312f,2.0105937f,5.6145144f,28.590958f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(15.996546f,-23.378433f,12.983983f,-12.635383f,-58.576347f,-7.859611f,-8.18577f,-20.107697f,-13.668669f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(16.29181f,-10.852882f,0f,-10.306376f,-43.02551f,73.4913f,-14.491807f,-47.66085f,89.79744f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(16.588306f,-40.322975f,-15.780064f,6.6762004f,-3.1760807f,9.804825f,13.292576f,11.137626f,68.374245f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(16.760721f,-28.592487f,-3.1196034f,-4.364631f,-7.80274f,74.12003f,-26.416504f,-186.82382f,0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(-17.055313f,-5.8603964f,-25.772013f,-8.660265f,-14.773057f,-41.981075f,-2.812689f,-2.5904913f,7.223781f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(-17.221085f,-205.47813f,0f,-18.173069f,-49.329994f,32.083614f,-5.6204963f,-4.2777133f,38.910633f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(17.314562f,61.02073f,56.585598f,-91.762474f,70.182755f,-86.55376f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(17.390272f,-49.236855f,38.64988f,-1.9377592f,-19.936897f,-9.693081f,-5.2044125f,-18.87989f,-57.48531f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(17.477564f,30.122044f,23.229475f,-60.21179f,-20.218864f,-37.204144f,1.7937119f,67.386635f,-62.788734f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(17.569061f,-62.946697f,0f,15.473959f,81.52939f,17.707415f,-37.202614f,40.95049f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(18.206255f,2.9756742f,30.778406f,6.649628f,8.782422f,33.714672f,-0.39016387f,-8.210285f,-41.233402f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(18.809906f,-4.6481466f,-37.402493f,-20.11223f,-100.0f,-99.98832f,0.7411726f,23.076921f,23.54659f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(19.074976f,-13.888399f,29.71112f,-9.811699f,-79.77325f,1.7184296f,21.451471f,95.617584f,-13.365673f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(19.220278f,15.150873f,3.7385783f,-38.269764f,-62.355362f,-53.368702f,-70.39949f,-87.0563f,0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(-19.320103f,-55.59675f,-22.111467f,-15.753764f,-40.254868f,-91.66239f,-3.4400835f,1.9934299f,51.66867f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(19.372408f,-18.816486f,-82.15853f,-3.6938848f,-30.072693f,42.680237f,-4.075254f,-12.60713f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(19.497654f,35.16058f,0f,18.193121f,7.5026693f,-28.54223f,45.77216f,4.3583937f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(19.680567f,-29.475182f,-21.627151f,5.162881f,-5.497013f,-18.384743f,6.4679685f,20.708992f,-16.503962f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(19.77126f,73.656624f,33.38422f,12.784302f,26.579107f,13.512422f,4.7868447f,6.363078f,-5.9136395f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(-1.9883883f,-99.839836f,0f,-14.983506f,-31.020342f,6.492138f,-26.925293f,-15.750165f,0f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(19.962624f,11.155289f,59.09616f,5.3947845f,5.369525f,25.334854f,-3.7530112f,-20.406828f,36.84845f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(20.264513f,100.0f,0f,0.9336606f,-10.722902f,-100.0f,-5.8069696f,-24.16154f,-80.11629f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(20.265856f,-12.053001f,-43.18281f,-6.8835773f,-36.841763f,-27.384338f,-10.958405f,-36.950043f,-100.0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(20.419699f,26.091722f,81.42562f,-44.412926f,-97.47843f,41.541622f,-32.43343f,-85.09273f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(21.04284f,-5.296848f,10.7567215f,-10.531797f,-48.922684f,-33.845028f,-14.247347f,-46.45759f,-64.46041f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(-21.044155f,-62.754852f,0f,-72.93771f,-77.261284f,-10.188098f,-18.929077f,-2.7785978f,85.075966f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(21.325031f,-31.364922f,-12.255634f,16.665049f,71.198975f,-23.131784f,-25.863811f,-70.633644f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(21.846607f,2.269512f,-66.20234f,-14.883085f,-77.5035f,23.019178f,-7.562633f,-15.367448f,23.596346f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(21.956913f,62.822678f,0f,18.56878f,46.503475f,11.035751f,5.814731f,4.690143f,-33.557636f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(22.264698f,73.04227f,-9.278971f,-83.983475f,-41.9622f,43.085068f,-23.707596f,-10.846909f,22.282164f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(22.337757f,-18.492628f,5.257854f,7.843656f,6.018388f,11.340079f,3.0184803f,4.230265f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(-22.54346f,28.602057f,0f,-29.709291f,57.155495f,0f,-12.157385f,-18.920246f,34.893204f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(22.556017f,21.187553f,66.16823f,-30.963488f,-16.546354f,0f,-14.5659895f,-27.300472f,-78.08955f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(22.619413f,-23.220762f,53.460674f,13.698427f,26.204527f,24.015892f,5.96977f,10.180861f,8.549149f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(22.966888f,-17.169443f,26.771673f,9.036995f,9.983702f,11.4027405f,3.1973894f,3.7525625f,1.8291587f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(23.128586f,-7.101419f,0f,16.242397f,34.90522f,5.1471972f,6.9357867f,11.500749f,4.1619864f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(23.255072f,-2.1422653f,-31.824133f,-4.837447f,-100.0f,-50.89931f,-49.47942f,1.1173965f,0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(23.42058f,-99.76827f,-100.0f,1.7819736f,-13.68824f,55.433098f,-2.604446f,-12.199758f,-67.948875f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(23.47173f,-38.053364f,16.268404f,31.94028f,100.0f,17.319155f,15.319172f,29.336407f,2.026454f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(23.757454f,7.197643f,-33.415886f,-12.167827f,-61.551f,-56.354027f,-6.186857f,-12.579602f,17.419449f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(24.3445f,-10.806768f,52.727207f,8.184767f,-11.03244f,-1.9378681f,19.427008f,-39.56989f,-77.10699f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(24.571407f,-11.212837f,98.15068f,9.498468f,9.169677f,30.880589f,4.252739f,7.512487f,17.195946f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(24.736477f,24.748653f,52.72524f,-25.80275f,-78.4671f,47.486633f,-49.48037f,-99.59246f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(-24.739098f,-89.93216f,0f,-11.559704f,-38.94574f,-100.0f,17.446022f,81.34379f,-42.691124f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(25.0f,100.0f,0.46042562f,-100.0f,10.478081f,0f,23.789055f,0f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(25.322691f,51.215927f,30.677128f,-49.925163f,48.863888f,69.396454f,-4.779851f,30.805758f,95.38215f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(-25.610922f,-99.35779f,-29.934341f,-16.310793f,-33.744015f,-12.065375f,-5.888235f,-7.242106f,10.663827f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(25.800596f,-13.513842f,79.38535f,16.716225f,-71.31391f,0f,-19.368652f,0f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(25.81049f,16.258375f,18.7588f,-13.01642f,-79.53579f,-41.298866f,68.150665f,46.591698f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(25.880407f,14.713471f,-20.892883f,-11.191483f,-46.133347f,96.71513f,-4.5658855f,-7.0720606f,22.410837f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(26.004044f,15.287859f,-44.43227f,-11.271687f,-20.420338f,-27.939423f,-50.670452f,-3.2801838f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(26.065207f,-12.610416f,-99.286415f,18.606268f,-6.4127855f,0.47272617f,54.77265f,-32.11972f,61.914948f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(26.490923f,29.854542f,19.679573f,-23.890848f,-26.75233f,-51.136253f,-25.529495f,24.69933f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(26.705093f,-92.884094f,6.198371f,99.704475f,2.6344755f,0f,44.939762f,56.17956f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(26.770487f,-25.302256f,-17.6408f,-2.991193f,-17.719404f,-7.755813f,-21.015856f,-34.828354f,4.3369527f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(27.638624f,44.573982f,0f,-49.509907f,15.040307f,-17.398365f,-9.142854f,12.938493f,45.856518f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(27.791346f,65.02173f,32.32274f,-53.856342f,99.97282f,-37.27567f,-12.769508f,2.778306f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(27.860155f,29.470844f,12.397856f,-18.030226f,-22.37463f,-80.130394f,-77.60642f,-20.808748f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(27.877132f,-39.575756f,0f,3.632821f,17.212975f,9.863716f,-30.558823f,-29.13762f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(27.945831f,25.277147f,-5.2938695f,-13.493822f,-21.543371f,-51.830513f,-60.377747f,-46.1263f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(-28.186548f,-66.162605f,0f,37.83561f,-68.613205f,0f,24.665293f,60.825565f,-50.51209f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(28.246187f,31.920458f,46.11675f,-18.935707f,-46.681107f,3.4950063f,-91.76675f,-22.437187f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(28.272343f,-78.26507f,-69.686455f,91.35445f,-11.654939f,0f,-61.79243f,53.62395f,0f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(28.743137f,26.123043f,52.872818f,-11.150493f,-77.12379f,-14.693315f,3.7786777f,26.265203f,-17.193224f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(28.909258f,36.72041f,31.567795f,-21.083324f,-13.595423f,-10.449296f,-99.64719f,-59.569447f,0f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(28.971159f,-59.623333f,0f,40.3078f,78.6499f,62.449f,53.61013f,64.991615f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(29.02393f,36.15558f,35.5632f,-20.059858f,-19.964815f,-100.0f,-89.298546f,-99.99979f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(29.334276f,33.201187f,7.5598726f,-15.864081f,-4.4390173f,99.93985f,-2.78174f,4.7371216f,26.169243f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(29.340506f,14.004459f,-66.865585f,3.3575647f,-6.4570856f,-26.25283f,-9.453161f,-41.17021f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(29.558346f,33.27417f,75.4177f,-15.040789f,-71.87938f,-37.051426f,-17.842123f,-56.3277f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(29.82888f,73.70758f,-83.46895f,-3.3797216f,23.165764f,-12.560585f,-66.513535f,34.895786f,-40.98974f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(29.903023f,-100.0f,56.038673f,-6.0805736f,-43.06609f,-27.62746f,-11.159225f,-38.556328f,-100.0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(30.057287f,-49.150654f,0f,26.761593f,27.32433f,75.42242f,5.582727f,-4.430686f,-50.629803f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(30.096731f,22.20853f,-37.08057f,-1.8216057f,-42.319637f,0f,13.772556f,56.91183f,9.8031225f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(30.173313f,24.425373f,31.6652f,-3.7321193f,-64.13702f,2.2354207f,17.88416f,75.26875f,-16.57106f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(30.244188f,-93.28042f,15.301037f,9.406159f,3.065418f,88.28229f,4.3150306f,7.8536057f,24.033974f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(30.25804f,4.190409f,90.37222f,16.841753f,25.834757f,54.051743f,11.274218f,28.255121f,100.0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(30.327545f,30.746271f,2.83091f,-9.4360895f,-10.1733675f,-100.0f,-4.196126f,-7.348414f,-15.024162f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(30.352673f,12.17324f,44.690636f,9.237449f,4.978575f,1.5178051f,1.6185493f,-3.0141938f,-100.0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(30.523146f,-10.186159f,0f,-2.3097687f,-34.81216f,0f,-4.950113f,-17.490683f,-30.20046f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(30.729477f,-0.47297934f,-7.304398f,2.1834142f,-11.67299f,-4.927656f,-10.32283f,-43.474735f,-0.73323816f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(31.038158f,74.625244f,75.47876f,22.020206f,49.285168f,40.81919f,7.757498f,59.676025f,38.512833f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(31.064476f,12.5465145f,95.03569f,11.71139f,-125.75125f,0f,-8.81973f,-46.99031f,-69.42126f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(31.172293f,67.720604f,44.73039f,-43.031433f,-4.262899f,0f,91.1574f,-46.25565f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(31.453835f,-28.276451f,-4.449407f,54.091785f,53.848648f,0f,15.256835f,6.9355536f,-41.36327f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(31.788328f,27.76793f,47.090977f,-0.6146196f,-67.80759f,43.66786f,33.56078f,0f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(31.896732f,29.996572f,64.99997f,-2.4251695f,-77.03026f,129.80008f,93.60464f,-30.007967f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(31.926268f,76.551834f,61.637615f,-48.84676f,-39.0413f,0f,-34.098095f,-87.545616f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(31.971752f,64.15966f,-53.961456f,-36.27265f,100.0f,0f,-61.19961f,59.491955f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(3.2056227f,-100.0f,-98.10112f,12.82249f,-25.599813f,-42.929634f,73.68415f,27.707895f,-48.01761f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(32.11114f,21.077475f,-32.402256f,7.3670835f,-15.398986f,-53.889694f,12.75618f,43.657635f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(32.349003f,10.615013f,-97.07409f,18.780993f,7.185143f,-46.04341f,35.589825f,-9.431198f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(32.45218f,27.245539f,19.058693f,2.5631833f,-42.52872f,-51.01077f,20.03639f,-20.139883f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(32.50754f,23.982452f,5.9956365f,6.0477204f,-42.496346f,-100.0f,34.176884f,-100.0f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(32.53256f,15.079151f,-93.33892f,15.05108f,21.12297f,43.125996f,6.5487895f,11.144078f,-48.386856f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(32.777023f,17.991657f,-95.3937f,13.116443f,34.5833f,-49.137413f,-2.5742865f,-23.41359f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(33.141838f,19.255043f,87.397995f,13.312308f,10.670421f,-14.321264f,9.436976f,24.435595f,50.393143f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(33.305992f,40.45749f,38.704826f,-7.2335234f,-10.180858f,62.41076f,-52.059227f,-8.266524f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(33.388767f,17.063725f,75.01632f,16.491337f,19.90842f,11.514404f,12.668162f,34.564213f,-41.73582f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(33.40623f,41.863964f,98.10402f,-8.239048f,-64.05439f,53.89168f,-2.3080313f,-100.0f,0f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(33.43571f,25.159628f,22.3678f,8.583213f,-90.74056f,0f,-10.190498f,-49.345203f,-96.44976f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(33.4595f,31.292305f,88.02236f,2.5456955f,-17.830027f,69.64861f,-5.44669f,-35.149643f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(3.365942f,-74.582436f,-1.9970766f,-11.9538f,-39.78226f,-34.71853f,-11.398881f,-37.874287f,6.852754f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(33.665432f,29.90866f,-0.56636053f,4.753069f,-62.789417f,0f,28.614195f,-97.922325f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(33.97211f,12.790834f,6.627729f,23.097609f,-89.4365f,-89.37356f,70.122406f,-38.38215f,0f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(34.153267f,31.41555f,3.949436f,5.1969943f,-12.4405f,99.981865f,-0.9247911f,-8.895487f,-22.217396f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(34.580532f,44.724125f,41.659416f,-6.4019976f,2.6565592f,21.913532f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.05458f,29.135368f,56.04203f,11.082947f,-74.55513f,95.03275f,-30.206127f,0f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(35.266666f,-84.90734f,62.654655f,5.468686f,-15.191456f,16.943304f,1.7995545f,1.7295275f,20.310026f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.50102f,18.801184f,-78.41528f,23.202894f,41.33289f,-100.0f,15.977671f,40.707787f,-73.94109f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(35.803783f,27.10293f,-10.547923f,16.112198f,-16.84414f,59.446163f,20.896624f,-62.481033f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(36.056187f,50.40808f,52.31478f,-6.1833396f,13.261364f,58.851036f,3.0745153f,18.481401f,57.589725f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(36.182205f,31.438038f,-36.976402f,13.290776f,26.546349f,-28.207169f,-9.565444f,-51.552555f,27.819347f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(36.35417f,14.360605f,77.2821f,31.056076f,6.4289618f,31.33725f,81.44118f,-51.038086f,41.637936f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(3.6403031f,-46.51796f,7.965691f,-38.92083f,39.767895f,0f,-0.6780929f,36.208458f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(-36.429127f,-99.17794f,0f,96.251274f,1.1243893f,0f,59.211346f,-66.40861f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(36.492165f,40.527344f,42.759426f,5.4413233f,-2.1660058f,0f,-12.560867f,0f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(36.515038f,46.83844f,23.765709f,-2.6991205f,26.724304f,-52.005062f,-74.182014f,130.28716f,0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(-3.6831121f,10.378145f,1.0856876f,-4.879949f,-12.739756f,-48.949455f,-3.0969284f,-7.507765f,-14.194374f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(36.85893f,-78.73524f,0f,28.31837f,-6.0183835f,74.53353f,82.43294f,7.228743f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(36.862225f,34.20426f,20.707487f,13.244629f,-20.752659f,-51.374313f,66.32602f,0f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(36.89174f,13.016762f,88.60089f,3.1720073f,-21.988123f,-92.10691f,-2.2155855f,-12.034349f,-23.933687f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(36.969963f,31.045603f,-43.2972f,16.83428f,30.509644f,-0.29561496f,-0.14205733f,-17.40251f,-99.97762f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(37.335533f,32.70103f,-5.8459086f,16.641098f,-0.68549526f,95.40168f,-5.404376f,-38.258602f,-38.271f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(37.363075f,44.710323f,46.0332f,4.7419744f,-4.5549803f,58.03923f,-13.840196f,-60.102757f,-8.478134f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(37.377808f,22.484222f,-79.69801f,27.027016f,38.882965f,6.0290036f,31.75466f,99.99162f,63.1933f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(37.65052f,49.984985f,27.45862f,0.61710453f,34.83079f,-40.1505f,-15.998372f,-64.610596f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(38.18946f,45.757664f,53.528034f,7.000177f,-8.686843f,68.35447f,-1.5019085f,0f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(38.72815f,6.5716558f,95.943726f,48.340935f,97.959465f,0f,-12.891998f,-99.90893f,37.21669f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(38.87512f,33.129276f,-37.26893f,22.3712f,30.91091f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(38.875385f,44.489372f,26.272259f,11.012162f,12.80985f,-100.0f,-7.6365857f,-41.558506f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(38.880955f,24.03097f,6.6541824f,31.492851f,-49.41126f,5.0171614f,14.812377f,27.756657f,7.8521643f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(-39.014324f,-39.222935f,0f,14.07897f,96.06035f,-41.633545f,-0.730145f,-16.99955f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(39.150818f,-37.383038f,-100.0f,93.986305f,62.15947f,71.06282f,30.883844f,29.549072f,25.152973f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(39.228615f,28.706173f,2.3271089f,28.208292f,-65.4281f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(39.260708f,39.403706f,-50.88487f,17.639124f,69.23898f,-87.813354f,-37.943195f,0.08727739f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(39.30694f,96.38181f,-74.48805f,-39.15406f,90.32047f,0f,-7.271496f,10.068078f,-42.77666f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(39.42469f,32.12872f,0f,12.873698f,8.353707f,-18.402254f,3.7163937f,1.9918766f,-4.1025944f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(39.645313f,49.684643f,53.292347f,8.896613f,5.80091f,24.813242f,-9.859771f,-48.335693f,-7.6124024f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(39.71766f,33.99694f,0f,24.873697f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(39.913597f,45.76052f,15.648508f,13.893861f,27.479986f,-100.0f,1.8632842f,-6.4407234f,-55.106163f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.295258f,26.772438f,26.040277f,34.40859f,-59.245777f,-22.611328f,6.3845034f,-8.870576f,17.378973f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(40.379776f,16.542513f,25.437515f,44.976593f,-99.64724f,-14.792453f,30.286125f,76.16791f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(40.540184f,48.578484f,44.06592f,13.577479f,9.707843f,17.029255f,4.060716f,2.6653864f,-3.108172f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(40.69656f,96.84421f,10.925613f,13.521479f,27.64691f,70.77365f,-14.257555f,-70.5517f,-95.3633f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(40.968117f,62.02559f,12.960189f,1.8468764f,-4.7002935f,31.29699f,-6.4875193f,-27.796953f,-100.0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(41.14607f,45.90608f,42.60313f,18.67816f,-0.124893166f,17.7508f,33.691467f,-82.835014f,28.524956f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(41.168392f,1.2286836f,-68.83136f,63.44488f,-67.422295f,18.743334f,0.8132522f,0f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(-41.40018f,-61.01967f,0f,8.132487f,-38.16921f,0f,-30.060879f,-75.000084f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(-41.42783f,20.849771f,0f,10.870469f,7.3647084f,-0.061384194f,77.545f,-7.253316f,0f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(41.575974f,27.891748f,-85.576164f,18.651316f,23.10028f,24.79335f,9.929007f,21.06471f,70.60045f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(42.13823f,1.2069032f,-100.0f,67.346016f,-81.985214f,0f,17.104364f,1.0714482f,71.7406f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(42.31189f,54.73561f,62.64597f,14.511946f,13.984583f,-39.711708f,1.7513117f,26.402483f,-78.56893f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(42.424908f,61.783382f,94.12587f,7.9162517f,10.582749f,-28.75921f,-21.34265f,1.3905739f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(42.43268f,-46.390606f,100.0f,14.737844f,8.229361f,46.15075f,8.289336f,18.419455f,57.15912f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(42.48629f,54.003963f,23.16625f,15.941203f,50.363304f,-94.170746f,-29.084787f,-73.37284f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(4.325281f,11.64214f,-89.358116f,-94.34102f,31.601395f,-38.795464f,30.278528f,-44.05929f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(43.392418f,42.928524f,27.168056f,30.641155f,1.1536214f,-34.256294f,-0.50720143f,-32.66996f,0.64578813f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(-43.448402f,-38.752926f,0f,-56.411613f,-83.94975f,85.1319f,-98.2483f,-40.748714f,0f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(43.493374f,59.17097f,80.38095f,14.802521f,12.809558f,-26.874392f,2.9071536f,-3.8201318f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(43.560665f,3.4715543f,13.278052f,34.968372f,-3.6871705f,34.118755f,100.0f,-87.307365f,19.475197f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.727314f,-55.704517f,0f,20.100412f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(-43.936237f,88.400536f,0f,-2.6196854f,17.443813f,0f,16.013683f,66.67442f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(44.18155f,42.77979f,18.763325f,33.946404f,8.174289f,-31.952173f,83.42978f,100.0f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(44.635838f,53.61633f,4.47689f,24.927015f,67.3689f,33.21576f,-12.296672f,66.05846f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(-45.216164f,-44.183086f,22.930313f,-12.367261f,-13.3901205f,-45.926346f,9.137238f,48.916214f,-9.857735f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(45.285072f,29.072853f,-94.888306f,52.06743f,65.89465f,-30.215439f,97.09f,92.02186f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(45.678905f,34.60783f,50.59697f,48.107796f,-83.38999f,0f,5.759292f,-25.07063f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(46.16592f,100.0f,0f,-9.517946f,-79.40742f,-15.580704f,-4.8302827f,-9.8031845f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(-46.24998f,29.22003f,36.76701f,2.183074f,10.8228245f,20.011446f,44.15945f,-8.123253f,-37.485577f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(46.31755f,53.9125f,99.244194f,31.3577f,-29.911749f,-63.02124f,13.625594f,0f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(-4.6332307f,-99.31869f,2.424283f,-19.214231f,-41.25978f,0f,-8.969027f,-16.661875f,-6.308656f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(46.47148f,32.90327f,-7.524556f,52.982655f,-7.3338375f,98.42365f,21.06552f,31.279428f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(46.578793f,65.01884f,63.513046f,21.296335f,49.983513f,100.0f,-11.376962f,0f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(47.082527f,66.731285f,100.0f,21.59866f,19.842617f,-65.23879f,19.469492f,56.279312f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(-47.15848f,-83.842865f,95.58653f,-31.32688f,-51.23497f,-13.440745f,-26.914068f,-76.32939f,-2.7337878f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(47.621433f,53.907837f,-20.023024f,36.577892f,88.032936f,99.870834f,14.509679f,21.460823f,-16.69932f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(-47.903355f,21.545984f,20.307138f,-15.567028f,-6.5299497f,-16.326553f,-7.834807f,-15.772201f,-79.083405f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(-48.10822f,42.06269f,0f,-59.23663f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(48.128643f,63.639095f,28.818354f,28.875477f,77.60938f,-48.36568f,4.595855f,-10.492057f,26.71295f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(48.720455f,68.888176f,99.99757f,25.993643f,26.834673f,97.74112f,28.419445f,87.69927f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(48.793232f,93.58324f,0f,3.102307f,-36.75557f,-25.752197f,0.3715683f,-1.6160338f,29.919867f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(48.811726f,37.32389f,100.0f,57.923004f,65.330025f,0f,29.053589f,58.29135f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(49.19931f,-85.86336f,0f,22.871777f,33.95768f,43.107906f,8.330112f,10.448674f,-0.49309593f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(49.519722f,29.85152f,70.4044f,68.22736f,21.561508f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(50.31911f,53.320534f,-21.875126f,47.95591f,-87.78098f,0f,-41.148598f,-18.038464f,0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(50.803566f,57.691505f,19.905153f,45.522755f,60.0573f,-78.07089f,71.230156f,-25.511633f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(-5.113862f,-77.85003f,73.282555f,-42.60542f,-11.039039f,0f,2.4381561f,52.358044f,-3.3615623f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(52.029255f,-63.982075f,0f,31.477823f,61.266712f,0f,0.76435834f,-28.42039f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(52.02961f,7.097947f,0f,17.387726f,-97.97089f,0f,-12.385343f,-66.92909f,-86.17269f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(52.44226f,87.52599f,-40.735294f,22.243052f,-12.741841f,0f,2.125247f,-13.742064f,-49.451855f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(52.66577f,67.14237f,71.36374f,43.520718f,44.53998f,100.0f,76.87711f,-32.50316f,-26.601398f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(53.32889f,40.179047f,71.63129f,73.13651f,-55.563343f,-92.19533f,22.098213f,15.256341f,94.49049f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(-53.445614f,59.70328f,-36.264626f,-3.9150558f,22.828615f,-28.205986f,14.956778f,63.73222f,-10.745534f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(5.3557935f,-99.54644f,-77.96284f,20.96961f,71.15109f,-54.04981f,7.3715615f,8.516634f,-44.456112f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(54.547462f,-68.850784f,0f,40.76007f,82.57393f,27.244816f,25.918884f,62.91547f,-4.010228f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(-54.989464f,-68.086655f,-77.85219f,-27.123083f,-29.451544f,-63.973408f,-24.05133f,41.376972f,67.35619f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(-55.24615f,34.70625f,0f,12.105078f,20.064789f,0f,2.3496802f,-2.7063575f,-33.2399f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(55.618816f,-29.898952f,0f,16.490005f,1.102434f,-77.78286f,9.238773f,20.465086f,71.519135f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(-5.6027584f,37.118927f,-4.1486034f,-30.829292f,-21.919044f,-94.25403f,-95.795364f,0.28822026f,-2.7585454f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(57.046696f,-20.860458f,62.450504f,11.476833f,-31.3783f,-82.031746f,20.238937f,-34.097828f,58.965855f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(57.24544f,79.49643f,0f,37.144894f,9.778203f,-85.621185f,81.55593f,8.092673f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(5.8697257f,77.00036f,0f,-2.3080497f,-89.09639f,19.334627f,73.99447f,54.456055f,0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(59.17132f,-33.523624f,48.15255f,4.4707365f,-1.3228073f,11.80845f,-39.965565f,11.953209f,6.1160855f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(59.4814f,-43.321735f,2.6588502f,9.751214f,-13.880234f,14.186048f,-6.596312f,-36.136463f,100.0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(59.700943f,97.9265f,-33.448563f,40.877262f,29.647259f,-59.07364f,7.706054f,-10.053047f,-77.5655f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(59.73758f,21.19119f,100.0f,20.125143f,16.034115f,24.029762f,4.7288766f,-1.2096359f,-27.681976f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(-6.0159883f,84.8143f,0f,18.65801f,91.0803f,46.421223f,-10.432263f,-60.387066f,-85.50547f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(60.7125f,62.98659f,0f,7.3524303f,-74.35042f,0f,43.047638f,27.158476f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(63.784134f,-28.431576f,97.33863f,3.988581f,-3.0166152f,1.3351542f,-44.813194f,11.04138f,-88.9814f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-64.00165f,-100.0f,49.318233f,-20.515888f,-23.11378f,-12.662617f,5.051875f,40.72339f,-21.777445f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(64.11632f,83.77334f,-62.266953f,72.691925f,42.758804f,0f,-57.028667f,0f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(64.727104f,43.675663f,57.231354f,24.235441f,26.170597f,36.830463f,6.0440636f,-0.05918375f,-32.451393f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-6.495078f,-98.44614f,-100.0f,-27.534174f,-100.0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(65.2662f,60.223846f,0f,85.04788f,-57.271786f,0f,-17.502321f,0f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(65.48722f,97.832466f,0f,-96.560616f,-29.727636f,0f,-22.494566f,6.582355f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(66.17364f,-61.754074f,0f,24.398567f,-14.93283f,19.433674f,46.35347f,61.781143f,0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(66.250015f,65.00008f,56.436005f,99.999985f,37.314278f,62.37448f,30.389343f,21.557388f,18.525932f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(-66.60408f,99.33027f,0f,47.42418f,-0.57234913f,0f,2.2386923f,0f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(66.75691f,25.910204f,0f,-26.159454f,13.706047f,0f,5.8627486f,49.61045f,-25.381372f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(66.795395f,98.64888f,94.44311f,23.85599f,17.896828f,-69.98852f,10.731738f,19.070963f,47.65528f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(67.14605f,63.201992f,-32.867283f,14.920629f,32.844177f,60.079872f,-40.307713f,-6.825784f,-5.2445483f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(67.16362f,29.127031f,0f,-66.71882f,81.05693f,0f,-17.213528f,-2.1352887f,-72.38456f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(-67.3944f,221.38345f,22.977812f,-1.8782827f,55.05326f,-15.287132f,4.2839494f,15.956102f,0.82690156f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(-67.47112f,81.04909f,0f,-7.6409187f,36.711845f,34.05138f,0.19560376f,8.423334f,-66.960236f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(6.7683964f,24.165617f,31.733055f,-97.09203f,-41.83898f,-42.38527f,-24.438993f,-0.6639417f,17.155453f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(6.7858925f,8.988235f,29.16705f,-81.844666f,-100.0f,61.003613f,14.4468f,0f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(6.8424706f,64.60537f,0f,19.83377f,63.81255f,-88.8574f,8.680062f,14.886478f,-12.946698f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(68.917015f,-68.1261f,0f,-94.80361f,1.3949375f,0f,-30.452291f,76.60749f,0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(69.82336f,171.2055f,31.189913f,8.0886f,-21.820137f,0f,-15.636101f,0f,0f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(70.320656f,-100.0f,0f,45.903633f,92.60584f,-72.5983f,20.688028f,36.84848f,34.100044f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(-70.756195f,79.7301f,0f,-16.906153f,-64.290054f,0f,67.42164f,0f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-7.084917f,17.454636f,0f,-56.552624f,91.38878f,0f,34.990295f,8.738061f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(70.95867f,-22.66023f,0f,6.489173f,-43.393818f,14.350973f,-1.6081628f,-12.9218235f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(71.152985f,84.61201f,-99.67163f,99.99994f,11.95104f,19.896128f,27.994633f,11.978588f,7.968679f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-71.41749f,-100.0f,0f,1.1238097f,71.50248f,99.99943f,4.410247f,16.51718f,-9.844014f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(-74.70495f,-31.595125f,0f,79.29342f,-99.27763f,87.562996f,15.711675f,-16.446722f,17.779068f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-75.027824f,-22.6123f,-68.664276f,-21.374733f,-8.46773f,-3.245089f,-2.0033817f,13.361206f,64.15164f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(75.3691f,84.31259f,0f,8.575157f,31.679296f,0f,-4.4726267f,-26.465664f,-43.63775f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(77.81043f,46.40624f,0f,27.681522f,23.31244f,53.75526f,9.603218f,10.73135f,10.009742f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(7.7839985f,-97.47343f,-27.580612f,28.60942f,6.6536846f,82.17118f,100.0f,14.1000595f,0f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-7.850218f,82.86041f,0f,12.125055f,79.70325f,12.283274f,-23.352808f,-58.070297f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(79.2229f,-86.649925f,90.90541f,24.213314f,-25.99002f,56.391445f,43.620377f,-97.914925f,71.36728f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(80.015076f,-55.637943f,-37.921436f,33.047974f,18.914879f,-1.7502642f,33.261932f,99.999756f,12.005501f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(8.147392f,29.200212f,62.874542f,-96.61064f,-54.22109f,-100.0f,-41.189667f,-68.148026f,-0.8233289f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(81.62709f,-53.03807f,0f,-49.07128f,11.966304f,0f,34.04179f,-34.09576f,0f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(8.176037f,33.04356f,0f,-23.747427f,-88.68455f,-99.9974f,-14.481196f,-34.177357f,-33.54369f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(81.81674f,-20.447468f,0f,97.045685f,-82.605415f,43.41038f,20.869179f,-13.568972f,7.460353f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(-8.188105f,-48.582054f,-90.3354f,-30.239319f,-19.088243f,-42.99274f,-93.68093f,45.461143f,-62.547325f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(84.95288f,-85.05645f,23.102766f,37.911243f,-10.396141f,4.239837f,77.088234f,1.3208092f,4.2527237f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-85.95214f,-151.83012f,63.69348f,-34.255383f,-43.016895f,9.273871f,-7.445495f,4.4734025f,17.72763f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(86.56653f,-27.2589f,-15.177154f,36.657856f,4.858029f,-9.523163f,55.206867f,19.556322f,22.011026f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(-8.745743f,-55.2896f,69.39542f,-79.69337f,-38.82949f,39.236366f,-19.487432f,1.7436403f,65.29148f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-88.548645f,38.633152f,0f,-27.205719f,-40.058506f,18.972685f,19.784384f,116.54701f,0f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(88.86552f,90.93416f,0f,-78.67803f,-8.986043f,0f,-50.534027f,0f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-8.967157f,33.86032f,0f,-24.171297f,43.772755f,0f,-3.9886048f,8.216877f,-6.916642f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(90.31198f,-97.1149f,0f,88.56616f,-29.141182f,0f,-71.87986f,-47.381294f,0f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(9.266061f,83.09271f,0f,-89.881294f,61.51637f,-41.32335f,-25.010214f,-10.159558f,-77.14439f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(9.285791f,-73.63342f,-7.433398f,10.776589f,11.328179f,28.976595f,22.492386f,79.192955f,-83.72143f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(93.46568f,-17.520401f,0f,3.287658f,-98.00567f,19.990454f,17.690622f,67.47483f,-12.709245f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(93.616295f,45.847702f,0f,29.241144f,15.191168f,69.33388f,8.157114f,3.3873138f,-9.799027f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(-94.02913f,25.24335f,0f,-29.133112f,92.71404f,0f,7.6659603f,59.796955f,33.49983f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(94.570244f,20.738123f,99.99184f,28.754335f,12.003631f,-6.4974823f,8.44347f,5.0195446f,-0.36948392f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(9.670141f,25.083363f,0f,-78.33964f,-24.795868f,0f,-26.674236f,19.064219f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-98.23477f,58.89081f,0f,-83.921165f,-85.005905f,0f,40.047874f,0f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(98.700775f,92.87214f,-27.524813f,38.124226f,41.832764f,26.605476f,11.963361f,9.7292185f,-14.8792515f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(-99.98215f,77.355255f,0f,-57.656055f,-9.120374f,20.910719f,-15.721636f,-5.2304883f,3.9200575f ) ;
  }
}
