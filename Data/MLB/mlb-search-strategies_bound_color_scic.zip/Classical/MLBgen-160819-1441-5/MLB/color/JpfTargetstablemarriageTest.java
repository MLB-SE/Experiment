import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(-165,0 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(305,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(3,1506 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(334,0 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(3,5 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(3,930 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(4,-300 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(5,0 ) ;
  }
}
