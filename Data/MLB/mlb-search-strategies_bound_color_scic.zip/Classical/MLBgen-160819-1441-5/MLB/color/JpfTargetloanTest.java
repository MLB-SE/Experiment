import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(67.05809f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(-74.284584f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(91.8582f ) ;
  }
}
