import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(18.410810481029642 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119164 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(89.98118153561583 ) ;
  }
}
