import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-14.955856704552929,14.523202898607934 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-37.78013762891057,94.74135903735468 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-79.05862275588467,-68.26133500394727 ) ;
  }
}
