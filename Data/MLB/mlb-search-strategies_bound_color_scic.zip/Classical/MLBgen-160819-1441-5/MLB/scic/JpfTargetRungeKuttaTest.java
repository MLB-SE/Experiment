import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2706.4386984328285 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2714.347123692626 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2714.9711312595223 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2726.9542227534607 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2727.610438789074 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2728.7890092712273 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2730.355164586755 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2733.488913588069 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(2734.400799979304 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-3.2786527134436056 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-50.47317748498759 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-57.268188849192114 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(-70.65467912881836 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(-77.47322004857062 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(78.53231923357822 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(85.3396233466282 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(87.74174138388642 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(98.20689136109354 ) ;
  }
}
