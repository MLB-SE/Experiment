import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.5995400962104185,-98.0303836085019 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.6593011032138544,0.1247599338988532 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-1.036947009651712,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-12.272754043745508,66.54996660097098 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.2353675493260283,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.2462173188376084,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-12.475774980940841,-3.885284539373842 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.5389448011607954,72.14274841514685 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-1.6420481511820242,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(16.99986314678131,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-1.7595212678753995,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-17.76692890980236,70.60647969521952 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(20.03410636594525,31.168751607975935 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(-23.63088392602903,40.47768998407244 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-2.5505920029387426,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-27.260951729655375,0 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(32.78146228212967,0 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(-34.02646387908534,0 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(34.9489377568901,0 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(61.222401950630825,0 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(-6.126804264867289,88.70242418760037 ) ;
  }
}
