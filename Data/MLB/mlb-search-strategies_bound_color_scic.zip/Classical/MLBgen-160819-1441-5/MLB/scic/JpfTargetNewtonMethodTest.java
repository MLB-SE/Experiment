import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-18.417958194932726,0.21930156749019503 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-18.75000000057249,-60.867547021142585 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(21.383670804713773,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-37.579161369676925,0.4147277256031643 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-57.39526746014325,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-58.75,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-62.25000000000001,100.0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(651.4691118968409,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-71.25,0.0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(76.6185557935458,93.022661190343 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-85.14337527011642,-39.727795638650385 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-88.07427776452896,27.279171732390566 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-89.26431333684877,94.89299408718173 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(9.044701959399674,0 ) ;
  }
}
