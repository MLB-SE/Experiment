import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-152,-383,-249,1000,-531,953 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-204,-863,-804,-205,-844,746 ) ;
  }
}
