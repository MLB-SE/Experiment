import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(-0.167800076700523 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.1879542580325051 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996087 ) ;
  }
}
