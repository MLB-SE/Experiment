import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(14.892144862038023,-38.52337698886321,6.946331842583575 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(19.030605671607418,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(51.3097483463772,-70.76170227240017,8.507754637421131 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(89.71571490808307,-54.079380217793016,59.003276587147894 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(91.10617782681965,0,0 ) ;
  }
}
