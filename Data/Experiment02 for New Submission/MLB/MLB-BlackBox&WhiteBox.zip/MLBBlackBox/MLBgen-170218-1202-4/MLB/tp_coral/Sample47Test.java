import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-11.854114668596253,53.285971084024396,-80.8201599565593 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-330.97685259740086,-223.9858877983833,-554.9627344872168 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-70.71499868669096,-23.710901575492443,11.04635317877856 ) ;
  }
}
