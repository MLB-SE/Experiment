import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-28.251435708630552,9.431794912886886 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(93.22247680285025,59.85746399421958 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(99.44022004431756,-76.70738004528044 ) ;
  }
}
