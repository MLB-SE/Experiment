import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(-16.340570671330127,86.76433941648781,-13.1964653540622 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(36.197188436763355,-94.97106740828809,16.69203615627511 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(-56.681178723864846,-2.778476510895694,-39.48722156949822 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(77.46233195359244,27.999976785648897,88.61569615252608 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(77.93946854736606,15.731434313094297,93.62644731755279 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(82.67072455507574,-8.063864720546547,-34.066673433047384 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(9.008617046577271,-78.37589257604075,-14.989073689984409 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(-93.76999202438938,-15.495045834164074,64.16638618317975 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(99.36752795861142,-30.957223398970427,56.16273958969177 ) ;
  }
}
