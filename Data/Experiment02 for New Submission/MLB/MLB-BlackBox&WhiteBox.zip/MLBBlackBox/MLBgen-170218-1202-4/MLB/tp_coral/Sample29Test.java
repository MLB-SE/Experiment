import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341003 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-20.06402099727751 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(65.02291465757003 ) ;
  }
}
