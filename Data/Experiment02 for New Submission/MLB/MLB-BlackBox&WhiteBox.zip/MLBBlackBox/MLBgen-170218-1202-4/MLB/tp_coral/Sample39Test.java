import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(0.9936547024066726,1.7253497858660174E-15 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(39.81490306606838,-99.34030445009981 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(96.67199129235334,50.583447710584466 ) ;
  }
}
