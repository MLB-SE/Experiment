import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-0.6621334623880131,92.52070802170353 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-34.40553195529445,49.06596601733105 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-34.43117906191669,89.32539536314637 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-5.761640558058943,-45.9076903666912 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(75.87018311394166,-59.67712368825704 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-81.68806871442231,-67.19328860660471 ) ;
  }
}
