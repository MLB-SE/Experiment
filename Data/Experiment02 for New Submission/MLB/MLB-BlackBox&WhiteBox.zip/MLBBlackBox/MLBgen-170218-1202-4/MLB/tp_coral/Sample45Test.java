import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-8.852242521585922,21.195617652327762 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-0.9137634660165048,-22.352974212277672,79.87855166859853 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(100.0,1.0000000000000142,-23.10354093954073 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(100.0,1.0,-98.30892033584698 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(1.9721522630525295E-31,1.000000000002213,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(20.76134661070199,65.47276897882182,79.23562830851216 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(27.510867116314074,67.603480972883,46.107051757108195 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-347.3091196850185,-262.5140584767862,17.76005941618179 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(38.11304686189706,13.345021567041599,41.07366072676044 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(44.34799018113782,88.67190529119136,17.455103310210845 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(65.67685364422513,24.01930585378662,0.42321660252591187 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(6.777006338402372,8.777006338402373,61.29641336113219 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(73.53486005937066,75.4565734817844,32.83687632966709 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(81.07165713529028,64.29519320378333,43.428388959800486 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(91.60847564586916,-91.45257079902626,30.326165128385526 ) ;
  }
}
