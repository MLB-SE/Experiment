import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.9142228431251329,46.202548872756125 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(13.992884926570241,24.841530545305773 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.3998901759547482,39.944577416878644 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(14.426492539738263,47.38119674059132 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(17.64853133645246,32.351468663547536 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(-36.50978714506423,63.713606634424224 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(44.644043887212014,-3.5038495017908877 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(46.717538619207545,64.69135302426284 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(48.58541847045436,-6.970324129511795 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(6.48567265782674,41.27475668044241 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(8.811350248766786,29.77442385804136 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(-95.387372515675,-75.2362593912245 ) ;
  }
}
