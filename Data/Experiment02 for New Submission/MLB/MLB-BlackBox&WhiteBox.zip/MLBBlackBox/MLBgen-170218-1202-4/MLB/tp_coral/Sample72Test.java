import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,-100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(13.928819999531498,12.721391692143902,-18.766544457471465,-44.070355919190554,-69.53712369711226,23.984237579368227,-73.18185697177233 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-17.09124097953935,-41.88819709267748,-12.104231865420829,-59.54981396708013,-69.78310947424174,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-17.267273227223413,39.52436359123806,95.41586813487143,176.5994997730445,81.8222401215775,154.66851185368984,-50.98825924617331 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(20.652035161253043,-4.961589157573513,-6.818601554962247,-38.3170925978214,-14.263560726022135,-7.727587849106418,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(26.12010712446522,9.218301459142708,97.23611510067138,47.06253557713927,42.24696291863836,40.84590755618629,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-41.50129764000352,47.51953784432238,35.82182602185061,-58.42595358584318,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(48.28950127835196,-48.13173549711909,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(50.831399846715215,-2.560205608397098,-65.31814854263837,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-5.222595182244035,151.65969855359904,95.10453550359603,-37.05621853062527,37.81142268989388,54.55352148967645,-32.593799875015 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(53.612188614620905,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-61.72906808703831,20.91362019304195,63.861374566329914,-99.79417444880256,-60.51624339075858,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(6.580156261817805,84.59946921180762,11.934525028862282,-85.25468177341556,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-80.26529547579989,64.59641208156654,76.43402703633623,56.70391678214486,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(84.55432348879054,-82.96651815865255,-87.69575148798671,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-98.55153902493431,-44.76106307318584,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-99.8654870010301,88.0634573540412,87.3770621419458,16.75450899563427,-96.34282653359828,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-99.91558470971283,40.68447313981258,100.0,-76.74662825832502,-89.61569657188556,61.307581913681304,0 ) ;
  }
}
