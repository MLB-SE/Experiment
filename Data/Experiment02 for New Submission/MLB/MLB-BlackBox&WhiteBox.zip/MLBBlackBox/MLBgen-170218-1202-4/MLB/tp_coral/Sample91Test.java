import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-38.61149173327687,98.89862633472026 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(45.3504508321125,-0.3191107376616884 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-50.572079748633,6.589782598375896 ) ;
  }
}
