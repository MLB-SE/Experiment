import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(-1.437658983150984,2.0668633518347215 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(26.06385185986882,-72.06710676699458 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(3.656125468038695,14.727507781472156 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(43.622059376799825,50.38294906355418 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(45.47454718550375,81.48078587055022 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(-67.9001277820175,13.388638882806276 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(69.86304745187587,93.8041202986523 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(96.02838179785681,50.87257868958366 ) ;
  }
}
