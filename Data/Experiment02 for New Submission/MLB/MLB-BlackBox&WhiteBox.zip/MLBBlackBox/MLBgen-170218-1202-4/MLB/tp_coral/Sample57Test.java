import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-11.158948970113485,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-2.9555851298137554,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(11.882373062426481,79.21993260360765,69.42260510597913,25.35554368805721,-55.401460105901364 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(2.892469147021643,17.986500530072018,-69.5470843940798,22.48615511987677,50.702059558001565 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(30.258523140345574,2.5047967362714445,64.35950819460757,3.5779405400578668,58.63932982815194 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(50.73509418297083,0.4419612641331838,-94.07947908765678,11.281099824192651,-39.39175219691169 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(90.20555909365868,-18.05517700885038,67.63348782990505,-1.657332939519037,-79.22811308383335 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(96.59316182174082,3.739465225920575,46.982253946596316,-97.14310630253993,70.91139762638485 ) ;
  }
}
