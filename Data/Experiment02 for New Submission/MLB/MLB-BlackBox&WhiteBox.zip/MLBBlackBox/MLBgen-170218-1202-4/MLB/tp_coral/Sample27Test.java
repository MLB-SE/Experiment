import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(11.155119867716621,-40.09456995456997,97.66920956061605 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(29.59538814091374,77.94687967608064,-7.547180156230482 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-70.21939462017741,16.83198171560151,-61.8531544345469 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-71.98541200575157,-99.0857733856565,-0.44994519260470156 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-76.41046062109159,-100.0,-53.26749641802671 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(96.25153284629731,28.279191664446227,51.69943775006807 ) ;
  }
}
