import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0.6760588694927634,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,54.313038857151724,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,1.4210854715202004E-14,100.0,34.447810431556285,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(19.326425427976783,66.15548903759577,22.1820567145416,-38.77364703490576,83.924025108194 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(1.9521421218715176,5.080958270634113,-7.890694445651424,26.58749781354635,72.12521852468728 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(39.156167085466535,3.7068446668490616,-8.417851873151504,100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(41.32769178986578,-28.196964724393595,-13.461746779611266,-44.48006407451674,74.32568767635416 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(4.519752764939298,10.731334472362285,46.650555107166724,-1.532019714805017,-11.084661581635032 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(47.260768044628605,94.14230133080244,56.49572233950522,-27.81709098934826,67.82424159315289 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(-61.76539920224637,-19.323831959913477,64.52335109795825,-85.73842337242326,-98.38375557706082 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(66.50204338857637,35.5242255685325,23.293461825715255,-92.10183562422853,90.61433434763433 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(81.80442132921175,3.5027201700440713,-4.584208274439547,43.20888243144785,3.848713281674648 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(9.062307900758555,-6.905497167361261,7.1710986347280965,-71.13056489106097,88.51793950069717 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(99.11839539346278,0.9796571680987538,-100.0,62.79709719897775,46.02721134956349 ) ;
  }
}
