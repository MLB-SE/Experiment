import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,79.32781004976604,0,-48.30328482614407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-19.60890836490607,44.35440689501178,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(26.10423860009467,-1.5132410099787421,-95.15725115052287,-18.164778873017152 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(34.208038084755685,17.1863037089294,0,70.3235167944379 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(47.98106486347922,-3.657298452386044,-56.27036389107185,-28.719855530632458 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-6.97154994279457,80.45479498961984,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(92.87875438631431,14.256639496548857,29.769532471062774,12.939231922445344 ) ;
  }
}
