import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,-0.17088204230742576,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,-20.487656406394365,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(-0.6686225359076876,-22.22913520104636,15.94872872341746,-46.79721124788907,-57.33974418132999 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,7.105427357601002E-15,100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(100.0,-7.105427357601002E-15,-100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(1.331008119459895,80.65637034569718,-5.815561828251532,-87.03958288238903,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(20.564212365267238,88.49026658346662,-44.21802846499371,100.0,4.374253429277928 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(-20.63550013541156,-75.67134601409147,-85.44315580868458,-45.50768662861924,-60.67691550482566 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(39.8191921311477,13.355786144906006,24.77666785648161,-20.548338865506352,49.15995718553546 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(42.08584307529239,-75.22599320296955,-2.849336121385292,46.6234130878141,-1.3077688902529019 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(45.4934218414779,11.076587601918083,-56.675347419290816,-38.64204207692485,94.61621797664029 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(51.17549453523671,45.75440892708508,93.38452302121206,3.9444059308872994,-9.368169889764161 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(5.479002791786655,34.904114931083,-40.71797389811915,85.19412719296307,23.41733517804172 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(67.19101476071006,57.30672833961802,66.36277751964124,-94.15102273572214,45.340007727057696 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(6.921565140803411,72.4200382103989,-79.71731527320725,45.22791590229525,84.14735882352454 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(7.99276026925088,77.13356376675512,65.51547749733533,26.480834859293452,-30.857494887048603 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(81.97003936414978,42.15823608492386,-77.08378634845805,34.66291598695804,16.29701497525366 ) ;
  }
}
