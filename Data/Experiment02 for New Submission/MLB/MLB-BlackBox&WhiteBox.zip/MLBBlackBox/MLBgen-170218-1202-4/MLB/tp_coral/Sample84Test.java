import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.16558818073997372,0.027419445600774205,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999005,-100.0,-13.253597691794994 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.00000000000027,1.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,100.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,100.0,31.88906247764978 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,49.135084384201676 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,71.6253999652236 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,-8.286693600127188 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-30.635304551393858,-94.67269806147269 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-62.03829415094611,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(33.287686256780205,23.12289455194265,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(5.90483438494924,34.867069113678866,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(-7.038772272397978,49.54431510267859,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(-7.874610675220566,65.8234493362157,0,0 ) ;
  }
}
