import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-36.73659373603555,50.73855533738063 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-80.44070364918895,59.502862774289326 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(84.19337384291964,-50.54056954510362 ) ;
  }
}
