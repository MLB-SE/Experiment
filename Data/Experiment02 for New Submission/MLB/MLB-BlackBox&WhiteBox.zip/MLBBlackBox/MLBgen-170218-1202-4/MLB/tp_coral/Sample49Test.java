import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(10.617533131106686,39.3824668688933 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(16.012655354257376,63.42067821442217 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(18.628229385549616,28.648375336126435 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-37.20820206498152,50.82122525065387 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(50.79877543745087,67.55870910016282 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(56.45046869269619,-6.450468692696191 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(7.34646484492718,-2.7104362831336175 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(-77.72338409206014,-98.21605011185368 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(97.53831820069394,-7.649211582121595 ) ;
  }
}
