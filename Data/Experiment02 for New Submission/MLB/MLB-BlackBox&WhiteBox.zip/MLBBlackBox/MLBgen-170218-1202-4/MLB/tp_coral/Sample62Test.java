import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,1.759613696803953 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,57.5728016229705 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.9565304726671968,13.053146900235092,-74.2860683398847,4.267435818702793 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.3082595696385122,100.0,100.0,1.3177892083938185 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(-13.473519000390866,-44.58907355300092,-89.2064216568867,-67.16690263934942 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(15.158810424767083,96.21577085748496,-70.21784069558575,82.67854424881318 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(1.5292568026253113,-1.154122327223217E-128,100.0,-90.50473069649945 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(30.541066042081923,0.0,-88.72039574802477,-71.4138886747419 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(31.831005998800606,12.329102796544106,69.55953271350839,28.600705146166206 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(33.89709850094863,48.70370998597332,-41.44959965171735,-68.28552227750642 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-37.71965135697708,39.038453542049105,65.95438766134359,-10.803717237682598 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(40.47830533499498,2.56845983207721,14.571795860671646,-8.463143542799934 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(44.00664831148248,63.7324667851868,-52.100455587329165,77.80588415431444 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(45.34044577879292,15.98369960122982,36.36974239593568,24.95440298408706 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(56.39255508663909,-57.55576630274055,61.54828718438819,-52.91239143194404 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(62.05881894326174,-41.65691509527003,-7.521333153710415,-81.61094582007033 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(68.91952462894227,2.7820304583014774,84.05055573965191,40.46403499781459 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(7.507093749477292,-33.443210856115336,88.83907208541427,-0.7083224593574755 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(80.68026762026452,7.89215749487191,52.67543625926055,82.1413167185924 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(81.79625816911431,-54.525321134323754,99.07845133679672,68.47716384589694 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(88.68201952562178,-42.59795720433661,63.37091195727878,-2.08183737779317 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-94.79144356445427,94.55336708255376,14.532287903004482,-61.04041771365558 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(97.19933080079687,4.440892098500626E-16,-26.183655677630014,-13.820505675725371 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(97.89185245354162,-90.26472580433436,96.15491610907475,15.073422446649644 ) ;
  }
}
