import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-33.07854433526802,-28.94786660947652,14.423229203177186,-51.787268941425246 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-59.435729931220635,-27.850861916528586,79.7730540777026,-90.42736206205642 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(61.89163204577858,-17.583473704869675,72.61919617856,-43.52500184206176 ) ;
  }
}
