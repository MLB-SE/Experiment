import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(2.480589815984928 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(78.28822491238589 ) ;
  }
}
