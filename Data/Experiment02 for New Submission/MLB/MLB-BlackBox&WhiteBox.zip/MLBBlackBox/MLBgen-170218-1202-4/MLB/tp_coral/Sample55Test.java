import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(10.880522957996966,-14.849282776277521,15.882472647430289 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(1.2311435849218386,1.994718859636281,2.946891623268019 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(24.139257776640633,46.704656874761184,25.324436779646827 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(25.737078885831437,72.16921965346867,5.020714076518232 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(28.43134321131182,-94.63324015723805,28.286462072182673 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(32.540525599225305,-18.64689341260531,3.404225252393786 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(3.3545981260348183,-68.68223179098442,1.6044536170378159 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(3.781300338577836,-154.68223227164196,4.768331971589106 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(37.82772184891118,0.17687835794970397,56.8398223019889 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(43.435070872538034,-32.589103440709806,92.78556323865746 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(44.87659754154478,-43.848740019273016,65.88153747549086 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(46.05740068972554,-63.6082803911634,63.88805533419031 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(50.96393792587125,-12.88311728542466,64.74656732363465 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(53.50041492957339,-70.20198756809609,55.823350061208295 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(66.94566041447544,-72.74788252716564,67.89067061212192 ) ;
  }
}
