import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-1.152228660906431,-69.31160350940344,13.263185073987557,-59.838230352519005,92.00567181826753 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-13.471715611740294,22.958304196363486,74.80683312743591,-70.04981511268653,-75.33488825315553 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(36.81398595259836,41.98329237933166,-83.62385995108734,0,-26.423315785395744 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(48.19667357129033,-88.74262460906466,81.64453633085503,56.871022456667845,-85.55933767248631 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-59.26689945162449,-47.6974125348554,-7.69666557743966,36.95667101894594,-62.546337060006785 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-64.35022098324797,32.6243669186074,-34.49934511010193,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(66.33542478983802,-39.00752748009126,21.421896999428895,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-67.07658884788182,23.87426241667741,95.3856920091699,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-86.23138073919858,100.0,-81.66567070976924,75.44870953551153,45.45212209420707 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-89.85045227239473,2.0528189812370883,-86.89423499360899,0,93.28373429406503 ) ;
  }
}
