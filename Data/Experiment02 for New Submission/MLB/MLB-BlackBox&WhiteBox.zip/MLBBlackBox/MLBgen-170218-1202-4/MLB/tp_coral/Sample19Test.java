import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-38.33963080438008,51.639287497044535,-46.03708181473638 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-43.39592925273266,9.949476868777055,24.186292469417552 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-66.22360650533514,65.74961465965816,-70.91208058049196 ) ;
  }
}
