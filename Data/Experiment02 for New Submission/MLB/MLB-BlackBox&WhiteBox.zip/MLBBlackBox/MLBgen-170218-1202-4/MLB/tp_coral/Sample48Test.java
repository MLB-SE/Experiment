import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-2.4196689358995798,-64.86920338130932,0.065647769799142 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(48.591630573348965,-38.02713277594314,10.564497797405828 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(55.25709456606302,52.443091138834546,75.26684782243217 ) ;
  }
}
