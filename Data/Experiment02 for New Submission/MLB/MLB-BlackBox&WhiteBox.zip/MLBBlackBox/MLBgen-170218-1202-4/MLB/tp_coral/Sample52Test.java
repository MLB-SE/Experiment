import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(32.240725212609085,3.3061775375816893,-51.80174102937352 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(65.82577340047112,38.09442066759894,-87.65182288681663 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(-80.52177129376021,45.58365616794339,92.369463301156 ) ;
  }
}
