import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-1.3762889986521856,-55.3408865043282 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(6.733172791152995,38.60244304437002 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(8.553858503744209,96.63173752408022 ) ;
  }
}
