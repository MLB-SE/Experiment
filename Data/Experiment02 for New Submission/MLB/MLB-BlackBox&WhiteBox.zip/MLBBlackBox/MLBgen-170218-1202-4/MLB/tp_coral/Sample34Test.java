import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(44.53807510159078 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-5.497787143782138 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(57.49304678345288 ) ;
  }
}
