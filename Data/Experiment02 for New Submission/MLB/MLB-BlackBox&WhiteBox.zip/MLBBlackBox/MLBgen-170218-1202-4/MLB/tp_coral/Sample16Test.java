import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,7.285397318753596 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-78.90545068284824 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(43.03943321465121,24.462179491754753,93.38019728042718,-66.6434951396478,-27.70548161460931 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(71.04468738825679,14.199954549963806,-36.54313661918245,-100.0,16.660360753010224 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(98.42810329232609,80.17715134767295,72.09373810872057,98.52362629823338,6.259049814906589 ) ;
  }
}
