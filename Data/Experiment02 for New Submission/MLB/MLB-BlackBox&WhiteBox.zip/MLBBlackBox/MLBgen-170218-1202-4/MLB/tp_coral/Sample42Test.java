import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-88.02230255528332 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(2.181334660988142,10.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(38.37469884050947,45.53614235234579 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(5.066110769757756,40.5179560707588 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(58.85018966701372,87.76454237487593 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(58.85678181778948,0.7584259526232024 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(-66.58413532514129,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(-80.94955211764538,90.51498818759259 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(81.33636183515594,5.753865977262976 ) ;
  }
}
