import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(2.1917030796883395E-8,100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-7.621377222856991E-8,-100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(86.6381328967901,60.378082227050555,-52.1104735881188,18.549174251267047,0 ) ;
  }
}
