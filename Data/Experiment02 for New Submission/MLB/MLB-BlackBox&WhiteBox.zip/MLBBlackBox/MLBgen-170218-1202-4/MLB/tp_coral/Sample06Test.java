import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(15.412140048240275,-17.93637652269051,-27.18530249366043 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-44.56089781037167,-97.53114985406151,49.29234388660407 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-94.3368532932732,-61.04197508894612,-53.82324363318247 ) ;
  }
}
