import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(14.137166940810834,-46.75830710952433 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(28.27433014458968,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-37.42572478560988,81.55037629472193 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-42.1940455602023,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(51.38862226255574,-36.84945369623978 ) ;
  }
}
