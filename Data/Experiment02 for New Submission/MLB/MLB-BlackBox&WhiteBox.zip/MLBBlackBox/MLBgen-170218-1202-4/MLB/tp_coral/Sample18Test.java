import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.41871743720222576 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.9595496299847904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(-82.79348648927743 ) ;
  }
}
