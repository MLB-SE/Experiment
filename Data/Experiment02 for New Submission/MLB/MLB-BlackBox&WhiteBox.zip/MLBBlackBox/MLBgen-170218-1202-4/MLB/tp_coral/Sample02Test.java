import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-21.60834769546781,45.93589435682055 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-35.44838475365147,52.981160951228674 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(41.895399296259114,-21.38656774149436 ) ;
  }
}
