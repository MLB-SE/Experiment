import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.4493056263623032,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.81147344878892,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-38.09742591447409,1.1843046129037553,-13.843385192461337,-19.079271470847083,-33.16324962259818 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-61.72898333543917,1.4229322687546926,-15.553169677703863,-26.430528533315623,-23.053054121332295 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(83.60478155301158,30.82712094357538,-82.82681209414824,98.51608036019977,66.3630876300536 ) ;
  }
}
