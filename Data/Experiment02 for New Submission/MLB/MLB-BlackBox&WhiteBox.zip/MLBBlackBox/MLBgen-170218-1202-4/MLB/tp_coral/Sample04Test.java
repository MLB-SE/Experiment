import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(3.7831915349523513 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-62.25104779019921 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-682.0831359567671 ) ;
  }
}
