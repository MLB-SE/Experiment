import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,3.2678252249205997 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,8.988013186081403 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(13.28578309427273,27.408170092154624,99.90187049022467,-55.68628703564231 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(15.971764883079658,-16.841351176648764,74.96227443424803,-86.20452620817524 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(-18.524357825077047,71.24405193783653,-35.57523809427627,-10.021132412248932 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(28.44491176143783,-16.728571914437055,54.846433304662995,-43.13009345766222 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(-30.749025187633485,55.529371146563065,26.845299892359044,-0.5537434433837752 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(34.83108347692518,0.0,-81.86768770173347,-74.92224701243353 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(36.52433454733281,55.42983154406687,55.12667849258838,71.49882381711564 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(4.240694565592873,-0.0020285181450983053,54.43023679262248,-46.35630349364295 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(5.401730803872735,57.500975810456204,100.0,-1.595192924492494 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(60.22956610252379,-20.286781739124045,-20.12637359523977,60.06915795863952 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(62.01332020134919,-7.407641420281024,-96.04928348280606,76.41199386506295 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(66.04514626520475,2.023713328583426,-83.61954563160808,5.507976781258634 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(71.42958125526964,0.4380840903405012,-100.0,-100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(81.96317028454428,32.826984994342894,30.413519985643035,-23.108304042709122 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(87.36186136333762,-83.42107507068573,22.56343138448686,-8.24121771034882 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(91.8657219428367,-90.80359939016824,21.238938426537302,-6.875629269123678 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(94.44956518388727,-26.2871339616959,-7.153473681947631,10.40777146293776 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(95.59597915879371,74.96272487928564,42.506291500321225,27.573703299162915 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-96.65727880977487,73.38292389549946,15.57703800934243,-95.86216308328919 ) ;
  }
}
