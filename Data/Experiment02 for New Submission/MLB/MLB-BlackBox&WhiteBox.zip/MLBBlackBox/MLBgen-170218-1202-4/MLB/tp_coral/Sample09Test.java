import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(12.46901176364159,56.36968621681655 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(2.5699734707834,93.17363504657955 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-77.83551361634495,-19.46335698456214 ) ;
  }
}
