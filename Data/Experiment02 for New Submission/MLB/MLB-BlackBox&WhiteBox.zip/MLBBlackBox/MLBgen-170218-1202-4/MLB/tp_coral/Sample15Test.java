import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.13682019922028132,-6.913563532287398,25.976151994354296,20.71821221670089 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(17.223995195570737,-35.56265152007032,-81.70376058498013,-79.2336275921622 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(31.063824420912454,61.087466826187665,-40.178945355495266,-72.41449106579941 ) ;
  }
}
