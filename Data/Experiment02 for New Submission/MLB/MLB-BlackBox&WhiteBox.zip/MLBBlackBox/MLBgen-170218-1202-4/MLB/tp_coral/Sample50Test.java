import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.003587204949481565,-0.05989327966877056 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(11.612533421652927,24.61253342165294 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(17.02071871546245,23.38648501001505 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(18.49993126622543,31.49993126622543 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(19.813873733177417,23.787596112412984 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(24.15265774868311,87.49538754739504 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(27.310133610967597,70.31853484244888 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(39.4908608271669,-1.8336192933331432 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(53.13640917675909,36.96834425874417 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(61.940996101557346,-11.940996101557344 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(6.380975578458802,28.562979373695953 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(97.78284988435274,-57.70758896924837 ) ;
  }
}
