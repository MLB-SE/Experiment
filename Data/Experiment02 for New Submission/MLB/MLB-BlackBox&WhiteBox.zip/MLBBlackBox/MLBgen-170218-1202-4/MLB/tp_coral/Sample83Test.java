import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(7.730733023470321,59.76343512330778 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-88.48747436055824,-35.29213122528769 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(9.416297056490135,88.66532935003508 ) ;
  }
}
