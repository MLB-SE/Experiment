import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(52.561548414326126,-44.70756678035164 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-53.581050902143225,-91.61281186994779 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(61.39923064916982,-36.30111552968018 ) ;
  }
}
