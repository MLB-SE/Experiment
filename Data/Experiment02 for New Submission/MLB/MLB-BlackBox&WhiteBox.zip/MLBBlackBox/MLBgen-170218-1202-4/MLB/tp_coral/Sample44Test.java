import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(26.354654743859072,70.92995424510843 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(2.9404829816047453,96.04483863417573 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(43.445515629168284,0.29785323081685533 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(-47.099717801352625,-50.24292855361851 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(62.90378198038292,40.27602075175355 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(-99.16745068607725,-99.16745068607725 ) ;
  }
}
