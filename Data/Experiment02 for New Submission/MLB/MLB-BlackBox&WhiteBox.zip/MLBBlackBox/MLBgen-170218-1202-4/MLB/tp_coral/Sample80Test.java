import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-2.7230885585020133,1.5508451039231566 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(28.282776875749676,-51.273658910209676 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-41.914344572547634,-96.63496442828368 ) ;
  }
}
