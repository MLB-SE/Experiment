import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-33.77900657827526,86.94578681981793,-31.828119833240418 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(50.03409060811214,-85.54389997652837,16.050293403251885 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(-5.044188818855957,24.54878409529981,5.759873262741394 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(61.336583552492186,7.025461348757858,94.08514966770468 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(-76.0640126174956,-14.890449036091539,41.90353410638588 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(89.54627532311724,-22.70153091078882,40.445049693164464 ) ;
  }
}
