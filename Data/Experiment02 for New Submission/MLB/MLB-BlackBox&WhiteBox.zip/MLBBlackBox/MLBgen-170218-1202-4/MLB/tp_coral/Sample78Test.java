import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,-78.48595199166323,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.40746572400176717,-72.69726961316152,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,50.02041579307169,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,96.26164450323358,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-23.384959239272547,90.0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-38.77148357945386,-3.6E-322,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,62.35256391731775,-62.15904500348839,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-72.72430692628113,32.668833589760254,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-0.6978341432544113,0,0,66.20274018596749,-89.18477836653749,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,-100.0,-100.0,-100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(111.0,323.0,863.0,-111.0,250.0,892,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(114.0,-1693.0,-793.0,-114.0,-1171.0,0,0,341 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(-12.903785397488946,0,0,-25.059205802644662,-90.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-13.881165587198367,0,0,34.07899323182153,-89.17911918447324,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(23.732310537778194,0,0,42.98688306784307,5.9E-322,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-2.376775178986764E-28,0,0,6.089905273297869,90.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-26.836747005318614,0,0,-55.11928395956789,44.2511247034933,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(26.91810763584074,0,0,-99.99999999999898,6.731266206E-314,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-3.5282093367402467,49.03121500712396,68.06928202635837,52.32864024159974,53.36404276403289,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(40.53292270094397,0,0,-86.80177801672922,11.748501129307428,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(42.788424102443784,0,0,-9.232978617785736E-128,-46.48030712409856,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(455.0,-286.0,-106.0,-455.0,-2006.0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(46.168025300367376,0,0,-12.992025491995477,-90.0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(5.006316949836669E-19,0,0,100.0,90.0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-62.21970953857576,0,0,87.76751756199556,62.029399838280455,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-68.50841375653687,0,0,-79.78552359572662,9.217886557089415,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-70.7885346842966,0,0,-68.89446725944964,50.15282413966548,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(971.0,616.0,616.0,971.0,-2398.0,0,0,1 ) ;
  }
}
