import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0.8554612117299017,-91.05744997355109,1.4363534671381741 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-16.415008870491505,-36.13554150443876,-46.48844612923768 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-37.12357841006062,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(65.97343680090108,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-97.72715319228757,-52.56292093145909,-95.82904094703794 ) ;
  }
}
