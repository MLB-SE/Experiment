import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-100.0,100.0,-96.97387006387136,51.00527416287382 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(100.0,41.36523267381085,-100.0,0,-85.87205800925194 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(29.632827867825252,32.056675220296064,-27.572847636950392,-63.78074376185451,44.066537988603216 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-33.02577092335555,15.601149707826337,63.24878191655429,-17.816318513357473,-17.374639306693737 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(46.35080704116618,-62.365120235765126,-28.71059323448503,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-69.73633470736232,33.91302849374941,-99.58140388697917,-39.87346999041237,49.663426449668236 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-73.69617241848073,-97.20242021600323,-17.489472953958312,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-7.371461475047681,-50.001960641030976,48.12027619835655,0,-85.43197249736791 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-82.23665775730167,-59.01744039014049,62.53313451478661,-70.49063392594412,-68.85877987369045 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-87.23116698322607,68.31968622259697,95.70874600326664,0,0 ) ;
  }
}
