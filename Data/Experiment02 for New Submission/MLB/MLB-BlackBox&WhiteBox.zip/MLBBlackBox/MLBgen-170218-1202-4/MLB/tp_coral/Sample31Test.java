import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(5.048528432046282 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-72.56440395931376 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(83.57840554428896 ) ;
  }
}
