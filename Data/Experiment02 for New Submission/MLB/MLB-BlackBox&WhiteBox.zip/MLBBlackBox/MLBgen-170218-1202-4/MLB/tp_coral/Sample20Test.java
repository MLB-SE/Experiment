import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-22.42609752661081,88.67473029414202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(25.791799264544753,-33.72812577640716 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-35.292760834020825,27.26401756388927 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(37.82167649784765,34.64865235094089 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(49.30147593809056,39.41629484671293 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(52.25545969960436,49.97950308113403 ) ;
  }
}
