import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.914280270811247,16.787274429323972,-89.95136530900359,40.64067620270407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-80.05071100535787,85.17971993479429,23.963142148505852,91.39115658280676 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(98.75845635334395,-88.4123003625402,-22.553575287957074,93.2610450670594 ) ;
  }
}
