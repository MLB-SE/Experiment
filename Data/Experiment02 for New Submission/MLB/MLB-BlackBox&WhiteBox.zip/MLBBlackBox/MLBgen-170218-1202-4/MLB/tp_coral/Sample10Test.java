import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-21.715396518893797,82.24310637870221,-59.7752304734305 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-60.724007814983494,-79.95818846427053,-78.41871555707635 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-78.51043295594557,-75.93440781829868,93.51907629997228 ) ;
  }
}
