import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.1750047680517497,-75.07965773974638,-82.33344138023027,-19.42602396052122 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.6119143096547432,34.63087793071841,8.155936854436135,6.612370449177689 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9289129385352112,-52.78949255720418,-46.770922897177094,8.594016395638803 ) ;
  }
}
