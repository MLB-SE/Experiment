import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-11.96971101058169,40.070623755791104,77.90127021358182 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(43.45262139910457,-23.59052604252006,74.85193016937066 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(99.71888105581533,41.101722007315146,21.480742474614686 ) ;
  }
}
