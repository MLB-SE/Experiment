import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.885468063380884,47.31452310553337,-19.2476713833549,69.19822013576538 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-74.24148657795142,47.418504014845325,-57.237130027719104,-66.43362814203309 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-77.16431347533428,55.61822369425758,-74.87443278312199,-8.683068681566482 ) ;
  }
}
