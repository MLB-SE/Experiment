import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-0.07525706352022773,48.396159213108945,56.416369953203684 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(82.83000928501295,18.294855789996788,76.38684110200401 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-94.30063023907516,29.76585594740132,89.82424918955527 ) ;
  }
}
