import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,18.7907666373422,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,25.160374883286735,0,-49.14670401337129 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-57.35527768208491,0,-86.77589117456928 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,93.2005820595825,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-25.011915560841587,79.19916942921213,0.9520872621191866,85.79654941460473 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(30.317278301955525,-71.63888830919241,1.0820953106069453,-11.587200758461407 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(63.82624189306205,78.02021262572191,-92.4303960406087,16.772269765630753 ) ;
  }
}
