import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-0.2565202421634609,-90.68062174106338,9.947809929830905,-65.32175314240602,-26.21388834815053,73.33777815199743,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(100.0,100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,55.32589148968541,29.497110157239007,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-15.996759566208851,41.11189831349887,91.37845138043338,-84.49169190602974,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-30.403204492155368,-5.383792355959386,48.233535011018375,58.97105582161893,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-36.7878885283706,-59.5339649303009,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-48.34436469345771,-69.5314341430702,54.636659685272875,92.68225077268728,-1.576063818583274,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-53.93309191949843,-77.74078007297645,-95.72324393562711,-26.640282936764113,54.17615788824158,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(57.31514707681089,85.01780131596377,30.82110582142161,74.18360270264043,86.34217301508019,4.68508531754733,-71.97388634121825 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-61.5221023694799,-11.522810151774255,-28.6846576485651,88.37491806677117,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-62.096325601447155,-1.0885901392964143,-52.372846159368855,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-68.17334311138396,-0.3412500020089908,-58.33358076709045,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(72.9728954728439,93.46407887928672,43.122053206101775,91.96915235361294,-38.906456691777194,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-73.54768935966689,-31.180473117413413,67.01402292202587,-76.44989842521166,-64.79916551071355,-92.19974619254418,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-80.85205757519729,-87.20001375061628,-49.64364676302722,-5.744897004682969,25.368510789966635,41.47926363812266,42.29928919874163 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-88.79680339413171,18.585933774444328,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-93.17686221091857,58.81760262001908,-66.75780687093433,-91.32816498885383,60.91454110728396,-13.976304710377079,-64.56351162936775 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-98.78266146590148,38.24068774190803,201.4992231215328,-72.06925673431456,-88.25851437822334,55.40660535473165,0 ) ;
  }
}
