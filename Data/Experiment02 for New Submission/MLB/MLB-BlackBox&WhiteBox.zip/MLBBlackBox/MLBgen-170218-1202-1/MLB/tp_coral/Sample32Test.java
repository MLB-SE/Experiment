import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(22.393860280462263 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.000000000000004 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(36.920679802770536 ) ;
  }
}
