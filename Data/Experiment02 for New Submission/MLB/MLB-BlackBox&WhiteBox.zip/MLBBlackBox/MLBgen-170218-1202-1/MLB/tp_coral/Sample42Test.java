import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(-0.4722187500774595,86.4711930692032 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-3.0040270775242264 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(-11.59185462785986,5.4348320144800795 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(21.927572926414896,86.8334590097464 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(41.955370629216674,0.951278738205545 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(56.05300983712945,52.08737703615873 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(72.41019214366497,90.11141245192061 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(7.348639657379458,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(7.801360786392351,93.3877304067075 ) ;
  }
}
