import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(4.995830593933584 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-51.78983671883195 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(54.071738039909036 ) ;
  }
}
