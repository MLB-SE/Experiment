import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,15.968976747001847 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-3.6136269694203804 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(144.1748066383551,14.923717081210846,-13.12584945954525,43.05443119802868,7.063255314824119 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(58.65707273988659,-41.79253837399837,-25.95361925407751,55.37696406409481,10.726646408552924 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(86.4397632172197,14.468413797999428,48.39863042539383,-20.562860164757637,90.93344995659595 ) ;
  }
}
