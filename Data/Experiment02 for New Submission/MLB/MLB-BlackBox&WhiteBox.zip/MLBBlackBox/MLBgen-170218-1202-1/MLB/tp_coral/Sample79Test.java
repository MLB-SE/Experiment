import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(33.90124338317227,4.049685119259536,65.14855048630542,9.83413015101398,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-5.76762787211025E-6,-100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-8.590141776762444E-8,-100.0,-100.0,-97.4163305272178,0 ) ;
  }
}
