import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,47.48199175653929,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,7.954350264351248,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(10.793572216464312,3.391864306196622,-14.275067492099566,96.21586864943043,-48.18226849672398 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(-1.6439159094750564,-28.788029198930005,48.0530399045155,43.08753975936125,43.71089904514463 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(16.5272784931678,31.62322221657857,67.98236845681248,-10.67894318807285,82.20922965487847 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(24.865673041561404,21.868939153517076,90.42480269070641,63.11930575872746,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(3.126157741871964,49.597287446904375,36.31261974773557,-5.696446449497316,-10.052717359479459 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(3.1781482161702854,37.23281566213648,-99.79840523981458,54.97677895966763,73.3023719462235 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(37.38703742981866,51.832662995252065,-92.29239309923383,-46.243713962275066,-30.122916304862017 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-38.12373595678822,-61.920203243502606,100.0,-69.34351224903077,-13.698839593421113 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(38.25497060715526,40.75704379588434,82.98983637864322,74.47361451468694,-32.30238747554195 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(38.51526139210105,16.412003579442768,84.24420824426522,49.65477181859717,70.0038227645671 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(-45.90936101206897,-46.908496212220975,93.19825135435337,87.77289450400866,76.40409576146371 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(61.46095343912074,0.7317944264463137,-36.275899016526104,54.94511886650466,-1.2616531418655512 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(6.149870281552381,-79.10494073304804,7.321531138061488,-84.48599027878826,65.29605695953583 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(69.439734060114,9.355103579854983,36.16626475112476,-11.566849849747811,71.90499693094375 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(9.812094465920625,65.33633993222821,100.0,-38.80289423429382,29.875864470749974 ) ;
  }
}
