import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.0018386482728658,-2.0555509005442115E-14 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(69.47906353996493,-40.479029523803554 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(96.26156310175645,77.51352613590464 ) ;
  }
}
