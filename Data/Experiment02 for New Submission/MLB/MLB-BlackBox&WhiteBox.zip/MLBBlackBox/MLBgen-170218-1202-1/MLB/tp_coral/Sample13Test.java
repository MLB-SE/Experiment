import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.3360513185308207,-49.005391215516305,-13.283092803100587,-77.80123639404202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(40.62709715996644,3.1521361625603532,54.634182803571065,-72.04804534618674 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(84.4581098074097,-61.24792068795226,-59.54468594359159,-54.16097482055788 ) ;
  }
}
