import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-1.3145874456508346,-98.68541255434917,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(58.061365515359,31.3200508394373,-0.9573537816219329 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-90.34597548172965,-41.02282072583845,-25.14215756401677 ) ;
  }
}
