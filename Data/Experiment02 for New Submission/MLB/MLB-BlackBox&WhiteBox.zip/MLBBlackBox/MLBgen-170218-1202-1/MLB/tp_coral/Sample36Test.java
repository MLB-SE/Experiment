import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-21.991224486926306,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(46.84400699610961,32.56503607702868,29.327545632434322 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(53.24749940025197,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(63.51979470496482,87.20053650707234,1.4677829320898574 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(76.94935138666347,-64.09679523695534,9.99777329646284 ) ;
  }
}
