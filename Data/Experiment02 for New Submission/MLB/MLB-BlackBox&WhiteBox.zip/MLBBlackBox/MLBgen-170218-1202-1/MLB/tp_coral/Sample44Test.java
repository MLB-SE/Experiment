import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(13.285094690394189,71.99481561662145 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(3.0179422039523267,3.017942203952327 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(-34.62022438703191,-40.38008530530042 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(60.493426754774106,15.811169950456772 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(72.70766178041404,85.94176653536468 ) ;
  }
}
