import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.7985203597562247 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-26.351227882600554 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(81.11882727621395 ) ;
  }
}
