import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-53.673052527643385,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(-0.8242001652514591,-81.13114177142421,68.51517191058369,46.98293755117609,-47.68753810619242 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,9.170189888543675,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(1.1055899213235847,76.68650501953337,95.82411307036213,64.83326907133849,25.969275269954608 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(26.92233300773907,17.90976999736283,35.602286235294144,69.64485178982068,87.39711330869179 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(31.954527051144744,14.435240199255583,52.34801720427834,46.53217999423944,20.131658762506447 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(72.4285468408668,86.17237820949327,19.46717070313045,66.85582022559242,-68.4388723831451 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-80.34840330063813,-81.20916387808448,90.0836965547669,49.5399213729585,28.66512871122322 ) ;
  }
}
