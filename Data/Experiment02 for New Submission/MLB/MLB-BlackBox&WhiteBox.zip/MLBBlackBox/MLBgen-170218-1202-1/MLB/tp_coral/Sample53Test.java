import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-0.023354681419561985,22.39135589061327,0.8641972303410905 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(35.44359418667321,2.7665363357007045,92.28859601650709 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(-59.39061058098953,44.41234410531024,-55.37801867768306 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(60.721605396187385,46.10321182627524,73.40838971864429 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(65.08729535226792,-41.62030960273084,84.40073008468852 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(65.46950101739333,-7.035852827672713,73.65764544216867 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(79.34493971692606,-32.622338559622534,88.97078355596571 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(81.8599238772643,-54.27126623579841,59.010198251668186 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(99.97852022481047,30.02970522390615,-71.83476372677009 ) ;
  }
}
