import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(20.826787889088322,-13.074493713526644,20.996564139434806 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(-39.00786350883172,90.78127216734592,-12.590501959256144 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(5.279482082508906,-21.814503336650233,-54.90018756717823 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(6.03506986121597,39.35192522068866,-8.79674062800126 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(63.624700001839045,-24.739537877060343,-60.332757951760165 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(66.60754165474776,-76.41025150776808,64.792274292993 ) ;
  }
}
