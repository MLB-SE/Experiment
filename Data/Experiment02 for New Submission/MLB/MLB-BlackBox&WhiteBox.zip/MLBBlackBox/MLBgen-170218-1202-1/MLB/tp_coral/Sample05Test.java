import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(13.593892485395259,9.0589712457231,8.269176304485157 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-30.416049625481463,-9.659816292512986,-46.60743453583047 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(85.73962566097586,5.999782014657278,-82.41200100079884 ) ;
  }
}
