import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,0.15040531410377866,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-11.648448745274749,0,-67.76469029697955 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-31.43159143460925,0,88.75782491332532 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,9.424777963318984,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-17.851129993519777,12.225185791203723,79.78116488955379,96.70932977186877 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-23.828270645303192,-66.39011162143662,49.40629448844112,-82.20364129990966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-46.923836629787296,26.921955896466997,64.39142079761484,-39.69773705007571 ) ;
  }
}
