import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(30.452822336716274,19.553532356765565 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(4.995168369230612,-77.86837001233253 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-67.06438659498788,-11.487572722927723 ) ;
  }
}
