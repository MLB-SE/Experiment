import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-68.42874807746009 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(69.9004365423729 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-80.22096792131941 ) ;
  }
}
