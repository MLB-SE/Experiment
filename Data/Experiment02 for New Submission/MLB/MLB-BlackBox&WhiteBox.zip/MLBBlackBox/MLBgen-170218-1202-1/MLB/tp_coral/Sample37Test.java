import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(33.366158919361936,-55.85474384018958,-58.780847756416456 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-49.443017925056566,-19.334197821208846,-77.08930615290785 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(51.43165884618338,-61.357592136573714,36.018798282667476 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-65.97344589897955,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-74.13447494194448,0,0 ) ;
  }
}
