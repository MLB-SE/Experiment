import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.9392402261968775,44.6114791337754 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(15.633652940991276,34.366347059008724 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(17.388212907891656,18.63618697813068 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(17.913345954306536,-51.722292098197386 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(18.22279009743133,48.36043332306156 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(21.677134318553797,-4.655870951664554 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(32.518978073193324,55.369402568192925 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(-33.536552373032976,5.01240485831012 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(3.8870971254870597,46.1129028745129 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(6.078168916008536,-0.7163780797927708 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(67.01340607392197,-21.153907271245018 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(80.17162196276828,91.89293581918756 ) ;
  }
}
