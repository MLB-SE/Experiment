import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.15231614332944332,-92.14131622120985,-53.83331945953969,50.09024027088077 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.55799429509986,19.93620403517562,-2.816221288048368,-50.84227936128238 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-43.488765086491156,-25.657759146104,-63.12231358052007,32.196494363970714 ) ;
  }
}
