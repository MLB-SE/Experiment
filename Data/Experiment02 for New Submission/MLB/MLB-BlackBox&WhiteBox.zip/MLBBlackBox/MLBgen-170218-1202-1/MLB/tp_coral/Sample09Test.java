import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-32.05647982711682,94.66233069885567 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(54.133768935611606,4.86204931804918 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-79.36022074593735,98.89578309457498 ) ;
  }
}
