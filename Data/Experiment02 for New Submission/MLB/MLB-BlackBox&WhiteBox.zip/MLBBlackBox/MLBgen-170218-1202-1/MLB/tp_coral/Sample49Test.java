import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(17.45829173602131,72.16554440769733 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(19.92525429966821,30.07474570033179 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(22.460665888812116,27.539334111187856 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(56.27851111077669,63.63831338115892 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(5.736381486055194,81.63320346622584 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(-71.06500249822003,41.87377791011164 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(71.20750723579417,-8.438454078549825 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(71.77324479081241,-3.5321313573933395 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(82.16114360129362,-8.879052452181895 ) ;
  }
}
