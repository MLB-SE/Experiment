import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,27.80074490449185 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,3.6172582959450352 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.42078779835551927,47.1563184992531,43.397459664362316,26.970866926680188 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(11.573941606718407,-11.226338577434873,-23.890568059421774,-68.72945874109367 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(118.44072724254903,3.0140726337953536,-5.974075967445842,42.31099417212556 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(-1.223855755230165,6.070652527471792,6.076151935194449,-1.2183563475075085 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(17.23745460714234,35.178816914931105,100.0,-15.792556711284078 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(27.141711264802257,2.1706880970609124,-23.066465869875362,-13.082104647981238 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(31.256724069056077,86.2035003072356,88.17831620466171,-16.05349025270921 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(3.964122910750152,2.3122068783039027,-89.9852001766037,96.98074768091091 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-51.32146408131142,-76.80312861350869,0.9994237961956571,32.653590363137965 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(-56.774085036887634,58.73216285984418,70.70942907191147,-43.78612164272613 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(58.28043965685927,97.93552563585499,-14.565744866405254,-99.43656716748713 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(59.41988853763752,-55.63527484538044,-8.314597054852443,12.099210747109526 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(60.36778901879299,37.57278423507654,58.89366919691918,66.00871641956664 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(68.10645815805537,0.0,-28.2894006230366,-43.135681777434876 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(75.54204079886034,-1.3559549015566432,-60.11571213055114,-27.051361891567936 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(76.2790246763663,-73.48936985435324,16.261038329873372,-44.61483184514719 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(77.00267013624253,-75.04557803228953,83.14546956881728,-1.0260787131669629 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(90.38232613488941,-48.04282841777232,89.00489996242302,49.20768932670049 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(92.78743533251202,17.098834128329315,76.94616063351907,50.97702108944168 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(95.94321370448941,-95.17055709754314,8.326854274853332,30.90406167886337 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(9.714405683927897,-7.057286045693829,-21.996107760716306,68.31433228232947 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(98.50577822714732,-82.42813410095391,21.412175096282404,-1.264266745850704 ) ;
  }
}
