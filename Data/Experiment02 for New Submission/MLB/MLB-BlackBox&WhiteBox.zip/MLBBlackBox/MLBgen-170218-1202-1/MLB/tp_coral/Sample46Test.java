import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-22.582750901890392,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,85.74538865519935,-60.02256098289334,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(-11.381526082954267,0,87.98723879078744,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(18.48147787079529,-7.8711587195048764,67.41012588808371,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(20.188572661831657,1.0000000000040412,3.252691167458373,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(24.270946312509125,0,35.781030500835925,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(4.930380657631324E-32,96.11401909199417,1.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(53.361313863058626,1.0,31.457500897323,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(56.81804344049979,0.9999999999999999,77.02682853473334,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(-5.686539962540806,0,-85.23485513991041,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(66.78976287207792,31.49395918002017,25.31402704693903,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(67.61492692954303,27.28155192803439,98.54015039343761,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(69.19085342065586,70.82263572253842,86.26065673610088,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(69.98800916133368,0,72.11100135257564,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(-716.2567012050064,0,27.260184397756504,0 ) ;
  }
}
