import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.5496796440867229,-1.7288621948011325 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(36.367029627248115,-91.92117705429365 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(40.32134464509153,89.13543757516993 ) ;
  }
}
