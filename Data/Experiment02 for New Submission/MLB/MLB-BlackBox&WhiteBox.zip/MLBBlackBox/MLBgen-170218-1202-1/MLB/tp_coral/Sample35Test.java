import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(25.13276762432914,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-54.97787143166308,-50.50141424511284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-55.13561202787811,37.60237521282511 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(83.00659677120265,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(94.44146884111973,90.96095948594831 ) ;
  }
}
