import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(-0.7607196689546214 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-81.59915040437812 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-90.17593646876487 ) ;
  }
}
