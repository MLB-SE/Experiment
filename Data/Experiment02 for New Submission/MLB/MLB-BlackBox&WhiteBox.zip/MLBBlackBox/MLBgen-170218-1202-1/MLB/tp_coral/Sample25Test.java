import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-1.9578236072597122,-14.115807555498506,-94.66253081511353,-36.962936565834156,48.6353213200141 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(2.2983066415737703,-99.26775757418028,100.0,0,-55.933489792636884 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(30.23673444745569,-37.33570881595225,19.093715326327754,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-38.82956917048317,-6.871514785037732,-18.574377939117156,0,-56.47969149791565 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-43.23600012433857,-86.43315613994942,-47.352858728710046,-58.65856286083506,99.0362429054681 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(73.55838383741897,-83.46831091568588,75.24430936700915,-96.56192186139505,65.09293674237196 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(78.7312141528459,-11.740524218628726,-82.86587779064651,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-80.25246276453777,13.397641471591726,25.705776008860212,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-83.12589975323526,57.35253916189245,83.24879376323089,72.69342048319443,-91.11364585458165 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(92.90607895724948,96.36010757862303,-100.0,-71.20666198980214,24.60359948045089 ) ;
  }
}
