import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-2.5316160951104365,68.5564361836104 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,1.0000000000000142,-22.187786607807908 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(13.807945174834728,62.552671577447114,51.41113244507747 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-14.977921805173992,52.94343776229093,29.862692287717294 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(17.8686963013581,-50.92875995415511,52.46078849458746 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(19.37053784664772,99.07848057035221,86.17701907885899 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-234.1035032966596,-424.9706034840905,88.020799890467 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(4.440892098500626E-16,1.0000000000000435,1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(45.398804922286104,-22.038238605442857,29.500198014971375 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(50.3925108589222,51.77403141328415,45.66257916054403 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(51.81171806907082,1.0,57.14006478776798 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(51.91927879718358,53.91927879718358,86.07667047978774 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(54.72897613877615,58.847929510758775,32.96691917656639 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-7.105427357601002E-15,-100.0,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(85.52594682785704,60.21040838220256,55.87262475452769 ) ;
  }
}
