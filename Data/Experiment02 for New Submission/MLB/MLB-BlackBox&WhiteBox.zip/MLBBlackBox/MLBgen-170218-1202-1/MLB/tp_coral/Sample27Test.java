import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(15.88554365349004,23.68810272252224,-67.89206263840678 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(35.18068692797124,46.772892758216244,57.323442314386114 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-44.26474691996427,-58.61846906321946,-90.12387212319214 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(48.52101833776629,-52.94011768054276,91.03794006789934 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(49.80135340663313,14.911178187370126,25.684642634294153 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(49.99827008278398,57.318487697525065,-20.868256701549697 ) ;
  }
}
