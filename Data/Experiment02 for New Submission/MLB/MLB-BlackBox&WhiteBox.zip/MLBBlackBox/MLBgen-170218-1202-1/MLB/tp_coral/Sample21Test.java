import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(24.243221416899715,-74.57699375218328 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-26.82987768308428,-78.28274553197787 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-40.50609225877644,-1.5451270617693496 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(40.96661004451363,57.45411019726353 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-60.338588767943115,73.90441854845534 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-87.75952090768762,77.65105541536153 ) ;
  }
}
