import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(3.040234496878874,9.243021384074941 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-75.53058141556532,-40.57640563054026 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-8.746326864515215,76.50205541317247 ) ;
  }
}
