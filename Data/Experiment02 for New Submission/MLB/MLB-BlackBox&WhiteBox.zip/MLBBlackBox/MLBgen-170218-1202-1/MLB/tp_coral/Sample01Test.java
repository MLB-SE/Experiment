import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(69.78185566826792,7.207685698839157 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-72.26896790966762,87.80735554526908 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-73.5741214216414,86.16182820143538 ) ;
  }
}
