import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(-71.14284189242915,49.84669326799818,-14.408905795915118 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(91.70914558458429,-80.11062688893485,71.33877085350224 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(98.90017400608903,94.30587999110065,-83.17105168079975 ) ;
  }
}
