import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592153876,-21.991148575128552 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-20.713688498153065,-4.419052730565281 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(38.37515021512607,-55.36478546536172 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(9.9711125091886,53.41117368761809 ) ;
  }
}
