import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-0.7405852414243697,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,19.47611933211168,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.9636738559379859,59.59504468072562,58.48285767351983,-0.033376422192394034,-37.80655182685682 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(10.400291970363456,2.670670423611568,-5.610216211835561,100.0,-85.6500138235674 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(10.411426621895245,44.468243130398946,101.34590805625606,-14.0075431960162,10.274782767408055 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(1.15593529913164,27.09157262231698,11.513629743960145,41.59364517306428,43.87662131090653 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(13.195583960441112,94.50464291300474,-29.31480995835824,88.63557249252011,-14.153657583032 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(18.000451017174242,-9.05779239291337,-38.42943998642385,12.678583638275114,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(21.38434494315868,13.569946715749793,46.42604211620903,-11.471750457300558,62.02562501332551 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(2.5575726184091536,58.5281188475295,58.942201314407065,2.971655085286717,58.32524989887784 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(30.854826571490882,11.726432545292914,40.25714293951111,2.3241161772726997,37.8112968466252 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(39.493644680372455,21.122886211145484,-1.06842759176115,78.80173735596452,40.98294469684737 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(41.88719603309613,5.8282801617430335,33.186136324748624,100.0,110.94417747945877 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(45.29585957282255,13.057992369316946,71.14415482009278,-1.245731335407747,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(50.90067414765326,-3.373525735280296,55.30878878114001,-11.50932056883154,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(53.64273268881291,76.22227188301181,100.0,97.24780357701991,31.66991227384821 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(-57.773915268759104,41.62968521970697,5.053013985672081,-40.437210172004036,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(62.51258647450322,12.072247396639852,92.4723707047215,-16.594382861203513,-71.4432664982783 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(63.986180835665266,23.31927464721413,166.82429990521555,-72.06537373501752,90.54065387607955 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(64.60384084516545,-52.032988399557965,-70.83758630172052,-43.07987219770475,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(66.85111039242219,0.0,-47.18107869939874,10.337247298196665,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(6.872440174141303,90.21170366416834,82.69909163462951,47.92185787224838,48.62322620823295 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(73.38738824851512,-71.69135430730125,75.989611651914,44.8042989030794,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(73.97143031503518,80.91466882820814,80.37965387349567,-34.764309362974316,8.510611568822796 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(81.9597673443744,2.9517271398413616,-26.988116345738064,64.99852697881553,-32.001897560718305 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(8.712787154503474,-7.198061490484719,-28.096864803082312,-22.997288575977294,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(87.87359911763681,14.117597246639098,100.0,6.224401899449031,-42.039664842348095 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(94.94367216696762,25.14678233419359,79.717362875091,-20.944595345235513,20.473969154620875 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(95.27811091068509,-83.17170078502886,-5.219813044372444,28.794160076222965,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(99.64995462187053,3.169402463903958,25.337347103505266,88.45678714143882,90.7714397543474 ) ;
  }
}
