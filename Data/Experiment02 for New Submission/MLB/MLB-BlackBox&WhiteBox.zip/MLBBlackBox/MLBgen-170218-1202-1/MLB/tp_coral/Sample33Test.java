import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(32.201324699295384 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-49.99875444681165 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(51.40536465936401 ) ;
  }
}
