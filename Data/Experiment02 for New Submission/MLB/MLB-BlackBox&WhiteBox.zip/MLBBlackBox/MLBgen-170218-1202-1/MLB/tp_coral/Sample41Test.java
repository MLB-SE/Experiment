import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(0.3420893469429324,-0.22506422565109044 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(0.9123970248378617,-0.07992869390488011 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(2.4490033698595113,-54.250073257959116 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-2.6278043393092645,43.48418392553441 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-6.97583751532737,55.638146555576114 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(8.51978518548097,64.06695442126004 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-9.084125726039987,91.60546593254152 ) ;
  }
}
