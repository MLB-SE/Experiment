import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(20.014154782608557,61.164982756440764,13.774049849502262 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-40.980164413627776,-39.36320051531986,-80.34336492894764 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(83.18137633729282,-85.01192039168224,30.175994752317877 ) ;
  }
}
