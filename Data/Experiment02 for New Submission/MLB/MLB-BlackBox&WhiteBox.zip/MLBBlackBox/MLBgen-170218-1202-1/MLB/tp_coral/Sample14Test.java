import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.622736432608221,-67.25621252788434,81.33355278927289,15.816686672443296 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-6.321399056807863,32.14304447763902,35.757769674938146,-7.0751085271061385 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(7.568466177730443,86.6897608578897,42.52734673530787,29.59730561207249 ) ;
  }
}
