import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-2.0255073223311513,6.128187235148261 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-24.861519673769223,26.66263483857945 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(5.9822175708111445,64.66000492851515 ) ;
  }
}
