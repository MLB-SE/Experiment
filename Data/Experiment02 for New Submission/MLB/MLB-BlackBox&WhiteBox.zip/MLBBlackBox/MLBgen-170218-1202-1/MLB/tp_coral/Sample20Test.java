import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(19.18198875652064,-68.99462081485717 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(40.1816464608409,15.778458999249745 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(44.157920768726775,47.31108435967806 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-49.16298032087993,-43.06058522302103 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-60.260297682346,-24.26989764849006 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(76.76434392030691,-49.11175660660463 ) ;
  }
}
