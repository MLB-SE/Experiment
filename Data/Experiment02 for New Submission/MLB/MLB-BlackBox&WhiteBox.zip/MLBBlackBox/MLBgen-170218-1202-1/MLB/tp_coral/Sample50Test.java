import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(11.69080197063078,38.30919802936917 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(12.202666671840035,25.202666671840035 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(15.82007901534459,32.9836842469376 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(19.293838128824007,-4.3924751711107035 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(19.643179602704848,30.356820397295124 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(28.808497597956148,89.76591819668369 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(38.89723000268347,46.419522571632314 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(41.71016027136807,-0.5794692914755046 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(-45.13318274992315,98.34690808846739 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(-56.35735835165392,-35.41700789082529 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(57.24057992961846,88.14111235696612 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(73.11015715999253,-23.11015715999253 ) ;
  }
}
