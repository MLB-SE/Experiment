import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.9027706447956092 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,38.46294106370959 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-61.85223200207402,-2.176492664326517,85.74975518067828 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(1.487373956850206,31.780620489241556,38.758990640482125,-62.284606027108616 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(31.593982978654708,-24.16786522613043,43.150403697568464,-22.024162181935793 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(34.014299303185425,-5.500499545663601,-61.43620346818732,88.04063508846158 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(36.34533477926766,-5.332125924311176,71.27867510824109,-6.816293406267011 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(41.55260159952422,-1.919620939498584,17.032638970864927,-91.63210127600928 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(54.463249731109784,67.52832295430403,3.952193332052218,-27.355415828717526 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(64.48680793844565,-3.996251684428671,27.015109349516834,-16.021213365398296 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(-64.75628814223917,-94.44031812000797,-32.950185811946994,-96.2431286182315 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(66.31319010716155,0.0,-6.7078730686781425,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(70.08161652092477,-60.18913539614026,49.0086127603104,-9.0366022092375 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(70.34206430927347,-2.0347658728026943,37.779517877488246,-79.40679953360123 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(76.71385487552712,32.62458104542836,8.489691876848354,-40.598664840649356 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(81.06783587467271,-41.87162203002786,13.402107619036414,81.17595299463758 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(85.52856656434665,-18.432811332017224,60.53631856249953,6.559436669829893 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-9.39047413696818,86.48591179077286,-75.4130497528532,88.44584002254604 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(-96.89406350005187,96.85089499451874,-3.72772467608301,86.35287763719347 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(98.54707088732567,74.81988183179976,-50.57314505408448,-34.660297685614154 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-99.77832607472949,-8.673617379884035E-19,100.0,-3.552713678800501E-15 ) ;
  }
}
