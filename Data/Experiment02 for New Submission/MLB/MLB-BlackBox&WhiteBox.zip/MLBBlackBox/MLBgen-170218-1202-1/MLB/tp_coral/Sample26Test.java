import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-100.0,-100.0,-44.94623683093915,97.74645532355078 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-51.6691016345256,-5.017578092623239,-43.291923207308855,0,-66.32310318439863 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(53.60219761848629,57.10814986083946,35.07789159906483,24.466331417621106,-6.730161296342146 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-54.4648685115243,77.00439302959691,-94.81907158890994,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(63.560797196906094,48.57852716880723,-63.77240174357932,43.684357714417445,-25.347592576541473 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-7.570345670672649,29.995270260228974,-74.12354481485892,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(96.3121434143969,75.3568910867535,-59.61803276494484,49.6453503068993,-67.39246375513002 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-98.70446998714172,70.90487695026044,-100.0,0,93.80969521874235 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-99.13253958090922,79.61140027292862,-81.29717830007033,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(99.9989065454038,99.9999999999999,-44.20019524489453,100.0,56.68877906235336 ) ;
  }
}
