import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,12.057446849594424,0,10.464638001981795 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-18.826377500093997,-73.70257506020212,0,78.01016542503632 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-24.201689990425066,-33.92483636444166,-65.18679451296259,-53.84257743779386 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-39.554776773960334,62.65817411666666,-22.91649169789622,-84.86753968249714 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-56.636186587768826,-32.942963452521255,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(94.38085394335576,65.64987699738975,72.72441712026529,82.17698068426017 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-9.533514610854496,-68.80959815659824,0,0 ) ;
  }
}
