import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(19.97529949298911,-8.468949568902346,95.95209133646517 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-20.345876729081564,-60.91449459932119,43.44329703567014 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-80.99073668589915,15.525357538502462,1.5757645616388345 ) ;
  }
}
