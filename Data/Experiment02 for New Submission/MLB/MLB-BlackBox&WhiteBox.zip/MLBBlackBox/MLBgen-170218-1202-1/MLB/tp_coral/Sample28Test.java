import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(1.5918371879078705 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(46.671063739397056 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.38905609893065 ) ;
  }
}
