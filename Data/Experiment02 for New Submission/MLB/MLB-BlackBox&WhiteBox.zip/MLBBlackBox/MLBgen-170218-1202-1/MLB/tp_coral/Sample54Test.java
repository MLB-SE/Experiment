import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(20.27218367244589,66.0477021738698,-82.39926759916818 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(2.0285599216890726,-30.637473437609188,-0.3718249863098538 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(21.369874520932058,-20.92027378427663,-40.42424212048532 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(49.10515137780836,-36.85185383492971,82.12068925320892 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(50.40918897148218,-46.60919011371219,-87.78845460573099 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(64.98728177609115,-54.449273750105846,93.86418091999727 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(-68.95779319573143,-2.782022847820346,43.19143083924277 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(72.11442359053103,-100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(75.97306705435182,-42.79747564469623,-38.88006741532131 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(79.74243168013871,-5.4998270345662945,19.65513805538062 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(89.2523045320064,-9.861958378691554,56.942016851184974 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(95.40925683728966,88.43216966309964,70.67931999927387 ) ;
  }
}
