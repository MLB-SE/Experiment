import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-1.6895599723574435,-96.34957227632061,61.49506501748658 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(50.197873656476,2.7201202351667746,-79.37894925980886 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(51.71955233782154,-99.8482425929185,-38.807893052012865 ) ;
  }
}
