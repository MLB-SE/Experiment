import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-69.46038425522903,73.0652398807708,-34.08908749242062 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-70.76036584600169,51.75698568762897,42.65624831738643 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-80.3255391350322,-79.55314282950958,-79.66516948060132 ) ;
  }
}
