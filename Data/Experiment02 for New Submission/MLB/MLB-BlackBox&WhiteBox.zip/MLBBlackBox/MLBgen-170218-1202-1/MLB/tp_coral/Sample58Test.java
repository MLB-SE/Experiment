import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0.07514815657883389,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,69.43218748608587,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(14.052404879149407,44.7263878353844,20.92903972445069,-56.33897241995729,85.23786419457082 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(19.214782619460085,19.886004794924986,-39.74611519396684,124.43058263396318,-4.591341308065702 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(21.44889431157344,87.04213811807033,52.82009971396554,-13.138703971465702,192.43978599771788 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(33.64439544356267,16.67420599071787,-50.491730045471485,120.87892050921832,71.2951909332818 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-37.852016769751316,-49.895081475073155,88.25570537172774,73.80161838925972,-53.81148919654495 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(44.81079190031497,32.35061891124818,51.5964968289378,83.3794085347462,-98.10181839728133 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(49.19070599528655,-35.34305367212953,-86.17703962595324,69.10253060485039,-81.60281023921559 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(58.51850470896156,35.46556000536347,6.131665857603494,85.17641627710788,-6.183497078732785 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(58.92339828845016,30.296621962848178,79.19099437355402,41.99887602405252,8.302721359354436 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(64.9538475287796,55.648444275406646,31.999359390518105,-10.21873850104181,35.864947024783504 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(-8.6762191675328,-3.428951839489187,29.323592152616133,-58.01099496105995,50.99850203481907 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(-93.46087185738372,-62.92252748484886,-0.3010321877360269,0.8219236860727932,-86.23182283126363 ) ;
  }
}
