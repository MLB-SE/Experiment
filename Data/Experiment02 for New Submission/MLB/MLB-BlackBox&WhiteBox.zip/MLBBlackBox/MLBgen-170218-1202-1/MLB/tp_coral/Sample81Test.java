import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-56.62609760340565,5.709808958194614 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-63.55031719596174,-4.140350695097459 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(93.80599671661489,23.90051597279958 ) ;
  }
}
