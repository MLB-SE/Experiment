import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-41.64371519540777,-57.38600471620929,-18.489484698688713,-6.951395317358461 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-69.3971340461558,26.918474562685077,32.543728033797294,-65.5027555657026 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-72.73800060194165,-44.77571026043068,-30.646778389067904,-91.72473520549873 ) ;
  }
}
