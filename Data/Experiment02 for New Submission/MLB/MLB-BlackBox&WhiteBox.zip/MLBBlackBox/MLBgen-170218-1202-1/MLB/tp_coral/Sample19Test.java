import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-26.320070350948185,63.75899868454479,49.6523929850099 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(28.496926529315317,-81.78726783360463,-68.79253082950294 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(76.19732433581171,52.211209942973,-77.86143098057178 ) ;
  }
}
