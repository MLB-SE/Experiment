import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-12.807360300357914,-80.91498844661902 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(17.02486221502811,28.02043650299051 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-17.832758926959727,5.669665152340556 ) ;
  }
}
