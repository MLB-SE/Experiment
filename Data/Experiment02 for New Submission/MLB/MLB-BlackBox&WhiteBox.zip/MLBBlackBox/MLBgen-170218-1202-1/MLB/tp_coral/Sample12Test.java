import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-19.640283133211426,-66.39725285705788,-65.2825267781389,92.7811926742506 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(96.40803948142258,-86.0328018809771,33.344779785161876,-90.99847035421806 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-96.62643240053181,-9.56698061502648,77.82951035046514,50.63672570830556 ) ;
  }
}
