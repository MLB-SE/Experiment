import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.7218057652347056,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,42.404473253914006,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(17.12463757478993,94.53706620120045,-28.733521200666786,4.094229054383547,87.4366841608217 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-26.392335472810494,3.443460274079399,-92.59167932901889,82.35560340412528,-5.493008974145155 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-9.38863455940205,11.76788045133415,-24.09172596912211,-99.5134971274401,9.844059169057132 ) ;
  }
}
