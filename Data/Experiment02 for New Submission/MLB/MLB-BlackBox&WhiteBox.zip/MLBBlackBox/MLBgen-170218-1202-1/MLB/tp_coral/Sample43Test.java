import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(1.0591023905726331,78.22708567146566 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(12.611213884970468,37.889719090254005 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(17.528960086018117,0.5479411056557097 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(2.4156225017693203,5.8352320710542696 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(29.451759322833624,42.90553961333822 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(4.2857689286589675,81.46453969675632 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(52.71385714188756,57.83274654868302 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(64.58895500513509,-21.916639128822553 ) ;
  }
}
