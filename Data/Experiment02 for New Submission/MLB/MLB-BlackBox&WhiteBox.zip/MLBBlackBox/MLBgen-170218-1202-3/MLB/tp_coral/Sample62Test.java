import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.08651838750867569 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-31.8888501590789 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(1.102625320796669,22.751641436146627,23.890581209291888,-26.115921801042205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.515990498475368,9.506799746586523,51.45701797158648,-84.92496193100169 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(17.449371131897465,35.80583682193722,48.80417003015123,8.879414494477771 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(19.33638743876962,22.421160417987892,90.11553979314755,27.919735318498056 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(20.518959735343614,-11.30244009902647,14.19752393542737,-1.8154451211921048 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(28.23692584863781,-1.607603711814841,25.68303272517447,89.37010352009383 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(29.12638393443774,21.277347179194848,93.54589295721792,-12.657708303963233 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(-29.37332745842748,19.56825549772772,-26.59048285947032,2.7119110360483916 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(2.9490916282006268,58.15524152963414,58.83505484223506,3.628904940801551 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(-33.83580714964352,92.86450382456155,90.90571940208733,-2.302784577677869 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(40.413272526197886,0.0,-29.0931472453546,54.602171332701886 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(47.37186299775115,44.16118603370239,28.58638108624848,12.19312791055171 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(48.28939452646296,-24.223708429671944,94.35051662776092,-97.59169472013609 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(57.12523936408822,0.17842880486488885,-68.3821015151434,-87.70414674967061 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(59.98760401606498,-22.701478065864606,22.606353690315245,60.762034308016695 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(6.090898362006159,-6.747006683667535E-80,100.0,-85.5880156520068 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(63.189421276777125,-59.40212090407033,66.69860877330453,-26.273703249913027 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(89.53477455750775,-58.53173094474545,18.878533098642137,12.12451051412016 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(89.94112981337099,40.441383892155045,-87.44027421513279,-1.4907884820568995 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-90.09453105754201,70.94816736680465,5.057917320345908,18.497973562848387 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(93.08612056414643,25.866213442115594,-44.54758524380411,50.80917529667934 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(96.8318797948865,99.72462899759594,58.9050259895055,-60.557696863273904 ) ;
  }
}
