import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-66.93433459379094 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(17.591820607601676,0.44492970938002707 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(19.738645969003727,64.43093726754682 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(35.121579938927226,-48.47465579231829 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(53.46888740117771,70.04667219987437 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(65.30674634891352,90.22497906873662 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(6.5493620859913,10.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(87.12105858715361,29.749784007382885 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(-96.5193526475695,-77.44169588264029 ) ;
  }
}
