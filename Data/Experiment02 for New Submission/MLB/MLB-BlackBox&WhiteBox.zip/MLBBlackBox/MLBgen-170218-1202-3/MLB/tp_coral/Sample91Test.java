import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-20.35830813317447,-99.02221270323767 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-27.049143947245625,-92.96858304273931 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245743669,-40.84070449666731 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(74.68780029962457,-57.28874034697642 ) ;
  }
}
