import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-10.448248257682195,-28.44881243658986,-18.97894522095085,-7.049531009769439,-78.06081549146677,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(145.41355373573657,-87.82177842826412,-1.3923537901916738,-1.6884066406247755,105.12968186091459,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-18.233754241312397,-37.15830482976512,56.8285782191908,25.153754716995792,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-20.407152816938645,-45.56629290844702,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-32.377879745174624,-1.846450752600333,54.780644915867924,0.8898251696073345,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(34.55488925511344,-9.006255511075551,-19.207124723388674,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-36.27321815342647,52.0511206764082,27.054847050250274,72.38885090513706,-15.010718217110824,-21.284625687541837,-27.405500118145973 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-41.725908782855605,8.705208604639168,79.17005598799852,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-42.35937310836615,6.865623434823732,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(45.28322137999646,-15.494824876560486,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-48.86725279310839,126.38352068583117,91.41550779876735,-19.176614127744386,35.58413076576582,-3.356887808176296,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(58.94538114711199,-79.25004639690347,-30.80251971450106,-85.22990988986632,-69.22488178457604,-82.51234155081744,-97.7621648883957 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-62.62967314492427,44.89111825914884,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-67.46122741322198,21.055951640208768,-28.81449183622803,-72.70631819784708,-43.57636125490201,-59.621117349882205,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-72.74183405146361,79.38671205341336,80.42994336331907,-101.8070526846336,4.504681595154651,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-76.31089611573664,-14.289759503992144,-76.81642745011186,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(89.46977495107306,-99.19694285686789,-44.16112616338718,-50.87330132519731,41.51027213532339,-33.23646162707249,-1.321057562415239 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-98.36087041585952,-34.04658531135412,-46.59728289212908,9.951501385099618,100.0,100.0,0 ) ;
  }
}
