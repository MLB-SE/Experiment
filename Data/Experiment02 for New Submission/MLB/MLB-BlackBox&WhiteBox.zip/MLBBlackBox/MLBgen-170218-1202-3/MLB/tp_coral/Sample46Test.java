import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-25.907748312306826,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,96.23315164730118,-17.173906019012477,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(18.933267393471723,0,87.32889474139051,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(1.9721522630525295E-31,25.765913947681117,1.0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(-44.62672039947917,0,1.6140021139419218,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(-45.932781095972786,0,80.66706144382442,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(48.48887982485595,1.0,14.559340889699442,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(48.66433036143192,70.10514746326038,50.77747816402322,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(53.28775844367281,0.9999999999999866,3.4306768850628515,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(56.48194745879982,26.452617182047163,36.57598524505468,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(62.13876016515209,0,93.40666200418332,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(65.51411073732655,-43.43753327437199,49.68186115348482,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(-691.2081270478885,0,10.313201510808227,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(83.01624947653849,37.57722984851134,73.3263572145581,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(92.9963694946785,1.000000000080595,99.18895070314512,0 ) ;
  }
}
