import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-29.236572846549628,-18.654049054224384,33.71046606038852 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(6.841639143795916,-29.519671522608732,-94.6042562050071 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-81.18125283941815,-17.344345020202994,-10.437233199955102 ) ;
  }
}
