import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-32.981581435570334 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(37.13592440328489 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(5.141219722348016 ) ;
  }
}
