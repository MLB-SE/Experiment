import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-62.25240312098499 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(82.46680715673207 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(89.04396490962753 ) ;
  }
}
