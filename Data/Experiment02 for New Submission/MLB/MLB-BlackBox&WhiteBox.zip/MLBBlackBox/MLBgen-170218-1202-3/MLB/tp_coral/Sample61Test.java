import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,28.834847817504652 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,7.115198628409232 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(111.97906873736248,-1.7415979198563996,84.23922889266544,85.68804850517614 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(12.614133679925633,0.0,48.614127613539395,-34.98573482788229 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(15.580206591420486,28.368830833015235,111.9767977124925,-36.097895269861205 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(16.48847367545487,-0.8512603580226166,92.48060080774142,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(-18.070329709357267,-57.97913794366665,43.440990829651525,-91.19874560139192 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(32.60825926300508,-13.131326397867554,49.170511013807925,-29.693578148670397 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(-44.65594765868202,44.09966972348657,50.61579670128353,-90.99012112263605 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(46.82140227114499,7.693251561064102,63.545216598546716,-74.4020858819404 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(52.61782095400135,-100.0,33.97518598689567,-0.5261782095400135 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(5.27993576976082,2.201684061975708,-47.83055181779691,55.31217164953344 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(54.68714553206814,-48.020480874054236,82.90243892533368,-72.28015179703031 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(55.006353638112074,-56.42040707828555,74.47054027389893,-9.97356203474456 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(59.03036252621453,11.082049066760845,56.957859773931204,-69.312618920841 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(78.52141612211051,9.257477385847707,28.926188067251985,67.08712928534794 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(79.23185962128437,-11.34095679301494,71.17527237347022,20.495581088210656 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(79.95287661062156,59.16838224433155,61.476902048160895,-7.209393921132914 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(93.56121639741252,-17.76737923496671,-24.824899542163095,54.58985044238918 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(94.18726164517389,-42.99269558088221,5.009534359507796,72.94886419391739 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(99.13651509548086,-65.3506458630786,57.066230455233836,44.65912190486242 ) ;
  }
}
