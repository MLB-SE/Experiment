import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(28.76802538456232,-95.22043129091185 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(3.4054825103422104,33.7659097821215 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(3.6652393235447307,2.118919009672619 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(49.15732160308016,96.40833879149108 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(60.44574787757756,26.885212935830822 ) ;
  }
}
