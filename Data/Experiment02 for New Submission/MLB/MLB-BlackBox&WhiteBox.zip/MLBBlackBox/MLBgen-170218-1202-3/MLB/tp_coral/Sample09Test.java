import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(75.18397559593322,122.44044200403899 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(88.87840277824117,98.18730874602107 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-92.15915486748074,34.505356506005455 ) ;
  }
}
