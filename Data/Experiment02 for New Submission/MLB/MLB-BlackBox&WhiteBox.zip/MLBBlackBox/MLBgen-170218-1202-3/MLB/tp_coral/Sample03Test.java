import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(19.80058955576635,-95.02652832488698 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-57.23920863128935,30.770941520026355 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(58.497544478727754,-44.36037753757368 ) ;
  }
}
