import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(-22.245818792373996,-94.65632413951317,57.485765999721906 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(-32.62834452755676,76.15075156694172,35.4337456090322 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(39.29168731530112,93.27562977338329,41.02021127946242 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(63.39098311865541,-86.8387400666561,-30.02339654329755 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(70.0590985447347,-66.67571641845683,54.8105357890193 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(74.39377159313915,70.90502037417463,52.1422513760908 ) ;
  }
}
