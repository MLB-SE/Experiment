import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-4.284049432629359,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,87.07928909754489,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-0.8738985821678095,89.36401836465652,-73.08854379380728,13.610570612359467,32.220543676296955 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-0.9604367071995537,-72.9532756236894,74.34002864082316,174.43371222002165,75.57979683633741 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(13.768473522584042,97.34813277263984,72.04207149313608,-26.68729821964068,15.755927697974627 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-1.7786412983168418,-25.185235258832208,-56.27633927848017,-72.29637371049392,-5.321893537773988 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-22.882963830648364,38.386486822704114,32.23089844473242,46.01026283177018,-17.88381870057559 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(2.582404753832913,52.281971809401234,-54.12583854905264,61.21828238503693,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(32.62334940966488,56.67161061737983,9.07801970662807,-47.08220546142903,73.33034379732638 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(48.45655835612781,3.8621349238832736,64.81666287368381,2.835857025772866,20.092933484870585 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(48.62092759447167,68.6258798534378,25.586417634903718,39.88856425675388,76.49770403199653 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(60.24759562546237,41.14030703830866,19.158760380146077,7.362466574303355,68.47882669383606 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(6.3264824877019805,72.67475195071503,-22.71208743514977,71.01242593741236,-40.081711574385096 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(91.63970380777315,23.900604770436075,174.69716184739485,80.81872923646029,-49.78479301376444 ) ;
  }
}
