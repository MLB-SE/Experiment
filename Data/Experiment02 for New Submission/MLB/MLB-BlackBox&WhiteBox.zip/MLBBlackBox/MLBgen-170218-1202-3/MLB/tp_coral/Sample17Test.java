import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.16494497517548723 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.8682111351873516 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(97.30810957372196 ) ;
  }
}
