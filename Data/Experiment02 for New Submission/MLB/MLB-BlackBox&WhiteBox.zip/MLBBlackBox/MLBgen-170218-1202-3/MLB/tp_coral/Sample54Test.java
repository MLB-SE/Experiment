import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(20.396482315034476,54.020280527711094,-85.36572063994615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(20.570278090561523,-85.06222600826524,31.173777137570227 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(27.611573095150632,-42.554991484233874,21.36932393133381 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(-28.753954895483687,-36.095466003753906,29.293717978922103 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(34.9267749294616,36.745848226562316,42.44899297752076 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(38.62801104155348,65.47350938300707,43.17710351893092 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(44.796722261807474,-59.05718350066094,33.884658006368426 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(51.29574191410859,-41.22471652876163,76.65427286277139 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(54.7002145532841,-75.0613025457739,53.075578171802206 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(7.375482538944212,2.6454217575267007,10.373306606785107 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(75.42080078344006,17.13835515617366,-58.8609579697184 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(76.40307691605867,-19.941769960550147,79.4061133310176 ) ;
  }
}
