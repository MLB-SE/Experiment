import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(10.867194140304463,39.13280585969554 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(12.288714043139848,23.0510457389814 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(13.96175095229043,36.03824904770956 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(15.74029002321545,-3.9674034359030657 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(53.57967591317302,71.13990211982957 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(-55.056470501745935,-13.690298667600416 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(-64.91639327983441,49.82909193948282 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(70.00358892141435,83.40453195145668 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(79.61727476605557,-3.9733628846398688 ) ;
  }
}
