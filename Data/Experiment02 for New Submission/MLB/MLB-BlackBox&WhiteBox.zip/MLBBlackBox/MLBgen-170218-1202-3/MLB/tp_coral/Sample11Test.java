import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.6374738598920459,-46.92189755515229,-9.907285089567281,85.05275216678663 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.8223510549373882,94.15049104721714,86.65217574187238,-34.353767397748584 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-44.29669889619656,-95.27991052339122,-85.48891185183953,-99.03930604009274 ) ;
  }
}
