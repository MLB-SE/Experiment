import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(50.74924508667465,97.2029568161696 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(66.51614929624704,42.70952830350575 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(77.97791599271088,-67.23054871469714 ) ;
  }
}
