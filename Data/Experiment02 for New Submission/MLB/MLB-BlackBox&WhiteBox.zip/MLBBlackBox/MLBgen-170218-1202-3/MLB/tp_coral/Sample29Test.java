import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-74.82179441474113 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(84.29639820623962 ) ;
  }
}
