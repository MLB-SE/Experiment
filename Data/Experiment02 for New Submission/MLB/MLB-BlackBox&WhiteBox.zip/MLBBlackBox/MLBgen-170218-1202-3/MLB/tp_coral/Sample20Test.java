import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-11.853593628549419,92.23145973353544 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(33.929278818056616,-20.41039602088432 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-72.91568906839166,30.526045264076966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-73.048622149263,-41.27899960841113 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-92.77646253269927,86.44750904508558 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-9.356382931751583,-45.718715364337804 ) ;
  }
}
