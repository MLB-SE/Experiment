import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.6243282131906064,-30.453489065873043,-64.47396508764949,0.3559967388018208 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-64.08081741045197,-5.344284352559711,-35.140063133157355,31.570821947131577 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(70.12002943394239,-35.07234290055226,-4.962472063192507,-58.913155616418564 ) ;
  }
}
