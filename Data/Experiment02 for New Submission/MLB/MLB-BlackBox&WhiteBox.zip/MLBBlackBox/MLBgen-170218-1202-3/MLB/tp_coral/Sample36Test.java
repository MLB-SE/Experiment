import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(44.74662294251606,-100.0,6.79040557423344 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-6.283116223626298,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-72.43130570100804,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-75.05338719769892,36.05669723320375,61.95469888539637 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-9.560472148371304,12.830094598304314,1.2793781777898943 ) ;
  }
}
