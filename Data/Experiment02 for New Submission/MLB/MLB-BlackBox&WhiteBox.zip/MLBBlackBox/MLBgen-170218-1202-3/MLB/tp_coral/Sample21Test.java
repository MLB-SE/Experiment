import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-15.581623140377927,-94.07275643830266 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-31.03478551426855,50.76193020904299 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(46.088988782549535,40.86409456091557 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(68.05161016951755,12.54881389756666 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(75.14744753385509,19.25342458237904 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-7.90805994370163,5.8426987635461245 ) ;
  }
}
