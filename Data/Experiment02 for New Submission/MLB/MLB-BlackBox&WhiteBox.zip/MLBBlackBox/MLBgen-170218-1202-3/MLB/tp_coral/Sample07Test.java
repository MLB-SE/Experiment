import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,13.442588206585029,0,-81.33411962511423 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,17.80235837264134,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,22.251561127455744,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0.5375622038419863,-92.81026272903476,91.93170260380927,32.74435735042209 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(0,-76.71501014278512,0,-92.92137965091341 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(63.53166793858884,36.27485601596558,-79.9381427030784,-4.038669926193693 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(70.76498715402019,11.050997140685297,-32.04641673276463,-20.466780431397396 ) ;
  }
}
