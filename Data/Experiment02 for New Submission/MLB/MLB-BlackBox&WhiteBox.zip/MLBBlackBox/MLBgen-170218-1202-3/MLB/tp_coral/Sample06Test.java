import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(37.80820049050985,19.18037095650915,54.83848021570006 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(74.87590661585801,46.94329439727326,0.9454296304673967 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-92.07606820480008,39.35410121480166,-56.12139515834229 ) ;
  }
}
