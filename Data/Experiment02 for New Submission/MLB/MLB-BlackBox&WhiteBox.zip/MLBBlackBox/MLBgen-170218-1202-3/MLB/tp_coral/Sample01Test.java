import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-16.29412416188964,6.288577940734115 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(16.904743201870318,-70.65135664398113 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(50.54992663198367,-43.21440438717852 ) ;
  }
}
