import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-22.444689199629025,-58.09875119932899,21.18626003293241 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-57.05019560354552,-42.94980439645448,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(67.75890005023692,98.27081701230674,49.64920922958086 ) ;
  }
}
