import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,2.7490119642929756,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-3.9843940765038894,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.12799313595159845,104.33984612013835,30.13812743621139,91.37537041346528,-84.34316709178873 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(100.0,1.0661515810602613,-196.03403842810653,100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(100.0,3.222028720310058,32.22027848662915,100.0,-65.37548673908357 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(1.0269874509690358,32.35146247317078,31.324448505438568,-3.3881317890172014E-21,-27.07261370422634 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(12.921213852010997,24.510959718341162,76.86592995164624,-0.28997505312121774,-9.556568186137355 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(14.155859233802488,91.76570492030086,92.65751375366196,71.80327244150104,-6.692792311660114 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(1.420833490807562,10.027887114092037,10.157531537483013,1.550428775456893,-7.912837610240416 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(15.56027306185102,90.66042933946898,177.80407023670801,-68.17111920779149,-44.55213099579814 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(15.630253885532113,67.56125116746725,94.07065144507754,-0.6731802666796369,-52.33050723599695 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(166.5040022285565,3.4609985799044694,37.69506621464071,159.27176374818134,-39.28312549501965 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(17.515220433272887,71.23871473014361,68.02668625916291,17.15543300502118,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(17.744867176351345,57.4255459068902,87.67316129037656,-12.224277893459131,87.86720786558146 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(18.00800682404848,62.57312671967043,-25.98656809319195,35.77366827635356,62.93280977972725 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(29.66217003818116,2.2778309304928683,27.343928386108047,-53.7545397551471,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(29.711958084313814,0.0,58.84062334770533,-60.478467742819326,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(3.08520500922522,38.31695295141674,3.982717233151888,92.99979381521968,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(-3.260086357599605,-16.84956745069828,91.84301698324515,-3.977078933562443,-39.55869658537996 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(45.535605612277976,48.73788235586861,87.47715807463362,61.83031231869995,85.28157315573765 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(45.57181331952316,10.195861755868833,59.65024411796966,4.469638213100682,-34.46504376385863 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(4.830004055050125,34.77886561217307,12.024655841797763,58.60185702866255,97.3555490663789 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(51.867796661064766,14.627552233295802,92.3595785033769,3.5458972105395237,-94.16810732568432 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(56.02178790225844,-24.29349032680939,-181.83119724838636,-35.25607000122644,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(61.261459139899216,10.24210068368528,70.95632273895907,88.30194704301226,-34.02245316845054 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(63.16477789108103,78.27367578431532,13.839982899251098,84.61355809490973,-88.65224256030034 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(75.57052920643164,84.41745570357472,-91.33325954730347,31.916364749236777,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(90.92090499517943,-90.9107872567366,0.1369706237495423,13.537671933653455,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(-92.424661895573,77.63787605214779,26.947906700896482,-38.50257274758706,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(93.16542012688498,34.223359947749685,66.41042880518754,60.97835126944713,-22.98536267538323 ) ;
  }
}
