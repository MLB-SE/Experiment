import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,-0.9161261140686321,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,25.858443200569184,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(11.26897289482357,97.00509645506418,19.25275892259362,-59.78345974755253,46.56533157730797 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(11.71899217034508,-51.29950230990499,38.783217118915815,94.7680294170132,9.863469555523908 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(11.932268350578184,21.956171647693985,-34.25600685782291,14.59530348236116,95.87944171667093 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(12.494099843265577,4.242101174487553,-15.764593596034992,34.053307058333004,45.40440941111066 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(-12.829285096057298,-60.967609850025866,73.11422721797426,-87.80066424137969,-42.69214859454141 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(18.44334022393528,69.64255935388121,-13.406395013726808,-36.09481281190865,29.737431823185347 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(20.74152144735592,92.74381166918954,-90.41138567167681,68.14144617704187,80.93249483695752 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-23.33500976830811,-4.040025330826708,51.02492219016261,12.633217305001821,-11.711074261621079 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(30.411061834362656,-3.343473349950912,-92.08212000987648,-98.88499808703577,-88.81146389834598 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(5.199072474582863,9.473187919653892,-15.241558979620505,75.0,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(5.443490321627138,40.81379072446441,-46.38882499539862,91.32896810202715,37.54078123770495 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(59.1124261814945,91.17015544211748,34.031746826208376,-59.944380777881825,29.528767869297354 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(69.41494390152144,48.144916348122734,67.49513717090895,-55.70435736447968,53.178692474885025 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(-75.33868524815848,4.799441887493324,71.04843944839881,41.76165610611699,123.17637134035354 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(-83.85833597852275,68.33580589963631,2.031956291574204,-80.0604951240778,58.61373424480982 ) ;
  }
}
