import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(16.65463299352716,-4.327266191044515,-25.509459354135927 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(40.75522414908323,57.53491085124617,88.85105070108219 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(45.43094547371999,31.12034476893146,-95.49522364522733 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(-63.00543990374592,0.2464383567835556,-64.47073031154864 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(72.92675328419816,24.83581574645548,-71.0140437513179 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(98.38065676349223,-18.505260073937578,35.120444433931425 ) ;
  }
}
