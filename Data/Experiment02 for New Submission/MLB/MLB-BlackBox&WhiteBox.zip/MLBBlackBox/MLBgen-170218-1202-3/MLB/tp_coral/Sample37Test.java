import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(28.177503392168575,-35.08713406839912,189.73975490405238 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(37.775427536233025,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-6.283125114397152,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(69.11784857925235,-21.434781702643207,-12.240220969412547 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(84.70596079840335,-15.375580886816957,-58.54669982443981 ) ;
  }
}
