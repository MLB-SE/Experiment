import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-1.7012265077834314,9.979314662231872,96.99171518417828,24.619165286680357,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(2.288158628231365E-8,100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(8.558954717381172E-9,-100.0,100.0,-100.0,0 ) ;
  }
}
