import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-1.484894993065339,-27.78028616979273,35.1515639014996 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(27.428795507054588,64.71373715129022,83.11842414866743 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-2.834104642659696,95.5750513602647,6.496538111842824 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-32.663230852181634,95.00067948070577,59.60506194906728 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(38.555551168559674,-4.116050254907151,-28.976709165065188 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(72.76029548834504,14.238986251576293,27.901970747329266 ) ;
  }
}
