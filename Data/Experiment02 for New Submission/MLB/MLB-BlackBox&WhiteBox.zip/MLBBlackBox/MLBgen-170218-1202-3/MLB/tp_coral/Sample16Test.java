import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,0.1526474541558116 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,53.479316495386115 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-20.96894358828068,15.353079164614726,-2.3734166205403113,-9.836815632616023,-47.70896726130509 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-46.053514951513655,15.216584374303574,-34.44608208662138,-11.16016214280316,-25.035168203632338 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(79.96619959991523,15.691641373226417,-96.03014626045562,39.02399168502345,78.87647076389581 ) ;
  }
}
