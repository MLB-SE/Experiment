import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,6.82291636973396,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,72.13679622386223,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(36.11922339230398,58.83047970711641,-93.9325704993329,79.03436066170809,-44.31018805095683 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-6.168954571389338,0.5376563041662474,30.117694806495194,-53.68412419924133,-26.378735165838435 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(76.35123569258323,-42.93299368107566,-88.85608968802335,-4.96391954236779,92.99472972512638 ) ;
  }
}
