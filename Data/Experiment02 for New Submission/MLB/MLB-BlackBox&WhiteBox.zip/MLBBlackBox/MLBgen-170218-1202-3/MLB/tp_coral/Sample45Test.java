import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-67.20418409253844,87.70048002499655 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,64.85509585975737,-39.763458399640214 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(12.582974083871658,14.582974083871658,64.99313342785257 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(21.552708087695677,16.519430161588858,80.31953594783784 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(23.456155952210494,35.39538030489288,9.66819212537915 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(26.67422162084054,-98.82345946685678,86.1673650971232 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(27.524489145799322,-31.1237935925152,53.43843097687878 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(27.896499990342264,29.896499990342267,12.237382918461691 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-390.0199556247206,-308.55216246130624,92.8241678859863 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(54.0078782915283,54.71792480836467,26.199919131442883 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-63.48726911882709,-14.614351201699364,1.3644765825763017 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(6.887970966151041E-17,1.0000000000015736,1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(71.11781661519558,25.08255720506898,97.79964854326983 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-86.0682347837676,99.70794074612047,27.33248384566558 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(94.97871653330813,1.0,100.0 ) ;
  }
}
