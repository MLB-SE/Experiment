import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.010686336071032088,-43.980299065485866,-41.63635984322109,-89.98432877596301 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.9179768001397122,-38.4443837742704,37.96359663210086,-6.118100756751232 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-49.27322591943732,17.988595324581482,-42.216912482474164,-65.46577032061171 ) ;
  }
}
