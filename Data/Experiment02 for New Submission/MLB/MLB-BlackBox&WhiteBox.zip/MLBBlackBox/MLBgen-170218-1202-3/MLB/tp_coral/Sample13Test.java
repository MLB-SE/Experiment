import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.04029196845819172,-7.0975550920702375,44.004048587412,33.5059165717945 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.6016895036835592,-18.543946964455344,77.27714083639185,-63.1625850386548 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(13.175414899399371,-80.5273088510057,-58.72023172179455,68.96031329932532 ) ;
  }
}
