import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-38.35282749684625,95.14235692275074,-79.8506899867865,-22.68807263003889 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-72.39667388655573,66.22778655207046,65.81738895491523,-27.74354640492733 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-92.83654090613662,16.139320852056002,9.280894093274483,23.04376578580134 ) ;
  }
}
