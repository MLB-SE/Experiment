import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-30.05477199051532,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-30.494215580293528,92.86544078201135 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-42.411500827757415,-93.32554112287497 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(64.37339161581897,-90.19823423095559 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(69.11514689012533,0 ) ;
  }
}
