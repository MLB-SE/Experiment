import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(10.86980119826113,94.82820622031397 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(2.028916778679271,97.29528552203827 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(21.853476622436062,23.982891904901436 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(2.20722485070948,0.04440760641288133 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(38.35177791894034,8.50583603915311 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(44.609940622480025,49.12359212277127 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(-6.905239220928962,47.68232869825562 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(-97.54648963956068,-17.09964981213315 ) ;
  }
}
