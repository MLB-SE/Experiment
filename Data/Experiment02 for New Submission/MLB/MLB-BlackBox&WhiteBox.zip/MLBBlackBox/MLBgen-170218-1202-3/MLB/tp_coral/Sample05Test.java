import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(54.47583471011464,-79.69195540777946,69.74985932176266 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(63.31621702759068,67.86918596278795,85.86747887768078 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(71.69712296221255,20.567290890313288,-47.001486347589626 ) ;
  }
}
