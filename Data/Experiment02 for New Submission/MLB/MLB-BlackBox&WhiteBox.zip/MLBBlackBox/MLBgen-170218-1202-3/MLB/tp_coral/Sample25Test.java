import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(0.9683476732400322,65.38336939506081,-3.4749387346103617,38.211191846906644,11.023928590512043 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,91.50618599898428,100.0,-26.272270260003353,-33.84925749972524 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(13.9672397982375,-65.09458919566771,-70.10057180560759,37.71866985624169,97.19259755717303 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-32.383023766345644,-3.0096729121263235,6.063487182506563,0,-72.52047051385028 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-32.59682030371336,-80.3861752619001,7.757909075489351,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-39.1879045876758,-44.939807564412625,-96.60018415076863,-82.4933593863002,82.20139610915918 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(6.136537719951916,-46.0077177775399,74.34911483234796,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-78.7563609386527,-43.06544793418239,24.419791242359224,0,92.03506822667106 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(9.359774758659796,-70.21354142271542,-2.0491481982031843,84.49593675163186,77.12304101947964 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(95.12285510878772,-20.173105223828316,-61.71136048865746,0,0 ) ;
  }
}
