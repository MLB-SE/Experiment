import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,-41.76624334971083,-100.0,38.78715392182041,18.244268087777556 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-10.645826330318144,6.462247815875417,-32.22896462856759,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-26.7560775275061,85.05923113803959,-69.3520614084394,-73.66847045676982,64.71468241325657 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-28.168293593471617,-77.86272366250249,91.53970971835324,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-3.18279348540365,-1.3199364970761849,-46.70711061376516,11.324974295507587,35.14888160942769 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(3.5033952361277727,12.134631132268296,68.6304069513532,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(40.65250834954949,25.207219525659823,-53.07697063114234,0,35.85964719993174 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-44.91577250063952,24.11474402317424,-68.70466817406205,22.565034676522842,-1.2421782373292132 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(64.94593933946925,-27.009859946663056,41.00803142122169,-97.63195033003069,64.00422961065635 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-97.70999388504636,34.719213774533316,-73.43154605867922,0,53.08368594613501 ) ;
  }
}
