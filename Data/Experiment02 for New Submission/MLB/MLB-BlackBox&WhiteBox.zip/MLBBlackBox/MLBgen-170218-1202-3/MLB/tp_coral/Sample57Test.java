import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0.3551436982399155,35.348037380738674,12.005418543184561,-19.385366058224875,-23.990292602560245 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-4.173726728972298,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,90.4555386791713,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-13.244846489796444,43.171316262618944,-2.8581299060572007,83.811171941108,43.952585049349466 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(37.59058131239709,74.71736758980953,-27.844733084712757,43.655040669248336,25.792152845408694 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(43.29443060245785,91.93492428665283,-77.22966532722978,30.88024946810782,96.92419085652503 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(6.112530568954313,92.06005821818215,138.82818123480013,-76.4669749895509,-3.239558831168736 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(82.00454239012906,2.489851649724898,91.82581987640197,30.60428544868457,-79.8474511780356 ) ;
  }
}
