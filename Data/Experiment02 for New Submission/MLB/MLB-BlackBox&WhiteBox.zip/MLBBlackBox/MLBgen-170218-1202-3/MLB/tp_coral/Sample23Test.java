import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,73.03993071285883,0,20.814100566330165 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(21.445392431127203,22.95928773072194,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(3.580951697706674,-72.47631055321011,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-57.566570684946505,63.73346998675399,4.810446344959402,-98.27220801095156 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-62.44079460100653,-35.49419739301601,0,-67.62166878084403 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(6.960614378141955,44.86151877706109,51.31539147649187,-96.31573959404231 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(81.81984333031457,47.33518043046402,6.966203114862829,35.49733380956009 ) ;
  }
}
