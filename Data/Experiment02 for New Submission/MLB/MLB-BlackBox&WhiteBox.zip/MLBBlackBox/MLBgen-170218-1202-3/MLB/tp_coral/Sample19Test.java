import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-8.087191919771186,23.979273956836238,65.40192392873752 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(83.51177999583561,-90.19875779401778,50.225449475423005 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(87.6106922917628,18.745327398520374,48.794619409290874 ) ;
  }
}
