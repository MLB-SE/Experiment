import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-26.51500798166437,-2.7558012890715684,25.20318491266468 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(30.429311085592246,18.921241237451383,32.55763500441728 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(38.23661313745569,-81.66683896928134,58.35219399464623 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(43.981549381393535,-63.77422750996566,40.592178225362545 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(50.26343897330031,-56.74887244839619,-54.892775309127195 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(7.718695699498284,15.85053609490052,16.885614026646792 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(-7.985576826818459,73.45758599207176,-9.271167069154892 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(79.99479587945413,82.2382566461136,24.987664810648 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(93.81771048247877,-24.424155196780486,93.02903014810539 ) ;
  }
}
