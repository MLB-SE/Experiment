import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-6.726654245264868,91.22458727013719 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(6.904598312372826,40.76887954284886 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-7.252453758196481,54.46065880844705 ) ;
  }
}
