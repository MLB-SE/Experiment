import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.304453499372741,1.8296247785736747E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(18.235871701201603,5.9941772464650285 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(18.611382779926444,-91.73643078490994 ) ;
  }
}
