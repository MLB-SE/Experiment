import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-21.45922692566667 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-46.05197467976914 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(61.86912803320112 ) ;
  }
}
