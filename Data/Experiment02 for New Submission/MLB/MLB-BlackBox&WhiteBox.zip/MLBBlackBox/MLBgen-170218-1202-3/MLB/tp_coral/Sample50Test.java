import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(14.107311846436517,80.48892203331246 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(17.41747734501135,32.58252265498863 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(17.904907559395703,-4.231419095220385 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(17.90888632982673,32.09111367017327 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(18.498696769805036,31.498696769805036 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(21.373833999511135,40.60290262731158 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(2.691719845126583,-1.6406461669496508 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(4.734703290715061,36.51120876159263 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(5.949352015666648,16.214019988534687 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(79.4197926332719,-69.95825123174122 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(9.607824098407619,16.546231207162762 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(99.73003236638505,72.15528415717088 ) ;
  }
}
