import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-18.04381946055254 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(6.488817050957678 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-68.329640215578 ) ;
  }
}
