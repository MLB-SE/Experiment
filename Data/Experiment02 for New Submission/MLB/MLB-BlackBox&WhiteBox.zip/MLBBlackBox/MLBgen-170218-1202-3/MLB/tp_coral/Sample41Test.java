import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(1.9019523161181469,1.7154702966690363 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(2.8699468142511924,5.366647902379376 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-3.8120116474045713,18.343444447352685 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-38.603517580899236,86.63827998570355 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(4.220523353911503,13.592294027000897 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(4.376920647592382,61.785139663639086 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(5.026558972741918,20.239736133710366 ) ;
  }
}
