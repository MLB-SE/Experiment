import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-85.30319894586677 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(94.90335027215491 ) ;
  }
}
