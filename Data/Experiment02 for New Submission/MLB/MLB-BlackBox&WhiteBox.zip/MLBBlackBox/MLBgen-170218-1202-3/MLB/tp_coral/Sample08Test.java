import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-57.26045181253778,21.451756503420143,29.566502546427188 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(86.59778781663931,-24.911714820950138,-49.767484916442626 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-9.455324798890391,58.8325969610661,76.40186014407081 ) ;
  }
}
