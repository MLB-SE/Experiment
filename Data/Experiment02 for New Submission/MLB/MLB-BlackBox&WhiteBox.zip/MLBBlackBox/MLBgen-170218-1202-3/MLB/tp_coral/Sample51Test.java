import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(1.1203609968677672,48.879639003132226 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(12.654834248736819,73.34246394179482 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.3801775970299262,36.310964021256694 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(16.861397620668697,32.98821019564218 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(17.972474821838546,28.231880702241853 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(26.26732581136541,47.45960901243754 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(34.77113348213547,59.14548974999619 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(50.050357524280486,-74.45954928775338 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(-50.39909815762758,90.80715853505791 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(60.23242049141016,-10.232420491410162 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(7.670119233652143,-2.7694980111298406 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(82.50350498921674,-6.09269181039231 ) ;
  }
}
