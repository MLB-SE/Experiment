import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-53.465962222503485,43.74247618628857 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-66.68767742219521,-1.8881759846833859 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-75.75545899458187,-4.500155969188649 ) ;
  }
}
