import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(14.658392662168723,10.978600326669266,-55.76803626714839 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(32.111088071349656,-66.57503725422664,-34.46394918287699 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-80.41599897135978,38.78770640508719,47.050447520315515 ) ;
  }
}
