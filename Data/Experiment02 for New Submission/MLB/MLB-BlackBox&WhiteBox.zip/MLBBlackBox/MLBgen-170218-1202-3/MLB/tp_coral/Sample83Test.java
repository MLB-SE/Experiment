import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-29.212002559312467,25.00642957991586 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(5.471723220008666,29.940022009766416 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(9.268503366803257,85.90519000039416 ) ;
  }
}
