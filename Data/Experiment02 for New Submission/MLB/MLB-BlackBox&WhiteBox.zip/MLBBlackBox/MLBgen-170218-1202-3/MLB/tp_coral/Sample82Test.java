import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(40.964612198656624,-50.13620901605651 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(70.95271337268753,-31.941134128471262 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(85.87810906980397,-71.49707702617167 ) ;
  }
}
