import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.9136384209928394,77.59553077686829,93.64649481814735,65.36684395374093 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-61.80377831216137,-55.132134002863495,-29.821469842227827,34.93023220939236 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(98.72127986338299,2.102677348797826,-97.2806361331075,8.86826749140755 ) ;
  }
}
