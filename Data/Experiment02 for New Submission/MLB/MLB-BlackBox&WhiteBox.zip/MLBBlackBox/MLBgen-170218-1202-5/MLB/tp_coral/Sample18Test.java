import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-0.1399620228047187 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.9595496299847904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.9918334746217283 ) ;
  }
}
