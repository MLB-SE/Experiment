import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.15278418019650533,0.17612718591482354 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9290403507419569,1.7921563240486953 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(10.49587228301312,99.66746269830995 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(10.51249128469419,99.99998172607712 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(3.048210998272282,16.749460449755563 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-5.904525771929788,40.76795036331285 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(8.913237545452432,-84.27651203341937 ) ;
  }
}
