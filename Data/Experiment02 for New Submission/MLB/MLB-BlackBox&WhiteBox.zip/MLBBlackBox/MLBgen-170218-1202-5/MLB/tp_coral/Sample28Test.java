import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(2.8546507159707915 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(31.319125981571574 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.3890560989306495 ) ;
  }
}
