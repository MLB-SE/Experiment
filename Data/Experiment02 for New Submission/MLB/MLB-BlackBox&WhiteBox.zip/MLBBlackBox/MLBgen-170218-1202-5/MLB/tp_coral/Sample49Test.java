import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(1.1208220953932653,13.476930067139591 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(1.5993971929589579,48.40060280704104 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(-16.78577671749288,91.50149232052561 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(44.628692291234415,53.99999944105821 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(45.96983876101609,-3.948706718276412 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(46.07509996730562,75.50054700040175 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(54.247187898880725,61.83208094284936 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(-58.94489096136404,-97.84726924183495 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(85.80278109353978,-9.262979061486632 ) ;
  }
}
