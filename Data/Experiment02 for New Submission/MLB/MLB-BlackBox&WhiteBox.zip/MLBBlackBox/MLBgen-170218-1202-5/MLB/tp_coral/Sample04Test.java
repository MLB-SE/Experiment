import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(36.385788541888985 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-47.20063324969528 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-661.8367532024936 ) ;
  }
}
