import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.63038535837945,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,7.003740258603358,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-1.928338437721155,7.880941268376062,15.59378927001849,-20.21788633802953,-9.595610235518805 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(55.44423246305615,-33.87483333712413,-91.04370907633141,-51.96399554174553,96.31406959122185 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-76.46805227437987,-34.98902399948744,1.6993717915414095,-75.94730208143523,-95.23213681151645 ) ;
  }
}
