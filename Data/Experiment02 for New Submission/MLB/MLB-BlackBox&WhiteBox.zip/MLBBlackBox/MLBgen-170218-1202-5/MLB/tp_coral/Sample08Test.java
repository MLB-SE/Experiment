import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(1.5882496114300295,63.51352134030364,32.76439611533897 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(23.604466517728184,21.728679976924905,-93.5432105458157 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(24.030518620434123,-23.57683820120333,-20.874292890454342 ) ;
  }
}
