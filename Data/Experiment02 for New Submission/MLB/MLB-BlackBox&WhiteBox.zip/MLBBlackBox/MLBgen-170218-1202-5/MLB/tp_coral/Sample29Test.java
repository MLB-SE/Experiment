import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341003 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(17.541301436239237 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-59.62877649026994 ) ;
  }
}
