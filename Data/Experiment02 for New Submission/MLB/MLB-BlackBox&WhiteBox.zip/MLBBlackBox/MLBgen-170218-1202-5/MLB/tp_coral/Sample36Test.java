import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-24.219294658596823,10.380164066278681,3.8035299583535487 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(52.2543912888645,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-55.438155359605254,-33.14156457533768,8.841661727740938 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-69.11499382139151,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(89.10998665991812,42.16314945425867,14.17740800390861 ) ;
  }
}
