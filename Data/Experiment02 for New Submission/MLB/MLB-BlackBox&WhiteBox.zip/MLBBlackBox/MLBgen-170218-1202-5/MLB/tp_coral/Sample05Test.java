import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(28.132117742834087,-61.05161297705957,67.70653477769295 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(49.46173022202447,78.84460263394277,-14.308457111007073 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-93.97723917539275,-12.301674032425055,-2.6563191764786183 ) ;
  }
}
