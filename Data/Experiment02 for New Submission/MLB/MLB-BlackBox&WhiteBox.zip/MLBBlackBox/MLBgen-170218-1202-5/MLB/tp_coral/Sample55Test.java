import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(14.084060758708361,0.7497677614987586,11.739582029504614 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(14.772350570278746,55.90549467084057,-94.54212114954873 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(19.678344230913922,-48.368297834367915,-84.65546043754723 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(21.000876694483424,2.6739420585820994,29.252616575035255 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(22.63338756417963,-7.012502569316553,28.49810708874557 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(28.173600353168066,-25.347120247209716,43.11827235630256 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(2.961832273119419,2.42483114750217,3.930177378350768 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(30.453884685065532,39.435346204823105,-19.287230837685755 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(32.34056877516308,-63.52187311199257,33.482742765587346 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(-38.818046070774884,-93.10948191756472,-41.25982486263244 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(5.492073149890004,-33.37201825720257,66.67461731878572 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(55.4916110137391,100.0,56.426285288004 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(61.41297930563159,-18.405720064884747,87.50488746132118 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(63.78065962374902,-73.1170887359124,84.23197784907649 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(79.56204116147332,33.94699521596835,80.50779112028792 ) ;
  }
}
