import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-65.82339092635857,17.80497697184198 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(8.934585864231522,15.532114660198573 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-93.29001788368596,10.382539684777214 ) ;
  }
}
