import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(18.230926379529706,40.8912846293058,92.66943609889137 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-2.3193463189572867,-26.791654173728617,-34.494705647000984 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(2.5177703860234026,25.492992347297143,-12.2455554884705 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-32.348949769760154,-2.891427402071727,78.73929366164165 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-46.23306744298992,5.14930819574394,-42.319272684397546 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-67.33382654164765,59.917320426242696,-4.383163580282584 ) ;
  }
}
