import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,10.87552476496299 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,64.88935206352585 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(10.098726047308315,-59.68550678346379,42.02631189614038,-0.1691989662405987 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(11.575641331116225,0.20902225742887026,-1.428666600849301,-13.546945232174062 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(128.49845386065476,-75.60213973414199,44.58605960700254,20.136250915608883 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(21.2327219425477,95.52544855646227,-93.83727077222474,87.26872417275979 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(22.11207718362722,35.093623607009974,149.6138245488171,-24.637917598012407 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(25.45258723227002,42.16245868282931,52.387774356868675,-97.9264013811346 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(30.874434091069816,2.7641711826561703,-2.846097893118037,78.54246257343681 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(31.807813258859056,-2.563950546714724,51.43724891495829,-13.835395998489375 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(35.26390544598107,23.582968885359207,89.96864399547462,-19.408465250405357 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(44.618971877389356,-4.37117041931036,-77.42427653995674,-29.162450656521898 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(-5.49392431518249,0.0,-54.50660799626008,8.567614323278047 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(5.855688108852846,18.275246816688266,44.22340920097006,-51.81596989417112 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(-65.09532078441313,-83.60037746070974,32.25831907850869,80.9372267780661 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(67.17204190222742,94.11662302849987,-89.26769622691782,-34.130464898838866 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(79.48055821231759,56.11979176676863,0.7733609511108739,-15.423514435937264 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(84.89135712550566,-24.055080752597704,-16.085195693442415,76.92147206635038 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(92.36220839742862,-40.08963632913027,-79.40637519266744,82.12865891315593 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(95.01636397641356,-94.70366701776662,15.566116746647051,49.78019873938882 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(9.793761164983522,58.12747073340225,84.2348682825552,18.92041748160176 ) ;
  }
}
