import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-41.10786692563407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(14.547644245937263,16.018300158778672 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(26.250783002255957,33.23428552438605 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(-31.981727987131464,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(3.9797075881663844,10.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(53.68686569788633,0.8826857340740295 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(7.43300090097982,53.62483060050198 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(82.48306433767794,-86.00764149117757 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(88.92343628318707,20.25182916101693 ) ;
  }
}
