import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(26.415836547220394,78.94082889596015,0,86.14248200623712 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(30.01958144445524,-62.118195104847295,0,69.5436075608607 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(48.357628911371535,13.635139943026473,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(56.176618377677784,87.79154317907566,97.59267730959252,9.26270874079303 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-58.34233587690332,66.20506419899097,-80.75901845612242,82.23414208635374 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-75.97027202637841,13.245641570027672,24.101944087228716,31.249503082192632 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(93.4940610567386,17.655618867069844,0,0 ) ;
  }
}
