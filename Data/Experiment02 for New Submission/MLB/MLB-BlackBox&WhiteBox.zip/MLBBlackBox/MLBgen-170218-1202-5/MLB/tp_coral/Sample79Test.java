import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(37.00526864759175,56.78734838166167,-94.24987593672694,29.336553654601715,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(4.4754371825583295E-12,-100.0,-100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(6.560469862238689E-9,-100.0,-100.0,100.0,0 ) ;
  }
}
