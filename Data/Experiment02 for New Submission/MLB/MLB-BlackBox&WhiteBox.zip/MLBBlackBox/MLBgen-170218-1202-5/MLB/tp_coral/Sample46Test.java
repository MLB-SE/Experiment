import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-19.113735603132437,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,60.91642964240677,-62.74686748750986,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(15.28456152138898,-39.94939296144637,61.01388658349208,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(20.89497351777888,1.0000000000000004,58.14055892810334,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(-21.517276215641985,0,94.7819802959151,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(23.667029523428823,43.893299641697155,91.99013709273808,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(26.346296538360136,0,24.793850437267892,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(28.382370186273675,0,16.212020524767425,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(34.701108047872054,79.28100186688908,71.3187071049517,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(58.610863071173014,1.0,72.95220947060153,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(-66.05033569650931,0,0.07888780489829372,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(6.6174449004242214E-24,32.99218811416336,1.0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(-691.1136135230481,0,4.764899395797713,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(91.06581716443418,4.810265328779153,13.798371858917207,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(91.80525924108383,1.0000000000000002,8.576497065307619,0 ) ;
  }
}
