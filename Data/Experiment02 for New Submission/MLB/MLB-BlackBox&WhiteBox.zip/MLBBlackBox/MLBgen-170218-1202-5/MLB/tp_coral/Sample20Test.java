import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-13.225428650185583,37.59982490439767 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-35.28661078801423,43.89214899453731 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(60.996734926733154,90.9650367685814 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-64.01625707350703,-41.478681878470816 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-91.12860258928404,-44.381166931421554 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(96.98436849537956,80.26289972857518 ) ;
  }
}
