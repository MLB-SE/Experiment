import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(10.345017345773954,39.65498265422603 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(11.541883048500758,38.458116951499235 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(24.542015925251953,25.45798407474804 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(32.860475747067056,67.95056796640941 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(3.8348359471749234,16.834835947174923 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(40.83959220027407,60.815978341949204 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(44.729296515461954,-6.247592936391541 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(63.106537420706104,-13.106537420706104 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(70.43065059151326,74.87605686167697 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(-70.78649699465554,23.940890782949097 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(81.87022705449374,-65.90099662538108 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(8.684714617589517,-2.946983986653052 ) ;
  }
}
