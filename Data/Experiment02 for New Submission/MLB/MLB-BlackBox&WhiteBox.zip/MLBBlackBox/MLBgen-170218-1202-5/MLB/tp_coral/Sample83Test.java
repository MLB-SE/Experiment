import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(1.1939992973556937,1.4256809732166154 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-75.59458878360978,-47.13301368813825 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-9.647789610880803,93.08503754379255 ) ;
  }
}
