import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-100.0,92.47875800066484,-150.27362230025201,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(100.0,73.56194440870486,100.0,0,-99.99999929567775 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(1.677404824675449,61.50132502451186,83.90946952197154,30.202001922979917,-4.426040070714848 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(17.208792336747322,39.24553371055967,23.503198129287455,0,-88.26008913758818 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(18.310339576432458,-67.30923791050928,49.8503335691487,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-27.759425386352518,-65.7528071805794,59.656674312726636,-81.48187660454514,4.942704972972109 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(59.31992680243172,-28.161862816194798,17.496408986990005,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-71.08455218495531,78.69765344465738,33.90200562745235,-91.2196151870591,22.831609688875318 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-73.72552611269006,-84.38041589773667,56.71054982049691,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-90.95188107923661,65.23656947741608,34.947441671720156,5.999930057827015,-13.726599862875759 ) ;
  }
}
