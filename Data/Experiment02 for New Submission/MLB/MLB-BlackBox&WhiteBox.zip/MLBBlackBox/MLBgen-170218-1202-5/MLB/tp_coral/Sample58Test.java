import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-2.102986842868276,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,38.217416327667024,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(11.163996591661515,82.85209564370398,-94.52327348650091,100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(18.391331888997442,127.94129390079242,8.099902680824972,111.55006853511108,-79.38446045017827 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(19.50200709870313,27.98225698275172,74.56560234380066,9.917785946086127,9.884880968169355 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-27.39497728610691,98.56174530534585,-70.29938023567654,-8.678575735596453,7.112558136149062 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-37.02398108745868,-63.78127819793633,-63.140311280354425,16.790832049608056,-18.021816391359252 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(38.61977736155754,8.620675626293746,58.199753418034106,-50.581624211076104,95.99608811858857 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(63.59079499862807,88.34141552543454,54.39412983349263,-27.4326102698122,92.61929371673833 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(-70.65004226833182,1.661568791099777,-76.15601870818605,1.318497883409961,20.464319879968613 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(-94.5042443097045,2.631907456460965,-95.51775056761242,58.87870288138828,3.8206866393685885 ) ;
  }
}
