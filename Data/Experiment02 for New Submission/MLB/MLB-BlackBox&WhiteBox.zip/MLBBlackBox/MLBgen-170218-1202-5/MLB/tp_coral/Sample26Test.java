import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-46.7474027717047,100.0,0,-10.177752015276717 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,73.19707199975224,-100.0,-84.22727502768157,-39.66746273249849 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-18.674216694914094,-73.80439190560281,35.967382790463716,-59.6007335466038,-3.579176699178774 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(29.283406655857075,97.97339947480118,-70.72754273500868,44.66659134711722,-20.733785038861452 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-38.45345924402081,-30.887434381518062,-54.97316326398107,-7.621764430700068,-7.805927117067029 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-39.61469723240232,-47.933491315620856,39.91733083967813,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(39.954249554932034,-10.187751663719652,-36.6244821123642,0,32.10893906995193 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(43.610770943021926,75.77583135532588,-49.07256911408124,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-45.304187787316685,88.58121790714442,-62.26626313079309,94.49000695454775,-80.595067340408 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-45.34972079388737,24.65468732122858,-13.665178666115722,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(-5.245511788677752,-19.52981980936396,-10.261028531378361,-72.95938843003763,25.490133290523914 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-87.48826195981674,1.7040587112384822,51.93561878971312,-86.36650585177827,96.78547874956392 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(-95.35402988413033,-51.298467644730295,-17.757089089824277,-94.41730922973738,-59.55826245220606 ) ;
  }
}
