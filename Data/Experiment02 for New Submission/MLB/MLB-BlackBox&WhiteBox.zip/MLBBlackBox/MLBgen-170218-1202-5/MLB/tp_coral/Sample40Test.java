import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(11.815669487098205,151.89232294024814 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(24.023448692490774,62.6039887935828 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(6.294094018819706,33.32152549892229 ) ;
  }
}
