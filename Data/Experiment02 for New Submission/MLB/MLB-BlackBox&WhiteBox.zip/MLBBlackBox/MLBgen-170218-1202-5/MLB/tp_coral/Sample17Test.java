import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.5742911983469554 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-50.356260840437315 ) ;
  }
}
