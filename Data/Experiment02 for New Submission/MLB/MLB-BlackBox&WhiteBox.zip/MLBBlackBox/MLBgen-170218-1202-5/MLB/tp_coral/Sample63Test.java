import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,0.691371884167566,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-5.917755273534354,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(100.0,4.789323237310299,100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(1.1366233230698513,45.70613577061936,44.56817542634054,-9.08861740862753E-4,6.11935199570566 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(1.812975186262189,25.763370553632086,34.68954551980548,95.92147960450914,-77.2171595025441 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(19.556639846924245,2.2835804519714467,-100.0,68.3035321313075,70.72848949909411 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(22.603809149010985,37.714074703037454,53.68465120788068,-84.4746985112497,47.29037192148874 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(29.987342415633407,6.449160331830768,35.31605328332503,94.49707492959564,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(32.43893984238946,17.83204225911299,66.3617452498646,1.819137672007909,9.175963739898464 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(32.70999401498284,-19.25095114166473,24.57649613963744,-47.67011734870519,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(34.42960069600272,45.535160696299016,98.56511679923449,-18.600355406932717,72.20933762281987 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(36.02094922475456,0.0,-57.29986585468569,53.94240565571761,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(37.187810472036645,3.418327540447706,-7.177250719860474,47.78338873234485,-25.65600133020304 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(44.60390882595352,29.239642257566885,100.0,-2.0923445607321156,-43.600728552256115 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(44.67565094583105,97.93697625438352,41.499465260586504,-91.48257921839702,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(4.643546044395745,34.433022346899065,53.02998085144541,-7.769344958227469,79.1643379848681 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(52.893154217174,2.835413844880925,17.802424998695233,37.926158457604906,51.87078298244699 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(59.559441366006325,14.212588223171778,100.0,-1.4282824725001149,-6.767329192463876 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(60.70556733576677,91.7380381653762,95.83758041686167,56.6060250842813,-17.075312976954947 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(66.38045325587393,55.781490442412775,42.546281684951765,0.1353457989922333,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(67.30937096622336,23.925592623712944,77.57376855848489,64.9871685793457,-5.101998834815902 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(67.74959755205852,7.533042607049974,62.004581941660874,8.99365645414745,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(70.0110398583262,96.21998659788758,51.4834267461963,98.5800896828631,-66.91931555098967 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(-70.59467621060027,-56.19225973244116,14.402416478159111,-2.220446049250313E-16,3.339430887052912 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(73.68121086981778,14.867515007311487,100.0,4.62685796488894,74.07874907469656 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(77.53233003668385,24.078758955887537,-38.11494778886446,3.572604685066395,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(83.68885072952887,-83.51115395501527,-12.329526983130616,-69.38520418775262,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(839.9462403761896,1.891190695012356,43.85888991835304,-100.0,149.06194295665483 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(94.87749043485846,73.09956139673778,98.2385001780712,62.62206969628269,4.73943547178051 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(95.72495432788031,-47.79878173765915,-32.57554851311633,84.36174798127863,3.3835066691578106 ) ;
  }
}
