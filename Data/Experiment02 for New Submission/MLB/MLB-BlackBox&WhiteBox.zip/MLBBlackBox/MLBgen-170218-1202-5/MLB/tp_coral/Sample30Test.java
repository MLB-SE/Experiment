import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-2.8379972040168298 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(41.093210147464845 ) ;
  }
}
