import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.16944407351332916,-33.352765615606344,0.004717337626285788 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(36.06409381510369,-92.21867078650835,32.63094711667404 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(-37.35130360338823,96.89227616085967,43.926368174804765 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(4.768411069389572,9.125462742734271,-79.84174670585193 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(53.945143143481744,75.93127678616452,66.62081674342824 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(56.061640126553755,-36.07082681265577,82.91609075264984 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(-62.32107380462198,-2.7802792847739815,82.94332715960164 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(67.53865086690186,-94.66410771212391,-23.846725952944922 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(69.72443939585779,-40.269907020668924,88.89398582245468 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(72.382862981497,97.87425684950733,99.70637559541359 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(-79.31174259377225,-73.51912015471578,-76.8210532584232 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(93.91869764102388,-21.203157422127646,96.16329432263876 ) ;
  }
}
