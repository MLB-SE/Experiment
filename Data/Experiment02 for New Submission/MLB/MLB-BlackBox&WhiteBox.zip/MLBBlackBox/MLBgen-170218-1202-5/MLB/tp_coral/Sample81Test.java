import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(26.044270458371237,1.6437432101962193 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(36.7676230458612,-67.18126053859079 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-91.2055790044213,1.3556378156522157 ) ;
  }
}
