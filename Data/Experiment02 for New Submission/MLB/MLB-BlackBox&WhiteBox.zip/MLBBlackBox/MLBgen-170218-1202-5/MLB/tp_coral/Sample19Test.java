import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(13.353718292433953,79.38956365391593,42.901487317145296 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-38.284637632543486,62.25207594506236,28.62869084218272 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-48.42514320854121,46.844017451965016,62.09436204604114 ) ;
  }
}
