import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(89.73614860021087,57.61891839858122 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-91.4573478738619,61.116025175520804 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(98.3048293690143,-2.6633623854545903 ) ;
  }
}
