import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.3981926780734157,2.017817307017529E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(18.628658152682306,-40.166407307818645 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(93.11701250363015,57.413950941495955 ) ;
  }
}
