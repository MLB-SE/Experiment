import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.917532916108907,4.2876396512929595 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(38.866894322710976,68.68092306977022 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(46.0807555222475,73.53930397197055 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(47.82564526306675,33.24290340818678 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(71.76025270501137,0.887014035004615 ) ;
  }
}
