import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-36.12831554567447,-28.88976756506156 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-75.39821698309984,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(82.06894126308302,-27.256228369500434 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(90.71298646943521,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-91.69166477961659,15.295719818659052 ) ;
  }
}
