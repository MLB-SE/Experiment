import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(40.036351537128894,-8.066202075773248 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-57.11473983340041,-60.70790926945748 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-80.53767507016438,-97.61190221145624 ) ;
  }
}
