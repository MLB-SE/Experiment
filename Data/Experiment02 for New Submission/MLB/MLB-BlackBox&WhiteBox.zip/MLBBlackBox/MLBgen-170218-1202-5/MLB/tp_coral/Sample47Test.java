import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(55.92268887393067,-7.666096623661161,-77.63840608897854 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-675.6535533187707,49.333149187803116,-585.6992371481227 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-90.14297238169127,39.33837845619439,89.03126407839994 ) ;
  }
}
