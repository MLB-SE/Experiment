import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(20.003992649730797,52.71015162548005,-0.5051675452085098 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-83.8460387100184,33.524902463159435,53.17625810749291 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-97.88074394348736,29.60274092223412,56.44732415355455 ) ;
  }
}
