import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(18.98750272754542,90.70722038145587,-39.57174324651454 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(39.543898797834686,-74.0111792604736,22.615803248258402 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-60.68625931406851,-45.72911900372026,-39.39061973324913 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-65.9734635552107,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(78.07989477319447,0,0 ) ;
  }
}
