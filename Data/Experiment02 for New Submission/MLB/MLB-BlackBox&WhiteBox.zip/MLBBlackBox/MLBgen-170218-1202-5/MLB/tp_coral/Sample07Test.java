import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-10.685593574327449,0,-34.71250954165891 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,24.085543674812207,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,61.6965626530984,0,83.00257869603135 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-63.25785086650137,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-15.044212627035463,-17.51035889795982,47.269726771404095,-30.616670529249234 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-45.517705644306105,45.01037639494652,-85.49756351884976,81.5275813124997 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(83.38162910880295,43.668075784804515,23.8413027546979,71.36020441574591 ) ;
  }
}
