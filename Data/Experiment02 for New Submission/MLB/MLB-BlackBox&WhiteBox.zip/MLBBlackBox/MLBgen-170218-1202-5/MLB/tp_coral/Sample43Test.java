import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(2.0752774218353736,43.61931111203998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(36.282516325685236,40.80450582161123 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(-46.67256797937112,-63.05867161548693 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(49.112873664502786,96.18460680428495 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(-5.034490086416497,25.34609043022599 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(54.61248921733636,-73.16171962400932 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(65.4368138801145,19.556753639140666 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(-75.92480131640123,100.0 ) ;
  }
}
