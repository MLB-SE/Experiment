import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-79.68245742562041,88.99424384165852 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,21.999516954085948,-47.47236553528793 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.0587911840678754E-22,1.000000001039303,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-1.4210854715202004E-14,-91.7698692154764,68.521341302928 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(17.07794710866814,79.5522457832952,96.40153959959275 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(19.59976016128762,28.300174405853795,9.564404601451855 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(22.99014839960077,24.99014839960077,40.69079731977777 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-307.32474595620937,-370.95556868526285,68.1316388251467 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(34.448921164639046,5.035082872046303,15.055958562793052 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(43.47794825801478,-28.00891334342404,16.19968364100764 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(44.30985733273488,75.83524609294713,29.21843223374853 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(56.90890309960133,46.34144479000449,59.08319783419745 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-70.97931326533462,-8.756128209168352,74.94678835896741 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(79.73010443421472,1.0,30.478062239136 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(83.10399173511348,-92.56448913649965,66.69963667398565 ) ;
  }
}
