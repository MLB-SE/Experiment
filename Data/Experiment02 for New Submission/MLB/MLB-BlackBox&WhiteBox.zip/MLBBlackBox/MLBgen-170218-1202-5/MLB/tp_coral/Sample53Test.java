import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-11.260449499396813,84.81880041875297,-23.02377302904364 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(27.156816935937456,-12.018232887867143,-57.161489040736726 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(36.033761372225285,-31.68012354422258,55.574171111220565 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(49.321580935447685,-75.90388579938232,72.18293658108294 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(53.94201430252107,-85.06479990622165,-17.234851930080737 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(-72.585784339568,49.31878001213141,-94.72557701339099 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(72.86325285170844,2.782900355191801,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(-91.75887911940956,-66.4958385599333,-90.8154631703206 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(94.16750250432153,52.12448513796471,57.05398367553448 ) ;
  }
}
