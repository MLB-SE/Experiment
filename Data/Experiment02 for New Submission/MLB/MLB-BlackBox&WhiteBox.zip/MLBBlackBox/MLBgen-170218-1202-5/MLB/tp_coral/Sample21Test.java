import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(35.34142797482034,-66.53613721797878 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(38.61782337414877,-63.16781259889153 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-53.27366550586885,-69.39769024732297 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-56.42232763704524,5.492246706103614 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(6.2325381271794384,51.947608016030415 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(73.8641104327468,-31.789800813584662 ) ;
  }
}
