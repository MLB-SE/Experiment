import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-10.948611770063522,52.36834294337375,21.095091196393323,-24.749718439718087,15.324940478948708,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(26.232643102096233,-91.87234864504627,60.69477122996568,-58.48070865020609,-65.68205489330305,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(38.86895515330494,52.338445676463806,-62.69407936351232,-38.05365288089266,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(46.66583104323851,2.907709645353478,-68.9471558220305,85.87740903186267,36.59862663179325,8.020710497456335,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(55.430189888524836,10.755499847833903,-52.7174572126633,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-55.77385807803087,-43.26688726997694,76.07247906009908,-100.0,99.49031342433966,86.82142636989178,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-57.12019924588194,-8.334107133352404,-83.46297332475729,12.974913353428093,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(64.6645153705748,-60.873688564986075,-80.95901181029063,-50.02837352960467,-94.49952699891038,-13.703657236171926,-39.70341787485456 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(72.88811839863948,-92.2237630923703,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-79.42088059020762,-9.525226086270195,56.300064401281844,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(82.00160175533492,81.8113697680065,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(82.71779153317752,-44.31396794356826,-13.219023474000679,-57.96952058340784,-64.32908351992458,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(83.45677881060305,-71.00649926915148,98.7635029133305,42.608166498210196,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(84.94674035076585,18.725817217697326,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-86.44399720821771,-23.310318944603736,45.287205949008424,-86.04591011993794,86.71036305869447,-13.952898112547919,-9.447332221382585 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(95.63296231817048,-74.6176519176948,69.04365079301557,-33.912174250021664,86.18191649789516,-57.90758261558702,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-98.60751720558198,-36.59765203695855,-100.0,-22.320054999240213,18.86167599532743,-0.1168632954917399,74.08557741584852 ) ;
  }
}
