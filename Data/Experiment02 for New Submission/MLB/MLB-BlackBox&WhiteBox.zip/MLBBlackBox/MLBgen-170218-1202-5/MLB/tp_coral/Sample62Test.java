import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-32.07754418473013 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-6.761856041990285 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.49381086669943386,62.87198677871331,42.96829040689772,4.242362978079669 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.8031504946395336,98.56173718620653,88.3297121323372,90.7833441242588 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(14.524567192207911,65.27366123782855,81.05313973168774,29.985204108411068 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(160.4695662474664,-1.5383530860930534,11.334309338046893,58.1737277113798 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(29.45091895522988,-29.056613740872486,18.98728191915454,-1.0135702397352224 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(37.05196307419919,94.09407889329455,95.43300634461826,35.71303562287548 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(38.87165889238208,1.7845892011040885,-15.419587462777429,-69.65347535966791 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(40.61258927780004,0.0,-100.0,55.91476213167092 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(45.233733162783125,-39.085132245133664,93.12966573298871,-36.43303380745713 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(4.729206264131054,100.0,100.0,4.729206264131059 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(5.635930112810513,32.67080836096232,32.739953470232486,5.70507522208068 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(5.843082181229912,-8.720267142495451E-4,81.7774233149159,-75.93521316040022 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(58.75558016158135,-37.109831029428044,74.11020349145957,-33.62611364705262 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(61.003441514076314,-67.94928874911739,90.37131947168618,-13.010841789864358 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(-62.26583468327682,14.269480536412374,-92.11677063188878,-12.36681474906976 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(67.5081080935283,85.14440637962682,9.540333104188136,-74.62505367009516 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(68.0856834346121,-20.16124978725111,35.388385408628466,-71.32578069299137 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(7.833871045828289,3.587725306935525,94.22943207644471,85.58727439449453 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(79.80718592072819,67.72014421257671,8.56937729589336,-7.290572358624601 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(8.616956592118875,54.774550812359735,73.47644095396026,-3.489968546306926 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(88.82891122171284,-28.848081444799917,98.25907858661108,53.174601206860274 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(89.08196517980323,-46.02006243000005,-99.78297391292799,2.9109423483118633 ) ;
  }
}
