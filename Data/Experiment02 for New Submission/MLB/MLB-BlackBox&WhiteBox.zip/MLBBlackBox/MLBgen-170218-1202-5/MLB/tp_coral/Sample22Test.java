import org.junit.Test;

public class Sample22Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark22(-100.0,100.0,-100.0,-85.62458661487008,75.43059730159656,-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark22(100.0,-121.41684156814647,100.0,0,0,-92.94250916823812,-99.99991314321684 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark22(24.30627059945469,1.135237146708974,91.62352612325756,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark22(-40.75937046989132,100.0,40.80171135402997,93.30495828859375,-84.37697557549575,-46.69194917046277,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark22(55.914654824583465,-8.434804243138998,84.54844509864162,-23.05969228817763,46.81292841175804,2.619161740183685,56.289228791216686 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark22(61.658111752606,68.6809472574684,96.7987194506619,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark22(62.29661548137443,21.13385371678855,41.27680910726937,-60.62182193423846,-43.74991093397171,91.05890915797292,-88.06189921177115 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark22(82.78855087892742,-46.42460213167545,34.87988731001758,0,0,40.15990319857633,84.29284914275058 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark22(89.21503029913043,-10.816612733406927,33.377565679167446,61.99743724785708,-81.69855964842606,2.026528147082132,-88.89083975979575 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark22(93.65602923395014,3.2847624799875064,6.449256517716833,0,0,0,0 ) ;
  }
}
