import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(49.85384256903194,68.05264897396557 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(5.447185985835176,78.8697517213134 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-93.20892686701563,99.9990213285595 ) ;
  }
}
