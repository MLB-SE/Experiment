import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(29.19251104444973,28.780726713525127,38.60281636906615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(44.31603042314006,83.61714055380199,92.87715351807165 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(47.4472760499903,-91.85663237417772,49.10642362476884 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(49.56774484486121,-91.60982899321131,42.36583747848354 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(72.09141173688607,-78.83856243908578,47.51040330585397 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(-7.424198881278576,96.12446370019714,-4.910070433616639 ) ;
  }
}
