import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.16204421179733863,10.256732982699697 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-13.752435747075495,-62.317547947525355 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-25.740712327542496,58.051342392410874 ) ;
  }
}
