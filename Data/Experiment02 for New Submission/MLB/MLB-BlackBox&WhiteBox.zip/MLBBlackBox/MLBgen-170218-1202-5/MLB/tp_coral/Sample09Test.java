import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-24.199065484522578,-63.122551537804775 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(4.740258871149933,74.37380855368463 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-62.30955232248632,-72.5039934506569 ) ;
  }
}
