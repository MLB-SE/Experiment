import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(15.143134297894548,30.409959179157454 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-5.662946424100696,52.81106611564758 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-85.34938612038655,63.46863605545329 ) ;
  }
}
