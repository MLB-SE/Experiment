import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(37.07047363972947,41.56483042249306 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(77.98369897770733,63.91096958018047 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-87.2325053743994,50.61697847349714 ) ;
  }
}
