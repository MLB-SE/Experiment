import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.45523451922062463,0.862928632510787,97.52053175583441,-98.97694244626842 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-80.92510931002892,-70.8807384999832,4.344582474898019,18.30025878373833 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(83.08799678705279,-21.73388157658458,-94.14591812832265,31.446463337236793 ) ;
  }
}
