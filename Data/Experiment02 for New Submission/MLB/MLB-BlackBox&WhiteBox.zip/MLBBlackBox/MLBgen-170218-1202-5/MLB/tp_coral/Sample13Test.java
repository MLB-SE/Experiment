import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.21727272107949602,-25.48945517255099,64.78029772456313,30.826050421285373 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.5716613235706866,-41.44139111750941,-28.47900708098136,2.2445740191134482 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(25.745612467286747,43.92751290126881,-71.47880256638805,39.7705215717599 ) ;
  }
}
