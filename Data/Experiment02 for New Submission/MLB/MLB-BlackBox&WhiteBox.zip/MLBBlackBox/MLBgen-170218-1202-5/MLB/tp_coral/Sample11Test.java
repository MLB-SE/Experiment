import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.8002378565950181,-80.53418176530727,-32.504867261083746,-20.62893833196921 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.8351350301039488,31.16765725883525,85.0218103857924,26.745260438104324 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-6.561096619026642,48.35668339912104,-9.109080690463898,-76.52759521928687 ) ;
  }
}
