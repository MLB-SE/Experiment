import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,3.7041031684890555,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0.8684613965911997,27.789103323309604,22.76198845468744,-13.797184786894519,-90.05799963031171 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,88.43401667704796,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(18.531255499868294,90.14758194206337,-109.57238126706633,36.290024572363336,61.8446817739129 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(-23.667173559867628,0.11037218110964453,24.542467298312296,100.0,6.287557139750874 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(2.9550705162748825,26.289630874411003,61.26293781669607,-21.063832448998284,80.43591705922856 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(34.05948203672359,2.474493461200268,19.532134462348946,57.18762040388391,-26.85776419573446 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(36.13547674900502,49.451622548522636,3.405272946004459,53.716773630348314,1.4423404317909956 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(4.170098489923974,-11.253877118722064,6.4341379666037195,-198.62775501784105,-25.97685889400826 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-44.927327878657984,-31.04313213500574,75.14505615333175,-75.72542725142937,1.4928114875596101 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(47.58393598914533,38.704942712193564,53.57821312819501,-33.06076092187075,7.377178808264844 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(-80.77232998022271,-51.88082810258909,33.841890090290434,50.50047291103351,62.85374878402379 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(86.89913950288124,-2.921161538724064,-33.909590419875116,-23.904772014691147,-13.701738344210042 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(95.580859008002,32.50463115475603,88.28115124412955,40.919091406644384,25.905366641249316 ) ;
  }
}
