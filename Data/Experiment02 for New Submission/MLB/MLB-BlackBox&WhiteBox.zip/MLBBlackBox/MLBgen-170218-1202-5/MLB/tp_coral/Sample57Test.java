import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-2.0477435719198525,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,70.67021628048383,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(-1.355266837384499,-40.736788882173535,46.06279613544021,67.55062485616037,94.12565336452514 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(15.6073519111481,21.929553854129693,60.47626025257571,27.466191516271294,84.2264742445154 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(21.23288605319314,-76.0713040133445,71.52514434791553,33.56341846250345,26.497208960019748 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(65.60247157063203,10.966948615886935,70.36843110537589,81.76711162626017,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(89.95818754991492,92.68010616564149,57.692801097868596,64.05705899049255,75.20968888485257 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-93.7043595554835,-14.753862319498339,-63.5439094208605,-25.13670977548908,24.083965999823434 ) ;
  }
}
