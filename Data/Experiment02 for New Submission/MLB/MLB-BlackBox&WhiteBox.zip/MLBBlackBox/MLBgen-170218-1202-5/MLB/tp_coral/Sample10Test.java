import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(31.38495608158057,-31.265562511470677,-83.70120148614937 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-56.94103773700427,43.6802928124705,-71.20508906136094 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(99.26097562642065,28.016662344633772,62.40762216105574 ) ;
  }
}
