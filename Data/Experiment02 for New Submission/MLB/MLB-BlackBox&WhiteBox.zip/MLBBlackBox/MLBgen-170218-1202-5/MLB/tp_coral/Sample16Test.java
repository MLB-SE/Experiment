import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,86.13080636410743 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-9.519961087212963 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-1.8361556472856364,14.726654068064661,37.73769823989224,73.13963800209999,-30.960227964676193 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-50.695367050574156,14.90536682797591,-54.44749194900016,50.18828192877959,-83.18690817146683 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-57.38212600940569,-71.36614077813826,29.30529400589967,26.20517390949564,67.28892856180244 ) ;
  }
}
