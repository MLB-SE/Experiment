import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-26.626283009497016 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(52.219415677499114 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(5.369317803410153 ) ;
  }
}
