import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(17.105580532748604,-23.122512713599775,-21.89570940588756 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-55.52285834907407,27.02361141776757,77.06037556437022 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(65.70216794540106,-20.355586078248546,45.34658186715251 ) ;
  }
}
