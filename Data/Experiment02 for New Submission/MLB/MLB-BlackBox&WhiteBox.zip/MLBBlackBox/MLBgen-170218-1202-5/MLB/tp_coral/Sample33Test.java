import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(38.48451000647497 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-43.278159528395264 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-49.468899885820235 ) ;
  }
}
