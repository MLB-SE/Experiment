import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(10.379051104305859,28.34894073692277 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.1439091144438969,44.131884537179765 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(13.533364721452159,36.46663527854784 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.3608124911284258,33.17477391193681 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(13.744949925797556,19.788780432039516 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(1.9372558451546666,73.24448524119009 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(34.206881953956156,-5.848664971936429 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(35.463448544065415,86.84377289226668 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(5.800700544434619,63.72276019906204 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(59.83047326412756,-25.240957780168088 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(62.086695680184846,-4.195231255098221 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(-8.757856536634762,45.33508770638642 ) ;
  }
}
