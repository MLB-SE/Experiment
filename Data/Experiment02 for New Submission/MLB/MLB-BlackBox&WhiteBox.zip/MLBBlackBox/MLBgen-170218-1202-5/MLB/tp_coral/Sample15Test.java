import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.10235273518455301,-4.6418812485135845,-35.9215763579203,96.63699990533493 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.5964448555621829,-25.499723742138045,44.13921451717019,74.67197022905955 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(3.4224888687118664,-27.68982019930513,34.2220293842031,92.16153560419639 ) ;
  }
}
