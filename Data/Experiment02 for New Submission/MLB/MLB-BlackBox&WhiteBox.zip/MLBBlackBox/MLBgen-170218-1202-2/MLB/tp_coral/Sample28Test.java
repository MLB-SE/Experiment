import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(34.04508590957934 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.0476468984063985 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.3890560989306495 ) ;
  }
}
