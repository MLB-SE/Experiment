import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-55.29028694609226,23.16173409696188,12.010718554903658 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-69.2995461137919,37.01341363759505,-75.39178107816167 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-71.5681481648992,-82.0881592698383,93.31176279565202 ) ;
  }
}
