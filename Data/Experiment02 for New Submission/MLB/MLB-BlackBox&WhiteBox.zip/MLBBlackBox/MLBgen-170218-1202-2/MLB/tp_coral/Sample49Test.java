import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.01349293245359632,-0.11615908252735263 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(-0.2780158960008663,24.319960541976783 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.9266048258451267,12.265431305012967 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(119.50352485490075,-10.162502780544628 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(16.34751256858158,20.948703372695007 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(18.01900181943565,31.98099818056434 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(3.6624547832624756,63.912837819769805 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(71.15013346115472,91.06171860877379 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(75.72252676722033,-25.72252676722033 ) ;
  }
}
