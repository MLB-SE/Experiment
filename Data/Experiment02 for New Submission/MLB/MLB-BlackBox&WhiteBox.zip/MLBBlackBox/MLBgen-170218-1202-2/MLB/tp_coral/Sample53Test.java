import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-20.1376485800576,-2.7423030338878602,16.922521515743238 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(-26.031775575791556,34.02751774175849,-9.19850754067943 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(-31.2527315741971,17.696490038934826,-28.49140913817683 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(-39.731146879497544,69.26131704072833,64.87842481280782 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(66.94154729813599,95.30339196555082,-95.90084129830221 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(69.38750167658074,-30.79391593094023,79.48967535783308 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(73.21352242477275,-62.8979300437005,73.48296521953958 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(88.88612840323546,13.118982045958319,34.63117152031373 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(91.35134750249449,90.14699408627257,60.288714025076814 ) ;
  }
}
