import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(15.267138045492976,-100.0,-34.552918773052824,6.803101010333046,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-1.5374273174659976,-56.58425483367409,-35.22119835136701,0,-30.768557735224704 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(15.381042504100066,-75.23949107205728,42.79397105320186,31.204165924327782,-95.54344585531925 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-49.38514079550891,-94.03909692375831,-23.70449767405507,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-70.68660455341129,92.47481553937371,74.61324295001901,68.53211546886428,-76.11031166023731 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-75.54923174291987,-50.363322723530366,-18.86394502652891,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(77.00249939368084,-34.99037977456521,-58.42739341723438,-56.89510801374462,71.94308851614448 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(78.97789751095218,-80.98579355354107,59.43669238427566,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(86.59501321957963,40.13289754213628,9.983050015891308,-56.08509688664655,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(99.92346705392107,-62.03877449448105,100.0,0,-23.57730580384608 ) ;
  }
}
