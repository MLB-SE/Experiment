import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(-11.516719973672682,-2.70031153628027,-2.7100810496399674 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(16.388996754207216,20.962041362729096,17.70962222787378 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(35.156210960487016,91.49908595055109,-50.31085169510256 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(35.674297889026434,-82.67276704294986,46.52281785239245 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(42.36291532078894,-97.54459035883085,89.69595091051806 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(4.413448302257805,-44.584452757769924,4.172106314086818 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(77.95175331481968,50.7862907665353,35.45040612208902 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(-83.0787451369741,-11.558756030014308,18.454304376729 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(-93.3756074710588,52.08171335148427,-90.11039766830889 ) ;
  }
}
