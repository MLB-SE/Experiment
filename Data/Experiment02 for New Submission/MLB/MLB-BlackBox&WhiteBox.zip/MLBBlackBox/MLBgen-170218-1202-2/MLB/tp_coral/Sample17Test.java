import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(-0.10108537809717433 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.18028585166905486 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996087 ) ;
  }
}
