import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-0.4515140594354392,0.6553790053033085 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-59.66639265611149,2.6099210737227168 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-7.401508043255019,87.84707375139459 ) ;
  }
}
