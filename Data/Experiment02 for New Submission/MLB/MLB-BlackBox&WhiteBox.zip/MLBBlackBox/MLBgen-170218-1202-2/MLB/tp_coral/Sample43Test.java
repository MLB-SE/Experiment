import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(11.183192294652315,125.06378989917091 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(15.076783749607458,0.09345585767288966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(2.2897013396299655,19.76153089605181 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(24.50592666528648,46.22239520077102 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(36.66662477746442,31.52024793320348 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(71.40730280765695,-12.05918658717367 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(7.713993414230643,87.05984114271484 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.545957657946659,48.47181746583777 ) ;
  }
}
