import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(1.3767375025931297,1.8960938148545246 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-4.029768187256111,16.239196489292222 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(48.17429986007528,36.84069558641531 ) ;
  }
}
