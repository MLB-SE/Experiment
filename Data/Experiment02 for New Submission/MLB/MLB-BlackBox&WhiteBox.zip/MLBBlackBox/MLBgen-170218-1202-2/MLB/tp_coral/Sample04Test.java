import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-664.8734095548818 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-78.96758977297698 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(89.13259431743842 ) ;
  }
}
