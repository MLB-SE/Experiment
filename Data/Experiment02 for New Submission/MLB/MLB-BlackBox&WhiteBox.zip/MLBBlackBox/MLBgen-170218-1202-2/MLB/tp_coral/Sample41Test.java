import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999973,1.999999999999992 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.8933759618528114,58.81284394099811 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-3.849461534743682,18.667815642214865 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-4.398766281211991,23.74791107793956 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(73.44707912576703,83.03180012399079 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(8.165802482376403,58.51452769880822 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(9.947575945348238,89.00669124312265 ) ;
  }
}
