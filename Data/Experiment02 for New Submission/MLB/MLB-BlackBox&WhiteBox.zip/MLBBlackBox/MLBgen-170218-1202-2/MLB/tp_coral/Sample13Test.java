import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.18052924357604638,48.548425943365544,0.15499744947544514,-96.2374256577115 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.24575707754489606,-30.901222666786282,21.232351039097793,99.36474864525562 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(-0.9408963939341807,83.9549844665962,72.004205115988,100.0 ) ;
  }
}
