import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,1.333962224179757 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,22.073686826352798 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(8.754586736404875,14.918447620927694,-55.11647158889501,-90.54695805153243,-61.52801777743109 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-92.19665777108521,-29.5171810701452,3.30178953975539,14.35791846755103,85.38544120979972 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(96.40754764379909,86.68611496333384,-56.68365256123411,-96.83154260709247,80.6066594021039 ) ;
  }
}
