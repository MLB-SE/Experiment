import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.09458713805976515,48.44698080769541,-67.23271768778,75.05995046152219 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(59.10852477725717,98.7972687368025,70.22624315542788,5.03612568056198 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-80.5627503644051,-0.010710868347544533,-75.0707879365006,-78.27375426228151 ) ;
  }
}
