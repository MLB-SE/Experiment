import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(100.0,100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-10.10058558105358,-75.825514332762,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-10.204303196183059,106.98846767683992,-128.35910104577118,-145.2474958990243,93.28749742312914,-14.75114754666781,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-10.657500437186783,-68.12998351749597,-9.026994319369663,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-11.094583512531003,-174.21824897634386,8.289109070755217,0.20037172579428653,22.435243518887276,-27.728599899007946,-19.706302158400376 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(13.944618449814044,-22.613010622559045,81.22038128892297,-94.88332299352642,10.279544220988086,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-18.02099933483288,11.922512569973549,3.0855236629935945,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(26.352306040547262,-86.96226982550564,-56.56173776976645,15.908158264575036,-57.152160641255854,-8.250796154984101,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(39.56126019254785,95.14342503306068,52.5114296856596,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-43.93021909329969,-65.62618609640333,22.617711734104756,-96.76280910230739,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-4.462086332823701,25.7884481533731,-100.0,100.0,-75.92918860102841,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-48.238593266052064,1.0281339217593912,-6.264672096767427,100.0,-27.60472609413042,-0.9097553205245674,-22.543483727861613 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(57.62496177906499,5.277117112812007,98.61801625723683,17.37874884483297,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(62.14458367728338,-41.5187622953191,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-92.17617948304881,-63.47060081038271,-71.05677792268517,-58.19144902996904,-15.8065190398613,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-93.3885457538374,38.013695455821676,18.784225226333078,-44.27519407110289,-82.54712517414069,-36.55067685514224,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(95.63031966148444,-187.53945702095217,101.31991467446572,-81.38526286470258,192.04700306821644,-21.461333185378408,24.602546233422203 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(96.07062812778577,-55.64005761031892,-13.007397030459032,90.86598420228353,0,0,0 ) ;
  }
}
