import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(14.736111996815197,-70.08858201056374,-92.09579299155548 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(25.55072505874614,-52.85698078986407,26.31273291716315 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(4.232526158327232,-21.673207050471333,-32.526177396113496 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(58.41942289153371,93.61330292732956,-91.17439536497301 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(60.88314244777084,-88.64063855221515,97.79471068774487 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(-95.83415498502393,72.90847719584775,34.55587801160519 ) ;
  }
}
