import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-5.524498742931755,36.46257187223267 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,23.28165840693191,-87.59584873840814 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.9721522630525295E-31,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(21.07818095621717,1.0,24.194499565610577 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(21.912436255374317,73.34089415558816,25.633478350520207 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-24.577597313641093,-76.61702144182647,3.921484017080985 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(31.896479720143304,-2.21414523069798,60.83756792955592 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-347.44429994165563,-260.45092485037173,30.390219828886984 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(36.25887190227701,21.63660299663465,85.01956479983662 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(48.14099956224899,10.827607978380854,14.384924333282783 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(55.9081403150507,53.42503304750653,12.152737611947344 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-67.81685295546532,-7.429059853587418,99.91581259820782 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(79.01466239993044,11.004765552895421,66.5528208152428 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(80.61774596829935,10.46989643788217,65.91712185266073 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(9.471409031123784,11.471409031123784,89.59542509817572 ) ;
  }
}
