import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.6057727068294838,-72.00568564778385,-46.56254238446864,-66.94453168490548 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-36.305151786703796,85.08343385488075,9.001134957699037,-95.14294649062765 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(44.425451082703916,36.42684064668032,22.05577409216839,22.400876050320775 ) ;
  }
}
