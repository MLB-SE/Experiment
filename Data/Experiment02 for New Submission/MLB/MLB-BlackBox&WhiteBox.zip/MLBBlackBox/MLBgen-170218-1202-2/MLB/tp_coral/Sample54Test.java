import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(16.58436764704807,-67.78378758479668,78.83426353574507 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(46.14088842619154,43.11805086519246,71.82433630934653 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(47.67842038080852,-13.759941003947148,29.734142343817666 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(-7.131817432942327,-45.66693891770215,47.17903599196194 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(73.15483292606311,55.315417406654376,76.6164106996901 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(95.32804156012145,-13.790406532331573,41.05547033074387 ) ;
  }
}
