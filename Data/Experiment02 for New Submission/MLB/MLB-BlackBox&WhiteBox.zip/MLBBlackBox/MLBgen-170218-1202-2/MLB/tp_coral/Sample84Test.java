import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999998579,100.0,47.647327560268934 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999982,1.0,42.527919777135885 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000002,1.0,-91.06228885372272 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000053,-100.0,-13.81320730119097 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000142,1.0,-17.681164329358463 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,-14.555134970935683 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,-20.071678389556027 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,61.95065651946652 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,35.45752725103578,-42.397055515184 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,87.00491398768722,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-9.15096624724486,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(17.24089561171722,14.859132418423783,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(3.5632139140065835,12.696493396970116,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(-4.184495686291001,17.510004148587996,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(7.250346764222266,52.567528201468285,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(8.712603535150848,88.33644299041777,0,0 ) ;
  }
}
