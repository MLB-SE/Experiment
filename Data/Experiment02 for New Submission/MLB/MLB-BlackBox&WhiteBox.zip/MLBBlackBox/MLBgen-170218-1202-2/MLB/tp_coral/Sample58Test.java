import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-3.3286910996653205,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,55.25240418616937,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-0.568746686510794,11.951187936018545,-10.84525060409118,5.4924091710701894,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0.9553657258698856,-6.987701585610021,5.253303680749184,42.51874060074487,-116.29713819172974 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(11.025411454624304,82.28924695498984,68.34061031273691,-72.98466274002047,23.02020972266139 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-13.500055506861798,-24.62513098554571,37.45194516386047,-21.42665347408286,-1.8726230369002026 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(16.6313066534792,41.891398689256675,16.069249172756855,-42.336407367215735,56.97774316914047 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(17.825307133321814,-55.223972324867376,-20.149548133689606,-44.50811602342808,40.19301122897784 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(21.342786000220684,55.193380391003444,99.55170137036922,-25.58238487602091,-35.37847967441594 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(25.247956410628532,10.580728467966011,22.92828759215739,22.791941532150915,19.21579835680724 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(-4.115121249058447,12.508380103913224,-49.43185701340094,52.68648189938199,-91.53558489119114 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(56.21562396535072,15.645291567774802,-71.51343803465019,45.247125337663164,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(70.58691717697333,5.140309544656971,37.89074733184322,69.41113584766435,5.98226369400912 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(8.564504878909341,62.81251276817129,-72.73962398250235,68.27755917573622,23.827509670627478 ) ;
  }
}
