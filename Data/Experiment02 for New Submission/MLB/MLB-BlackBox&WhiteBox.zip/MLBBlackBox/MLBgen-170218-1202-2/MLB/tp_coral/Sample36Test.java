import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-100.0,-100.0,0.9217619980030847 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(45.11733021624559,-12.640434347907359,8.956291333411343 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-60.49414164254616,-10.922393376465237,88.05584595380958 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-62.83183173298043,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(82.66831350771895,0,0 ) ;
  }
}
