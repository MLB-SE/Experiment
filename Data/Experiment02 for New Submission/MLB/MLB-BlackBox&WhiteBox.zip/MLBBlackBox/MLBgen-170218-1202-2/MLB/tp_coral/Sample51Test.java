import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.02137755431703657,-0.14621065049112042 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(10.25364150042094,39.746358499579024 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(11.764706219783733,35.29215474401559 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.216285290024492,35.82387156012966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.308927454463119,26.450882779169927 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(-2.8828551934443283,68.48148483955839 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(37.937587290404906,77.01673100589679 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(66.22588199176212,-16.225881991762122 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(67.29481606748865,73.1659757272682 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(69.73528101337399,90.23991297804298 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(73.32264074557622,-3.2173268818306298 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(-92.7453780896167,-46.5753264447772 ) ;
  }
}
