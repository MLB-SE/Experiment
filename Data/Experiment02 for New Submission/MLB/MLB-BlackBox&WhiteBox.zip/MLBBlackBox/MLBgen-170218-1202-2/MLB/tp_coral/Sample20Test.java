import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-0.31261855568665453,-33.95852685898598 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(43.3232391144307,68.5551972988105 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-59.31236257713499,16.472709445620268 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-62.01269774598437,-46.01724646100944 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(64.47832313024014,60.17586756729381 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(78.89968282930573,67.84022921251605 ) ;
  }
}
