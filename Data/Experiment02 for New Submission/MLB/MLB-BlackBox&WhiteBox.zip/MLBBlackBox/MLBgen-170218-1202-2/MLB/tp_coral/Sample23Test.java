import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-24.408076974343402,-33.625358410740716,0,11.314892063665809 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(43.34811916705384,-78.20746232737426,-86.14423440606326,3.855256814834443 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-53.492104787038805,-7.405611192236577,-68.7150458584763,-17.042533337078353 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(60.220148203022404,-47.049525592874296,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-62.15827735032165,49.20025581818041,0,-95.59861407867291 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(76.38738687997045,-99.68556513496338,2.624235739953562,12.65279093740574 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(88.5365881921921,-89.82138757532742,0,0 ) ;
  }
}
