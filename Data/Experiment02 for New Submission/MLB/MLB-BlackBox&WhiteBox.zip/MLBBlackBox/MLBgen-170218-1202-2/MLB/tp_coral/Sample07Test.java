import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-33.15172401766485,0,-72.33960567414073 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,63.87905062170629,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,88.74047580337364,0,31.813383945291815 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-90.6494521248863,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-14.005025934879725,-73.44664916951683,18.464065805709943,64.92419465932738 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(51.961058432371345,-15.603895027666127,89.98820702207573,48.081662417058254 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(99.702803966668,30.768188722517976,-17.79885593451027,6.39147601705794 ) ;
  }
}
