import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-0.20083902858864633,-84.95798585386696,0.5021266693491171 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(12.348990639811007,-76.75021709006123,87.98173193418495 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-97.39392509148944,-44.27839487085941,50.77220306096223 ) ;
  }
}
