import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(30.054370768289,95.92381249690813,62.728579379958326 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-52.35578676739252,-80.18754114602655,-8.950993931030027 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(70.29866396819719,-26.530104021568633,-49.10403453050045 ) ;
  }
}
