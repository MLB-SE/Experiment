import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(17.514042893387938,-32.404789477333765,20.256332566144835 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(27.35757162008416,-39.530049627069275,84.5042278493371 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(29.02528098316547,-43.004085085369056,1.0906119987827338 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-39.8157656549109,-76.6102698752566,-43.84980237456404 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(5.469988970459269,48.11729159671531,4.22192481059594 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-74.59894254873491,-38.6691109285374,37.195055414634396 ) ;
  }
}
