import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(44.061217551600464 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(-79.67148325677789 ) ;
  }
}
