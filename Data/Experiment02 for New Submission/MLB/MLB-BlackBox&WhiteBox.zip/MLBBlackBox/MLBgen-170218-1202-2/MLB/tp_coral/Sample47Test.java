import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-394.6581152365698,-208.11052771958,-592.6202447629382 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(61.973601621536204,-52.268198327636185,54.836232855178054 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(84.1342918930219,-34.11788935971762,-78.65460846495188 ) ;
  }
}
