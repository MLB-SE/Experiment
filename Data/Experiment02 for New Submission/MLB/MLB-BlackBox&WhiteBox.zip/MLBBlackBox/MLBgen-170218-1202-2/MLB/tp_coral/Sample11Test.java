import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.3513709639547642,-99.02963799199722,83.3564159493045,37.563769058336135 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.9308841641075816,-39.46613882852173,84.68624346100151,5.470039113102488 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-59.62551131525213,1.9141545892938723,-46.75707177094364,39.176664190813085 ) ;
  }
}
