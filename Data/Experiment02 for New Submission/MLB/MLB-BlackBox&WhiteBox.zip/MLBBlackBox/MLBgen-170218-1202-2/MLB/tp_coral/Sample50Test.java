import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.8282788459494554,14.72863542547686 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(14.46917049775675,27.469170497756735 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(17.627700181676055,-4.1985354805784425 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(18.499995991885363,31.499995991885363 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(19.252368500002262,30.747631499997738 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(22.069806167242632,94.92606900872102 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(23.34415712151616,26.655842878483696 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(3.762379244883803,46.23762075511618 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(38.988616545098296,62.94409254915843 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(52.300435502741294,-5.8021403619421505 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(69.13182508236667,70.09984118954839 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(84.6605185610691,27.33406732287071 ) ;
  }
}
