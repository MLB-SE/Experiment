import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(40.840701850450785,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(45.643403546412856,69.44447879627782 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(59.635132639779755,-16.210367799479926 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-67.5442420092231,-82.97134338254538 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(95.09780949990997,0 ) ;
  }
}
