import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(20.760181611270447,-31.251872123956304,-60.81966979242647 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-7.499924911605078,71.52036571958726,-89.79333604101593 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(94.92984889712878,41.69094567842282,39.000598974616 ) ;
  }
}
