import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(11.331788385297486 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999943 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(91.82096274007773 ) ;
  }
}
