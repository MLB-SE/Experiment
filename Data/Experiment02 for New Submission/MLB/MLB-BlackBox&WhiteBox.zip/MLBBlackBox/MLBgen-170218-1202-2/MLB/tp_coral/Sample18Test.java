import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-0.35240258936248914 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(6.86711693639397 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(94.48678345819766 ) ;
  }
}
