import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,1.0441359245885025,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,13.855210010998448,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0.9192191269164169,92.00945839051869,-20.03250275655111,-78.03316194673333,43.752431629757695 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(100.0,100.0,100.0,68.3163472339234,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,1.5777218104420236E-30,99.09853784787616,5.244248288587091,91.38936642096688 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(15.063049508401775,94.64402472979879,33.89936716644016,-13.764272899121252,49.42920378520688 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(1.524648783425576,68.29701589736104,62.897074995181725,-1.4539119648845542,28.35668007454339 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(17.246967749031974,15.270337262914635,-45.34447125544692,100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(-19.59368847055632,-3.884614587720449,72.52068399616837,-69.76892159924077,50.42302762702187 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(27.906139871714146,25.25685333803294,63.9618502790826,33.68966742736049,-33.07518288918449 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(-28.489862094938193,75.99916900823843,-47.829490861509676,-42.24181693765608,53.2378414762139 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(55.564225081383455,22.23099958142211,-42.761984396894604,56.85868077279329,35.143958970846256 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(-7.85905528394687,18.825552671322708,-10.560672548848187,-32.53064924234868,59.24141065486012 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(-78.73996266846979,42.59133297704284,-46.07198543077038,53.87083346715994,83.930864362112 ) ;
  }
}
