import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-13.533821140027328,15.4678232644832 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(21.505249403255704,52.55835938129347 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(92.47726284229587,16.638551189822607 ) ;
  }
}
