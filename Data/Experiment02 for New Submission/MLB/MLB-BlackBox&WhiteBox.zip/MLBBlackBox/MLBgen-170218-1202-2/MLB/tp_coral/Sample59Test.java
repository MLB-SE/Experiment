import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,1.8884527001392684,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,40.908006041413216,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(-10.143727390031671,-6.358632988645368,16.85921427184357,71.2932020456029,50.93770349045994 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(143.2282602694273,0.7902256888929315,-69.42197787775666,-40.32921084726557,75.0383199999734 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(-18.72627860828932,-69.41070145592545,88.20803190113648,-93.03688176532141,-96.78112401156929 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(19.091700090097447,48.81561388926144,68.77521026997536,18.57717045507499,164.06105637995876 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(34.17093869106046,36.451349869391095,8.584047200134265,71.96571252830978,71.43979595044115 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(-44.10982898380246,-56.67510324592943,100.0,-46.76438682804684,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(65.10254133538353,10.164256595146611,57.34792404881321,-29.856794613747553,-5.719461405521997 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(7.168328943574494,84.46291222638396,78.16609225550872,78.89390875618122,-96.67694945529747 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(-73.01413114031014,29.717090400049045,89.21557686840762,72.13309852282427,59.353656204193925 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(75.87668711941231,8.141868681619457,-13.781716621864135,-79.9671522792803,-0.01148723603503754 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(92.26171250826837,13.705323239991095,98.82547523906061,-70.54921247428487,51.331290172968295 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(9.717328592269993,86.84937467048721,29.20273352503534,11.316758847008046,85.17214482248349 ) ;
  }
}
