import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-13.37976731048147,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,3.2460028474462916,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(-13.931327679390918,-85.56189526839715,84.83648601341898,67.83768715939081,-64.93227905635143 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(45.73996778188004,54.835015397754916,71.4661646116445,-56.48571455748406,51.82527183212008 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(47.60692438413899,84.83772775806239,10.385638993158608,-93.51105770084887,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(57.15303048495875,3.1648343125831246,-86.14482653408145,24.05304994503169,91.19295604724417 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(5.794345280720473,14.859845033216022,85.8783887991828,57.92267312822466,-0.6377723576735264 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(81.85693393577566,-84.11518183085967,-68.69062554735774,-36.04640620128159,-13.060971640889036 ) ;
  }
}
