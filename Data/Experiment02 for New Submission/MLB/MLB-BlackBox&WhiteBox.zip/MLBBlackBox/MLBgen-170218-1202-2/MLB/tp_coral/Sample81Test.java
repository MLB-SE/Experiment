import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(62.23386997289458,-38.236097815589076 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-62.755873280412956,-4.116107207179252 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-71.78249778935599,-1.0235762590369433 ) ;
  }
}
