import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(35.053267027777736,0.9572079829588684 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(58.31300852896885,40.01333223342695 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-61.62703594554804,19.06546028217511 ) ;
  }
}
