import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(26.438279572828407,20.626392955480128,-50.66646475313077 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-43.941843002105664,-55.038409317840944,37.73696899456303 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(82.53290656064013,-54.43741515476952,-54.23450567188861 ) ;
  }
}
