import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(25.918139392115794 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-74.2875736220343 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-81.14308507408376 ) ;
  }
}
