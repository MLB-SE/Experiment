import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(70.1555986621535,-87.76921909238051 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-80.7950746828124,76.82762099477603 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(99.54567692053311,-10.010286293043048 ) ;
  }
}
