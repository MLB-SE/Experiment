import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-3.4369305372166536 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-73.04429519016401 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.9165826217638228,-21.32934712641153,-20.4030571054842,0.001961802572091906 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.9807328197743459,99.95869108139856,98.97794923426441,-9.027359795481777E-6 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(11.003481552065224,-1.531911879546783,-51.38841528371847,-6.5212900608184015 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(-12.828934912669055,81.21747237409781,-65.76211284281831,-79.0524100647527 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(13.330584820685715,1.5041078831834938,-31.82868034214745,80.46519750471253 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(1.9474756371301114,-1.840596399137772,-0.16109774386186645,8.515260715501258 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(1.9981996960413912,72.51595937445771,56.80941805198097,17.704741018518135 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(2.017453715899208,52.66355086673832,72.74977011414921,-6.605775934468355 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(22.565376846961584,71.78459760964614,92.26383532904103,-24.19542137149206 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(25.18460435376572,92.37711098937368,-2.7066006965008427,57.27883129272752 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(-26.709750987422538,-88.0019794659326,-5.577486284627241,41.93962300715506 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(31.675392624116284,7.650134948308619,-32.01632434383792,69.10257314820652 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(53.9945993359494,-26.655427742544518,-61.58247371351575,91.53595244914118 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(54.69803062940575,0.6462167910216969,-95.44236368714645,-63.97622129555458 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(5.679352305308555,16.851868542733797,40.16034801796198,-12.226351614514101 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(57.83381778087757,0.0,-38.95227654139322,-15.856617839415506 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(62.12808977678522,-100.0,100.0,-0.720249074640563 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(64.07118513776655,-52.858916878629735,54.29580463626195,47.72374151337985 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(75.3577134264762,-48.08537277782172,81.49537662197406,-1.567165004099401 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-80.52954943448727,79.55680316018378,-81.46005203186772,83.74234287373156 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(8.457457482134487,8.755728098077583,3.8058384444421165,65.96038242352378 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(90.58492482959929,-46.47438633119656,96.80812323018867,-7.32482838281318 ) ;
  }
}
