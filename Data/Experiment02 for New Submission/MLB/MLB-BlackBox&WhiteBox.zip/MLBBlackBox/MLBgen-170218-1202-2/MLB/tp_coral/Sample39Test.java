import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(11.42534978413805,-1.2532331560223104E-17 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(41.68525592984352,-56.11275190460114 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(81.43915388866219,37.131607311174406 ) ;
  }
}
