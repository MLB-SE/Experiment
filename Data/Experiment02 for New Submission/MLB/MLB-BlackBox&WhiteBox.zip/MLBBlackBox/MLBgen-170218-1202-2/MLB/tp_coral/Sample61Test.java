import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,1.7311197471025537 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,72.67031664974371 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(17.622050713392355,45.974832990849166,49.16844696624753,73.30865540670726 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(27.41491503797758,99.49394181337107,96.49081428738208,-99.00784939471336 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(3.07255522409662,13.820597312384594,24.22571824503736,78.7263903543408 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(31.596094129365866,64.1156708035004,31.443637621978922,95.68625201704211 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(33.18574600304996,88.41842751917031,-5.111314057460575,73.52959739168503 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(3.4891726631742843,-1.9672890672945316,17.48087190290698,-0.48420402989744077 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(3.6427642436343817,53.5402942446097,61.58410740678369,-2.0174679375867868 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(40.793968013800566,0.3699412256038386,58.775101680540615,66.01850089648863 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(-46.022613038555484,46.37694202999229,-27.770437950357913,-78.37472693879327 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(46.34502630034178,23.432464041554944,68.17424012430727,1.6032502175894514 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(47.91310759292699,79.84112871485104,-55.894213579075355,70.7326766772471 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(-52.01867031875798,60.01029183046606,-57.26335551527284,37.578230495285254 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(64.15934633381723,-61.44341475376214,20.207342054123487,-1.044202158863392 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(64.32019263223091,0.0,-29.1718492860862,56.31827023276952 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(84.43141217960459,8.881784197001252E-16,-21.477111598178737,77.23952249052255 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(87.11840553351789,2.8004502683667774,-62.37207065419905,-0.9097498013899816 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(95.06827534155485,-42.823510685638496,81.01011061257631,-8.293792578916381 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(97.00770924507188,-20.90743923041758,36.044154941734774,59.20830087282286 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-99.14953000300592,28.89124705059777,-52.715344904589735,71.31129550157056 ) ;
  }
}
