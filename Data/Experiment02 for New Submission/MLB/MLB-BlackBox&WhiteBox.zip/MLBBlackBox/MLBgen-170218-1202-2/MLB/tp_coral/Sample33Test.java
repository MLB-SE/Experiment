import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-11.698140328325252 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-5.597305450552994 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(69.9004365423729 ) ;
  }
}
