import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-22.535347476489463,-55.86199804162489 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(72.57626117254583,-39.455328470048954 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-76.39836374588735,6.815218658836585 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-78.41347621217379,-3.493222800912122 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(91.05643210188268,-96.86324371994566 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(96.64130099586538,87.20519742974051 ) ;
  }
}
