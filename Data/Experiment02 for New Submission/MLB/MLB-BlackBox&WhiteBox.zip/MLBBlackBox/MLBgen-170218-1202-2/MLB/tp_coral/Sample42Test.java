import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-52.17716346612322 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(12.955763229229461,89.52413621622065 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(35.70969101709832,82.5548250955699 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(59.71798024410049,10.168864017085212 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(59.9653878186387,75.527151428584 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(-60.30369511188107,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(-6.03762631251945,-21.005783081222845 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(6.208001758482412,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(66.39510021452517,0.8414899413609263 ) ;
  }
}
