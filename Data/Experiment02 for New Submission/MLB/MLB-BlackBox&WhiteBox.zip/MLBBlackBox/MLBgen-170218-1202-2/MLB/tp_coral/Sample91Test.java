import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-46.141033818308564,-58.683262085063646 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-4.96518750711769,0.8571287989993124 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-7.779414328601314,1.6453636321680651 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(83.20088033243117,-14.085841953455718 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(84.82300164692441,-3.1415926535897865 ) ;
  }
}
