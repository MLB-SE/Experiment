import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(15.008024428010216,38.3061459380902 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(30.975886295374124,-15.274488302517526 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(58.297529354450944,74.2426465049578 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(67.6086071821274,22.115550201913464 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(89.68244891104987,0.28501480393286016 ) ;
  }
}
