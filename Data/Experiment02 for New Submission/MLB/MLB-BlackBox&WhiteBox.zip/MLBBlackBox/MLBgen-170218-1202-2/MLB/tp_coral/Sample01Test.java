import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(2.324050215164645,64.12870278888158 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(29.275382111247666,-69.02620181873462 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(57.66137674193672,-5.234732747666655 ) ;
  }
}
