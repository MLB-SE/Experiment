import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(67.10961226364952,-88.07425395619288 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(82.07366271471204,52.69889279180141 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-91.39719510956749,-97.579084546257 ) ;
  }
}
