import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-43.99328173881156,-93.72290978723147,-5.604552118261381 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(51.02192856607627,-9.959887256256621,-78.16745834996128 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(89.22200651598291,-10.177842899239579,79.04416361674333 ) ;
  }
}
