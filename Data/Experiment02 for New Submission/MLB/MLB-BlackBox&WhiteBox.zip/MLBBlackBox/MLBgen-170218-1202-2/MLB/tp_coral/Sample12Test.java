import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(24.798380787118006,-25.180510067284928,-32.209824370010764,-49.68874973099177 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-68.12032055078383,-1.474461154309779,2.493651562311939,-80.49064630591998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-71.73277490321873,-10.341709170238715,-25.266827037010557,58.76715874897758 ) ;
  }
}
