import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-1.9187343202283583E-5,100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(49.673110042286794,61.5283762908341,56.58145987356613,67.97849905314052,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-8.885969351957591E-9,100.0,-100.0,-100.0,0 ) ;
  }
}
