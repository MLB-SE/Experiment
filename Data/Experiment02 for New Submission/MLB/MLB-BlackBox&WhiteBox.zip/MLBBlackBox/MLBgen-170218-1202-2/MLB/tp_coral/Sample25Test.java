import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-13.15808860574414,4.840060333114394,58.30649380587616,-51.697223698479846,41.61582229954769 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(37.08495296895049,57.93511293985824,43.329078851431774,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-4.884607459289534,100.0,-99.99999906286385,-100.0,-87.45572775636596 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(5.290525887747606,97.18442287904818,-98.29351416486772,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-59.75240564575639,41.86895747217778,47.227641578966626,0,-86.4649207929146 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-60.084512755048806,50.374359370224994,-23.419074151980766,-34.58649593145499,-15.024056821588587 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-60.53140289041914,93.35073694829383,-13.581198893168875,0,180.86411885560742 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(66.67581374795955,-56.27971341390807,87.12659841515713,-26.738369613264297,38.695881867449856 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-7.0108494578108305,-18.955644330923423,78.66470915949827,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-80.43994312568734,-8.08678260393503,92.79992770719929,-21.36617780253883,85.92603568638492 ) ;
  }
}
