import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,1.7804796321801746,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,42.63217844246219,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0.6859106346735908,-15.103765433008249,1.9299537418807375,-13.38770323485295,65.30033500816538 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(13.58790255773124,84.20305071288229,66.07789821945161,5.163271195743405,17.922186858990116 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(18.10652140380992,-16.617946632739915,81.77262696528308,-42.923211206951486,-11.584822396322167 ) ;
  }
}
