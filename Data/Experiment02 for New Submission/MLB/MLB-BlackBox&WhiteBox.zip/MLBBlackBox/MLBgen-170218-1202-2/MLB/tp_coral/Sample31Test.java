import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-17.719545448722272 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(24.498606903841562 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(4.81223718982886 ) ;
  }
}
