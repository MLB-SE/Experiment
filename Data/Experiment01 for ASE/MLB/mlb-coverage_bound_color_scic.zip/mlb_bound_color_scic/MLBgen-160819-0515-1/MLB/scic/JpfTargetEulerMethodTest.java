import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.248781741660103 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-3.0689748421960985 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-45.9375521161703 ) ;
  }
}
