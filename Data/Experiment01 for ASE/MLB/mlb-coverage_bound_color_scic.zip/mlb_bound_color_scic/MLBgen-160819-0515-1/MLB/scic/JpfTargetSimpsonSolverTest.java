import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-38.36155140637692,91.72728597577344 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-6.400931453771079,74.7077922566978 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-83.00462904468552,-44.62715475294063 ) ;
  }
}
