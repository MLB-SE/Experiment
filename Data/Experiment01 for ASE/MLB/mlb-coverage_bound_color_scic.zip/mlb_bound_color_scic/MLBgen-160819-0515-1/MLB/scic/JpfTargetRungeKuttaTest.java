import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(23.74763233637509 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2719.3227491859493 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2723.535262186721 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2728.44920435565 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2728.7023691583836 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2730.061321604871 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2730.2156640533553 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2734.6494987670094 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(2741.451365905856 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(63.29140638441652 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(72.33706220265421 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-77.2512782725363 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(81.62439504982174 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(91.12878051138412 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(93.10810766320029 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(9.367966522341419 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(95.38177761162271 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(95.49975537859211 ) ;
  }
}
