import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.09715011565280918,-98.75579191240882 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.44131495345791905,-12.82063936814113 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.543724277664893,-4.741628697214267 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(0.7471121479965603,-93.71894856810567 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-1.1565746019741425,4.042832797667124 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-13.920809688014828,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(1.5626496355646877,0.005123212843545444 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-15.802819478482434,-97.88477207135536 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-16.234783266873706,0.9799178025126736 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-17.72703307798737,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(20.579203539482677,-11.919173986955727 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-21.995063314249833,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-28.693892804176755,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(2.885508697487765,-25.331505767118955 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(35.91958044973833,-14.731377087178615 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(52.080700262892634,0 ) ;
  }
}
