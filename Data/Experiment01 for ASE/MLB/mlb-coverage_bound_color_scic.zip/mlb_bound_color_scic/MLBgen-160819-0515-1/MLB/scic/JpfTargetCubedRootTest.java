import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.99854013611913 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(54.91673270631151 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(5.523150085010343 ) ;
  }
}
