import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-21.750000000028507,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-3.1479893147423184,-46.05705470532007 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-34.68440823475836,0.0747790534697188 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-35.75,-67.08648029922155 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-39.90663288505678,-65.4819271910788 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(59.88412181920748,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-69.25,29.101034851685792 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-78.75,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-82.26477820535194,0.014604375539462922 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(86.68038480509523,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-9.074780852330406,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(91.47488038589157,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-94.55090317202897,37.92042110707422 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-99.82635250767706,52.47789117159988 ) ;
  }
}
