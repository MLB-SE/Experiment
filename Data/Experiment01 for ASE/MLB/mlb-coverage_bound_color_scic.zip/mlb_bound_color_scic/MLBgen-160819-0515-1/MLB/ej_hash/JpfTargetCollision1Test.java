import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-611,-1621,-650,-589,-898,621 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-784,-717,875,419,-782,281 ) ;
  }
}
