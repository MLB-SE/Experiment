import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-25970,743,-652 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-64,-221,-575 ) ;
  }
}
