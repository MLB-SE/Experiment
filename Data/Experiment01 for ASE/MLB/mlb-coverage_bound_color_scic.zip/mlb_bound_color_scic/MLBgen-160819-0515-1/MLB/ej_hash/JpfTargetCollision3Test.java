import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(-26782,-144 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(-355,521 ) ;
  }
}
