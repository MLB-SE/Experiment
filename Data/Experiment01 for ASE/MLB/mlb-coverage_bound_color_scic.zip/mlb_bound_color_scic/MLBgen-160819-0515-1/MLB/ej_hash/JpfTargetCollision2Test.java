import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(79,1278,98,-272 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-913,-563,209,-849 ) ;
  }
}
