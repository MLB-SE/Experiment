import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(2,0 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(2,553 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(-331,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(340,0 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(3,872 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(4,2 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(4,-983 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(552,0 ) ;
  }
}
