import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.021915693f,-75.36397f,-13.210383f,-24.548368f,100.0f,0f,5.5460377f,46.732517f,81.38403f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.29111457f,54.85518f,0f,-20.572258f,-42.256325f,-13.825968f,-40.323822f,10.859756f,0f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-100.0f,-100.0f,0f,-79.60452f,-81.41109f,0f,-44.90113f,-100.0f,-97.708244f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(100.0f,-15.649961f,0f,4.584363f,-67.23987f,100.0f,-14.422683f,-62.275093f,100.0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-100.0f,-45.272427f,94.41265f,-47.2718f,-8.498978f,-3.521582f,-80.58822f,62.069897f,-100.0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(1.0296738f,-78.09202f,-87.82063f,-17.78929f,-46.785706f,-75.71071f,-25.401125f,-83.81521f,0f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(10.45601f,-53.5515f,-12.399406f,-4.6244626f,-20.969103f,1.6141111f,-7.984757f,-27.314566f,-5.4214582f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-10.523639f,-28.568056f,0f,66.09185f,-100.0f,78.5876f,13.833478f,-10.757939f,43.13476f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(10.788136f,32.850155f,87.64241f,-89.69762f,-67.02992f,30.31546f,-28.272652f,-23.392988f,1.7306181f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(10.948006f,-40.483833f,-8.520361f,-15.724143f,-95.346695f,-57.172237f,21.50212f,-11.179303f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(-10.963009f,62.084015f,-56.08083f,1.41895f,16.510637f,-15.174736f,0.12817106f,17.714323f,-21.128752f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(11.089825f,-12.718693f,-6.945491f,-42.92201f,91.64467f,0f,-85.19564f,-17.116219f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(11.312532f,13.583029f,40.364704f,-68.3329f,-97.34512f,-93.61385f,-27.225363f,-40.568554f,-37.703735f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-11.3726225f,-29.23251f,0f,72.86145f,-12.935778f,0f,40.596794f,89.52572f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(12.363343f,-4.558645f,-81.78373f,-45.987984f,-48.814194f,-100.0f,-16.913795f,-21.667194f,-20.940792f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-12.4788475f,-47.97773f,0f,-58.540092f,4.0322294f,0f,90.06729f,-71.49092f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(-1.2565639f,-85.61154f,-51.19127f,-19.497679f,-53.945255f,-39.013905f,-22.788895f,-71.6579f,-88.5045f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-12.578163f,70.010574f,43.107464f,-6.7234087f,2.0465143f,8.367198f,-16.361986f,-63.468307f,12.383385f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(-12.630886f,50.06648f,-92.038994f,2.0638206f,26.716291f,80.11918f,-5.8301225f,-25.38431f,-46.545387f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(12.635739f,-10.576411f,26.012619f,-38.88063f,-37.69711f,0f,-24.116316f,-57.58463f,39.025295f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(13.162318f,-86.65554f,0f,28.885551f,74.46003f,-34.840103f,27.919855f,82.79387f,0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(13.246855f,-53.666046f,38.4111f,-3.2840374f,-19.305807f,4.751607f,-7.0771976f,-25.024752f,-73.716f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(13.330425f,15.198085f,6.5816746f,-61.876385f,-59.11976f,-40.621376f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(13.634761f,-19.017601f,0f,5.905548f,11.653618f,48.12523f,-1.6661865f,-12.570294f,-60.26861f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(13.686496f,47.749107f,-100.0f,-93.00313f,61.84299f,0f,-20.841557f,9.6369f,-81.03575f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(-139.37346f,70.46755f,0f,-36.10375f,25.391844f,4.867244f,-30.43708f,-85.64458f,-94.46008f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(14.095259f,-50.635532f,0f,3.7807992f,-0.32554322f,41.121403f,1.3534806f,1.6331232f,5.5045557f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(14.500727f,-10.658476f,25.24573f,-31.33862f,59.121433f,-92.11449f,-6.020669f,7.2559433f,-24.07699f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(-14.730951f,-36.43418f,-35.248005f,3.765219f,3.850522f,-51.928947f,25.941305f,100.0f,52.646652f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(150.40372f,-28.218924f,0f,-173.73714f,83.08728f,0f,-41.715393f,6.8595943f,-13.950495f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(-15.306572f,44.225147f,0f,-7.235139f,-90.97604f,-63.11754f,77.34206f,33.438858f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(15.676071f,-8.260463f,-100.0f,-29.035141f,-48.717926f,-57.575985f,-83.09872f,-100.0f,-87.07797f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(16.514769f,-23.030914f,24.42351f,-10.910015f,-18.940954f,10.528189f,-41.213875f,-52.351074f,12.034165f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(16.569736f,-190.74011f,12.913549f,-11.1286f,-44.6322f,7.571742f,-16.139624f,15.369162f,62.84822f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(16.931513f,-46.51361f,45.85728f,14.239665f,32.932045f,35.699127f,7.0951023f,14.140744f,-49.076263f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(17.207315f,-30.11219f,100.0f,-1.0585488f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(17.662363f,-18.915148f,0f,18.1851f,99.49988f,0f,-48.689754f,0f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(1.7697961f,-81.34766f,-65.499405f,-11.573162f,-26.705307f,50.64286f,-21.357138f,37.381405f,0f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(18.268873f,-42.033268f,0f,-1.5627656f,69.29627f,0f,-93.81621f,0f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(18.471989f,5.2767434f,-70.70838f,-31.388786f,-26.656635f,20.412067f,-49.638863f,0f,0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(18.534935f,-34.96289f,-97.28732f,-2.8164358f,-26.185507f,-55.318806f,-3.61517f,-11.644245f,-16.740763f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(18.688242f,-42.091095f,69.08687f,16.844059f,27.10244f,-64.64779f,21.585552f,69.498146f,5.0267344f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(18.86099f,-17.74973f,100.0f,-6.8063064f,-30.601377f,-42.71643f,-15.4848385f,-55.133045f,-0.23345771f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(19.293394f,-5.484237f,-74.64741f,-17.342188f,26.262257f,-91.88047f,-3.7371702f,2.393506f,-12.951061f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(19.723295f,61.198368f,47.587196f,-82.30518f,77.48298f,49.71208f,-41.428143f,-83.40738f,0f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(19.747969f,47.32302f,84.06616f,-68.33115f,-14.522043f,54.311073f,-31.931189f,-80.12637f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(20.357037f,99.28994f,93.57921f,30.65645f,70.85702f,58.49112f,31.411749f,94.99055f,69.52825f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(-20.618511f,-157.98604f,0f,85.90478f,185.1784f,114.99332f,38.2857f,67.2383f,45.520832f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(21.109617f,-26.720045f,81.99028f,11.158515f,25.730968f,-64.566444f,-2.2065272f,48.70642f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(-2.1588004f,-86.1612f,58.85788f,-22.474003f,-4.5006833f,0f,56.77733f,0f,0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(21.706638f,-72.340965f,96.33312f,59.16752f,-33.355965f,0f,-95.9875f,0f,0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(21.897116f,-21.886223f,-50.38944f,9.474685f,11.644852f,0f,4.356773f,0f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(21.920456f,35.720844f,-11.770633f,-48.03902f,-16.937576f,0f,3.238314f,60.992275f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(22.031736f,-15.563195f,74.67186f,3.690142f,-9.875044f,-31.907019f,2.6038747f,4.2798977f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(226.8894f,272.41342f,0f,37.10108f,-87.68423f,-160.06624f,8.397439f,-3.5113282f,65.36671f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(22.73703f,-70.38001f,0f,26.27108f,73.68088f,0f,-10.283124f,-32.139282f,0f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(22.924019f,5.428157f,29.392115f,-13.732081f,-49.575466f,-90.080635f,-28.276878f,-99.37543f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(23.129145f,-21.603233f,99.96375f,-3.6193113f,-33.922237f,-99.34911f,-3.6841516f,-11.117295f,-6.8627915f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(23.176859f,-74.68678f,-5.1055717f,67.39421f,99.32238f,-45.669632f,24.220253f,29.486801f,-5.595426f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(23.632769f,8.564851f,-38.111107f,-14.033776f,-51.26194f,-99.99875f,-28.505934f,-99.98996f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.730722f,-10.5673685f,20.329277f,5.4902596f,-3.499477f,1.7654386f,1.729792f,1.4289087f,7.4853196f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(23.80124f,-59.16726f,35.89378f,2.7519186f,-12.765588f,8.216795f,-0.027967576f,-2.8638062f,1.3382516f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(23.86563f,44.81472f,36.47725f,-49.352203f,18.916008f,38.029182f,-3.2013342f,36.546867f,-44.767937f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(24.324568f,45.39234f,39.178314f,-48.094067f,66.076324f,39.905563f,-7.4500027f,18.294056f,14.549905f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(24.61828f,99.90852f,-92.29089f,21.601646f,54.3242f,87.53187f,7.4641023f,8.254764f,-28.769247f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(24.983519f,21.241179f,30.408756f,-21.307106f,-70.42756f,79.60401f,-39.784378f,60.95723f,0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(25.140501f,8.921186f,10.544243f,-8.359183f,-100.0f,-75.142426f,1.4768349f,0f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(25.67806f,20.246841f,45.791183f,-17.5346f,-90.48187f,-4.6654377f,2.8150628f,28.794851f,56.517128f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(25.813677f,30.193493f,-0.2576104f,-25.59754f,-61.324345f,-23.433224f,-63.571217f,-225.67198f,-151.21982f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(26.123564f,7.62224f,33.817192f,-3.1279871f,-35.129112f,0f,-3.5064015f,-10.897619f,-18.393267f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(26.14177f,75.59289f,100.0f,-71.02581f,-44.096073f,-100.0f,-24.847546f,-28.364372f,-44.513866f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(26.144857f,-0.31629443f,-36.180004f,4.895725f,-91.23003f,-53.46254f,-1.6668996f,-11.563323f,99.92658f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(26.254305f,-12.088367f,-100.0f,17.105587f,35.110287f,100.0f,7.057758f,35.423935f,-40.87293f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(26.788443f,51.202602f,96.30252f,-44.048836f,-18.28055f,42.85762f,-81.697685f,0f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(26.865585f,4.737776f,-84.15762f,2.7245655f,-23.75686f,50.1882f,36.258293f,-77.6597f,0f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(27.387016f,14.153548f,-100.0f,-4.6054873f,16.13543f,16.029518f,-61.944393f,-100.0f,0f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(27.427652f,18.738356f,-30.231268f,-9.027746f,-51.160698f,0f,-11.755353f,-37.993664f,-89.05861f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(27.700274f,30.042189f,-74.85645f,-19.241098f,34.223053f,16.532095f,-2.4141457f,9.584516f,6.5291524f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(-27.888424f,-13.197726f,40.925377f,-13.244318f,-17.75103f,-28.455118f,-7.337819f,-16.106958f,-39.338985f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(27.97911f,11.406066f,-63.10141f,0.51037455f,-19.253435f,-58.730743f,-6.684178f,100.0f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(27.992996f,6.2256594f,-142.55629f,5.609725f,28.97487f,142.98683f,-34.527515f,-143.76767f,-63.637585f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(28.041256f,-36.54599f,0f,15.492168f,6.8507085f,-15.155365f,4.188532f,1.2619585f,-5.9914064f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(28.376165f,29.96539f,76.79157f,-16.46073f,-85.30618f,11.863987f,-8.237377f,-16.48878f,27.588444f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(2.858104f,43.403103f,99.99873f,1.2493653f,9.42085f,23.87126f,-7.281492f,-30.840328f,-13.934545f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(28.641333f,28.285099f,53.11881f,-13.719772f,-68.61974f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(28.695505f,-3.2100077f,-12.319349f,17.992027f,33.91436f,22.436798f,7.6424046f,12.577591f,8.753597f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(28.714622f,19.84416f,-52.830177f,-4.9856696f,5.6743035f,7.190681f,-54.331604f,0.648042f,75.918594f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(28.783487f,-76.43898f,-42.783466f,-10.430505f,-42.001656f,-63.33251f,-28.503849f,-17.80463f,24.249546f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(29.026058f,-84.12059f,0f,14.679821f,25.689194f,-98.86942f,4.004032f,1.3363084f,-24.347992f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(29.032661f,-19.864555f,-59.240757f,5.89868f,-0.4502861f,38.014027f,-4.987654f,-25.849297f,-97.95924f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(29.041847f,19.602217f,-70.10937f,-3.4348235f,19.476383f,-32.161552f,-62.257526f,-72.46598f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(29.062206f,1.0264286f,-98.19564f,15.222398f,-26.760853f,-100.0f,58.588257f,-23.292192f,31.537584f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(29.46502f,10.828089f,35.209476f,7.0319858f,-16.299728f,60.99219f,14.962653f,32.284443f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(29.489044f,9.366908f,-20.311674f,8.589265f,-100.0f,0f,84.62106f,-95.15938f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(30.046587f,-1.6866804f,23.597288f,21.87303f,44.82968f,12.98193f,12.615847f,-20.946217f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(30.514467f,34.81982f,-7.901241f,-12.761948f,16.666052f,20.203848f,-98.22831f,24.402494f,72.05059f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(31.161634f,33.04727f,24.322868f,-8.400734f,-23.295416f,-43.150105f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(31.63589f,13.614212f,44.34825f,12.929345f,25.271711f,0f,-20.870533f,-96.411476f,-100.0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(31.839415f,25.484646f,-12.8619995f,1.7650853f,-21.48913f,-100.0f,-2.8746238f,-13.26358f,-28.315895f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(-32.327507f,7.6368713f,0f,10.644128f,-75.52401f,0f,88.983055f,-63.740326f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(32.37961f,30.339725f,34.996616f,-0.8212935f,-46.01732f,-0.29443467f,2.7420435f,11.789467f,90.43314f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(32.616405f,31.243387f,31.560616f,-0.777767f,-39.203472f,-62.781445f,2.012718f,-95.61216f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(33.14981f,26.095573f,-14.381268f,6.5036654f,-14.386246f,-99.5748f,7.251098f,-100.0f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(33.187664f,34.602306f,-88.932655f,-1.8516474f,94.15422f,100.0f,3.3762703f,15.356729f,-36.103573f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(33.222942f,75.04549f,67.026245f,-42.153717f,99.93275f,-5.7762814f,-8.8226385f,6.8631654f,-63.657448f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(33.51799f,60.40041f,68.985275f,-26.328444f,31.981367f,0f,6.8412476f,37.050526f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(-3.3519938f,99.874306f,-32.424885f,16.97326f,54.570213f,51.70727f,16.67482f,49.72602f,86.388214f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(33.539482f,-20.917578f,36.67029f,55.075504f,-21.612972f,-71.15966f,15.136142f,5.469065f,28.353092f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(33.5659f,74.54246f,70.800186f,26.698366f,53.663887f,61.858356f,19.563683f,51.556366f,13.145355f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(33.60243f,31.049168f,36.96009f,3.360552f,-46.36585f,14.250695f,-2.1572208f,-11.989439f,0.565314f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(33.625004f,35.956856f,-99.988396f,-1.4568394f,-43.96007f,-50.753326f,-4.4365396f,-16.289318f,-16.760662f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(33.88915f,24.668499f,-41.975033f,10.8881f,6.704788f,-9.682804f,2.958322f,0.94509727f,-3.4609704f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(34.097836f,32.31742f,38.888832f,4.073914f,-43.71698f,24.069107f,25.9148f,99.58529f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(34.209084f,19.154558f,-96.08641f,17.681768f,38.058784f,46.363323f,-1.540792f,-23.844936f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(34.21776f,35.990253f,39.68691f,0.88078475f,-29.94366f,-52.145687f,-10.219828f,-41.760094f,-26.988146f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(34.284256f,3.7734487f,-99.83925f,33.36357f,-19.35121f,99.20309f,6.0241694f,-9.266893f,-23.740534f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(-34.719955f,65.45836f,0f,41.34021f,-13.167414f,0f,-91.76812f,16.946016f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(34.83048f,28.46458f,0f,19.584332f,36.316715f,0f,10.531519f,22.541742f,43.318737f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(35.121662f,15.21232f,-95.71735f,25.274334f,57.1485f,100.0f,8.827174f,10.034363f,-25.838219f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(35.27538f,43.249702f,-29.505466f,-2.1481829f,-43.28091f,0f,-95.00124f,10.170875f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(35.34733f,30.64115f,-26.608557f,10.748158f,3.9799185f,20.055466f,1.5770946f,-4.43978f,-23.316133f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(35.55309f,-82.50974f,0f,33.89356f,21.686314f,42.51713f,78.33483f,-41.2492f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(35.607235f,44.424313f,26.515755f,-1.9953704f,15.574255f,54.711838f,-59.16297f,-34.843758f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(35.77351f,36.247025f,32.106518f,6.8470144f,-12.451741f,-92.51283f,4.0662904f,-0.3881729f,99.24217f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(-3.5787764f,-98.78081f,0f,31.50104f,99.61623f,-14.3997135f,29.966705f,-52.853138f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(35.923897f,25.986053f,-81.5136f,17.70953f,49.53392f,-54.124836f,-14.619695f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(-36.09663f,46.12725f,0f,10.359611f,55.51119f,0f,-4.7304416f,-29.281376f,-6.186341f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(36.57782f,6.146629f,0f,26.093557f,-11.779889f,0f,8.215885f,6.7699857f,30.643948f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(36.691605f,7.2172685f,-20.853386f,39.549145f,48.401573f,0f,11.406739f,6.0778112f,-35.497066f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(36.847893f,12.961996f,51.884563f,34.429573f,28.554901f,5.512931f,72.3155f,61.3151f,13.410317f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(36.89717f,43.664734f,-64.18024f,3.9239528f,16.096842f,-66.69525f,-37.298203f,83.493935f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(37.747986f,30.461481f,-9.835563f,20.530464f,28.340275f,18.764599f,16.033756f,43.604557f,56.553684f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(37.749607f,45.03345f,4.367673f,5.964979f,18.28546f,13.873152f,-32.17515f,8.270254f,32.839478f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(37.92696f,32.165466f,104.975f,19.547617f,39.229298f,53.413605f,1.0326247f,-15.417118f,-120.61403f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(38.163464f,14.818679f,-0.7463061f,37.83517f,-17.347767f,0f,-13.63903f,-45.067802f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(38.324192f,37.14508f,-53.89575f,16.151693f,14.778427f,-83.67391f,11.504151f,29.864914f,71.96051f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(38.611244f,32.79361f,35.652912f,15.165574f,15.477257f,2.8202238f,6.573797f,11.129616f,22.46741f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(38.932594f,56.26862f,20.568998f,-0.5382388f,65.572876f,24.282387f,-5.5892787f,-21.818876f,-37.16307f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(3.9044743f,-82.058624f,-36.33845f,-7.6570997f,-31.732405f,-33.669113f,-2.8004696f,-3.544779f,10.28898f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(39.2297f,8.149042f,-88.971275f,48.769753f,-27.563978f,0f,92.48038f,0f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(39.322853f,-22.973135f,0f,63.962055f,-46.017433f,0f,4.4931855f,-45.98931f,-13.222635f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(39.593464f,-57.626385f,83.117584f,3.6316917f,-13.6529f,48.669983f,-11.413798f,-49.286884f,92.75783f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(39.908043f,14.50825f,69.450134f,4.9814634f,-11.240048f,-24.499887f,-8.742139f,-39.95002f,59.38959f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(40.404892f,35.9805f,-62.63332f,25.639074f,16.46027f,0f,31.40977f,100.0f,89.604706f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(40.44365f,-44.319157f,0f,0.89731485f,2.890136f,-82.01839f,-39.744526f,-0.12195876f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(4.049308f,-74.81396f,-9.956625f,-8.9888115f,-32.737797f,-35.750767f,-7.2667603f,-20.07823f,15.377765f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(40.614155f,50.12263f,46.16118f,12.333991f,13.715191f,65.87f,-11.743496f,-59.307972f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(41.148487f,62.30667f,50.462868f,2.2872777f,57.615334f,2.1322749f,9.966622f,37.579212f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(41.15882f,21.390684f,10.368111f,43.244595f,35.074707f,31.13204f,96.74484f,44.531513f,27.784515f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(41.20165f,13.64234f,87.703026f,51.164253f,-45.351543f,0f,37.28925f,97.992744f,96.30697f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(-41.593723f,-55.99135f,-61.535343f,-10.8311825f,-3.1431243f,47.541954f,1.4121172f,6.708078f,34.991844f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(-42.004757f,37.573536f,0f,-16.122276f,-9.76547f,0.8631716f,-5.4591217f,-5.714209f,-7.6322455f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(42.03419f,54.705254f,-100.0f,13.431509f,12.860299f,-1.865415f,-1.1684554f,-14.830152f,-100.0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(-42.337242f,-52.496395f,0f,9.916166f,100.0f,5.6176143f,11.458779f,35.91895f,32.217022f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(42.506428f,28.067003f,-100.0f,41.95877f,69.76235f,8.956245f,16.381912f,23.56888f,8.131272f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(42.51699f,32.32326f,-23.536833f,37.744698f,10.312892f,-14.510816f,-60.232815f,0f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(42.55184f,44.876343f,27.74814f,25.331018f,9.205397f,-15.100488f,49.566837f,32.173073f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(42.943363f,50.53768f,11.222454f,21.235777f,16.51171f,22.544819f,25.488033f,-28.271444f,0.6106606f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(43.115524f,57.218853f,9.268459f,15.243244f,18.686117f,0.98016125f,-0.8286665f,1.302215f,-39.9881f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(43.218098f,29.907724f,-12.241288f,42.96466f,-11.345907f,10.2779045f,29.236197f,73.98013f,-34.1913f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(43.489098f,64.302986f,43.374573f,9.653408f,-6.484707f,-97.582085f,1.6092397f,-3.2164493f,-7.99033f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(43.558475f,51.587368f,-65.83841f,22.646536f,38.936848f,7.9815245f,8.090818f,9.716737f,-8.160722f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(44.249184f,38.278477f,-82.4218f,38.718258f,-17.854462f,0f,25.072084f,61.57008f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(44.41194f,11.828997f,-86.81801f,65.81876f,49.374924f,0f,65.434135f,87.89422f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(44.424103f,64.14907f,84.60514f,13.547337f,-28.222324f,0f,42.730915f,0f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(44.616196f,36.040203f,25.402895f,42.42458f,-25.858282f,-41.381035f,7.2574954f,-13.394597f,-34.977604f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(44.680283f,-85.248375f,0f,15.534155f,22.435177f,0f,24.984293f,84.403015f,-62.581974f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(44.984055f,32.208138f,82.93217f,47.72808f,-99.08367f,91.68589f,27.883629f,63.806435f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(45.53529f,68.664505f,96.52147f,13.476648f,32.526146f,29.499031f,-24.15484f,18.464407f,75.23682f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(45.865417f,-1.2024312f,0f,-6.112841f,-63.904514f,0f,-6.4122634f,-19.536213f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(45.900806f,48.32833f,2.5823283f,35.27489f,44.830185f,-100.0f,50.368565f,-41.305393f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(46.317455f,64.88561f,57.35817f,20.384203f,55.866817f,49.42419f,-4.3085537f,-37.61842f,14.11698f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(46.320805f,62.072895f,29.712069f,23.210318f,68.09518f,49.70613f,-21.57471f,43.9441f,0f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(46.337368f,71.075294f,51.76879f,14.274171f,9.1687f,-40.478466f,1.5906166f,-8.1962f,5.3980947f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(46.84604f,59.73688f,80.54378f,27.64728f,14.9812355f,26.95617f,48.76184f,-54.41539f,12.29966f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(46.961407f,-100.0f,-99.97715f,10.148237f,-14.35715f,10.616629f,7.988693f,21.806534f,93.59459f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(47.77154f,10.696247f,-41.032547f,80.389915f,-63.954006f,55.249622f,41.103626f,53.83498f,0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(-47.92098f,-36.29814f,0f,-29.270851f,-47.9437f,-74.99502f,-21.218733f,-55.604076f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(48.201103f,53.17902f,97.85576f,39.62527f,-33.339783f,-4.4643683f,143.60678f,0f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(48.54972f,66.228325f,-82.015236f,27.970552f,9.437785f,5.522656f,53.894707f,-61.970394f,94.668076f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(48.803146f,1.2065191f,26.712696f,93.979836f,-170.682f,5.653702f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(49.202953f,68.41101f,-23.162424f,28.4008f,12.322389f,-14.003897f,14.463723f,29.454092f,91.03025f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(-49.384937f,-8.2295f,0f,-57.052444f,-63.7765f,0f,-27.189318f,-51.704826f,0f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(4.964112f,-64.873535f,89.10577f,-15.270015f,-26.7138f,6.75515f,-39.33037f,-33.466797f,-35.37137f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(49.66296f,69.998535f,30.727179f,28.6533f,99.60401f,-18.23096f,-7.179946f,-24.55489f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(49.902565f,-31.804192f,-36.6176f,29.720272f,41.50841f,90.223976f,27.470108f,77.8936f,3.153486f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(5.0052094f,1.3593494f,0.43218812f,-81.33851f,-100.0f,-100.0f,-22.603083f,14.303444f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(50.170433f,-26.321274f,0f,-1.5335304f,-35.029182f,-21.143127f,-21.275372f,-83.567955f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(50.798298f,-3.2874794f,0f,18.187838f,-39.832973f,-42.076653f,61.786026f,-33.427032f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(50.908417f,100.0f,-12.578065f,3.633661f,-42.76052f,0f,-6.7848973f,-30.77325f,-73.547585f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(51.17072f,73.84018f,-30.47411f,30.842695f,0.38507503f,-9.391039f,71.81499f,-93.75154f,20.456131f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(51.313164f,40.587345f,99.99849f,64.66531f,-88.96227f,-94.4656f,-88.93983f,-30.676964f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(-52.047432f,99.74671f,18.898537f,-7.4128437f,25.748661f,16.658344f,-3.3526022f,-5.9975657f,21.986176f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(52.20667f,43.198444f,0f,-0.05000411f,-51.61088f,5.8227744f,-0.7958042f,-3.1332126f,-87.502716f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(52.378693f,-8.718714f,0f,84.71586f,100.0f,0f,39.305607f,72.50656f,-24.416346f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(52.424297f,70.536026f,-79.03023f,39.16116f,86.82551f,42.874355f,17.488327f,30.79215f,18.854773f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(5.2700934f,-72.62233f,70.10654f,-6.2972984f,-28.05922f,-35.54949f,-2.4000673f,-3.3029711f,-9.713116f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(52.890823f,64.95412f,35.59759f,46.609173f,71.32804f,89.82077f,21.297787f,38.581974f,61.70207f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(52.94578f,21.963543f,0f,69.434395f,-47.08481f,-9.413255f,15.127224f,-8.925503f,-3.7444258f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(53.5479f,97.25504f,62.6274f,16.936562f,79.89359f,0f,-30.062357f,-24.215496f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(-54.00597f,4.281143f,0f,-90.770386f,66.40291f,17.606928f,-19.256021f,13.746298f,7.8383064f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(54.23811f,59.051968f,0.36349922f,57.900467f,77.36376f,-11.652981f,100.0f,58.65479f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(54.509865f,62.52156f,-11.907583f,55.51789f,0.79621226f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(55.136837f,36.730392f,-74.23842f,83.816956f,66.023155f,42.7104f,27.094265f,24.5601f,5.1229854f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(55.50067f,100.0f,96.54892f,22.002678f,31.3076f,20.420626f,1.2024436f,-17.192905f,-35.68784f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(-5.565933f,99.40445f,-74.77862f,10.485777f,37.31227f,9.057513f,10.196768f,30.301355f,73.69638f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(55.756344f,-39.016747f,0f,-46.094414f,-41.80774f,0f,-31.793303f,-81.0788f,47.042187f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(-55.868984f,-40.895027f,0f,-9.875422f,12.542089f,74.729774f,3.8252091f,26.209032f,0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(56.663048f,89.29188f,61.338516f,37.360306f,55.616806f,34.42631f,37.161377f,61.38872f,20.749933f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(56.727665f,86.779854f,-21.181295f,40.130802f,20.532595f,0f,83.26295f,0f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(5.6839128f,-67.82136f,-8.433727f,-9.442993f,-39.80555f,0f,-7.609603f,-20.995419f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(57.059998f,33.815125f,78.20051f,94.42486f,-100.0f,100.0f,18.858568f,-18.990593f,5.179064f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(-5.7444787f,37.457508f,0f,5.7485085f,25.258503f,12.111614f,3.4800093f,8.171529f,3.9476025f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(-57.481407f,18.721607f,11.143176f,-19.884588f,-24.841866f,-78.31635f,2.7849224f,-19.888126f,-30.718714f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(57.49064f,98.93398f,-63.000523f,31.02858f,99.90842f,0f,-9.211921f,-67.87626f,-97.21366f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(58.030098f,59.54411f,0f,-65.69104f,3.0027847f,0f,66.60385f,0f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(-58.065464f,-78.78819f,0f,-6.7850986f,17.693512f,96.46095f,13.231558f,59.71133f,100.0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(58.35908f,91.16037f,-35.26003f,42.275948f,-51.065044f,0f,8.574754f,-7.976933f,73.19679f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(59.276043f,39.33565f,-13.7600565f,97.76851f,11.826627f,-45.172337f,-4.912378f,83.89597f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(59.510445f,51.26085f,14.545075f,21.710403f,25.52566f,43.619747f,1.8055104f,-14.488362f,-85.28462f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(60.349365f,-3.9779382f,0f,-91.4905f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(60.549877f,98.61674f,-18.485441f,43.582767f,99.148575f,99.588524f,14.63262f,14.94771f,-53.990356f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(60.84165f,-64.97165f,-60.374496f,-9.531435f,-41.818283f,-78.25572f,-57.1491f,-14.514327f,6.5730023f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(63.18426f,54.40713f,0f,98.32991f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(63.249737f,-40.826595f,0f,3.5197978f,-37.52994f,-67.76287f,-11.640605f,-50.082214f,60.503452f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(63.56614f,70.22173f,0f,-41.757397f,47.25114f,0f,-90.69143f,-33.616447f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(-64.34318f,135.83286f,0f,-35.06986f,-34.15084f,23.974442f,-41.790684f,-131.98059f,0f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(64.50502f,-100.0f,0f,20.212635f,3.577748f,10.659289f,12.767772f,30.858452f,-29.453081f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(64.54291f,-39.061157f,0f,148.06712f,-24.723553f,14.255306f,38.15904f,4.5288677f,4.6860375f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(6.5601397f,-76.008255f,-19.252882f,2.2488122f,2.4723508f,100.0f,-0.03724128f,-2.3977773f,11.956312f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(66.048935f,33.48949f,0f,17.516829f,-38.326866f,0f,42.34525f,0.2953404f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(66.992134f,-24.74064f,0f,48.27183f,100.0f,1.6428564f,26.095198f,56.108955f,98.34062f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(67.131966f,33.53545f,0f,23.825897f,21.174858f,-50.26904f,6.9967656f,4.161164f,-11.526969f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(-67.394165f,-52.012608f,0f,8.124132f,72.53189f,-45.83031f,6.387671f,17.426552f,-9.213357f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(-68.37327f,100.0f,-96.54955f,-23.277964f,20.616005f,-38.907993f,-45.35459f,44.64998f,-66.758255f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(6.864331f,-40.28868f,2.373531f,12.665743f,15.632206f,-9.848238f,28.166435f,100.0f,-57.39869f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(-70.44478f,-68.19996f,-6.195774f,-15.10642f,-7.246318f,60.55931f,17.265415f,-6.2382035f,58.036865f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(-71.54825f,-45.353474f,-205.87115f,-40.22711f,-72.90888f,-181.14749f,-16.28812f,-24.908201f,-45.057053f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(-71.758194f,86.33936f,100.0f,-12.67021f,28.321285f,55.92151f,-7.243933f,-16.305523f,100.0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(72.05551f,80.72387f,0f,13.844885f,-58.22387f,0f,-44.772152f,0f,0f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(72.78215f,158.88281f,108.625824f,32.24946f,19.270689f,122.774254f,36.968178f,81.118866f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(72.93911f,-36.375534f,-100.0f,-10.242505f,-13.909124f,74.664665f,-100.0f,-83.68313f,-100.0f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(73.19498f,92.779915f,100.0f,100.0f,97.92467f,-99.86911f,50.0f,100.0f,-96.098526f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(-7.447829f,-69.04466f,18.886734f,-60.746655f,-57.3818f,0f,16.461176f,3.5417516f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(74.605774f,100.0f,0f,19.88512f,19.91783f,68.788574f,-14.983124f,-67.61413f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(75.366005f,30.370033f,-1.4621696f,25.737902f,-3.2530653f,-6.663147f,30.838663f,-62.45705f,-51.391678f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-75.99789f,35.035732f,0f,-16.784485f,25.19309f,73.47433f,-16.333143f,78.22304f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(76.48092f,52.81009f,-37.13175f,24.871683f,16.44438f,-13.278315f,6.5614357f,1.37406f,-17.509575f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(-7.7399993f,20.598776f,0f,-56.339115f,57.63991f,0f,-86.42265f,79.63179f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-77.881775f,-28.067713f,0f,-2.1280005f,-39.021175f,0f,1.8453454f,9.509382f,-90.356255f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(78.148575f,-6.5475473f,0f,35.12219f,24.736305f,10.822715f,37.603878f,-20.499556f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(-79.01572f,76.98909f,0f,-21.714064f,50.529167f,-27.945045f,-58.369705f,-29.203564f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(-80.48741f,-66.94798f,0f,-21.96117f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(81.90114f,75.71464f,0f,-15.039787f,-12.584197f,0f,9.353612f,-71.93362f,0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(8.252893f,-80.03749f,7.517604f,13.049067f,31.570385f,67.07623f,12.372989f,-61.76372f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(82.66711f,-58.374817f,0f,9.443107f,10.309166f,70.50532f,-55.203846f,19.66306f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(-83.635994f,76.90078f,0f,-10.205748f,8.571642f,0f,-2.7057352f,-0.6171932f,-8.334679f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(8.377469f,-26.205393f,0f,-16.859186f,-43.320374f,0f,21.380995f,0f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(-86.48894f,-100.0f,0f,-6.8071947f,51.54197f,-0.92156607f,7.7181892f,37.67995f,91.45965f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(-86.65493f,11.183206f,-50.314995f,-35.341946f,-12.9016285f,-0.3008375f,-41.811226f,-27.146936f,-50.954113f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(87.62194f,48.31505f,0f,-0.9461658f,-40.561684f,-17.931173f,-50.844925f,88.48121f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(8.852027f,4.5520005f,50.937073f,-69.14389f,-76.98601f,0f,-21.34091f,-16.219744f,0f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(-89.738144f,47.543243f,0f,-44.576378f,-94.37842f,0f,5.8110533f,0f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(-9.106846f,-84.004555f,0f,11.943674f,50.687927f,-35.064312f,6.1936164f,12.8307905f,-5.55838f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(9.178862f,15.540981f,15.873353f,-78.82553f,-62.88829f,53.7576f,-24.646046f,-19.75865f,8.499738f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(95.04697f,-0.72448695f,23.191092f,26.345594f,7.3456535f,18.148056f,2.989761f,-14.38655f,99.145065f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(9.592756f,0.703401f,-99.65356f,-62.332375f,-7.1255946f,25.381947f,-11.19801f,17.54033f,88.48493f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(96.553055f,-100.0f,-100.0986f,32.377674f,-45.085762f,-156.81348f,77.74306f,44.34176f,-27.303587f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-9.669388f,37.089333f,0f,-84.56445f,55.03058f,0f,-5.493981f,62.58853f,-90.33216f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(-96.80952f,-51.35337f,0f,-12.263611f,62.1058f,-74.64628f,-14.350726f,-66.6618f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(9.739792f,-74.77194f,45.69658f,13.731108f,24.51339f,90.32777f,20.671251f,68.953896f,15.126023f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(97.53392f,-100.0f,0f,-30.60233f,97.21464f,0f,-10.180211f,-10.118516f,0f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(9.809623f,-38.28225f,88.31904f,-22.479261f,-7.2569046f,8.199604f,-92.46976f,23.534286f,-3.3061757f ) ;
  }
}
