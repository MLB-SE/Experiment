import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(100,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,11,7,6,7,2422,-209,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,2,690,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,6,3,8,3,276,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,6,8,909,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(4,2,0,8,-1801,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(4,6,6,4,4,-479,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(4,7,3,9,10,1587,-450,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(5,2,2,-82,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(523,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(-530,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(5,3,7,5,4,1650,1080,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(5,4,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(5,6,3,493,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(5,7,3,2,0,977,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(5,9,-651,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(6,5,8,1,253,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,-713,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(6,9,4,6,5,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(6,9,8,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(7,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(7,7,0,2,4,1913,226,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(8,279,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(8,6,5,0,706,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(8,873,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(9,0,640,0,0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(9,6,2,9,8,3,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(9,9,8,0,0,0,0,0 ) ;
  }
}
