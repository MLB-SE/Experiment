import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(66.048164f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(85.838745f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(-86.53612f ) ;
  }
}
