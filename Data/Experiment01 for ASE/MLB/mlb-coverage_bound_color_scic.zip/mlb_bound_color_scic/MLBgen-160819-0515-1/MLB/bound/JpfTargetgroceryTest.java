import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(104,205,63,-992 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(104,575,12,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(116,468,109,18 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(12,508,863,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(13,837,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(154,190,154,430 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(180,-158,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(19,27,471,194 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(193,181,282,55 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(286,589,572,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(292,73,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(365,244,-428,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(463,0,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(513,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(-517,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(550,164,654,993 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(611,8,71,21 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(618,508,629,771 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(661,460,228,442 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(831,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(92,510,0,0 ) ;
  }
}
