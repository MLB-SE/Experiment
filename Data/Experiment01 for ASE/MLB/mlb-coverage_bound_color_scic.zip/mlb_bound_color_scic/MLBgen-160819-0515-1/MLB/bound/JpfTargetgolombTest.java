import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,6 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,1,3 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,1,384 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,156,0 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,2,2 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,5,0 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,5,4 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(119,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,2,1099 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,3,0 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,4,6 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(1,5,1 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(1,-530,0 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(-183,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(2,2,0 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(2,4,0 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(3,5,6 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(4,1,1 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(5,0,3 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(5,3,3 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(5,5,5 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(6,4,-69 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(6,598,0 ) ;
  }

  @Test
  public void test25() {
    bound.golomb.solve(845,0,0 ) ;
  }
}
