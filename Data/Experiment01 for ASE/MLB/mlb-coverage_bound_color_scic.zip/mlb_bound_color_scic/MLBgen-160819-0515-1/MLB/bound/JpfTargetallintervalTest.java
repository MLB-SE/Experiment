import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,1,-259,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,4,3,-779 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(2,2,3,1 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(2,3,415,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,3,4,781 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(2,401,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,3,4,3 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,-50,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(4,1,308,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(4,1,4,216 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(4,1,4,3 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(4,3,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,4,3,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,594,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(-526,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(731,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(847,0,0,0 ) ;
  }
}
