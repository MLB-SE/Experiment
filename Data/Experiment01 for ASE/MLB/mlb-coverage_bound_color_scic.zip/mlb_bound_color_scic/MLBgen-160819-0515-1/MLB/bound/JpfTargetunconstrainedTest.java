import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,4,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(145,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(1,668,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(1,6,7,-199 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(2,10,7,9 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(2,314,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(3,3,3,0 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,8,577,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(5,1,891,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(-542,0,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(5,8,10,5 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(5,9,-420,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(6,2,9,4 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(639,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(7,2,7,1168 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(8,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(8,8,8,85 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,-822,0,0 ) ;
  }
}
