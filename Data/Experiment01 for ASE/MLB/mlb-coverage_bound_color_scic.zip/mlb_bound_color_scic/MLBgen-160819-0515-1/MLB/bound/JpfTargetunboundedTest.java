import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(142,-598 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(228,-7 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-307,270 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-586,-14 ) ;
  }
}
