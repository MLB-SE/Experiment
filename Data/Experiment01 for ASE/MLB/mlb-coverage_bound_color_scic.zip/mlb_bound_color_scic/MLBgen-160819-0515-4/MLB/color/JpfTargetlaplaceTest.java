import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.7419465f,-84.09839f,58.934044f,-12.933825f,-36.70794f,0.34384492f,-15.769304f,-50.14339f,-42.487843f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.9941566f,3.6682177f,8.489603f,-99.69159f,-94.81089f,-69.70981f,-26.80273f,-7.519328f,-100.0f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-100.0f,-100.0f,0f,-25.118937f,26.565363f,26.413109f,-27.041113f,-83.04551f,4.8915725f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(100.0f,100.0f,0f,78.139015f,-57.252914f,0f,18.022163f,-6.0503597f,61.23472f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(100.0f,-100.0f,0f,93.13582f,30.459278f,33.339108f,26.879019f,14.380252f,0.18271331f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-12.968725f,0f,-26.461765f,4.058078f,18.995638f,-9.905136f,-13.15878f,-46.78806f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(10.456612f,-35.370514f,-197.67114f,-24.968103f,-102.50012f,-59.165623f,-7.757077f,-6.060206f,88.35652f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(10.815946f,-78.4748f,16.841866f,21.738583f,3.5034583f,11.376141f,72.634926f,59.37391f,25.159239f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-10.951792f,-36.075115f,43.885735f,-0.37875172f,-5.965469f,-49.395702f,15.402253f,61.98769f,-40.210297f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(11.043661f,75.48692f,0f,8.549669f,-76.73469f,0f,-35.663006f,97.84733f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.553544f,-75.58778f,100.92456f,21.801962f,30.246578f,-91.430855f,45.386f,159.71275f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(11.974782f,-13.674904f,-74.630455f,-38.42597f,95.34151f,0f,-73.447044f,56.027782f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(12.273905f,-61.48722f,-10.801125f,10.582839f,16.530302f,82.59193f,13.527148f,34.43366f,-82.42292f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(12.555385f,-58.44825f,-67.727486f,8.669788f,-7.537933f,72.35157f,29.661701f,-52.72484f,3.2528148f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(130.1946f,94.65232f,41.233f,46.95023f,53.140553f,100.0f,4.4706955f,-29.067448f,-168.93678f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(14.350898f,-58.770332f,-20.433155f,16.173922f,-21.126709f,-0.12838537f,71.4715f,-41.78204f,41.04632f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(14.692475f,19.726711f,41.515064f,-60.95681f,-77.3007f,46.33354f,-23.036032f,-31.844082f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(15.130656f,12.046612f,-6.2051587f,-51.523987f,-60.73905f,-24.839128f,-17.77653f,-19.58213f,0.18705589f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(-15.437505f,-88.2234f,-100.0f,-73.52662f,80.03225f,-3.3852437f,-14.038492f,17.372652f,3.496852f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(15.462599f,-12.183914f,-67.675446f,-25.96569f,-96.52281f,6.9005704f,-26.865839f,-81.497665f,-66.72243f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(1.5577383f,-80.79552f,-100.0f,-23.48903f,-23.89947f,86.57312f,-71.614395f,-77.88645f,100.0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(15.972942f,-88.89272f,0f,46.559143f,-59.24593f,0f,24.816824f,52.708153f,21.228148f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(16.286282f,-9.855483f,0f,-4.1131206f,-70.64537f,0f,37.906605f,0f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(16.508926f,-7.0123916f,-56.874184f,-26.9519f,-87.62656f,-5.3616633f,-36.689972f,-100.0f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(-16.67403f,-79.92751f,44.09136f,-86.76861f,-100.0f,0f,-6.5728617f,60.47716f,-75.47471f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(16.763077f,-8.088225f,-49.116287f,-24.85947f,-99.99969f,15.996315f,-31.214867f,-100.0f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(16.82977f,-23.517265f,82.21865f,-9.163654f,36.69143f,0f,-32.519073f,0f,0f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(17.043184f,34.96922f,39.046066f,-66.79648f,-16.212378f,36.575184f,-40.320095f,-72.39037f,0f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(17.569096f,-39.380436f,24.64607f,9.656818f,38.96746f,0f,-17.909285f,0f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(17.678059f,-129.54134f,-45.23752f,-12.758471f,-58.933517f,-67.487335f,-9.766826f,-26.01452f,-23.375465f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(17.680616f,-72.32165f,4.4147515f,43.04411f,31.95777f,0f,-42.97565f,-1.0816033f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(17.757334f,15.688434f,20.065348f,-44.659096f,-75.06895f,-100.0f,55.662407f,0f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(17.864603f,19.436186f,-43.210518f,-1.2394346f,-19.426418f,-83.55816f,-3.3959243f,-12.344263f,-23.97457f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(18.120432f,-31.272419f,73.866615f,3.754145f,77.39126f,-21.94402f,-80.49511f,-60.521683f,0f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(18.128227f,-52.36964f,0f,5.49111f,-1.4320217f,-76.03684f,5.268234f,15.581824f,58.491085f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(18.777292f,26.528488f,-0.7329993f,-51.41932f,100.0f,0f,-8.498322f,17.426035f,-21.79754f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-18.956322f,-27.503508f,0f,-3.134659f,24.53392f,-25.829159f,-18.116236f,-69.330284f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(19.00015f,-80.51601f,0f,1.8960098f,-11.595072f,35.644997f,0.17896083f,-1.1801665f,6.6954446f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(-19.317156f,13.3509655f,81.251175f,-5.838729f,-2.336787f,-15.894223f,-1.7009726f,-0.9651611f,0.17711496f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(19.627495f,-23.786402f,-31.49909f,2.293302f,-9.533331f,-10.663097f,-0.9209559f,-5.9771256f,-23.527687f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(20.001373f,-17.14941f,-34.777786f,-0.29655185f,-15.377386f,-78.8932f,-5.8101945f,34.82962f,25.053778f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(20.043388f,23.528599f,39.128426f,-43.355045f,-65.05742f,32.98511f,-17.25215f,-25.653557f,100.0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(20.240377f,12.523029f,-37.664295f,-31.561518f,-32.483967f,72.08796f,12.73591f,82.50516f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(20.843645f,-34.78984f,49.367786f,18.164423f,-8.2850275f,100.0f,60.099075f,-100.0f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(20.850834f,-67.47824f,1.1749728f,50.88158f,4.830602f,0f,46.36757f,-40.180786f,0f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(21.112202f,-23.313002f,-40.961014f,7.7618065f,-0.48008218f,63.203568f,10.415106f,33.89862f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(21.277676f,11.423049f,21.831175f,-26.312344f,-97.41666f,-33.13725f,-29.110395f,100.0f,0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(-21.445509f,-64.83705f,25.343225f,-31.52022f,-43.228733f,-61.81909f,-61.40664f,-14.738568f,40.107704f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(21.893196f,-18.498419f,253.48285f,6.0205464f,-6.80056f,78.74176f,12.607295f,40.27573f,155.20135f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(22.10934f,0.041107696f,-66.37659f,-11.6037445f,-55.56832f,20.855417f,-12.955997f,-40.220245f,-13.694733f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(22.531416f,10.16558f,15.643695f,-20.03988f,-97.51278f,-100.0f,-5.178154f,-0.67273486f,100.0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(22.533209f,12.272823f,-19.936253f,-22.139986f,-49.604446f,0f,-73.53552f,0f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(-22.741446f,-15.071081f,0f,-8.21676f,14.07874f,0f,-18.552603f,-65.99365f,18.483728f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(22.789743f,-41.63736f,0f,32.796333f,79.73687f,-23.051485f,28.65872f,81.83855f,-1.5493063f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(2.297469f,-58.67601f,86.10828f,-32.134113f,48.77625f,-5.975115f,0.27315447f,33.22673f,83.85752f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(23.015999f,7.6403246f,-89.94525f,-15.576329f,-71.41956f,68.48742f,-13.901755f,-40.03069f,-2.3059752f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(23.01971f,18.028736f,47.745564f,-25.949894f,-98.65033f,-31.654978f,-28.168953f,0f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(23.170809f,-24.999846f,0f,-8.562153f,79.4193f,-15.611266f,3.1006005f,20.964556f,1.3383222f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(23.200989f,4.589025f,-46.067307f,-11.7850685f,-58.777584f,18.48624f,-11.563681f,-34.469654f,-71.42315f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(23.359478f,16.084255f,-26.728357f,-22.646345f,-33.77178f,-2.841475f,-80.17308f,-43.21447f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.882664f,13.220034f,11.539575f,-17.68938f,-82.5421f,-19.663593f,-86.787636f,22.895512f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(-23.949041f,-42.97084f,0f,-28.910889f,-78.48954f,8.142819f,-13.204976f,-23.909016f,-3.941549f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(23.959095f,11.549774f,-71.38317f,-15.713397f,-6.3768253f,17.360928f,-80.43586f,0f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(24.368856f,6.2218494f,-33.26691f,-8.746421f,-66.21455f,-42.016193f,-3.8554878f,-6.6755304f,10.410148f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(24.39316f,22.1571f,100.0f,-24.584463f,44.313126f,31.371862f,-4.9056807f,4.961742f,-19.560476f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(-24.768173f,-31.70468f,-58.731453f,15.294126f,25.560455f,19.848888f,60.38422f,98.80349f,76.434746f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(2.4877155f,-94.19022f,-2.0216644f,4.141089f,-75.04115f,57.093334f,89.11779f,49.02438f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(25.160456f,100.0f,0f,6.4034195f,-6.3177605f,-43.18402f,6.7709823f,20.68051f,82.268814f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(-25.249897f,9.689176f,0f,4.572507f,39.419983f,4.449304f,4.119943f,11.907267f,4.089143f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(25.359812f,90.40335f,10.445818f,-88.9641f,-31.18671f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(25.40797f,-82.34415f,0f,8.233666f,4.405678f,-0.9734566f,3.1210155f,4.2503963f,9.474892f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(25.435892f,22.83855f,-31.022305f,-21.094984f,-9.820686f,-8.186539f,-99.99514f,-32.839775f,8.096834f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(25.519909f,4.174162f,-53.412518f,-5.49727f,-0.13455863f,-27.810863f,-47.37443f,28.595736f,-87.3664f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(25.52493f,-3.9604943f,-40.67251f,5.5582023f,-4.174375f,-16.265892f,0.8822551f,-2.029024f,-4.823753f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(25.705135f,25.830019f,-94.37341f,-23.009476f,-52.99763f,0f,-64.74541f,0f,0f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(25.732702f,1.1803293f,-105.82908f,2.232547f,-20.86964f,-138.30142f,4.5226154f,15.983256f,-105.743095f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(25.791767f,26.610758f,-191.84183f,-23.443691f,-3.8926544f,-43.779095f,-115.722f,25.041412f,-169.79417f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(26.028349f,38.538567f,19.976805f,-34.42517f,-84.11259f,0f,52.728844f,0f,0f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(2.6063461f,33.712288f,0f,-77.03009f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(-26.429216f,-50.681377f,-99.67633f,-28.198269f,-8.452233f,-27.051346f,-77.91163f,72.12206f,-0.07682053f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(26.724213f,-2.6621795f,-61.721653f,9.559028f,-75.651276f,16.240355f,87.16318f,-50.767403f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(2.6911209f,-91.30219f,53.11811f,2.066677f,-23.640736f,74.42407f,29.216324f,-79.7515f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(26.924448f,68.29857f,48.60238f,-60.600777f,97.66745f,-12.765221f,-47.42788f,-59.854958f,0f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(26.975912f,2.9775524f,-15.9614f,4.926093f,-99.1043f,20.584515f,-11.893287f,-52.499237f,-98.99937f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(27.575802f,23.63994f,53.46209f,-13.336733f,-86.47813f,-35.605206f,-26.33494f,-65.488525f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(-27.593407f,100.0f,0f,-25.746443f,-93.75677f,-62.36393f,18.364397f,99.20403f,58.45081f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(27.63462f,2.4424536f,23.650099f,8.096029f,5.5838213f,23.230137f,-0.83432627f,-11.433334f,63.686626f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(27.750628f,8.387427f,-67.60136f,2.615084f,-6.609333f,2.0125804f,-10.680959f,-39.452423f,-49.303493f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(27.754131f,90.5473f,149.67992f,-80.30754f,84.73237f,-252.92986f,-1.6087044f,73.887344f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(28.03437f,13.121429f,73.44878f,-0.9839445f,-12.801426f,10.329801f,-19.168724f,-73.67299f,-19.328142f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(28.351429f,50.810417f,0f,-14.800164f,-69.48011f,-36.34567f,-18.071976f,10.858296f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(28.502993f,23.03011f,30.805803f,-9.018136f,-67.188354f,-77.14684f,-5.732684f,-13.912601f,17.270638f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(28.654099f,100.0f,-51.335934f,13.704844f,23.506477f,-16.6093f,2.6588018f,-3.0696368f,-38.443825f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(28.96308f,28.754463f,112.43807f,-12.823979f,29.329512f,33.937393f,-109.57251f,67.48843f,146.44055f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(29.217411f,25.534561f,53.411594f,-8.664916f,-80.49076f,-46.766144f,-4.6949306f,-10.114806f,-53.775204f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(29.602716f,-34.737038f,0f,58.71592f,-18.788166f,0f,18.132164f,13.81274f,48.945396f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(29.921854f,61.79151f,-38.722294f,-42.10409f,100.0f,0f,2.222066f,50.992355f,37.65256f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(30.057343f,23.498423f,-15.512225f,-3.2690527f,-61.03577f,100.0f,-3.4496226f,-10.529438f,22.36764f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(30.086235f,11.6298685f,-90.8955f,8.715074f,7.328738f,27.732893f,-2.5546799f,-18.933794f,-80.50923f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(30.23408f,12.815497f,-21.244715f,8.120823f,-0.8261877f,-10.961465f,3.0753996f,4.180775f,51.100563f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(30.380297f,47.704304f,12.104413f,-26.18311f,48.332497f,-99.2866f,-1.1301893f,21.66236f,39.447052f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(30.788654f,-80.18603f,23.569588f,0.6669256f,-20.874508f,25.67377f,-7.2464437f,-29.6527f,100.0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(30.835068f,19.484015f,46.109226f,3.8562555f,-3.9498696f,7.7786703f,-11.4601755f,-46.91842f,-11.044673f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(30.850752f,35.352142f,47.5082f,-11.949133f,-51.910206f,0f,-15.311554f,-49.29708f,-91.30098f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(30.888525f,30.61198f,-41.909008f,-7.057878f,33.468407f,100.0f,7.015661f,35.12052f,99.99802f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(31.52688f,27.080006f,-41.421043f,-0.97248316f,-86.167015f,-72.155495f,50.7502f,45.34541f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(32.43448f,29.741604f,8.13177f,1.8313476f,-21.718817f,-298.88528f,-3.2477393f,-14.826308f,-34.38254f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(32.440514f,30.145836f,15.383469f,-0.3837781f,-27.24064f,-100.0f,-6.734986f,-26.556166f,-58.071102f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(32.814335f,-82.279594f,0f,-3.7190154f,-10.696104f,72.33452f,-36.994293f,-29.120329f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(32.859493f,37.57191f,2.831653f,-6.1339426f,12.793291f,22.016453f,-70.18855f,-16.587189f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(33.032608f,4.2781825f,-94.29626f,27.852247f,-21.623617f,41.348007f,100.0f,-61.162266f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(33.035603f,26.279964f,0.5557427f,5.8624425f,-28.471485f,-54.97612f,18.885653f,69.68017f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(33.147026f,19.993515f,13.903863f,12.594596f,-67.07683f,-64.37807f,-91.5998f,79.70424f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(-33.283916f,-188.73274f,-63.19055f,-44.398666f,-24.77239f,12.959893f,-119.48637f,-53.52219f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(33.465763f,33.88268f,-13.590228f,-0.019621981f,-34.961212f,-8.336377f,1.4169619f,5.68747f,46.84551f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(33.652225f,73.31327f,61.977345f,-38.70436f,97.6235f,74.59611f,100.0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(33.681915f,23.751041f,-95.77774f,10.9766245f,57.099995f,27.533936f,-46.875412f,-16.050108f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(33.878033f,30.970552f,-0.041233946f,4.541581f,-9.954591f,100.0f,-5.757118f,57.19406f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(34.11697f,-28.11021f,-80.5422f,3.358216f,-13.67512f,1.4456706f,-7.0089855f,-31.394157f,100.0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(3.4117606f,40.16993f,0f,-59.244244f,77.54258f,0f,-20.931587f,-24.482103f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(3.4414587f,13.765835f,-68.318344f,-100.0f,15.590312f,-55.99022f,-23.442608f,6.2295694f,32.770573f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(34.509735f,22.581287f,14.3296f,15.457647f,-58.514183f,-65.262886f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(34.743164f,51.2417f,38.419994f,-12.269046f,31.803646f,-8.984355f,37.99706f,-37.947323f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(34.78693f,26.449457f,-28.754555f,12.698262f,-0.23454854f,-18.216658f,16.240667f,-21.869255f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(34.958595f,22.458109f,41.53142f,17.376276f,-86.657585f,81.614006f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(3.5238147f,-85.45343f,100.0f,-0.3112222f,-6.2756586f,54.364536f,1.506955f,6.2974863f,100.0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(35.44239f,-58.23043f,-11.782969f,100.0f,-79.027466f,0f,24.017584f,-3.9296649f,37.194157f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(-35.502426f,-23.788311f,0f,-18.927698f,-29.52077f,100.0f,-10.687596f,-23.822687f,-55.082382f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(35.553207f,33.947495f,-6.452813f,8.265338f,6.689588f,-94.9098f,-9.181445f,-44.991116f,-20.795351f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(35.853798f,41.6906f,-24.576124f,1.7245915f,-95.40963f,0f,63.56457f,6.1119986f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(35.926704f,34.764584f,-64.87043f,8.942241f,14.67282f,33.161484f,-14.830564f,-68.264496f,-22.208939f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(36.111374f,39.586727f,34.497223f,4.8587728f,-12.261692f,-89.89302f,-4.4145923f,-22.517143f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(36.176846f,28.118029f,-42.554447f,16.589357f,18.849712f,-0.4241824f,7.4110856f,13.054984f,25.95914f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(36.498028f,38.20754f,22.23437f,7.784579f,-5.9022512f,-50.687206f,0.54253787f,-18.913914f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(36.833385f,21.770994f,37.5601f,25.562555f,-87.30951f,28.469408f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(36.868042f,50.04628f,22.502441f,-2.5741103f,23.209206f,23.529531f,-70.37369f,21.835121f,100.0f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(36.934494f,43.657326f,63.807865f,4.0806456f,-26.113056f,38.73677f,5.501146f,17.923937f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(-36.954906f,42.90939f,0f,-71.13736f,-41.7268f,0f,14.866444f,0f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(36.964153f,7.8557467f,0f,1.7162491f,-29.419174f,-63.34767f,-0.67998224f,-90.173164f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(37.17386f,45.831184f,-36.468937f,2.8642569f,82.61981f,51.84254f,15.86089f,0f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(37.353313f,31.337204f,-41.345226f,18.076056f,29.340725f,85.84132f,8.4704485f,15.805738f,25.411762f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(37.40558f,-4.4725876f,0f,-9.658269f,-71.47982f,-23.013233f,-4.558836f,-8.577075f,41.730354f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(37.427456f,8.229202f,0f,6.806734f,-10.299557f,-68.940735f,0.099038996f,-6.4105783f,-8.075132f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(37.453167f,53.216434f,-22.960758f,-3.403768f,9.568968f,-2.8494217f,-60.637207f,-8.687375f,-8.953656f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(37.548073f,-87.997765f,0f,70.13301f,61.18887f,0f,79.068115f,-25.888912f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(37.644997f,48.910286f,-15.143077f,1.6696972f,-34.701202f,-100.0f,3.734995f,13.270282f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(37.81641f,-16.805838f,-65.703156f,-13.580058f,-12.504858f,-23.812004f,-79.63178f,4.178468f,-17.04f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(37.930622f,39.62262f,5.282062f,12.099866f,15.277796f,-11.636918f,-4.808952f,-31.335674f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(38.082687f,45.948204f,17.524569f,6.3825436f,-13.007741f,-99.80008f,0.45522773f,-4.5616326f,46.654102f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(38.927834f,22.766724f,-74.34749f,32.944614f,-93.41341f,-14.194713f,5.0137515f,-12.889606f,36.841232f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(39.011482f,47.176823f,57.638615f,8.869108f,-7.9427996f,24.551971f,4.4077525f,8.761902f,-61.316982f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(39.108543f,32.52518f,-29.762796f,23.908987f,0.07943179f,-99.283104f,56.44797f,43.166664f,-34.37698f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(39.109272f,37.841904f,-7.8517323f,18.59519f,24.588198f,0f,40.05189f,-9.769296f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(3.9126506f,-6.1363845f,-42.4439f,-78.21301f,-95.553085f,0f,-19.066055f,14.063461f,0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(39.281895f,28.671436f,21.41302f,28.45614f,-46.00917f,-43.019363f,12.041704f,19.710678f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(39.303833f,44.86755f,-15.595373f,12.34778f,34.97684f,47.54193f,-24.889551f,35.150105f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(39.564293f,52.021526f,21.205702f,6.235646f,47.31611f,-85.30797f,-61.93782f,-11.789308f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(39.699703f,43.884205f,28.823917f,14.914609f,7.0131927f,-28.588533f,14.125166f,41.586056f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(39.92185f,46.653008f,52.58395f,13.034385f,-5.8937654f,90.44545f,5.020512f,0f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(-40.030468f,95.84422f,0f,16.705044f,25.490822f,-18.885925f,81.359825f,-44.025124f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(40.289433f,28.881443f,37.501507f,32.27629f,-62.26517f,-29.811398f,3.078124f,-19.963797f,18.961432f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(40.418137f,15.043986f,0f,77.04496f,-48.98514f,-14.320608f,16.88238f,-9.515445f,-5.959013f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(-40.646416f,-68.634544f,-22.58956f,-27.163446f,-55.023907f,-99.52718f,-12.983474f,-24.770449f,-31.074411f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(4.0786095f,-26.0563f,-79.24703f,-57.622807f,-129.06241f,142.8548f,-12.729359f,6.7053704f,68.96807f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(-4.0801444f,-191.2962f,-214.64012f,75.10598f,11.595499f,0f,22.235033f,13.682423f,21.288054f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(4.0914817f,-9.240572f,0f,-16.705091f,-83.994995f,-34.022655f,13.083149f,69.03769f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(41.223576f,32.780674f,-98.62283f,32.113636f,73.59143f,-100.0f,13.639535f,22.444506f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(41.309097f,44.790882f,6.5320625f,20.445503f,-66.08002f,0f,-1.0773418f,-24.754871f,36.36114f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(41.323692f,54.29073f,54.330444f,11.004046f,21.508772f,16.091425f,-18.81628f,5.13851f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(41.397232f,-239.56517f,0f,95.53303f,-175.30112f,-6.4809794f,12.954285f,-43.567104f,-12.357797f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(-41.46899f,-37.58342f,0f,-16.8722f,-18.873682f,0f,-3.1381953f,4.3194184f,39.28955f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(41.50104f,67.74672f,-22.598967f,-1.7425522f,7.717466f,8.58144f,-56.188717f,-43.71574f,49.20726f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(41.716656f,-94.37363f,99.999886f,11.141149f,-1.0153416f,74.85915f,3.8632767f,4.3119574f,14.399893f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(41.725197f,49.273376f,63.41789f,17.62741f,-8.049584f,0.10687674f,36.83403f,-100.0f,0f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(41.81004f,48.37864f,9.428572f,18.861517f,20.93068f,22.838036f,12.705351f,-6.355474f,60.99289f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(41.824577f,25.366032f,7.1250453f,41.932278f,-47.485493f,-96.86585f,82.68764f,-63.83564f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(41.922905f,30.31772f,79.34798f,37.373905f,-100.0f,46.06381f,34.343475f,100.0f,0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(42.27285f,53.102573f,81.003784f,15.988828f,-21.823711f,0f,15.062685f,44.26191f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(-4.234905f,-64.653725f,0f,-52.285892f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(42.5224f,22.405317f,100.0f,47.68428f,-71.428635f,0f,11.869688f,-0.20552742f,0f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(4.2657876f,-95.31621f,-14.20832f,-6.530541f,-29.67362f,-4.001692f,-0.7143315f,-12.846042f,19.313154f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(42.904274f,24.928564f,-100.0f,46.68853f,100.0f,0f,2.4785504f,-36.774326f,68.55412f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(4.3430367f,-59.259075f,0f,29.039064f,98.165504f,-100.0f,13.647723f,25.551826f,-9.605917f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(43.530228f,20.66505f,19.87227f,53.455864f,-80.742294f,-41.175972f,5.718221f,-30.58298f,-47.30784f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(43.73619f,60.991276f,70.28394f,13.953482f,12.390478f,0f,0.35371998f,-12.538602f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(43.85665f,41.10346f,-79.44255f,34.323143f,99.999725f,15.300629f,11.903925f,13.292556f,55.38806f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(43.867584f,48.33613f,15.304239f,27.136713f,34.172684f,-87.12496f,8.153866f,5.4787493f,-20.411552f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(44.1871f,50.369728f,71.75278f,26.378666f,-14.4609585f,-12.585318f,49.81565f,-6.355309f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(44.320774f,8.9740715f,-64.33143f,-3.8291576f,19.350407f,-6.7094007f,-78.98781f,78.96612f,18.891476f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(44.442657f,38.756588f,23.273155f,39.014046f,-12.689462f,-97.94446f,4.606056f,-20.589823f,-74.27589f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(-44.769936f,-73.652756f,0f,26.186338f,-11.325147f,4.948805f,9.311508f,11.059694f,46.252415f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(44.84034f,63.665253f,75.63815f,15.696103f,34.182514f,100.0f,-16.238443f,-80.64987f,-79.14274f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(-4.4887433f,-20.382378f,-66.4858f,-1.6939225f,11.254723f,-16.59639f,-13.541669f,83.69158f,-11.154472f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(45.056118f,57.532818f,43.564034f,22.691654f,41.510742f,99.992836f,4.1989717f,-5.8957667f,-69.29278f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(45.181503f,72.21073f,0f,17.798431f,-31.7785f,10.813671f,57.790718f,-77.59772f,0f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(45.237232f,84.39849f,-2.520925f,-3.4495564f,-77.94305f,0f,40.862595f,15.91537f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(45.47594f,45.49706f,0f,-65.424385f,-92.76837f,0f,-18.724741f,-9.474578f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(-45.70109f,-28.64084f,1.3291701f,-1.1674643f,-19.245811f,-8.315848f,60.277046f,-38.859093f,-35.999565f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(45.801456f,68.82756f,9.0830345f,14.378268f,73.70193f,69.19515f,9.045666f,21.804396f,4.4699874f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(45.918217f,-24.726238f,23.621042f,14.1322365f,4.1831512f,15.748541f,6.427576f,11.578068f,35.18997f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(4.5977926f,-41.317623f,0f,-43.792664f,13.964208f,45.36645f,-13.892187f,-11.776084f,-47.176357f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(-46.003517f,-51.913097f,0f,-0.84348595f,73.91129f,91.2151f,-31.281717f,-58.744923f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(46.09906f,65.13912f,0f,20.362316f,28.588646f,27.082035f,6.761556f,6.6839094f,-8.614565f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(46.123295f,75.301315f,55.151134f,9.191858f,99.93085f,45.56264f,8.267847f,23.879528f,-12.680581f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(-46.231434f,-61.219135f,0f,-17.057161f,-10.274851f,-1.6751051f,-11.722365f,-29.832298f,-97.33198f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(4.650138f,-89.60974f,0f,-11.651479f,9.9769945f,-11.38905f,-61.233047f,-0.9165238f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(46.56272f,52.720894f,-23.231987f,33.529995f,87.55284f,14.861778f,0.004407063f,38.089622f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(46.819283f,47.194225f,-6.2130322f,40.082912f,41.061012f,-5.5656934f,72.451355f,60.378696f,0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(46.840572f,55.044395f,80.547485f,32.317886f,-7.210472f,100.0f,89.64145f,3.4646466f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(46.976322f,58.998558f,13.282448f,28.906733f,75.73546f,-95.601814f,-7.0848446f,-90.84447f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(4.711089f,-85.43013f,78.49406f,4.277489f,-4.5731225f,-0.75032175f,16.97199f,63.610474f,-11.897841f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(47.131596f,69.925476f,18.853727f,18.621784f,113.64174f,-94.00978f,-64.095375f,127.845314f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(48.119175f,42.88384f,65.559555f,49.592854f,-42.14337f,-28.437788f,16.588793f,16.762321f,92.60387f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(48.551422f,57.07893f,-7.98097f,37.127163f,87.7453f,-18.45391f,12.211934f,11.7206545f,-53.074028f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(48.611504f,64.07087f,-96.937904f,30.535362f,22.304026f,-42.81295f,51.225925f,37.422817f,-96.617935f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(48.718136f,56.35328f,17.69511f,38.51927f,58.99987f,-85.57284f,46.359077f,0f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(49.053425f,-100.0f,0f,-28.485453f,96.59145f,2.2523766f,2.2763019f,37.59066f,51.49489f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(49.081684f,63.706104f,43.355484f,32.62064f,2.2979705f,0f,8.980129f,3.2998774f,-30.997993f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(4.942914f,-86.05916f,0f,-6.707055f,-26.686642f,-56.311485f,-5.084494f,-13.630921f,-22.75255f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(4.9677405f,-5.946602f,-76.813095f,-74.182434f,-51.941048f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(49.745323f,85.16685f,100.0f,13.81444f,2.086372f,38.71325f,4.540631f,4.348084f,10.765333f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(49.965614f,-10.094322f,-35.892162f,23.59045f,1.1513568f,-5.6840243f,43.24483f,-3.2066772f,53.66266f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(50.169502f,65.555595f,96.742546f,35.122417f,15.310333f,17.021019f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(50.22159f,-3.2740588f,100.0f,11.843001f,-2.3915946f,-4.4603734f,-0.45798665f,-13.674949f,-51.850212f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(-50.251453f,-1.218766f,100.0f,-25.921612f,-22.197868f,37.375786f,-31.237123f,-99.02688f,95.197495f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(50.97195f,62.272038f,6.8821406f,41.61576f,91.234055f,41.16935f,24.25704f,55.4124f,-61.854958f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(51.623898f,40.141407f,-99.87624f,21.21607f,21.41026f,-1.82153f,11.830227f,26.105087f,71.17986f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(51.809036f,77.33762f,95.654755f,29.898527f,24.441607f,97.3602f,43.343468f,61.18542f,0f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(52.20481f,99.6981f,-79.19617f,9.121152f,-2.1793396f,-17.577906f,-13.540864f,-99.9587f,71.1436f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(52.221493f,100.0f,100.0f,8.885973f,-34.673832f,0f,0.20913453f,-8.049435f,2.2669585f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(52.417274f,68.38507f,40.729263f,41.28403f,80.39374f,-100.0f,32.325115f,88.016426f,-100.0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(52.573708f,95.9173f,-34.518093f,14.377509f,13.571013f,-7.09466f,-8.634648f,-48.916096f,-7.4315605f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(52.904102f,79.51028f,0f,32.106136f,9.439453f,21.483824f,66.080986f,-6.418421f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(52.967316f,77.50031f,-41.566273f,34.36895f,66.83232f,7.663401f,8.869859f,1.1104852f,-71.26025f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(53.471977f,23.80773f,23.505108f,90.08018f,-81.74616f,-88.59374f,-82.39256f,0f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(53.72913f,38.54739f,0f,75.09063f,-60.051632f,0f,-98.64625f,0f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(53.738625f,74.9851f,45.10172f,39.9694f,20.971155f,0f,39.908672f,0f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(53.942226f,97.08548f,-91.78121f,18.68343f,32.60633f,83.08127f,-11.814842f,-68.42484f,2.1822927f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(54.024445f,61.390602f,2.92477f,54.707184f,88.61319f,-27.239155f,26.279448f,50.410606f,86.749794f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(54.735584f,-17.840109f,0f,-47.501972f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(5.533268f,-89.69185f,-63.83488f,11.824919f,16.50472f,5.2725735f,25.261686f,24.241383f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(56.495697f,55.169903f,-0.885109f,70.81287f,65.06902f,-41.896732f,22.867361f,20.656578f,-5.3100386f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-56.683144f,18.460135f,0f,-19.226992f,-28.605022f,-72.023056f,8.380204f,-41.630173f,0f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(56.991066f,86.36096f,43.677193f,41.60331f,7.576707f,0f,-64.65617f,-53.504982f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(-57.20885f,58.2754f,0f,-57.597694f,-14.611558f,0f,-21.667734f,-29.073242f,-88.298004f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(57.275547f,39.752087f,23.049982f,89.3501f,-21.317179f,-47.552162f,36.94885f,58.445297f,2.7633152f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-57.51964f,55.25872f,0f,-81.359535f,91.5726f,0f,-0.2601157f,58.087845f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(57.80955f,69.81266f,25.464724f,61.425552f,95.97635f,-82.16566f,91.91631f,79.57399f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(57.86599f,83.96525f,-0.42840943f,47.49871f,89.416916f,-14.035967f,42.71194f,-100.0f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-58.261837f,-57.11106f,0f,22.482927f,-29.794725f,0f,-0.078026906f,-22.795034f,47.73258f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(58.28159f,34.15399f,-22.688286f,98.972374f,1.0226657f,47.61719f,61.706516f,94.09268f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(58.285675f,77.50431f,0f,-2.421659f,28.589087f,0f,8.525671f,8.615709f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(58.30404f,94.78196f,-100.0f,38.4342f,63.06523f,28.00884f,32.36753f,91.03593f,94.628105f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(5.836377f,23.345509f,53.263206f,-100.0f,-84.724525f,0f,-29.325405f,-17.301624f,44.843433f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(5.890119f,-0.2578522f,-6.921528f,-76.18167f,-100.0f,-9.825848f,100.0f,61.64819f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(59.535053f,31.255972f,20.123232f,13.677449f,1.9995506f,4.0414667f,-6.824809f,-40.976685f,22.900274f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(60.80309f,-8.677866f,-27.821741f,7.8194375f,7.00792f,-22.026894f,-36.53326f,50.917004f,69.01805f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(-62.621704f,100.0f,0f,-11.531879f,22.823961f,4.9897747f,-6.329775f,-13.787219f,-79.81042f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(-62.65911f,19.194359f,0f,-1.1981405f,35.032066f,30.718246f,22.834482f,-22.718153f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(63.65121f,-83.0815f,0f,-54.76514f,-39.195747f,0f,-1.2637581f,0f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(64.148766f,71.80313f,28.595444f,84.791916f,94.46833f,-57.421356f,25.004778f,15.227191f,55.097107f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(-65.37299f,39.023632f,0f,32.43825f,-12.662369f,0f,12.584287f,17.898893f,71.67365f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(-66.72784f,14.811069f,0f,-17.26147f,10.450483f,-32.11398f,-9.088807f,-19.09376f,-77.73671f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(66.79817f,-100.0f,0f,-4.007681f,-94.88697f,100.0f,12.058075f,52.23998f,-34.18788f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(68.1274f,-7.8643694f,0f,16.459236f,46.11975f,0f,-48.41021f,0f,0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(6.9995565f,-44.014694f,-1.0711517f,-27.98708f,-47.438667f,0f,4.381851f,45.514484f,0f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(70.87958f,-16.748747f,0f,37.16022f,35.33799f,83.21806f,42.423325f,55.53671f,0f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(7.170045f,-41.730698f,12.044197f,-29.589123f,-95.175735f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-72.358925f,28.82283f,0f,62.752655f,96.50988f,23.029558f,19.571672f,15.53403f,-53.945427f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(73.040146f,70.72081f,0f,26.177948f,-44.00564f,-60.348923f,75.67729f,49.921623f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(73.164795f,57.971222f,0f,-4.1662073f,8.788224f,-38.280655f,-98.61785f,-80.70551f,0f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-7.428327f,93.29185f,-6.750088f,-4.2790685f,1.4259802f,-43.132225f,-11.113926f,-40.176636f,16.444918f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(7.472093f,-100.0f,0f,-3.1631632f,-17.096273f,-53.761887f,-3.028472f,-8.950725f,-15.678153f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(75.14785f,-10.40757f,-75.036606f,19.12745f,-10.440689f,-78.56576f,11.802643f,28.08312f,19.140873f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(-75.218475f,68.53231f,0f,-20.014797f,11.311889f,57.000313f,-16.152609f,-44.595634f,76.47383f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(75.66184f,91.01654f,0f,5.975622f,-67.69035f,47.13812f,3.4682848f,7.897517f,95.81213f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-77.37962f,56.14489f,51.41257f,-17.018597f,11.031359f,-5.1149716f,-1.7261207f,10.114113f,-82.90382f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(7.902137f,104.23329f,0f,-24.532795f,-100.0f,-107.6556f,-6.0333133f,-0.21358489f,105.15184f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(80.25874f,-12.063524f,15.997078f,22.97133f,12.59159f,66.28992f,-0.96500754f,-26.831362f,59.3607f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(80.88286f,-76.98447f,0f,19.716778f,16.79313f,0f,-92.7874f,60.17552f,0f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(81.68113f,-3.7964811f,0f,-1.3515716f,-76.01216f,5.119534f,-11.0752535f,-42.94944f,-45.088577f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-81.72468f,-99.83489f,0f,41.186523f,30.415308f,0f,23.6628f,-85.77937f,0f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(83.148705f,-36.80516f,0f,20.381098f,-20.403677f,0f,13.169574f,32.297195f,0f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(8.406644f,-90.37913f,0f,-20.550802f,24.622765f,0f,12.311995f,69.79878f,0.6375299f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(-86.14326f,-61.33364f,-27.490969f,-26.392952f,2.7335281f,28.090654f,-22.162075f,70.57005f,56.03142f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(86.58338f,96.15377f,0f,9.981142f,-68.288284f,82.3296f,21.629473f,76.53675f,0f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-86.826f,-32.47213f,0f,-32.934525f,-27.5397f,0f,-81.618484f,0f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(-8.743173f,-36.759106f,0f,-67.94076f,-83.450516f,0f,-64.6125f,18.424784f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(88.26202f,100.0f,0f,23.818727f,100.0f,0f,15.222529f,37.071392f,33.063038f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-8.861524f,-55.319073f,-44.822655f,-80.12702f,48.038376f,0f,-24.438295f,-17.626158f,64.70981f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(89.67153f,40.63909f,0f,68.08962f,29.80865f,0f,18.314705f,5.169196f,-27.446571f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-89.685905f,91.58235f,0f,-20.512562f,-13.740853f,0f,-7.4646015f,-9.345845f,0f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(89.89417f,53.578987f,0f,-35.74302f,9.7256155f,0f,-78.59136f,9.330568f,0f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(90.924675f,-66.11044f,-39.518185f,22.251938f,-10.10921f,-7.095557f,8.192289f,10.51722f,43.985798f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(92.44279f,33.15733f,58.450573f,36.76631f,27.698965f,-30.05548f,26.923502f,70.9277f,54.281708f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(96.35466f,53.360878f,0f,12.913941f,-3.0172973f,-5.7248507f,-41.681595f,-17.109308f,0f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(96.39008f,99.46415f,0f,15.793554f,-34.65873f,100.0f,1.4428592f,-10.022118f,-6.872597f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(97.19926f,72.61442f,0f,-46.547287f,60.637238f,0f,-19.385231f,-30.99364f,39.87509f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(9.8345f,-49.870808f,23.609982f,-10.791191f,-58.427986f,56.02665f,5.4287195f,32.50607f,61.227856f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(99.372604f,19.302275f,99.96988f,35.791073f,34.805885f,46.040535f,8.985795f,38.089664f,49.386383f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-99.49019f,7.225789f,0f,-47.446033f,-71.15852f,-75.259415f,-19.13543f,-29.09568f,-26.088774f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(99.669136f,-100.0f,0f,-2.3527064f,-100.0f,-73.186325f,-9.079963f,-33.967113f,-26.78836f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(99.987305f,21.491196f,0f,50.9127f,85.894264f,45.6523f,17.769232f,20.164225f,0f ) ;
  }
}
