import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-15.295069f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(66.71145f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(67.462746f ) ;
  }
}
