import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,4,-148,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,9,9,3,0,1529,1552,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(-356,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(3,7,0,4,-87,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(4,-251,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(4,7,6,-304,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(5,4,1,7,4,9,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(5,5,1,3,8,981,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(5,6,5,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(5,95,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(5,9,8,1,1622,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(617,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(6,6,7,4,1,-1658,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(6,7,6,8,982,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(7,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,2,5,6,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,4,792,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(8,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,0,0,943,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(8,1,703,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(8,-2,1,7,1,112,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(8,5,5,0,3,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(8,828,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,5,7,322,0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(9,8,6,8,7,111,-200,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(993,0,0,0,0,0,0,0 ) ;
  }
}
