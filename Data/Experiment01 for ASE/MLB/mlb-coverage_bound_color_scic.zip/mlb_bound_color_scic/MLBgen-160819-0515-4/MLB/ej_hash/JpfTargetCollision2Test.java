import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(564,-17,523,293 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-74,-924,-90,528 ) ;
  }
}
