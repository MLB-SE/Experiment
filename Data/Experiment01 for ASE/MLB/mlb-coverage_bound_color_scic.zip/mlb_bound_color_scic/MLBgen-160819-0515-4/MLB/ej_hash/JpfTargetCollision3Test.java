import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(24796,0 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(834,992 ) ;
  }
}
