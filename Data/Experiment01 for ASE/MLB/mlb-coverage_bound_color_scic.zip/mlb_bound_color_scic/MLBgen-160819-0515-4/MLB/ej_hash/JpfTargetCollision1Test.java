import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-32,-1416,-161,11,-46,986 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-603,-888,-716,395,772,612 ) ;
  }
}
