import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-26076,1148,-17 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(343,45,-872 ) ;
  }
}
