import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(20.187111172235504 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119125 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(42.068045965022094 ) ;
  }
}
