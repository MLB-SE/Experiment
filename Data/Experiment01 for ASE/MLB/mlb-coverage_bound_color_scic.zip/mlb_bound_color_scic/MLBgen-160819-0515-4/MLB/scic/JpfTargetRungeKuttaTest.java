import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2719.276594413864 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2725.894763015041 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2730.262307224928 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2731.6474745654823 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2738.7641826641193 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2740.8363532509084 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2741.5496579874216 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(38.53820022624001 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(4.158178528759507 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(42.613022450232535 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-62.87858673316264 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(67.84007512893254 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(73.9710719958527 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(-81.62597074744923 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(84.40659571537904 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(89.98435228195214 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(93.7819895472735 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(93.95583894207539 ) ;
  }
}
