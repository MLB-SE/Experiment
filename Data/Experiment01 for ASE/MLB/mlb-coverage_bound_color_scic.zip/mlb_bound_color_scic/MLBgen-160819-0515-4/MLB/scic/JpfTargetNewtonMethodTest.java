import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-10.249997186331566,-93.41281305246005 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(29.379724699597688,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-3.751868032913883,61.67105303314646 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-38.005799523056915,-88.5558075970361 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-42.171483814367704,2.142060105713938 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-50.24244108751744,0.007622260482975207 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(663.1323457232941,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-6.917639803731234,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(72.01428828045871,44.80864519583278 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-75.75,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-85.33201976081908,91.25494012493726 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(87.15211694212644,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-8.750012609792597,0.0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-94.35553602939224,0.11056877735103399 ) ;
  }
}
