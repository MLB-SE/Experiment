import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-10.999515775646909,40.08223438083247 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(22.39946220744153,56.643681915353795 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-68.68475037317721,7.790910891868847 ) ;
  }
}
