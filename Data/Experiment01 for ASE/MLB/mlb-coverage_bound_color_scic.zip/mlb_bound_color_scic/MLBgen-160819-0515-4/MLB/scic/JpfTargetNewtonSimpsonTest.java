import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.08210376661617147,-53.11872948596654 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.3408231327741902,-89.69043835936739 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.3689752035658671,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(0.4231977300336922,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(0.7915539399052847,0.23674885127268652 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-13.004327346942375,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(1.6448549800740482,-94.61693955205995 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.6448549801004906,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(20.573487513803656,-50.6685274687559 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(24.075886264382817,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(25.863246115155405,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(2.797581538425348,-6.380660792078771 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(3.0775758601558607,-76.97430250834587 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(3.0842131017367365,-92.87066668442017 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-32.780297894439656,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(3.325160500529506,0 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(33.329327139302734,0 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(37.95107014813331,-16.828492300875126 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(66.38103681144528,0 ) ;
  }
}
