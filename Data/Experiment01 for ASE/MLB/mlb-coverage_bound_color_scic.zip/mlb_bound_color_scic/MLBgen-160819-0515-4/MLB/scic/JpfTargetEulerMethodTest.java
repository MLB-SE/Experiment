import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.248781741660103 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-3.7867047529342983 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(74.47791442735644 ) ;
  }
}
