import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-170,-930 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-478,-922 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-858,717 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(939,-159 ) ;
  }
}
