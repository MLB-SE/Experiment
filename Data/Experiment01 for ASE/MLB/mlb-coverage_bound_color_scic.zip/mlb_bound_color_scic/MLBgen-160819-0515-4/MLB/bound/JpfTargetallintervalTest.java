import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,1,67,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,2,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,3,3,4 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,566,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,95,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,2,3,2 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(2,4,1,-744 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(2,4,4,62 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,-194,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(3,2,4,354 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(3,2,-87,0 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,3,3,0 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(385,0,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,1,3,4 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(4,4,54,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(-565,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(986,0,0,0 ) ;
  }
}
