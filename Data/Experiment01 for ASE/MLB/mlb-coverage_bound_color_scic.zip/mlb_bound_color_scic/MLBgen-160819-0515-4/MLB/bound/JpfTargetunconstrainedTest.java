import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,2,994,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(10,-888,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(201,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(2,1,6,9 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(2,2,1,348 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(2,3,-352,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(2,8,10,110 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(3,1,10,4 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(3,423,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(4,456,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(5,10,8,2 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(5,7,8,-473 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(7,5,9,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(8,1,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(8,1,393,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(-878,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(956,0,0,0 ) ;
  }
}
