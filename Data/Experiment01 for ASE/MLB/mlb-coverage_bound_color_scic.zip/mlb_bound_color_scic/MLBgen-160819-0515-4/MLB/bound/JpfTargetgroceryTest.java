import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(100,9,15,587 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(154,698,703,1159 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(176,512,595,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(179,96,106,330 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(236,314,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(24,457,-597,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(291,13,70,337 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(294,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(403,158,977,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(-41,0,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(417,529,632,387 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(426,906,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(442,486,169,479 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(462,-913,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(470,511,164,-324 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(497,150,242,329 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(57,26,627,1 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(677,281,689,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(87,325,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(92,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(984,0,0,0 ) ;
  }
}
