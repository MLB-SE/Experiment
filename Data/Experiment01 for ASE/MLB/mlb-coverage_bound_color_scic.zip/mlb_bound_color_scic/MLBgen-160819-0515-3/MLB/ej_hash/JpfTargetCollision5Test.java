import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(0,-25254 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision5(-143,-378 ) ;
  }
}
