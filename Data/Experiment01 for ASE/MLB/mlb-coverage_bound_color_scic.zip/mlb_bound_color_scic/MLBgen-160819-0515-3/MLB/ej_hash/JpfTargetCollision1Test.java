import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(612,-735,630,182,-521,201 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-778,768,637,-808,1717,48 ) ;
  }
}
