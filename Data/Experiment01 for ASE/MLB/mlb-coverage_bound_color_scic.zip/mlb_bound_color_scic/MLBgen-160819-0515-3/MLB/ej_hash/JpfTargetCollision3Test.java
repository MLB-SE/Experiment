import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(26803,419 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(8,-662 ) ;
  }
}
