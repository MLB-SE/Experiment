import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-10.224941278309657 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.994622194607023 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-89.47804300108426 ) ;
  }
}
