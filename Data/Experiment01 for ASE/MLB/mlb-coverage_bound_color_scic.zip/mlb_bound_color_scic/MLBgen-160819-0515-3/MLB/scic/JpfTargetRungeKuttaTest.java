import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(22.248802218051367 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2716.310875832122 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2731.471808488417 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2732.7517621971115 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2732.7694421613237 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2735.7138776781403 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2743.016744918898 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(32.14602313871359 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(-72.64600688292253 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-73.23422779159516 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(74.09360664005112 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-75.14177738685927 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(77.92549092638649 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(88.3610882914123 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(91.79578851371554 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.4938208756092 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(95.4860930736989 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(95.84867541442489 ) ;
  }
}
