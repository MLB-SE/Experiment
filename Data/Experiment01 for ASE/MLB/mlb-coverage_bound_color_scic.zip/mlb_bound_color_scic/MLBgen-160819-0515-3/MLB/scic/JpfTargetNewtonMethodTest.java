import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-30.176750925183214,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-32.650937530181245,0.1289312966379157 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-34.329762778614764,-6.057462598524637 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-36.05294112556698,81.13394052539994 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-42.25,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-46.75,0.0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-46.75,-0.054811611809338315 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-48.267677565730004,55.2586886285315 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(59.79717153283033,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(64.30696836556757,86.4032224170216 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-66.25,65.61247894467513 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(79.79618851585008,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-85.98005648065464,0.5581959327135024 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(96.97488038589157,0 ) ;
  }
}
