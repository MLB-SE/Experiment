import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(19.270731325411575 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119125 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(47.77575489440096 ) ;
  }
}
