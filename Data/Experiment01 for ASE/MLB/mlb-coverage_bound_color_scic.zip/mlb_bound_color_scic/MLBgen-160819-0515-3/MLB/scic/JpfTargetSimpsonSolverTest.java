import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-16.136581175511772,13.92712441985761 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-18.538050575937888,16.84172186950493 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-22.312570163158,-30.29725789441659 ) ;
  }
}
