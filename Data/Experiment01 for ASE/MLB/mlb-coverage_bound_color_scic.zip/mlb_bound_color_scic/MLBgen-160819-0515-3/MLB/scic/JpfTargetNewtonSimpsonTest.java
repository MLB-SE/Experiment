import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.7255528162054077,-37.824200431642765 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-10.120805571310697,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-11.860215260997535,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-12.179365846535433,-83.6203431007355 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-1.8370637651015045,-92.38606034054548 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-1.9525591720749276,13.61866248013581 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(2.1484679717294313,-22.8240895802617 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(33.57566079301762,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(34.050410392207056,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-39.94304154381367,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(7.599111777431133,-31.22772972937902 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-9.312900122834037,35.82017477112143 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-9.613245149356558,63.97631275203011 ) ;
  }
}
