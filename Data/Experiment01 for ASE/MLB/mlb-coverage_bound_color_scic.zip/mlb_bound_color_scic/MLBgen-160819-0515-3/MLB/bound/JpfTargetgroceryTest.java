import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(13,27,118,553 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(151,14,416,130 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(168,343,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(327,500,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(329,502,659,984 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(355,240,535,18 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(44,476,159,32 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(45,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(475,-379,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(477,647,880,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(480,557,471,186 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(483,5,223,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(494,131,438,210 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(520,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(537,100,137,-645 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(604,66,-376,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(620,6,259,0 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(622,331,389,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(-759,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(875,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(9,795,0,0 ) ;
  }
}
