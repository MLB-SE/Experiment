import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,3,1,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,2,176,0 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(2,2,2,-620 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(2,4,1,4 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,4,2,1 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(2,845,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,1,2,398 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,2,1,3 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(3,3,985,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(3,4,1,314 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,4,-693,0 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(3,790,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,-10,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,3,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(605,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(-619,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(973,0,0,0 ) ;
  }
}
