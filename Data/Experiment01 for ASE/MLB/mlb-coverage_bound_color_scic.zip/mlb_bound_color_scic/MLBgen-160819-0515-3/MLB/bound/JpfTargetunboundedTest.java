import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-183,177 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(260,562 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-814,-447 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-859,-846 ) ;
  }
}
