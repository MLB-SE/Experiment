import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(3,3 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(5,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(5,123 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(5,207 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(5,-350 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(688,0 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(926,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(-994,0 ) ;
  }
}
