import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.5096116f,-76.96884f,0f,-12.381438f,-28.377047f,9.278709f,-21.658318f,-74.25183f,-45.428993f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-100.0f,-100.0f,0f,83.48892f,25.397343f,-50.214344f,23.921667f,12.197745f,-0.5280291f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-100.0f,100.0f,-76.5384f,-30.633503f,-0.9447091f,-17.421633f,-21.5893f,-55.7237f,-27.248352f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(100.0f,-25.36796f,0f,-33.92445f,-74.556564f,-57.007977f,-14.360355f,-23.51697f,-5.1509576f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(100.0f,97.91301f,0f,43.56129f,44.87788f,-33.05757f,29.367289f,73.90786f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.561461f,-61.731712f,44.727356f,3.9775567f,-43.415955f,0f,9.770356f,35.10387f,77.86329f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(10.715238f,-59.72584f,100.0f,6.99235f,-8.796765f,-79.66493f,26.050928f,97.211365f,42.2277f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(11.166482f,-45.20604f,100.0f,-10.128035f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-11.356967f,97.98462f,0f,4.392165f,81.380104f,95.05828f,12.978219f,47.52071f,95.72452f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-114.999794f,104.18717f,0f,-37.028603f,-20.744503f,-28.582294f,-12.398773f,-10.554759f,-9.784264f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.914249f,-95.145424f,-30.937138f,42.802418f,-79.8403f,0f,98.64316f,0f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(12.727744f,-46.448116f,0f,-13.364339f,11.418745f,0f,-96.9349f,0f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(12.7638235f,-100.0f,39.916687f,-6.7990246f,-33.360706f,-7.0459642f,-6.5992155f,-19.597837f,-38.431427f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-12.834898f,-100.0f,57.004333f,-51.339592f,12.451104f,99.95194f,-12.056008f,3.1155612f,12.067148f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(12.897739f,48.110596f,0f,4.7440534f,-67.679f,41.834988f,73.75748f,24.555984f,0f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(13.721956f,16.436224f,47.222393f,-61.548397f,-95.19945f,-45.81427f,-23.873877f,-33.94711f,-16.715109f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(13.7946205f,-42.614876f,0f,-2.2066443f,-99.921234f,0f,-0.36270648f,0.7558184f,19.787914f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(13.912333f,44.414246f,13.570792f,-88.764915f,-43.409824f,0f,91.694374f,-75.037506f,0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(-13.966058f,26.913166f,0f,-26.962955f,-75.71439f,100.0f,-18.171371f,-45.722534f,-89.00437f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(13.983783f,-51.38845f,0.22705698f,1.7448008f,-13.027366f,-24.812155f,6.0227857f,22.346342f,-86.44831f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(14.217359f,-63.18974f,26.385027f,20.059175f,-35.178253f,0f,-13.841123f,-75.42367f,42.41741f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(14.690884f,-17.719803f,0f,6.83282f,5.9749384f,50.297405f,6.6654587f,19.829014f,82.915276f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(15.029883f,29.931314f,86.75848f,-69.81178f,-82.0631f,-3.3135757f,-25.265614f,-31.250673f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(15.436616f,12.039229f,-99.73052f,-50.292767f,13.864582f,0f,-8.412338f,16.643414f,63.66312f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(15.615284f,-58.178513f,0f,28.2537f,68.57193f,-27.72373f,28.827583f,88.68634f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(15.615663f,-29.454058f,-26.64943f,-8.083294f,-14.276644f,42.501633f,-33.67219f,36.942303f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(15.725998f,13.350508f,-100.05064f,-50.446514f,-225.82224f,0f,0.7719359f,53.534256f,73.37521f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(-16.590023f,10.839055f,0f,-7.329635f,-9.261367f,-40.295135f,-3.467151f,-0.25975406f,0f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(16.594254f,30.479874f,0f,-20.698454f,19.963415f,0f,-0.62376744f,18.203384f,53.47389f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(-16.72772f,89.91543f,-100.0f,0.22819956f,13.777203f,-50.259884f,3.863316f,15.225065f,43.259743f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(16.7616f,-46.904434f,-99.57696f,13.950837f,-24.725056f,-6.845697f,63.766804f,-59.100925f,96.91923f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(16.776833f,70.35579f,82.86687f,-103.22814f,81.70886f,161.21477f,-260.67908f,0f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(-16.851402f,-15.80745f,0f,75.7929f,-3.3964076f,0f,-1.6329596f,-82.32474f,21.713276f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(17.09679f,25.803534f,33.71638f,-57.41637f,40.95989f,0f,-10.896602f,13.829963f,25.256565f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(17.417004f,-12.55991f,27.25053f,-17.772078f,70.82174f,-86.3296f,-0.18604165f,17.027912f,-2.5240548f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(-17.458525f,31.732746f,8.266898f,21.269861f,2.9793136f,-17.791834f,99.55866f,-23.29352f,49.473488f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(18.128918f,-26.277054f,61.234222f,-1.2072716f,-14.334053f,-7.262792f,-8.623952f,-22.589094f,-75.275955f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(18.86256f,4.12999f,-71.51916f,-28.679749f,-55.283237f,-35.658646f,-12.26764f,-20.39081f,-14.012364f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(19.262138f,-19.941536f,-99.86803f,-3.0099113f,-32.421116f,7.7145643f,1.1193305f,7.4872336f,61.250717f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(19.511856f,22.124453f,-100.0f,-44.077026f,62.566658f,100.0f,-0.9160964f,40.41264f,100.0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(19.522312f,-30.473635f,-42.985245f,8.56288f,37.609993f,92.756035f,-22.880789f,79.594696f,-65.696945f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(-19.541346f,-100.0f,3.6204643f,-25.523392f,-57.013206f,-25.89677f,-25.539015f,-76.63267f,-50.19434f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(19.703903f,-23.870005f,-69.694016f,0.43523365f,-15.399291f,-27.47249f,-2.5636687f,-10.689906f,-24.796658f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-19.833326f,100.0f,0f,-36.399834f,-96.021034f,-7.340869f,-29.744967f,-82.58003f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(20.324339f,37.130745f,29.306602f,-55.8321f,-1.0383272f,-19.904932f,-15.36982f,-5.6980057f,-6.4007344f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(20.837584f,-8.229764f,38.437542f,-8.419904f,-40.3686f,0f,-14.148598f,0f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(-21.178375f,20.142431f,0f,16.407692f,-49.138542f,0f,-0.84052366f,-19.769787f,-29.10008f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(21.7221f,30.625526f,-47.529682f,-43.73713f,23.88805f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(21.777388f,10.216909f,2.7289693f,-23.107368f,-83.63872f,-99.99998f,-15.487147f,-38.84122f,-56.239f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(22.082352f,11.706947f,59.543186f,-23.37754f,-92.933426f,-43.658768f,-22.659086f,-67.258804f,100.0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(22.235088f,-18.674747f,-27.135862f,-0.13023405f,-7.675486f,-0.31270498f,-15.080539f,-11.584258f,33.560528f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(-22.381037f,-12.408856f,0f,-88.12549f,14.865306f,0f,23.45734f,0f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(22.546398f,51.89947f,0f,26.165228f,98.3347f,-65.74513f,-16.220186f,-91.04597f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(22.551971f,1.2200618f,-96.01795f,-10.868981f,-48.13554f,-132.83832f,-18.005978f,-61.15493f,8.733998f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(22.684053f,-15.400593f,24.707842f,6.1368093f,46.153603f,0f,18.37989f,67.38276f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(22.747778f,-18.714333f,43.310814f,9.705442f,-0.12530723f,40.093285f,16.199299f,-31.585625f,-13.709506f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(22.891037f,27.484976f,51.572197f,-35.92083f,-64.52333f,-29.93007f,2.9365327f,47.66696f,36.141167f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(23.227428f,1.0000641f,-94.77535f,-8.090347f,-51.19466f,-65.08693f,-6.3611746f,-17.354351f,-11.861569f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(23.25924f,53.99585f,12.874563f,-60.95889f,-53.096523f,0f,-18.334251f,-12.3781185f,-28.656736f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(23.282047f,-9.759542f,99.99933f,2.887732f,-22.09366f,8.909734f,-0.6761636f,-5.5923862f,0.40027812f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.397537f,-3.9652007f,42.10246f,-2.3959134f,-58.23691f,51.684883f,5.224407f,23.390196f,146.96054f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(23.450195f,66.647736f,0f,-57.2953f,-43.091705f,0f,3.6111627f,-78.48793f,0f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(23.90263f,3.9750197f,-53.08706f,-8.364502f,-43.648605f,0f,12.3786545f,57.87912f,-20.838627f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(24.050861f,52.916695f,-20.108727f,-56.713245f,36.007687f,0f,-54.897526f,0f,0f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(24.21863f,28.738537f,35.227837f,-31.864014f,-44.49232f,-100.0f,2.6726298f,0f,0f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(24.423702f,-29.846836f,0f,-1.6543436f,-30.31448f,-72.75223f,-4.698518f,-17.139729f,-33.545914f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(24.661556f,12.45246f,23.742645f,-13.806229f,-70.374695f,-44.068542f,-9.51179f,-24.240965f,-17.077372f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(25.12686f,8.7923155f,0f,-16.556374f,-100.0f,-37.781982f,-7.138118f,-11.996097f,59.153732f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(25.48413f,1.7846081f,24.431286f,0.1519134f,-13.151877f,-7.4937196f,-11.7246f,-47.050312f,-45.583176f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(25.50747f,28.13333f,71.87085f,17.263481f,37.35604f,23.839182f,6.1904125f,80.18817f,-8.734681f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(26.273943f,26.437078f,79.19947f,-21.341303f,-99.7251f,100.0f,-11.914056f,100.0f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(26.530584f,19.877312f,25.241882f,-13.7549715f,-72.26322f,-95.207695f,-6.2527757f,76.25495f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(26.711166f,-85.29954f,0f,31.31356f,93.5603f,-71.522705f,4.9827724f,-11.38247f,-35.470592f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(-27.470217f,-43.17187f,0f,-39.439728f,-73.40824f,0f,-4.5635247f,21.185629f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(27.52497f,-69.77394f,-10.083073f,79.87381f,-6.383104f,0f,-8.161769f,52.369427f,0f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(27.670479f,-34.551983f,0f,26.185572f,69.1215f,80.92558f,7.9503074f,5.615658f,-54.609177f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(28.073013f,9.276705f,-20.194239f,3.0153465f,-14.620148f,-62.211235f,-1.3865148f,-8.561406f,-18.230906f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(28.34643f,13.513607f,-63.068256f,-0.12788615f,-18.836086f,-10.771031f,-10.021889f,-100.0f,0f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(28.508604f,92.34214f,0f,72.96095f,99.106674f,0f,82.935585f,0f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(28.750387f,25.81827f,40.400864f,-10.81672f,-65.87817f,29.965893f,-7.30058f,-18.385601f,-0.36365372f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(28.79005f,21.031183f,-40.56237f,-5.870984f,-4.189504f,20.932312f,-48.08448f,-52.85053f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(29.220097f,32.931545f,92.125275f,-16.05116f,-89.619194f,100.0f,-3.8759778f,0.54725015f,95.68417f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(29.36045f,-21.344852f,-11.23771f,12.094311f,0.94955957f,-3.581875f,18.067234f,16.630655f,-34.28513f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(-29.740162f,-68.41258f,14.524235f,-29.744886f,-19.847343f,26.591112f,-69.39204f,-7.8230176f,53.10152f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(29.923254f,-39.385605f,0f,-12.256702f,-74.34877f,-13.562313f,-4.6012964f,-6.148483f,-37.33079f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(29.940044f,35.125484f,31.965887f,-15.365308f,-21.403994f,-100.0f,-69.997284f,-41.942577f,0f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(30.668804f,-43.266415f,-25.207659f,65.94163f,-68.51042f,0f,91.15266f,44.393326f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(30.802206f,30.33412f,37.074154f,-7.125294f,-56.680374f,-60.90768f,-2.6230106f,-3.3667479f,45.83639f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(31.042688f,27.510427f,26.009636f,-3.339676f,-47.010612f,-35.129032f,2.60922f,13.776556f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(31.302427f,25.800022f,44.76673f,-0.59031296f,-72.86907f,26.056684f,39.205395f,0f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(31.360075f,49.92461f,-4.000299f,-24.484312f,44.530277f,0f,-6.0212274f,0.3994021f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(-31.722645f,51.904922f,-99.99997f,-17.981142f,-18.018269f,-35.24336f,-22.183659f,-70.753494f,-22.955194f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(31.803904f,12.677316f,9.44762f,14.538301f,-90.54226f,-74.88683f,-38.603558f,-35.043915f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(31.827553f,27.385803f,99.88741f,-0.07559432f,-30.202314f,-70.34572f,-1.9276156f,-7.634868f,1.5904559f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(32.443417f,36.00066f,-74.071884f,16.294626f,30.77181f,79.23346f,1.96328f,-8.441506f,-75.725365f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(32.49489f,30.40965f,71.360214f,-9.204115f,-10.370597f,15.991384f,-58.94075f,-78.679306f,36.976917f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(32.527836f,28.156784f,2.975067f,1.954665f,-22.877642f,-40.373558f,-1.8315327f,-9.2806835f,-12.413561f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(32.64427f,44.55571f,65.752815f,-13.978625f,-53.573746f,0f,-11.40289f,-31.632935f,-61.5551f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(-32.840607f,-29.826094f,0f,3.8287554f,33.122272f,84.569016f,15.033357f,1.3784304f,0f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(33.14306f,31.972256f,17.83544f,0.59997886f,-23.489174f,-100.0f,-7.2539697f,-29.615858f,-89.000404f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(33.221092f,26.985294f,100.0f,5.899079f,-9.5553465f,-64.92895f,-0.069431886f,-6.1768064f,99.99603f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(33.34774f,36.504635f,56.410313f,-3.1136777f,-43.73951f,24.511118f,-2.0629387f,-5.138076f,73.62906f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(33.413208f,22.412756f,21.707512f,11.240073f,-57.912823f,-14.234949f,69.45991f,-70.96193f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(33.459843f,51.16096f,46.872505f,-17.321587f,24.311495f,-3.4062111f,2.1668184f,25.988861f,79.4266f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(33.580845f,31.284567f,38.308887f,3.0388067f,-46.252865f,63.21434f,24.827248f,96.27019f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(33.628403f,-67.22769f,0f,8.888583f,-62.94954f,127.18664f,64.87547f,-4.921487f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(33.66833f,36.141068f,24.725395f,-1.4677409f,-13.829459f,-64.209206f,-2.3356354f,-7.8748007f,-15.334107f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(34.000404f,45.63187f,-4.8571024f,-9.630248f,-2.6879117f,-5.435456f,-69.83349f,-41.317814f,-14.196809f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(3.4256392f,-72.90672f,23.938368f,-13.39072f,-54.779064f,-9.692403f,-2.209456f,4.552896f,-37.31672f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(34.27953f,1.4230058f,17.783367f,35.695114f,-146.38332f,-47.730503f,4.445651f,-105.328865f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(34.351154f,37.46559f,9.717933f,-0.060971193f,-52.15113f,41.280617f,17.55609f,70.285324f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(34.481728f,56.55189f,0f,-18.624983f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(34.910877f,25.654928f,-10.817649f,13.988574f,8.958005f,0f,5.542667f,8.182093f,18.2277f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(35.044933f,29.367006f,0f,7.8530607f,71.368576f,0f,7.450937f,21.950687f,8.983233f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(35.13724f,29.701984f,-54.79419f,10.846982f,-6.084455f,-8.3039875f,14.33514f,-56.582798f,27.662697f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(-35.358585f,34.614216f,-46.291958f,-13.154789f,-19.674852f,-23.667389f,2.414281f,-76.49145f,-28.702745f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(35.37463f,16.233025f,-44.34019f,27.74252f,54.534554f,242.44948f,11.669355f,18.929281f,12.758084f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(35.461033f,35.71674f,-100.0f,6.1273904f,-7.7822886f,-54.169147f,-3.1691866f,-18.804136f,-0.09522592f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(35.548508f,18.800507f,-43.556923f,23.39352f,-32.012913f,0f,-48.099964f,-8.474272f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(35.916256f,33.73727f,-14.654884f,9.927749f,13.6524105f,64.7151f,-9.85767f,-53.770477f,58.50916f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(36.068626f,83.84369f,-31.361055f,-39.569183f,-65.936035f,0f,-52.256714f,50.91338f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(36.08773f,36.032417f,-56.198055f,8.318498f,24.026522f,35.18778f,-26.840261f,16.567392f,100.0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(36.164925f,42.926746f,55.03749f,1.7329564f,-19.495426f,-94.70646f,-9.737674f,-5.613922f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(36.234383f,32.36186f,-18.441532f,12.575648f,11.695006f,4.925274f,2.3732185f,-3.082774f,26.447744f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(36.41566f,65.4348f,100.0f,-19.77216f,-15.504296f,-12.812738f,-100.0f,-45.73926f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(36.448093f,39.117905f,6.365153f,6.6744742f,-60.76137f,100.0f,51.011173f,80.03088f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(36.5252f,48.025066f,0f,-52.33023f,84.05069f,0f,26.139103f,-74.569145f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(36.705677f,42.090984f,48.09684f,4.7317038f,-16.438587f,48.48864f,-1.3400581f,-10.091936f,-22.589111f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(36.991917f,48.175392f,0f,29.519129f,38.296436f,0f,42.788162f,0f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(37.568623f,44.618954f,60.73891f,5.6551943f,-19.831724f,59.016796f,4.8838773f,13.880316f,-68.62883f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(37.61187f,54.034367f,52.146076f,-3.5868936f,26.379517f,-27.619617f,-78.33896f,46.531773f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(37.77102f,56.051075f,-54.011192f,-4.9670043f,7.670563f,-49.755928f,-65.30959f,-100.0f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(-3.7891195f,39.172394f,0f,32.775776f,6.065674f,0f,8.514098f,56.428097f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(37.904903f,19.920605f,0f,5.848448f,48.99838f,51.180935f,-63.50949f,-49.94467f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(38.101326f,36.144028f,29.941376f,16.261284f,-23.466597f,-32.130196f,50.4104f,56.1951f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(38.89933f,48.654755f,50.677814f,6.9425654f,68.101685f,0f,-75.590256f,85.94983f,0f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(39.412594f,38.248207f,-18.681658f,19.402176f,31.964981f,64.403534f,6.2311287f,5.5223384f,-16.106756f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(39.440586f,-55.01924f,0f,-7.103477f,-21.84443f,11.175786f,-46.010063f,-36.43079f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(39.480762f,58.66976f,14.863087f,-0.74671185f,-41.03777f,-100.0f,-1.4298388f,-4.9726434f,22.577038f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(39.53352f,32.437756f,-51.28421f,25.696325f,38.05322f,3.617467f,25.198563f,90.46133f,27.700857f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(39.725773f,46.48296f,37.12241f,12.420124f,9.084449f,-14.406208f,0.87047344f,-8.9382305f,-45.70774f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(39.85409f,36.001926f,9.175185f,23.41444f,-5.021566f,-99.301186f,66.79813f,30.280249f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(40.15918f,23.13572f,30.782404f,37.500637f,-78.398705f,-0.15795f,4.4423113f,-19.731392f,-4.9723353f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(40.32853f,38.051044f,72.8473f,23.263071f,30.813646f,-2.4368913f,21.910107f,64.37736f,95.1237f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(40.77458f,30.786715f,39.117134f,32.311592f,13.733983f,-2.7540946f,74.73781f,-5.4082785f,-19.311386f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(41.18015f,-2.312018f,-52.370007f,67.03262f,-98.05821f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(-41.221756f,35.9759f,46.29179f,-12.723281f,-0.9370412f,-4.7867627f,-8.734325f,-22.214022f,56.861233f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(4.131236f,-76.775f,-42.021847f,-6.700056f,28.653267f,0f,87.91967f,0f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(41.338684f,57.834114f,59.922333f,7.520619f,30.075438f,30.056326f,-41.331642f,24.89069f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(-41.53866f,-3.4711006f,0f,-20.691856f,-26.531612f,0f,12.181231f,69.41678f,2.0078595f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(4.1559663f,20.33244f,0f,6.728112f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(41.595352f,42.668377f,6.448324f,23.71303f,35.29408f,12.539067f,17.962688f,62.255836f,8.413868f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(41.628063f,49.778393f,42.65659f,16.733864f,14.8289175f,-42.95977f,10.478477f,25.180042f,45.322784f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(41.777378f,68.916794f,-93.689f,-1.8072834f,-44.634727f,95.907265f,-5.419225f,-19.869617f,-29.424515f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(41.886803f,28.744295f,6.6656704f,38.80291f,6.565742f,-16.2992f,10.571561f,3.4833343f,-3.2039666f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(41.929016f,53.66619f,-32.31089f,14.049866f,-22.210184f,0f,36.480633f,0f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(-42.05315f,-100.0f,0f,78.97526f,39.36345f,0f,34.368233f,58.497677f,13.994275f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(4.209361f,-65.216095f,37.931683f,-17.946465f,-53.082005f,-55.45907f,-22.913216f,-73.7064f,20.491486f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(42.329266f,50.208965f,22.021873f,19.108103f,36.484715f,-68.27771f,-2.3815696f,-28.634382f,-43.123592f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(42.747593f,43.32749f,64.03346f,27.662884f,40.647156f,0f,11.965639f,20.199673f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(42.8154f,34.253387f,-81.700745f,10.385402f,15.814104f,52.558372f,-17.087898f,-33.940746f,-8.958596f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(44.47119f,56.564938f,72.78028f,21.319828f,14.498378f,-49.46449f,26.30974f,29.573236f,0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(44.509445f,100.0f,0f,-90.04091f,24.175451f,31.451723f,-23.663004f,-4.611111f,-18.956892f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(44.580757f,-1.1823734f,0f,29.810944f,27.87942f,-76.98114f,46.783596f,24.572042f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(44.646355f,49.458153f,29.731028f,29.127262f,23.45523f,-30.534042f,48.407463f,0f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(45.25602f,76.1684f,-25.788876f,4.8556733f,-28.137442f,100.0f,2.304114f,4.3607836f,99.27629f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(45.263065f,39.89938f,-99.91427f,41.15289f,99.8116f,-13.295359f,17.915077f,30.507423f,4.303016f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(45.341324f,81.21374f,-21.14865f,0.15155299f,34.189266f,30.028261f,-3.21973f,-13.030473f,-83.09143f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(45.5595f,47.67384f,37.993336f,34.564167f,-7.3028355f,12.421069f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(45.57538f,52.046062f,55.72572f,30.255457f,6.8831544f,-44.028717f,-7.981513f,-62.18151f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(45.578407f,-35.53199f,43.892117f,10.977321f,-1.3682326f,31.262623f,-0.30089077f,-12.180883f,82.52661f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(45.61031f,50.496178f,36.61816f,31.945057f,19.756239f,-42.301247f,62.41368f,32.98017f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(45.944702f,47.022453f,-34.88325f,27.366438f,36.72857f,-7.2780943f,26.792479f,79.803474f,65.694084f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(45.95635f,21.33129f,81.457146f,13.283056f,-6.597284f,-107.34097f,14.705468f,45.75863f,175.29588f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(46.494087f,36.212097f,19.958155f,49.764256f,-21.60386f,-56.37948f,0.27361047f,-48.669815f,22.057802f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(4.666051f,74.33332f,-91.532364f,-10.801847f,-26.452738f,-94.46147f,-21.420702f,-74.88096f,56.51858f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(-46.934357f,-51.80681f,0f,-23.093763f,17.327152f,40.121162f,-7.559707f,-7.145064f,-38.347702f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(47.84431f,99.46718f,21.004198f,-8.0899315f,-71.78359f,3.7906857f,-8.420447f,-25.591858f,-22.163395f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(47.884075f,78.857475f,0f,13.191952f,4.7442017f,-63.285378f,0.13953061f,-12.633829f,-55.419052f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(47.890125f,55.421307f,0f,24.735645f,44.271267f,27.097357f,6.7811856f,2.3890965f,-41.496067f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(48.05729f,51.2587f,-47.76151f,40.970448f,-87.73503f,0f,-12.935381f,0f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(48.387226f,85.79792f,86.88171f,7.7509766f,34.06597f,54.1828f,-51.44929f,-11.467809f,91.9154f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(48.5117f,90.609665f,85.14038f,3.4371436f,11.634715f,-33.196083f,-46.397842f,-14.311863f,-78.122025f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(-48.553585f,-45.458736f,0f,-1.4617809f,-32.955086f,0.74054843f,75.661545f,78.04528f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(-48.613567f,61.378044f,-100.0f,-16.88272f,-9.516819f,-61.843327f,-9.400498f,-20.719273f,-63.959778f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(48.645615f,33.72237f,21.69692f,60.860096f,-35.45306f,-46.93469f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(48.743626f,53.434376f,59.315804f,41.540127f,5.678069f,83.828835f,17.940353f,30.221285f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(-4.931899f,-89.38304f,0f,9.600648f,16.770784f,-36.970177f,26.563707f,96.65418f,16.141573f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(49.342304f,60.198048f,42.37612f,37.17117f,49.073772f,9.306433f,-42.06918f,0f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(49.46245f,64.006805f,38.190456f,33.842983f,68.37432f,-13.911048f,17.495749f,36.140015f,58.689983f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(49.511066f,68.232f,65.303375f,29.812273f,44.08526f,13.265612f,25.652765f,72.79879f,38.172276f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(49.621788f,64.38021f,19.451786f,34.10695f,88.44726f,-100.0f,-1.6412544f,-40.671967f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(50.187f,61.65649f,5.961008f,39.09151f,29.07643f,-9.504529f,77.102615f,25.062243f,-52.31186f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(50.19304f,25.537207f,-86.20622f,75.234955f,3.254189f,0f,-5.381568f,-96.76122f,-82.55267f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(-50.44571f,198.12589f,0f,-15.474833f,0.6579799f,-130.77388f,-6.470357f,-10.34016f,-35.32626f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(50.552364f,96.13285f,-12.792224f,20.201523f,26.144651f,-7.9905457f,4.109073f,-3.7652216f,-45.314613f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(50.640305f,87.47694f,-100.0f,15.084287f,82.73652f,28.69655f,-73.03968f,-83.29261f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(50.940163f,54.03942f,-90.70103f,49.721233f,-92.572105f,0f,13.577265f,4.5878286f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(5.0990458f,-76.750496f,-45.292698f,-2.8533177f,-20.02058f,-17.31786f,3.5082636f,16.839352f,-61.671032f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(51.76921f,66.84304f,-76.530685f,40.23381f,99.99123f,-32.82129f,9.174809f,-3.5345755f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(52.368217f,30.298025f,50.55749f,79.17484f,-81.733604f,-97.25679f,44.793713f,100.0f,82.07789f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(52.44853f,0.46883392f,0f,7.855932f,-20.241419f,100.0f,-0.7833804f,-10.989454f,-22.933016f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-52.625538f,-7.6536345f,0f,1.5699232f,-61.904957f,-6.194128f,-4.111877f,-18.017431f,-6.05289f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(53.13107f,-129.4817f,0f,11.661373f,-6.618896f,73.125374f,0.13331908f,-11.128097f,-108.05775f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(54.1847f,98.60311f,99.57369f,18.135685f,33.981052f,99.81314f,-15.623012f,-80.62773f,99.99984f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(54.19838f,9.754797f,0f,-9.272052f,-64.380486f,43.342552f,-26.9061f,-98.35234f,-24.261967f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(54.47904f,-66.08977f,0f,21.377f,-68.05519f,0f,-57.279667f,1.6859721f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(54.75294f,60.581882f,40.513958f,58.429886f,47.060623f,1.4739541f,23.63449f,36.108074f,54.22941f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(54.851707f,53.15539f,21.039864f,66.251434f,36.73f,-99.99897f,21.428976f,19.464468f,21.797476f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(54.981052f,63.24429f,61.020294f,56.679916f,36.97582f,-39.064415f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(55.214138f,-92.26155f,0f,-16.14131f,-59.672073f,0f,-60.107304f,0f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(55.29402f,99.987495f,-22.882917f,21.188583f,28.14861f,7.360135f,1.3117063f,-15.941759f,24.174854f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(-55.430687f,90.77484f,-59.67344f,-16.204332f,23.496826f,-15.235427f,-32.883465f,34.65222f,-24.76509f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(-55.624485f,2.7641807f,0f,-7.4925365f,28.138975f,0f,-7.0287366f,-67.12252f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(55.68523f,79.55071f,80.19021f,43.1902f,16.853052f,0f,11.831782f,4.136929f,-12.137119f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(-55.859142f,100.0f,0f,-39.704834f,-82.648155f,100.0f,-20.31203f,-41.54329f,-63.212967f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(56.08912f,77.552f,-30.329788f,46.804474f,-48.099022f,0f,64.73838f,93.005356f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(5.718033f,17.458172f,0f,-12.001674f,-38.608162f,61.73492f,-15.116569f,53.609436f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(57.20624f,-8.6971655f,0f,-97.3164f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(57.344223f,-18.06555f,0f,-50.854877f,62.456806f,-29.016546f,-9.678794f,12.139701f,-4.2192116f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(59.35795f,-26.849712f,-54.70285f,19.746105f,-8.907248f,-47.908577f,28.53372f,19.383196f,-21.243109f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(59.58786f,5.6693983f,6.2130885f,26.612019f,27.971283f,30.660023f,18.888927f,48.94369f,88.45572f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(61.062164f,58.430206f,52.82432f,85.81844f,19.83434f,52.318237f,-68.904076f,72.64215f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(61.21351f,97.5744f,18.050817f,47.279636f,33.736782f,-25.53376f,94.16826f,15.626841f,-22.394999f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(62.160065f,95.50856f,0f,-36.78887f,45.593613f,0f,-55.173992f,73.59814f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(62.903057f,-39.908253f,0f,39.32544f,73.45641f,-49.7532f,20.942295f,44.44374f,83.37626f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(-63.320705f,-7.1150923f,0f,-19.853077f,-11.50106f,-28.48416f,-4.590542f,1.4909098f,22.05524f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(63.792366f,87.45817f,0f,14.197425f,5.4196606f,37.60616f,-12.422326f,85.427986f,0f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(64.888885f,72.84614f,11.604288f,31.939953f,34.079132f,66.94442f,28.791788f,-35.413975f,28.593369f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(-65.04503f,-31.727013f,0f,-47.664886f,-54.34038f,0f,4.7910037f,76.68278f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(-65.77555f,-28.367916f,41.0953f,-14.86644f,2.7602544f,25.21078f,3.5495386f,29.064594f,56.98756f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(66.70484f,32.667816f,-54.239346f,31.867613f,19.977604f,-8.209373f,40.788006f,23.584358f,3.9910357f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(67.00001f,-11.771385f,0f,47.927807f,-91.77128f,0f,68.59122f,-83.04834f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(67.14689f,68.58755f,94.56016f,100.0f,12.643159f,100.0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(6.734289f,-66.175026f,-45.99711f,-6.8878145f,-10.744621f,-6.946187f,-23.540926f,37.03055f,28.956982f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(68.202484f,33.204834f,0f,37.024815f,30.88176f,0f,14.536481f,21.121109f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(-69.23484f,-62.626286f,0f,-30.780727f,73.421364f,0f,-23.609928f,-63.658985f,39.34805f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(6.9240127f,17.913012f,-28.859068f,-90.216965f,35.274086f,0f,27.293789f,32.597298f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(69.88713f,-100.0f,0f,48.21864f,-3.6520772f,-9.773871f,12.48031f,1.7026042f,-2.0178168f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(7.069391f,-60.329784f,4.125364f,-11.392653f,-58.475445f,-79.393486f,5.835437f,-82.78586f,-72.84534f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(-72.239845f,-5.5584927f,-100.0f,-19.57074f,-0.9627525f,22.028921f,-5.0803595f,-0.7506983f,3.0403187f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(-72.26111f,55.18486f,0f,100.0f,97.30218f,-100.0f,31.191784f,24.767136f,-29.425419f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(72.937584f,-100.0f,0f,12.793998f,-23.180082f,100.0f,1.4184923f,-7.120029f,-6.718525f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(73.45993f,85.88441f,0f,38.060734f,54.589073f,1.5383022f,24.193926f,58.71497f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(7.4921265f,-61.4834f,-56.14774f,-8.548099f,-36.6037f,17.402042f,-4.593468f,-9.825775f,1.8940669f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(7.5110273f,-100.0f,0.40442908f,-2.652079f,-17.06595f,35.94977f,-1.0533937f,-1.5614957f,59.240543f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(7.575695f,30.30278f,86.59795f,-100.0f,-72.96253f,-4.673757f,51.47435f,29.419535f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(75.916435f,-6.554063f,0f,46.544373f,82.683586f,0f,17.168049f,22.127823f,11.855415f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(76.825455f,34.853363f,-5.2254343f,15.935928f,-6.1027246f,-31.348188f,-6.9790177f,-43.851997f,-72.953896f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-7.72572f,96.84415f,5.6420264f,-0.73422325f,9.629732f,-38.9616f,-4.8409047f,-18.629396f,-79.30641f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(-77.30975f,49.00284f,0f,-38.392326f,-66.90779f,1.2962447f,-9.351764f,0.98527145f,80.200645f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(78.54946f,51.94934f,42.65604f,162.24922f,-13.408138f,149.19563f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(7.905892f,-91.96038f,0f,23.583946f,26.621069f,0f,14.48386f,34.351494f,96.30105f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(79.30367f,-5.028595f,0f,-49.963142f,28.558302f,0f,-32.333893f,-79.37242f,-14.506061f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(7.997089f,-5.03833f,-29.91494f,3.7897217f,-11.83788f,-16.506897f,18.999678f,-29.596016f,-17.093773f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(8.034882f,-76.08815f,0f,-5.8757644f,16.391315f,-80.8515f,-47.929253f,-36.419544f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(80.67807f,-46.046043f,0f,-17.391365f,-54.485767f,0f,9.635726f,55.93427f,68.55157f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(-8.215567f,7.9288864f,-16.48116f,7.921275f,28.341078f,-2.485849f,11.559588f,100.0f,-67.21357f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(82.18964f,68.54676f,0f,21.38688f,-44.842327f,-4.663316f,48.200214f,-47.62908f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(82.49711f,96.839005f,0f,-0.33639795f,-79.470085f,78.05943f,-4.3726225f,-17.154093f,15.2263365f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(-82.775764f,36.1388f,0f,68.36351f,-29.441347f,0f,-2.2275062f,-77.27354f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(84.67225f,27.690825f,0f,-40.98603f,59.717186f,0f,8.63627f,75.531105f,0f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(-8.68179f,-96.93833f,31.190004f,4.8306556f,3.7969036f,15.295909f,24.20751f,91.99938f,26.196726f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(8.7770195f,-33.91277f,-120.92914f,-30.979155f,-4.674443f,-14.539214f,-128.06688f,16.819933f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(88.0969f,30.359348f,0f,33.226707f,28.830202f,37.99524f,15.979728f,30.692204f,77.958885f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(89.1299f,-15.331615f,-30.442247f,26.093945f,-5.8196115f,-10.286468f,21.065496f,-23.754309f,-4.8840117f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(8.994787f,27.301916f,6.8255925f,-91.32081f,-6.6143074f,-100.0f,-24.452717f,-6.49086f,5.103585f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(91.53818f,70.59931f,0f,-62.775524f,36.6618f,0f,65.13107f,0f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(92.71917f,70.71868f,34.22888f,51.07627f,64.82869f,38.86826f,46.75723f,98.65154f,56.41547f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(9.322544f,-86.59478f,-59.758137f,23.884958f,-13.782708f,65.39142f,100.0f,30.266245f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-94.52747f,-38.75222f,0f,-20.493305f,16.899937f,-16.71529f,-4.3456836f,3.1105716f,-0.11196547f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-94.704056f,76.18609f,0f,-34.80456f,-54.753494f,55.624264f,10.2393055f,75.76178f,65.66414f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(-94.88529f,-64.06545f,0f,-5.7028613f,68.0776f,37.022224f,3.9962447f,21.68784f,14.677516f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-95.882256f,-48.549015f,0f,-49.48271f,-28.533928f,29.30921f,-73.51466f,-91.769066f,0f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(96.38151f,100.0f,0f,28.700005f,11.533537f,-91.07593f,6.884969f,-1.1601267f,-23.059013f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-98.48652f,-51.34221f,-89.76411f,-27.861942f,-19.459572f,-29.28734f,6.498321f,30.653206f,-7.9256873f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-98.712074f,44.570847f,5.814466f,-25.10006f,4.697315f,-0.22805072f,-6.385481f,-0.46463686f,-0.17038168f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(98.83941f,100.0f,100.0f,32.80817f,21.997908f,-53.58983f,10.395365f,8.773289f,-35.11763f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(-98.952484f,-8.747097f,31.33304f,-9.0430355f,0.5084927f,35.52592f,62.27185f,-15.701819f,-52.772346f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(98.96769f,6.793135f,-8.231389f,43.61656f,45.762505f,57.312675f,29.736052f,75.327644f,57.971397f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(99.39869f,-68.43146f,40.887634f,17.653236f,-24.195913f,-9.992875f,-4.58983f,-36.012558f,-56.747f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(9.970516f,-45.384357f,72.15654f,-14.733577f,74.8083f,0f,-3.722624f,-0.15691987f,-6.4806614f ) ;
  }
}
