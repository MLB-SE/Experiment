import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,3,1 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,1,1,2 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,2,0,2 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,-275,0,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(0,3,1,0 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(1,0,2,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(1,1,1,1 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(1,2,1,0 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(1,2,364,0 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(1,3,0,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(1,4,1,224 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(1,4,2,2 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(1,998,0,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(2,0,2,0 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(2,1,0,1 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(2,4,1,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(3,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(3,0,0,2 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(3,2,179,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(3,4,2,961 ) ;
  }

  @Test
  public void test20() {
    color.magicseries.solve2(3,4,-834,0 ) ;
  }

  @Test
  public void test21() {
    color.magicseries.solve2(4,0,2,0 ) ;
  }

  @Test
  public void test22() {
    color.magicseries.solve2(4,1,0,0 ) ;
  }

  @Test
  public void test23() {
    color.magicseries.solve2(4,1,0,-695 ) ;
  }

  @Test
  public void test24() {
    color.magicseries.solve2(4,4,4,4 ) ;
  }

  @Test
  public void test25() {
    color.magicseries.solve2(4,627,0,0 ) ;
  }

  @Test
  public void test26() {
    color.magicseries.solve2(590,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.magicseries.solve2(-851,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.magicseries.solve2(994,0,0,0 ) ;
  }
}
