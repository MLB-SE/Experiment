import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,0,0,6,3,5,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(-1,15,8,22,-6,2,-2977,-670 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,4,3,3,342,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(-185,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,8,5,1,428,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(19,7,9,12,3,6,0,-1137 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,2,1,9,-2,13,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,4,8,-1,4,13,-1916,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(2,483,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(2,6,4,0,5,-418,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(2,9,3,2,2,1,203,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(3,2,7,0,5,6,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(3,6,5,2,7,1009,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(3,8,0,3,3,3,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(3,9,4,-16,-22,19,0,1559 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(4,6,8,166,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(4,8,3,279,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(4,99,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(5,0,4,3,4,9,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(5,1,8,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(-5,2,10,-1,-19,-7,-1669,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(5,6,3,9,6,-1,-823,-2067 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(5,6,-582,0,0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(5,8,6,-984,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(-5,9,5,8,-3,0,116,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(6,3,9,3,8,986,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(6,4,4,7,3,2,0,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(6,5,0,7,4,0,0,0 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(7,1,9,5,0,0,0,0 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(7,3,6,2,-1272,0,0,0 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(7,3,7,0,0,0,0,0 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(7,3,9,7,9,2,0,756 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(766,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test34() {
    color.sendmoremoney.solve(7,7,3,12,1,-7,0,0 ) ;
  }

  @Test
  public void test35() {
    color.sendmoremoney.solve(8,5,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test36() {
    color.sendmoremoney.solve(8,8,382,0,0,0,0,0 ) ;
  }

  @Test
  public void test37() {
    color.sendmoremoney.solve(92,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test38() {
    color.sendmoremoney.solve(9,3,3,6,1,3,0,-403 ) ;
  }

  @Test
  public void test39() {
    color.sendmoremoney.solve(9,-861,0,0,0,0,0,0 ) ;
  }
}
