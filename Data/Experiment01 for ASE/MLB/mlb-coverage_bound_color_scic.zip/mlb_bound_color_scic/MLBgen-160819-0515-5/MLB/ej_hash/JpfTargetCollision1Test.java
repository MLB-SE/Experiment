import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-762,937,-1686,-762,877,174 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(949,859,124,394,830,182 ) ;
  }
}
