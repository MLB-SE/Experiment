import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-828,-362,-779,196 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(85,-607,916,233 ) ;
  }
}
