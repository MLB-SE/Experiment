import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(1,-26717 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision5(936,495 ) ;
  }
}
