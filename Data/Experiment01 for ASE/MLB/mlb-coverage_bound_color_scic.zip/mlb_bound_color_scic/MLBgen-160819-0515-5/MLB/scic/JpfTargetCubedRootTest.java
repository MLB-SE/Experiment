import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.998540136119132 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(5.000979905385066 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(65.04292123920283 ) ;
  }
}
