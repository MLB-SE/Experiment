import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-2.4195201217822557,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-44.82110124474759,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(4.605071580923972,10.937676631672446 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-51.25,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-58.080096257300504,0.4066428217743052 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(66.17399522373915,59.097358775345015 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-74.99994065297562,6.735448503768197 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(81.47488038589157,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-86.56026432861603,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-88.71748300977337,84.05449861761335 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(96.76490071747645,-76.31331920012974 ) ;
  }
}
