import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.7169151087751402,-52.5436022995227 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-14.753294029064293,-12.367430299643331 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(15.355073124810133,67.72616882186938 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-16.08005696992653,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.6448549805993418,-42.639821975125834 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-2.774867341907978,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-28.651773198457505,-51.392967107687525 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-32.61242162450226,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(32.753100868407955,21.426271526550195 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(3.2810808235007585,-27.904706236252878 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(3.3069497999522923,-30.383137430433635 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(9.065063587165497,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-98.34065232203318,0 ) ;
  }
}
