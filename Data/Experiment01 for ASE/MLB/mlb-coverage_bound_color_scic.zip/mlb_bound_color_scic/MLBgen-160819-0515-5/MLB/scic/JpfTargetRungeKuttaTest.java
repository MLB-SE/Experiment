import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(-0.6714906697973504 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-12.453205079118092 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(-24.419607897290632 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2699.7406803051113 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2713.513558396175 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2720.8934037063186 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2724.819402044349 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2726.404633098514 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(2729.605815315415 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(2731.910160408391 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-50.38199101164509 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(82.55121881208518 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(86.01591679378777 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(87.70222674019078 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(89.00040041888826 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.24409036312983 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(-93.52444500840025 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(-93.71222976803256 ) ;
  }
}
