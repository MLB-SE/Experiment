import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.24878174166011 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(20.347839866020934 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-5.535493442859945 ) ;
  }
}
