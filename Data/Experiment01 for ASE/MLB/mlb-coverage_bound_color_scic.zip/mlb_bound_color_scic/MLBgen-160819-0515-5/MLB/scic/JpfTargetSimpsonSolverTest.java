import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(28.876643537719104,-11.627417015295578 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-71.849025123371,28.571186393537317 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-99.99999999999997,9.027808050192528 ) ;
  }
}
