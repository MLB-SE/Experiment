import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,4 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,0,5 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,2,0 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,2,6 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,4,6 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,5,4 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,6,-667 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,0,1 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,1,1 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,2,3 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,3,3 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(1,4,5 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(2,1,0 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(2,-107,0 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(2,1,6 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(2,3,646 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(2,6,1 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(3,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(3,1,5 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(3,1,763 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(3,4,5 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(4,924,0 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(4,940,0 ) ;
  }

  @Test
  public void test25() {
    bound.golomb.solve(69,0,0 ) ;
  }

  @Test
  public void test26() {
    bound.golomb.solve(837,0,0 ) ;
  }

  @Test
  public void test27() {
    bound.golomb.solve(-920,0,0 ) ;
  }
}
