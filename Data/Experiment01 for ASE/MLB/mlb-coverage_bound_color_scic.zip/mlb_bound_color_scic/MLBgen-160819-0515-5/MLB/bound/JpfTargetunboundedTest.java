import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-252,-322 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-399,204 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(683,682 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-800,451 ) ;
  }
}
