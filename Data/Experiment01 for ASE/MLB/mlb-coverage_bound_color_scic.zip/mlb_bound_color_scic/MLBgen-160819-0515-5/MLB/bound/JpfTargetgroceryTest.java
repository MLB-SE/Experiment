import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(108,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(123,97,294,197 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(134,-783,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(152,276,238,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(153,149,404,5 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(17,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(236,370,665,504 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(310,611,533,197 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(312,212,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(33,460,216,2 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(359,228,121,3 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(387,550,59,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(397,673,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(426,846,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(464,639,182,934 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(487,271,638,-884 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(527,24,-710,0 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(642,643,882,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(687,290,306,255 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(-709,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(957,0,0,0 ) ;
  }
}
