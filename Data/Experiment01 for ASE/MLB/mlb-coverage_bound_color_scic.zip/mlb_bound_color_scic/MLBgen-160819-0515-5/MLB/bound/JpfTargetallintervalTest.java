import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,4,-270,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,709,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,4,2,-334 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(3,0,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(3,3,2,47 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(3,4,677,0 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,-665,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(4,1,579,0 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(4,2,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(4,2,3,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(4,3,4,157 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(4,3,4,2 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(4,4,3,1 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,4,4,1 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,520,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(686,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(-849,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(995,0,0,0 ) ;
  }
}
