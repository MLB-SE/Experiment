import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.03672493f,-78.72263f,0f,-23.586456f,-100.0f,-37.781273f,-16.571257f,-42.69857f,-54.223026f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-100.0f,100.0f,0f,-23.3125f,-9.025964f,22.330244f,15.775967f,86.41637f,47.293694f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(10.124669f,12.284981f,33.803185f,-71.7863f,-94.78793f,77.97884f,45.179806f,-26.236557f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-10.247916f,74.06497f,-11.103419f,6.227912f,6.528886f,21.397223f,28.630678f,-75.57456f,90.16342f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(10.421878f,6.560739f,14.080565f,-64.87322f,-98.25949f,-50.238476f,75.69547f,55.442574f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.631596f,-64.9965f,-40.69794f,7.522883f,31.958326f,-72.286644f,-12.498389f,-57.51644f,-23.56033f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(11.091423f,37.700195f,-14.044654f,-93.3345f,-94.25122f,0f,-2.1631773f,-21.958963f,0f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-11.173966f,-71.26988f,0f,30.877155f,90.057396f,-21.696993f,44.62519f,-60.656197f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(11.391981f,-51.950928f,100.0f,-2.481145f,-24.08527f,5.432374f,2.768709f,13.555981f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(11.745419f,46.981674f,7.837508f,-100.0f,68.343765f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.980398f,-53.717873f,-100.0f,1.6394658f,-2.8907034f,51.288387f,-2.531831f,-10.772795f,98.46296f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(12.056927f,16.368752f,6.8597054f,-68.141045f,-53.441628f,-99.89736f,-16.271818f,3.0537698f,35.06456f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-12.1863365f,-79.09067f,-6.8675f,-69.65468f,64.455154f,0f,-7.7106285f,38.81217f,98.50414f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(12.25778f,-15.661124f,76.08096f,-35.307755f,-63.154995f,0f,-92.98684f,87.28575f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-13.2857f,-94.986435f,94.51883f,-18.54529f,-43.86285f,-12.334523f,-17.032612f,-49.585155f,-99.99407f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-139.00832f,19.189478f,0f,-14.769703f,71.96034f,-123.823364f,7.968984f,46.64564f,-13.822381f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(13.963022f,44.10649f,53.221455f,-88.2544f,9.2414875f,13.969068f,-22.588942f,-2.1013687f,4.9419804f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-14.148782f,-85.445885f,-24.662306f,-71.14924f,90.70821f,0f,-25.810652f,-13.300938f,0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(14.1838f,-25.93677f,-81.32471f,-17.328032f,12.17425f,-45.675045f,-95.67017f,98.820305f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(14.197029f,-21.450743f,-100.0f,-21.76114f,-100.0f,-100.0f,-16.300127f,-43.439365f,-57.457336f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(14.328073f,-15.409537f,-10.889576f,-27.278175f,78.86847f,0f,-12.293738f,-21.896778f,21.585175f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(14.365444f,-35.271805f,0f,59.911392f,-26.12407f,0f,-17.830029f,78.04639f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(14.383838f,13.969077f,41.49247f,-56.433727f,-100.0f,70.05095f,-10.101027f,0f,0f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(15.034207f,-4.872713f,35.78422f,-36.976177f,-170.71065f,-54.79824f,7.445289f,66.75733f,-130.0707f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(15.11273f,-40.68661f,-82.72035f,1.1375287f,0.9356312f,-19.6788f,-11.498246f,62.970406f,3.069521f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(15.473331f,-30.93838f,-10.902433f,-7.168297f,-12.240826f,-9.373734f,-31.905693f,-1.482893f,-14.351679f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(15.67427f,-61.784615f,0f,-30.932936f,81.78324f,0f,-2.5435855f,20.758593f,13.464986f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(16.123653f,31.780725f,38.6844f,-67.28611f,-27.68515f,22.956863f,-7.0799246f,38.96641f,-23.232153f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(16.57135f,-44.45934f,-47.81246f,10.719857f,3.1286705f,-35.72283f,23.17156f,81.966385f,-98.20753f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(16.612347f,39.69563f,36.63971f,-73.24624f,5.530456f,-74.10978f,-26.935122f,-34.494247f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(17.01488f,13.382011f,-70.20968f,-45.3225f,6.722846f,1.4905795f,-7.6413956f,14.756914f,59.946205f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(17.10821f,89.572685f,-50.118988f,6.3265133f,39.271248f,15.135525f,-31.073406f,46.05027f,71.38984f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(17.127934f,-26.335361f,-68.9843f,-5.152903f,-26.671337f,-34.457916f,-11.068208f,-39.11993f,43.110733f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(-17.235847f,-40.221233f,0f,-1.6474218f,9.356409f,59.511795f,1.2897518f,6.806429f,16.579556f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(17.242466f,-5.0981684f,0f,-1.479393f,-20.564905f,-40.876884f,-2.595132f,-8.901135f,-12.444506f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(-17.429821f,43.74856f,0f,12.318044f,27.805317f,0f,0.85369396f,-8.903268f,96.50216f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-17.525259f,93.73259f,0f,12.333281f,-58.46986f,0f,20.780994f,70.7907f,28.841381f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(17.999672f,-36.29258f,-20.773949f,8.291272f,20.329367f,34.020332f,-5.1639524f,59.946087f,0f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(18.26623f,70.63884f,77.1452f,-97.57392f,-3.9935489f,0f,-88.36881f,45.404995f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(18.394737f,-11.675473f,-99.92592f,-14.745557f,-65.170746f,97.283356f,-12.205914f,-34.0781f,-58.935913f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(19.678156f,-33.51312f,92.49994f,12.225742f,19.059916f,69.09319f,10.164897f,28.433844f,57.764977f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(-19.68759f,-100.0f,100.0f,-2.3504689f,-36.1954f,47.582672f,46.481113f,-90.01381f,-89.849945f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(19.887934f,-65.93168f,-32.381092f,45.48341f,-75.94593f,0f,-4.623084f,-63.975746f,-5.3750854f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-2.0372741f,47.270634f,0f,4.8044815f,20.367193f,47.309883f,0.88800704f,-1.2524532f,-26.265013f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(21.053726f,-81.88414f,0f,-2.9361715f,-94.761406f,0f,-10.18837f,-37.817307f,38.44757f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(21.21828f,-29.46599f,-7.9457927f,14.339113f,5.136799f,33.860985f,31.001373f,1.8130857f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(21.723665f,38.141254f,28.707546f,-51.246593f,2.1338143f,-100.0f,-60.781982f,-5.168296f,0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(21.79403f,-21.436316f,-100.0f,8.612434f,7.078765f,-5.78628f,5.5769424f,46.925507f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(21.998987f,32.532417f,42.04768f,-44.53647f,-33.917004f,-27.988335f,-13.436256f,-9.208556f,10.519033f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(22.028402f,15.5315895f,39.943806f,-27.417982f,-99.84585f,4.537561f,-31.854485f,-99.999954f,0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(22.089823f,-11.796046f,-84.56347f,0.1553342f,-20.676577f,10.277808f,-0.79190874f,-3.3229692f,-20.260572f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(22.123592f,24.259745f,6.654993f,-35.765373f,-36.65703f,-22.07878f,-12.592634f,-14.605162f,-9.170985f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(22.133734f,-68.35137f,26.440672f,56.88631f,-5.1308317f,0f,90.91522f,-82.23281f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(22.17923f,-8.710476f,-13.666365f,-2.5726051f,-35.415615f,37.10882f,2.9459636f,-21.702286f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(-22.2357f,-71.86665f,27.063244f,-17.28485f,-35.424843f,-23.9173f,-11.478854f,-28.630568f,-87.307594f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(22.360306f,9.536803f,-0.1451475f,-20.09558f,-84.06795f,33.600414f,-10.515418f,-21.966093f,6.718989f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(22.836552f,-3.087586f,-100.0f,-5.5662074f,-35.186893f,-94.11962f,-9.914486f,-88.13173f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(22.904116f,-42.443855f,-37.584606f,34.060318f,-27.340227f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(23.064661f,8.629192f,-100.0f,-16.37055f,11.452109f,-23.731808f,-99.99897f,77.28159f,-71.3764f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(23.297113f,17.00439f,5.670498f,-23.815939f,-60.950047f,43.97328f,-57.610825f,0f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.401253f,25.653742f,75.01841f,-32.04873f,96.47859f,0f,-8.5712f,0f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(-23.855087f,57.679127f,0f,-10.963048f,36.7f,70.20988f,-56.697105f,11.975126f,0f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(24.051493f,15.927506f,-100.0f,-19.721535f,-4.5313563f,-30.723068f,-98.40627f,-98.90499f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(24.157003f,9.706229f,-12.801805f,-13.078214f,-72.53028f,66.16986f,-6.1666775f,-14.4620695f,0f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(24.386314f,-19.87614f,-229.7185f,17.790298f,20.494827f,-2.413598f,26.308752f,86.42379f,76.45043f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(24.53754f,16.661497f,31.551575f,-18.511335f,-89.44312f,9.5448f,-9.139757f,-18.047693f,0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(-24.625734f,45.20798f,0f,-89.770584f,-30.453943f,67.00462f,-27.488325f,-20.182713f,-22.78858f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(24.650396f,20.370558f,-100.0f,-21.76897f,-99.69447f,51.531376f,-12.031805f,-26.358248f,6.2932816f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(24.868692f,-20.833597f,28.234913f,20.308365f,40.95414f,-51.864082f,7.6553698f,10.313113f,-7.3570566f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(-2.5143895f,-100.0f,100.0f,-10.057558f,-100.0f,0f,18.638887f,84.613106f,-100.0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(25.267733f,18.064903f,20.802837f,-16.993969f,-73.81096f,-34.853554f,-19.432653f,-99.852135f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(25.314888f,2.2834365f,100.0f,-1.0238857f,31.041912f,-6.865796f,1.8204209f,8.305569f,0.35994327f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(25.38472f,31.084517f,14.478347f,-29.545637f,-15.524998f,-73.171135f,-68.56626f,15.681265f,0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(25.5653f,16.59932f,54.463455f,-14.338118f,-19.32801f,-25.12817f,-63.58976f,-54.445072f,-57.218166f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(-25.88679f,-31.740978f,0f,-83.625496f,58.89518f,56.648617f,-14.26705f,26.5573f,61.60107f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(25.91129f,10.604952f,-43.671375f,-6.959793f,-39.820107f,0f,-13.266751f,-46.107212f,0f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(26.233551f,19.699837f,28.08665f,-14.7656355f,-75.52085f,98.317635f,-9.775242f,-24.167414f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(26.242361f,-28.002558f,-30.461363f,32.972f,76.699295f,-32.1324f,28.946346f,82.813385f,-47.441326f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(26.385836f,35.053516f,90.552444f,-29.510172f,-76.72422f,25.836308f,-56.822464f,0f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(26.59378f,6.172192f,-99.86719f,0.20292759f,-24.890882f,-65.506195f,-0.89118737f,-40.432457f,37.2865f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(27.003662f,17.788967f,-41.679264f,-9.774316f,-68.665504f,0f,-0.51751786f,7.704244f,100.0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(2.7127953f,-94.62377f,-100.0f,5.4749517f,-10.092453f,73.02479f,29.279465f,-24.245783f,100.0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(27.50903f,8.465754f,-25.194986f,10.353329f,-14.106854f,-59.64395f,28.01114f,-15.602548f,22.26118f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(-27.69374f,-56.736607f,-54.375725f,0.7656694f,5.5650015f,-21.769058f,25.191418f,100.0f,-100.0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(27.917715f,54.74656f,26.745451f,-43.0757f,64.32307f,-47.764755f,9.431435f,0f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(27.932505f,25.207712f,1.221228f,-13.477694f,-28.322886f,-40.352367f,-53.520393f,-84.66919f,0f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(28.124128f,11.956536f,-62.97016f,0.53997743f,-17.470858f,-15.005678f,-8.493361f,-67.37427f,20.418308f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(28.238647f,17.01246f,-89.57148f,-4.057873f,-179.19376f,0f,30.665953f,23.08547f,0f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(28.443365f,5.5808334f,-100.0f,8.192626f,-6.1200314f,99.99984f,11.933413f,39.541023f,90.42895f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(28.490242f,51.29721f,42.507313f,-37.336243f,34.191296f,-43.012604f,-9.364029f,-0.11987098f,-25.30675f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(28.548435f,32.604454f,18.129566f,-18.410717f,-16.260181f,-28.867096f,-85.93112f,-50.367367f,56.768486f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(28.863413f,25.924055f,22.276058f,-7.2330847f,-46.66921f,-202.68881f,-8.899961f,-21.30633f,-29.438969f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(28.937504f,17.616129f,-33.668316f,-1.8661107f,-24.804674f,43.34366f,-11.597272f,-44.52298f,-31.882013f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(29.009098f,44.670948f,68.120834f,-28.634558f,-29.187677f,35.267456f,-13.921185f,-27.05018f,-65.09186f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(29.105963f,19.837507f,-28.929255f,-3.4136522f,-20.826683f,-13.702355f,-21.93389f,-84.3219f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(29.164026f,70.56824f,0f,-59.911476f,-24.971373f,0f,-19.64113f,-18.653046f,-29.999683f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(29.720903f,25.608751f,14.625448f,-6.7251363f,-59.704037f,0f,3.0825894f,0f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(-29.840334f,-87.568726f,0f,2.8686998f,-26.64534f,5.482678f,-1.0369319f,-7.0164275f,-0.38343728f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(29.932337f,-36.21959f,0f,-77.52566f,-18.300371f,-18.713896f,-25.402534f,-24.084482f,-52.63502f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(30.10086f,3.5323305f,-70.19362f,16.87111f,36.50675f,26.141117f,0.87683433f,-13.363773f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(30.212795f,37.570286f,26.825138f,-16.719505f,-6.756795f,-30.84165f,-5.511826f,-5.327742f,-9.042348f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(30.232563f,26.38164f,11.2180395f,-5.451377f,-35.92404f,-81.50948f,0.11259943f,5.901784f,59.41858f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(30.407812f,25.994455f,6.4981604f,-4.362698f,-32.92815f,-100.0f,-14.930454f,-55.35939f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(30.455614f,47.061676f,98.12191f,-25.239222f,-40.330822f,-35.484882f,46.35411f,-69.87759f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(30.498789f,29.042963f,36.04158f,-7.047859f,-50.368515f,1.632564f,-8.321712f,-26.23912f,-46.26632f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(30.991098f,8.687904f,2.5977757f,15.276487f,-98.83726f,-98.2968f,14.262813f,42.939796f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(31.122795f,29.201439f,19.657597f,-4.61741f,-33.716946f,-161.89078f,-14.606485f,-55.110878f,-138.53668f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(31.218718f,27.566257f,-23.52059f,-2.691385f,2.566899f,53.885178f,-10.105374f,-37.730114f,0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(31.272661f,2.850757f,28.622772f,22.239885f,27.325079f,20.48662f,30.361801f,63.723053f,25.998632f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(31.32204f,38.35303f,10.751277f,-13.064869f,-74.460976f,19.693983f,-9.120546f,-23.417318f,-10.087758f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(3.1491656f,-55.128178f,0f,-32.275158f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(31.759348f,10.329841f,-99.40073f,18.740862f,23.051052f,1.2621818f,20.153046f,61.871323f,-51.63094f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(32.334896f,35.633835f,-8.871261f,-6.2942543f,-58.5543f,99.88993f,1.0423862f,10.463799f,99.36711f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(32.433384f,38.543934f,-8.613714f,-8.810406f,-70.73739f,-3.80751f,3.0623863f,21.05995f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(32.580513f,31.923115f,22.518644f,-1.6010668f,-27.406696f,-41.848537f,-11.578084f,-99.698586f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(32.686768f,27.61411f,-41.31222f,3.1329532f,10.012646f,-42.700428f,-30.167599f,52.00395f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(-32.68885f,21.448586f,0f,-3.8651183f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(33.205223f,31.882915f,29.962793f,0.93797636f,-35.636353f,-11.686795f,0.5525896f,1.2723819f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(33.26465f,32.62029f,66.714645f,0.43829665f,-69.49813f,-52.91873f,37.98667f,25.06409f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(33.509117f,-41.90169f,0f,42.83299f,-35.673134f,0f,75.12776f,0f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(33.7302f,31.949982f,11.624006f,2.970826f,-17.554287f,-96.68993f,-4.2926283f,-20.141338f,-97.53204f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(33.751804f,30.99884f,7.6274204f,4.008381f,-17.383865f,-20.441607f,-0.3344169f,-5.3460484f,-17.061663f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(33.766956f,54.14353f,13.161465f,-19.075703f,-5.311159f,0f,-3.4145098f,5.417663f,30.396322f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(33.77367f,-16.0062f,0f,2.5269933f,-39.57555f,7.2898045f,0.43202534f,-0.79889184f,35.947956f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(33.87205f,60.64741f,59.60174f,-25.159204f,49.115852f,77.75955f,-5.7485766f,2.164897f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(33.88828f,59.29461f,0f,18.43391f,-8.298278f,-5.243654f,10.137803f,22.1173f,86.62968f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(34.25621f,47.883705f,0f,-6.88096f,-59.76288f,-20.000607f,-2.0171702f,-1.1877208f,77.144135f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(34.25817f,26.733437f,-73.46638f,10.299252f,29.659462f,46.541016f,-22.72063f,35.064148f,32.360424f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(34.333855f,100.0f,0f,12.632958f,9.738414f,-100.0f,6.4595647f,13.205301f,36.623226f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(34.393307f,32.34071f,44.44588f,5.232514f,-49.476345f,45.44281f,36.013092f,15.7261305f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(34.48073f,-47.316025f,-78.28665f,85.23894f,14.847303f,0f,-22.478785f,0f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(34.565598f,20.576872f,-81.4451f,17.685513f,5.2317915f,89.38055f,4.73121f,1.2393277f,-5.0056915f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(34.601788f,62.32859f,0f,25.867392f,79.20226f,0f,13.5358305f,28.27593f,20.365631f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(34.709522f,-62.921505f,0f,79.14937f,-8.340717f,0f,40.362797f,82.30182f,-25.24328f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(34.711193f,41.449898f,78.01291f,-2.605129f,-46.924515f,100.0f,-0.8234454f,-0.6886525f,44.99335f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(34.923325f,29.6494f,-30.015171f,10.043901f,0.6032966f,67.77654f,4.648985f,8.552038f,28.955872f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(35.024754f,43.282623f,14.17159f,-3.1836047f,23.934155f,7.145746f,-79.35102f,0f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(35.165672f,57.13367f,94.420944f,-16.470978f,-1.0519284f,-55.661625f,-99.99766f,10.791218f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(35.220673f,33.58988f,-65.56549f,7.2928042f,64.70434f,-12.28737f,-70.75379f,-57.339096f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(35.23725f,33.455425f,-65.72457f,7.4935775f,64.30902f,40.702877f,-24.824738f,-22.593187f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(35.406967f,38.558487f,42.607437f,3.069384f,-23.780455f,-9.05872f,0.6510238f,-0.465289f,24.21497f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(35.598293f,16.889664f,91.36795f,25.469162f,-159.39844f,68.16534f,151.0033f,149.02113f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(35.60127f,38.898518f,-59.624912f,3.506555f,8.149599f,-28.775574f,-29.724648f,18.968895f,-63.62698f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.626625f,33.09848f,20.24166f,9.408023f,-23.474361f,-71.445015f,25.479828f,-79.22443f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(35.64147f,5.51519f,-63.84984f,37.050705f,-49.730877f,43.411667f,14.8574295f,22.379011f,29.230219f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.67276f,42.54222f,59.324562f,0.14882195f,-24.82843f,-3.6835823f,-10.2490425f,-100.0f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(36.29833f,24.362955f,100.0f,20.83036f,-13.49833f,-97.32664f,2.8774188f,-9.320685f,-26.66183f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(36.454296f,41.47942f,28.398252f,4.3377686f,-0.42556763f,6.448319f,-18.677654f,-53.967777f,-2.179409f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(36.550945f,32.280468f,2.785813f,13.92332f,-10.2148905f,24.584066f,6.781488f,13.202631f,56.243927f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(36.78626f,53.2162f,42.06477f,-6.071167f,34.013866f,15.042876f,-95.084694f,73.86756f,0f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(37.341927f,35.22813f,-21.48495f,14.139581f,8.256322f,-52.380253f,10.9600725f,29.70071f,99.58645f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(37.574417f,65.532295f,-57.103912f,-15.234618f,-91.03076f,17.118322f,-7.482131f,-95.142204f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(37.83558f,54.410976f,45.10863f,-3.0686574f,34.699696f,13.713798f,-84.809906f,64.99682f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(37.845882f,77.78655f,96.19874f,7.6999984f,2.8903008f,-26.480583f,-9.936192f,-47.444763f,100.0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(37.90683f,49.625206f,40.806545f,2.0021102f,19.787447f,13.600983f,-49.685833f,-40.99945f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(38.005604f,33.640495f,-25.73645f,18.381927f,22.292824f,71.10631f,7.7858305f,12.7613945f,20.966927f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(38.14799f,100.0f,0f,10.20173f,27.910288f,0f,-9.586978f,-48.54964f,-83.94717f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(-3.8199165f,-63.00997f,0f,21.457178f,80.131035f,21.72606f,9.517596f,16.613207f,-23.195805f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(38.229897f,53.55121f,-41.266872f,-0.63162464f,-27.170006f,-100.0f,-13.586388f,-53.713924f,45.167957f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(38.459995f,49.29549f,82.46923f,40.241867f,28.172668f,9.769502f,94.3348f,13.383821f,-71.563896f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(38.519356f,46.997143f,77.74909f,7.0802865f,-28.279877f,27.942535f,1.4340656f,-1.3440244f,21.469713f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(38.602283f,48.117493f,0f,68.65624f,-13.368418f,0f,72.44111f,0f,0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(38.696907f,40.396267f,-86.56678f,14.391365f,20.060629f,-100.0f,-1.1920748f,-19.159664f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(38.966614f,48.310596f,53.672054f,7.555862f,0.60371935f,66.377625f,-9.346887f,15.320915f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(38.994534f,61.087013f,-0.5829896f,-5.1088777f,-1.498188f,-23.230518f,-57.931854f,-38.740368f,-70.38135f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(-39.036854f,49.320366f,0f,13.929794f,24.657562f,0f,11.320933f,31.353941f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(39.10688f,65.079155f,-21.99213f,-8.651645f,-44.4693f,53.9924f,-29.244156f,-47.028072f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(39.13986f,35.833622f,-1.6703217f,20.725805f,5.864957f,-0.5903545f,-47.814f,1.68388f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(39.425335f,39.38085f,-10.410525f,18.320482f,28.508598f,61.523125f,4.9848723f,1.6190073f,-27.01744f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(39.709305f,42.19251f,0.26188117f,16.644716f,22.21163f,28.022291f,4.6579304f,1.987001f,99.9306f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(39.97454f,36.07206f,1.6894333f,23.826096f,2.62427f,-16.386707f,52.705574f,-33.01437f,-69.860535f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(40.01443f,44.635323f,23.016468f,15.422384f,15.510352f,-7.3290935f,6.164741f,9.236581f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(40.06658f,63.116108f,0f,-63.25317f,-35.20029f,100.0f,-17.671406f,-7.4324517f,23.141888f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(40.217175f,99.293976f,98.49948f,-38.425274f,38.409573f,-18.468994f,-5.2749977f,17.325283f,36.16656f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(40.58322f,30.222506f,-75.53796f,32.11038f,55.844753f,61.82815f,32.01354f,100.0f,0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(40.648266f,45.55534f,33.860367f,17.03772f,7.7127337f,-10.113873f,-80.54571f,0f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(40.717556f,30.11163f,42.520157f,32.75859f,-62.79119f,22.506725f,7.2197075f,-3.8797612f,-24.350454f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.89935f,35.095837f,27.88138f,28.501564f,-28.397377f,-59.25131f,8.901554f,7.1046515f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(4.0939145f,-38.606915f,17.27516f,-5.0659947f,-24.513622f,-27.895483f,0.15572873f,-26.486101f,30.256042f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(41.052357f,37.997818f,2.1351922f,26.211615f,8.8037195f,58.977966f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(41.32163f,17.33165f,-12.670369f,47.95486f,-59.324657f,0f,-1.3400238f,-53.314957f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(41.38226f,49.432983f,40.249672f,16.096058f,16.1f,-23.422974f,6.9019685f,99.999886f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(41.57012f,31.00677f,-79.07367f,35.273712f,9.084816f,42.481247f,90.43991f,-72.42246f,7.1591725f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(41.604523f,75.75201f,62.128975f,-9.333921f,99.27453f,1.3407494f,-22.918922f,-82.34177f,46.48217f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(41.67791f,7.457333f,-76.25991f,59.25431f,-99.206345f,0f,-24.649748f,0f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(41.911457f,66.71276f,-22.685923f,0.93305856f,-60.4769f,100.0f,22.297678f,88.25765f,-64.97987f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(-4.1916485f,179.0699f,-91.016106f,10.385344f,40.940674f,-35.947243f,5.1965213f,10.408729f,-3.2949493f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(42.025528f,74.99146f,67.23228f,-6.889351f,90.70804f,93.93764f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(42.119568f,-26.026628f,15.238279f,94.504906f,74.40195f,0f,28.045055f,17.675316f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(42.32448f,92.696594f,71.17302f,-23.398685f,100.0f,0f,65.414635f,0f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(42.329304f,42.670033f,12.0841055f,26.647177f,-10.945516f,-72.69067f,75.20492f,-40.408607f,-14.774272f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(42.335842f,24.51254f,98.76013f,44.830833f,96.13377f,0f,40.853714f,0f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(42.49213f,56.76777f,43.02769f,13.200748f,20.091413f,28.142069f,-9.780548f,-52.32294f,87.41387f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(42.928078f,23.364275f,29.266104f,48.34803f,-78.73708f,-6.2998567f,85.88923f,-14.232674f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(43.077427f,19.115236f,-65.020134f,53.194466f,-5.8215127f,0f,13.094769f,-0.8153911f,26.073723f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(43.09609f,-47.307392f,0f,27.722036f,58.820515f,75.38288f,13.017698f,24.348757f,25.556814f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(43.216267f,61.542553f,100.0f,11.322515f,2.953944f,45.4014f,-40.463337f,92.867714f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.38539f,73.33311f,97.20771f,0.20845808f,-29.21906f,-100.0f,-13.332499f,-93.2699f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(43.388515f,41.970932f,44.2105f,31.583136f,74.74734f,15.36308f,8.196686f,1.2036074f,-78.12959f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(43.507015f,48.784733f,51.519543f,25.243326f,0.112370156f,56.94665f,7.786536f,5.902818f,15.712367f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(43.626774f,76.820015f,43.44514f,-2.3129117f,28.738268f,16.820059f,-81.61669f,-55.54501f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(43.66025f,47.809025f,7.857343f,26.832003f,39.628727f,14.549717f,24.039032f,69.32416f,10.712799f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(43.77675f,41.043644f,51.07632f,34.063347f,61.537804f,75.94957f,30.938839f,40.05678f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(44.6845f,39.376938f,94.782326f,39.361065f,-100.0f,0f,23.607115f,55.067398f,52.61552f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(44.92947f,48.597435f,42.06032f,31.120451f,7.399939f,-2.9126775f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(45.040348f,66.32361f,13.2026f,13.837792f,9.558252f,-100.0f,0.75256735f,-10.827523f,-88.60215f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(45.164158f,57.195877f,72.479935f,23.46076f,11.139418f,-44.292118f,37.539463f,0f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(45.184334f,66.56417f,62.27229f,14.173156f,58.800064f,82.524994f,-47.291775f,0f,0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(45.66187f,40.528774f,-6.359707f,42.118702f,22.812937f,31.399157f,100.0f,84.97063f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(45.73225f,57.34323f,51.71451f,25.58577f,17.226929f,99.97374f,39.3839f,-16.175549f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(45.89967f,100.0f,-67.914734f,-16.401325f,65.23036f,0f,15.788543f,79.5555f,-100.0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(-45.94294f,56.30736f,0f,-13.29436f,-47.01865f,-7.705294f,39.78415f,-45.506626f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(46.64418f,32.87329f,-15.473429f,53.703438f,9.225759f,0f,12.5841465f,-3.3668494f,-35.2773f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(47.68863f,66.238914f,89.04327f,24.515602f,28.223766f,-96.89429f,22.150017f,78.48811f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(48.219486f,46.25305f,55.048702f,46.624893f,-18.255978f,79.47451f,-12.935343f,-98.366264f,-29.812752f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(48.698822f,-5.2047186f,-77.84075f,100.0f,41.78035f,17.349281f,29.401989f,17.607956f,-0.75051296f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(4.882365f,51.888687f,0f,11.153784f,34.11881f,-57.591324f,5.613961f,11.302061f,5.475471f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(49.512474f,65.31748f,43.92736f,32.732414f,67.83008f,-58.948547f,13.587095f,21.615969f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(49.673477f,75.81882f,46.6185f,22.241816f,107.34755f,9.93816f,13.406494f,31.384163f,121.14102f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(49.88114f,50.543343f,5.899677f,48.98122f,46.39255f,23.604254f,99.65119f,-99.77999f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(-5.0417128f,-83.37815f,82.69178f,-36.7887f,-33.892826f,0f,3.9385931f,52.543076f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(50.829853f,38.899517f,-4.884596f,64.4199f,-21.537222f,61.53435f,21.070368f,19.86157f,79.91314f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(5.0943627f,37.46721f,43.539658f,2.7015555f,0.34087732f,-57.587627f,5.3709817f,18.782372f,98.71321f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(51.23948f,65.57047f,18.185806f,39.387444f,92.85661f,-99.09999f,13.446121f,14.397042f,-38.977306f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(51.29226f,94.24214f,-11.320021f,10.926896f,34.04482f,27.182135f,-41.629494f,3.8281016f,-19.58787f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(51.484264f,89.42362f,0f,17.298855f,-54.07437f,55.156948f,71.78552f,-2.537991f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(-51.7257f,-88.64175f,0f,61.797623f,-76.81127f,0f,14.384152f,-4.261011f,45.383076f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(51.95657f,100.0f,-71.27314f,7.8262835f,-56.745617f,18.397821f,-1.6283997f,-14.339883f,1.0144845f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(52.432083f,80.06255f,-74.34845f,29.665775f,93.14421f,0f,3.5512075f,-15.460944f,-94.538765f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(52.508335f,-86.32278f,0f,-49.679783f,99.054565f,0f,44.95258f,0f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(-53.64073f,-87.3247f,0f,-87.709015f,-10.519006f,0f,-23.723509f,-7.1850233f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(54.338367f,-51.514362f,0f,7.209936f,-77.73329f,0f,-24.395851f,-99.242226f,0f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(5.509197f,-63.163948f,100.0f,-14.799264f,89.428535f,-100.0f,-4.6512346f,-3.8056738f,-100.0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(55.0983f,93.570305f,30.633654f,27.828823f,42.6435f,-29.244207f,13.573493f,78.41908f,-98.60774f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(55.385162f,24.309355f,-33.10864f,97.23129f,-54.403038f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(55.513798f,65.75041f,-92.22008f,56.30477f,93.55414f,0f,16.156286f,98.91883f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(56.957176f,-34.90769f,0f,7.3337674f,-73.517136f,0f,25.911083f,-28.778692f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(57.189514f,-62.311783f,0f,-45.785313f,-48.338177f,0f,-32.74982f,34.57766f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(5.7191586f,-1.4620516f,43.42737f,-75.661316f,55.950855f,0f,31.308067f,72.090034f,0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(57.969563f,55.970554f,55.44437f,75.9077f,10.46828f,-100.0f,-87.91486f,0f,0f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(58.045452f,77.25982f,67.03766f,54.921993f,83.95617f,90.89082f,77.68635f,-16.610258f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(-5.8255963f,-71.222916f,97.81491f,-52.079468f,-34.547836f,-39.286663f,-17.093868f,-16.296003f,-13.542307f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-58.95778f,46.794422f,-33.265965f,-16.588535f,-0.83774185f,-23.910908f,-6.5586205f,-9.645947f,-61.53993f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(-59.212116f,-76.593796f,-100.0f,-14.471678f,3.5856872f,99.97768f,-2.2602828f,5.430547f,20.396784f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(-6.00832f,28.295097f,0f,12.373127f,43.54492f,27.5078f,11.955906f,68.36853f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(6.030901f,-63.970108f,-34.18747f,-11.906287f,-29.906242f,-5.796678f,-23.749805f,-37.951897f,80.921165f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(61.13341f,-59.67583f,0f,-40.026093f,-12.360411f,0f,-23.29334f,-53.147266f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(61.224594f,82.993225f,70.74831f,61.905148f,100.0f,100.0f,9.172803f,-25.213938f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(6.1508756f,18.923775f,10.286633f,-94.320274f,-40.742405f,65.10524f,-29.398392f,-23.27329f,-22.952366f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(6.189071f,100.0f,0f,-12.672421f,-48.06276f,21.679409f,-8.815997f,-22.591566f,-33.48751f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(62.608616f,-24.759186f,0f,42.977833f,-13.005672f,0f,10.483461f,-1.0439885f,-1.6537427f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(6.345275f,10.1845875f,15.893662f,-84.80349f,-81.50059f,-42.03396f,-29.287296f,-32.3457f,-18.594913f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(-63.8825f,50.159073f,-4.9756985f,-10.1268f,30.79628f,98.093056f,-7.4209766f,-14.940206f,30.020061f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(-65.75403f,81.68512f,0f,-7.3088636f,7.4667106f,0f,29.051865f,0f,0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(-65.80946f,-20.089214f,0f,-43.377956f,-34.618122f,8.675999f,-73.08424f,-61.2879f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-67.30822f,-100.0f,100.0f,-28.81264f,-23.107016f,78.7889f,-24.835327f,-42.40433f,45.56361f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(67.32188f,116.55089f,415.82022f,53.46669f,98.132126f,82.79137f,49.11414f,140.90825f,13.737075f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(68.045525f,64.44087f,0f,-27.915396f,-146.19943f,0f,-33.507675f,0f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(-68.39501f,85.314964f,-5.2897806f,-12.085004f,21.40458f,5.7016554f,-1.3495774f,6.686694f,6.691824f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(69.51196f,-82.97643f,0f,44.20372f,-56.54636f,0f,15.368637f,17.270826f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(69.75348f,79.01398f,46.405304f,99.99992f,99.89713f,4.9631367f,28.534716f,14.138937f,-71.8761f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(70.61035f,-83.36153f,0f,55.95442f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(7.244366f,-45.011242f,63.97528f,-26.011295f,-99.998795f,-100.0f,-11.290753f,-19.151718f,34.682674f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(-7.325616f,-99.99939f,-2.3196535f,-29.303074f,-86.76315f,-95.22681f,-23.123522f,-94.2542f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(-73.32291f,-0.8711144f,0f,-45.580395f,-55.69132f,0f,-15.932279f,-18.148718f,-95.50323f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(73.7553f,-24.367235f,0f,-72.411705f,-38.015915f,0f,-3.739015f,57.455647f,39.459507f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(-74.34f,-58.215797f,0f,-28.706406f,-11.671504f,-33.305286f,-28.814125f,-86.550095f,-32.038704f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(7.5758142f,-4.9017816f,-46.571228f,-64.79496f,-58.0581f,0f,-11.543534f,18.620823f,25.243534f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-7.5759215f,-78.547005f,0f,-35.32479f,51.20522f,0f,-96.28702f,-32.01424f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(-75.79026f,60.502148f,0f,3.1870654f,24.249022f,87.907295f,64.2895f,-54.600418f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(7.586204f,-66.5163f,43.855675f,-3.1388903f,-30.062456f,-45.07044f,9.920691f,-5.524203f,40.0668f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(76.11294f,56.53627f,0f,-32.291534f,4.433855f,0f,86.37337f,-4.5256624f,0f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(-76.8008f,78.16635f,0f,-79.93724f,-26.145012f,0f,83.296555f,70.39116f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-79.244156f,-57.345818f,0f,-38.778065f,82.61832f,94.94975f,-2.7901416f,27.617496f,30.641811f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(-83.10845f,-99.70669f,0f,95.03833f,9.750791f,-66.57992f,19.346342f,-17.652962f,-99.708984f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-84.906f,70.3259f,0f,-19.737562f,8.2801695f,90.34985f,-2.324424f,10.439867f,35.803722f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-8.578906f,-99.99655f,-25.167677f,-34.31907f,-29.365158f,73.843506f,-99.332214f,-56.98851f,96.37959f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-86.30243f,-36.487442f,0f,-21.728941f,-2.8427327f,0f,67.8756f,0f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(89.53499f,-40.076f,0f,77.92733f,57.84644f,75.96094f,26.361725f,27.519573f,25.870129f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(9.069808f,24.880571f,-5.9835396f,-88.60134f,-3.563983f,-100.0f,-17.884403f,17.063725f,96.094826f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(-92.37491f,-12.537217f,54.522842f,-18.92352f,7.0706987f,2.3795002f,9.610128f,57.364033f,-48.38193f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-94.93875f,86.24882f,0f,50.66925f,24.340767f,0f,36.920883f,-26.489605f,0f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(-95.4686f,76.82229f,0f,-33.230217f,-19.045662f,-47.79865f,-18.406614f,-40.39624f,0f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-9.862813f,13.579562f,0f,15.072845f,77.67643f,48.622234f,-7.522231f,-45.16177f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(-98.94209f,-14.293895f,-46.569347f,-29.035118f,-8.973788f,11.2971325f,-8.224598f,-3.863271f,17.306349f ) ;
  }
}
