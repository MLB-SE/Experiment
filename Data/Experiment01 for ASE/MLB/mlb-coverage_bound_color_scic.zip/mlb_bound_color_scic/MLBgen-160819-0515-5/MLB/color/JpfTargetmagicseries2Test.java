import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,3,1 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,1,1,-323 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,80,0,0 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(1,1,0,2 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(1,2,0,1 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(1,205,0,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(1,2,1,0 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(1,3,0,0 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(1,-428,0,0 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(1,4,933,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(180,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(2,0,425,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(2,1,2,64 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(2,4,4,2 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(3,1,-605,0 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(4,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(4,3,0,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(4,3,4,584 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(-767,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(843,0,0,0 ) ;
  }
}
