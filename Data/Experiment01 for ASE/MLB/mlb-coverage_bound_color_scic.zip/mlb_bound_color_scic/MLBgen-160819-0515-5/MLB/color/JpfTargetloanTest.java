import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(47.166557f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(72.619606f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(89.49312f ) ;
  }
}
