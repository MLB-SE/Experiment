import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,540,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,5,5,9,-1879,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,7,9,2,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,7,9,429,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,7,8,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(3,1,2,6,-4,60,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(3,9,1,166,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(4,4,-940,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(5,324,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(-538,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(5,6,0,3,977,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(5,8,9,1,164,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(7,0,9,4,8,-815,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(8,1,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(815,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(8,1,795,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(845,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(8,4,6,8,4,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,5,180,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(8,-948,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(9,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,4,8,-20,0,0,0,0 ) ;
  }
}
