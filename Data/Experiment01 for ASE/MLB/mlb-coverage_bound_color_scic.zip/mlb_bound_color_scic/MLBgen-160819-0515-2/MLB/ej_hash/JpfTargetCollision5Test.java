import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(255,-608 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision5(9,-24403 ) ;
  }
}
