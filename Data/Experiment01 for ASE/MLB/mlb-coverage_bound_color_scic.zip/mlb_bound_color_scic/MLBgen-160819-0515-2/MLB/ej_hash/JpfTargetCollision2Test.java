import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-488,829,-186,-394 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-925,-674,-850,690 ) ;
  }
}
