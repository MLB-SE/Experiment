import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-324,-589,-125,696,150,215 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-586,-1537,342,-539,-57,1055 ) ;
  }
}
