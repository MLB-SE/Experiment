import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-25988,1215,270 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(80,270,-68 ) ;
  }
}
