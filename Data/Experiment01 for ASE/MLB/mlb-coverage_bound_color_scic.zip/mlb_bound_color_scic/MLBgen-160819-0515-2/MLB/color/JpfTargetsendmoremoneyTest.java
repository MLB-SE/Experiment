import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,2,0,3,22,9,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,3,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,8,9,5,11,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(309,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(3,1,-651,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(3,203,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(-321,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(3,-235,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(324,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(4,3,2,9,3,282,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(4,6,0,9,906,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(4,6,2,3,4,-352,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(4,7,7,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(5,0,1,6,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(5,3,351,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(6,216,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,3,2,-823,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(7,4,3,2,-46,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(7,6,611,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(8,2,7,7,2,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(8,6,0,1,8,744,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(8,7,7,842,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,8,6,509,0,0,0,0 ) ;
  }
}
