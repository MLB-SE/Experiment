import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.16164191f,-65.10578f,0f,53.904526f,17.596418f,0f,-75.7194f,0f,0f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.48087823f,-59.95411f,0f,91.13742f,53.758743f,0f,27.884647f,-84.16287f,0f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-10.05016f,-152.90854f,84.308815f,-7.8817596f,-27.299469f,35.42167f,5.6260495f,16.2851f,83.16148f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(10.212349f,-77.83222f,-99.9909f,18.681618f,-15.531863f,-2.3885353f,80.04598f,-0.58831286f,100.0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(10.511015f,-83.42177f,0f,16.019806f,89.7329f,0f,6.5517645f,10.187253f,-44.138462f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.705279f,62.069233f,0f,-3.3864236f,-26.709925f,-28.099417f,2.458952f,13.222232f,-33.094303f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-1.0984895f,-17.483212f,0f,-10.874249f,-35.72654f,-67.61031f,-6.671968f,-15.813623f,-20.855984f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-1.1269358f,-100.0f,100.0f,-4.5077434f,-13.294737f,58.479107f,-3.6093009f,-9.92946f,-22.8138f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-11.590805f,-60.741535f,-21.510658f,-85.62169f,70.68427f,0f,-22.688013f,52.86995f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-11.98055f,-75.39466f,-23.048862f,-72.527534f,29.707085f,0f,36.738476f,36.80443f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(12.018384f,-27.78761f,0f,-24.138853f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(12.291643f,-58.351353f,-83.0035f,7.517925f,10.017075f,96.95743f,7.762982f,-6.0557013f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(126.61602f,-49.72128f,214.27354f,36.770927f,3.1401901f,-50.00986f,17.327747f,75.52097f,21.15138f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(12.961985f,26.088697f,9.029472f,-74.24076f,-17.63667f,100.0f,-22.435076f,-15.499545f,-21.926435f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(13.044513f,-24.259752f,6.364993f,-23.562197f,52.27866f,0f,-48.234917f,0f,0f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(13.261087f,-59.546116f,0f,4.954792f,-0.526217f,19.126942f,7.0842977f,23.382399f,86.97152f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(13.298639f,-51.59082f,-46.667046f,4.785376f,-5.213616f,-14.837167f,11.05648f,40.788147f,-7.468005f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(13.316755f,-71.65038f,81.01922f,24.917402f,-13.392516f,-0.84822816f,99.74538f,-5.988859f,-47.36097f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(-13.38703f,-38.419846f,0f,1.8129448f,36.149723f,0f,-90.31162f,6.730677f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(136.29039f,-75.06268f,0f,28.744963f,15.177362f,-54.331985f,12.468102f,21.127447f,56.864323f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(1.3779147f,-74.61809f,-256.41043f,-3.0455675f,-17.834148f,-14.8487015f,5.627933f,20.778168f,97.623825f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(14.214486f,-27.53024f,45.474007f,-15.611815f,-57.53153f,16.026604f,-19.130219f,49.063084f,0f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(14.220454f,-100.0f,-100.0f,-19.527395f,-64.106255f,-36.911964f,-28.223778f,-99.985664f,16.458397f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(14.341594f,16.469004f,11.92028f,-59.10263f,-60.385857f,81.57181f,-18.646008f,-15.4814005f,42.468708f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(-14.541369f,43.985245f,97.29362f,-7.695576f,2.6214545f,41.95013f,-18.86239f,-67.75398f,67.88545f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(14.615716f,32.457405f,17.696245f,-73.994545f,-2.482333f,-61.67243f,73.141205f,7.72072f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(-15.058832f,27.067118f,0f,-37.66438f,20.860458f,0f,-15.193226f,-23.108524f,-98.10133f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(15.353411f,37.387344f,95.037674f,-75.9737f,-60.841713f,17.643442f,44.371418f,0f,0f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(15.356152f,0.08237771f,74.88642f,-38.657772f,4.7369337f,0f,-22.682026f,-52.070328f,1.8092461f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(-15.36004f,-25.992622f,0f,-42.578686f,-70.03918f,56.79143f,-84.91553f,78.20774f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(15.389172f,-74.78971f,100.0f,36.346397f,41.185505f,-44.39873f,88.81092f,-9.69494f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(-1.5450594f,58.323097f,0f,-3.3348157f,-34.61864f,47.524876f,-5.8571205f,-20.093668f,-39.898907f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(15.537256f,35.086025f,85.17071f,-72.937004f,-60.36387f,81.30454f,-33.800945f,-62.266777f,-14.329762f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(-15.549726f,-55.973137f,0f,1.0763428f,17.493961f,-0.17384182f,2.3611362f,8.368202f,0f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(15.579603f,-59.156853f,32.663277f,21.475266f,27.13847f,43.925972f,43.182987f,-52.361004f,0f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(-1.5724516f,-167.94505f,0f,-17.050638f,-58.884106f,163.3755f,-7.454158f,-6.4372697f,39.900414f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-16.316303f,-57.52285f,0f,-28.848589f,19.357718f,0f,-10.600551f,-13.553615f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(-163.8325f,81.434425f,-92.53313f,-29.32011f,21.57716f,12.485542f,24.979433f,21.708784f,-37.56598f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(-1.6519893f,85.39297f,0f,-81.20563f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(16.861639f,33.59591f,25.118511f,-66.14935f,-7.5965114f,-33.12186f,-15.327119f,4.840878f,42.28714f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(16.880716f,14.758956f,-84.04908f,-47.23609f,26.204191f,73.95397f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(-16.912457f,-77.43125f,0f,-98.89655f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(17.137741f,140.09116f,-139.97824f,14.640685f,48.491646f,83.638954f,-6.9799705f,-44.064312f,69.01914f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-17.164347f,41.60522f,-99.99629f,-1.7098923f,10.096916f,-2.1200452f,0.22545038f,2.6116939f,0.12291217f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(17.51787f,-19.940662f,-29.381847f,-9.987859f,-30.679422f,-6.239646f,-26.789883f,-97.17167f,6.6732364f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(17.795614f,-31.735632f,54.141476f,2.9180858f,-7.660229f,-11.256199f,1.5369589f,3.22975f,-59.26977f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(18.066544f,-55.08631f,0f,-14.907249f,-71.10457f,48.43707f,-6.5909767f,-11.456657f,31.868916f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(18.099943f,39.71209f,-23.265232f,-67.31232f,84.305016f,0f,-37.6993f,-83.48488f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(1.8109338f,-83.8383f,-100.0f,-10.539862f,-36.08733f,-28.978804f,-7.883053f,-20.99235f,-39.999016f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(18.126654f,-24.121302f,61.31611f,-3.3720806f,-26.501604f,0f,13.8376f,58.722477f,69.41459f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(18.177795f,-36.040867f,100.0f,8.5540905f,8.86719f,42.82412f,7.171377f,20.131418f,64.48711f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(18.37282f,-64.88458f,90.22353f,38.375862f,-15.676641f,0f,30.529493f,83.74211f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(-18.43947f,40.48861f,52.313145f,-214.25034f,28.139317f,69.33451f,-59.398415f,-22.984335f,-137.93712f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(18.493202f,-24.520845f,35.768333f,-1.5063455f,4.5960364f,-4.8164816f,-29.11462f,49.227818f,-64.995735f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(18.720411f,15.823967f,40.80813f,-40.942326f,-96.23267f,47.40855f,-86.257034f,100.0f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(18.761307f,-6.6854854f,-40.44321f,-18.269283f,-84.606926f,64.341f,-7.23152f,-10.656797f,49.211254f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(18.921509f,-40.70582f,-301.6374f,13.765578f,20.07066f,96.10288f,15.268105f,48.004726f,35.99594f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(19.04275f,-16.664503f,5.743659f,-7.164503f,45.95368f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(-19.374765f,-100.0f,0f,-6.2763133f,-3.9206774f,8.478083f,-1.8098093f,-0.96292436f,1.8787895f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(19.3776f,-23.97092f,1.5228226f,1.4813178f,-4.144521f,44.914295f,-9.307807f,-39.002777f,9.422785f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(20.166595f,93.080376f,0f,-4.1429f,-134.75822f,18.067892f,-10.416645f,-37.475594f,-4.6783195f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(20.190819f,-95.04353f,0f,32.850163f,22.205307f,0f,17.093699f,35.52463f,-20.124031f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(203.84949f,170.36726f,0f,52.504704f,-3.1512287f,1.4191695f,9.7481365f,-13.073957f,-58.42321f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(20.402744f,62.597084f,85.15714f,-80.98611f,-100.0f,23.227581f,-28.420786f,-32.697037f,-2.3673644f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(20.606245f,11.522486f,46.428936f,-29.097502f,50.506817f,-74.711945f,-8.953822f,-6.717787f,-68.42414f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(207.12596f,-182.57278f,0f,64.00039f,29.208447f,10.312771f,19.673489f,13.312442f,6.1033144f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(21.207256f,-13.699983f,81.94644f,-1.4709941f,-6.327185f,11.975645f,-20.764048f,-22.113409f,-27.716679f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(22.047483f,-42.193996f,-4.4486165f,2.1943078f,-12.892254f,-7.863025f,-0.3779987f,-3.7063026f,-14.11123f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(-22.125906f,95.66633f,0f,-31.057371f,77.10428f,0f,69.78257f,0f,0f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(22.49096f,19.579685f,-21.716862f,-29.615847f,-22.45536f,-74.17926f,62.901608f,-19.655146f,0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(-22.598719f,-26.986324f,0f,-31.71064f,-79.77924f,0f,-1.9602611f,60.082893f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(22.706295f,5.175584f,-100.0f,-14.350406f,-2.0039592f,-87.45427f,-78.10396f,55.69949f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(-23.057074f,-155.0249f,-41.115345f,-37.211197f,-76.48278f,-32.18767f,-15.913772f,-26.44389f,-14.657889f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(23.091942f,2.3915985f,-67.72129f,-10.023831f,-45.804253f,100.0f,-17.383013f,0f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(23.09329f,36.29974f,-64.45536f,-43.92658f,86.561035f,-95.56208f,-1.8724146f,36.43692f,61.05905f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(-23.09403f,-100.0f,0f,-61.31596f,-42.749004f,-64.566216f,-20.630386f,-21.205585f,-21.44295f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(23.099527f,13.315437f,8.3028345f,-20.917324f,-78.14062f,-57.421658f,-11.944771f,-26.861757f,-17.361647f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(-2.3099747f,20.75822f,83.25872f,2.1496084f,15.018037f,55.75244f,-4.1096287f,-18.588121f,-39.671276f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(23.201365f,16.256777f,41.825672f,-23.451311f,-99.99993f,51.04591f,-18.269567f,-49.626938f,-80.23826f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(23.28049f,15.080662f,31.447674f,-21.958694f,-94.40552f,-5.810743f,-17.305628f,-47.263813f,-70.369705f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(24.35151f,-22.09181f,-70.709236f,19.497847f,23.765665f,-2.342389f,29.874214f,99.99901f,-86.638435f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(24.56291f,7.851429f,-24.176968f,-9.599792f,-68.980225f,-38.366535f,6.0181518f,33.672398f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(24.665447f,3.616298f,-73.276505f,-4.9545064f,-36.923748f,-46.140438f,-7.559726f,-25.284397f,-8.344555f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(24.816475f,6.8752594f,-76.90218f,-7.6093583f,-20.413254f,-38.987263f,9.836682f,46.95609f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(24.824905f,-95.114555f,0f,47.609226f,71.83638f,0f,21.329815f,37.710037f,57.67395f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(25.08448f,-54.027973f,-6.7707157f,54.36589f,-42.23039f,-71.09425f,10.420963f,-12.682037f,-18.918724f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(25.441837f,27.633368f,-35.848217f,-25.866016f,-100.0f,-57.74945f,-13.775285f,-29.235123f,-3.1652093f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(-25.871101f,1.9755933f,0f,-9.368951f,-95.60819f,-85.56594f,84.003494f,-33.196526f,0f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(26.031647f,32.030815f,93.37774f,-27.90423f,-92.70833f,0f,-44.940243f,0f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(26.203703f,27.279423f,82.91399f,-22.46461f,-100.0f,-98.7415f,-16.062141f,-18.918797f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(26.507559f,58.174694f,5.71496f,-52.14446f,1.4549577f,0f,32.214054f,0f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(26.738358f,-8.060159f,-100.0f,15.013586f,11.337916f,-34.50046f,21.978071f,72.8987f,-14.678574f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(26.940622f,58.990746f,72.47148f,-51.228256f,36.550877f,-68.03135f,-43.054424f,0.2899986f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(26.983849f,28.422976f,16.209929f,-20.487581f,-29.501877f,-63.583263f,-79.4323f,-68.80655f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(27.090944f,6.9416013f,0f,-5.297939f,-31.18809f,72.1366f,-17.09461f,-63.080505f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(27.118187f,16.423029f,17.826717f,-7.950281f,-79.25279f,-73.93343f,20.333479f,89.284195f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(27.20687f,23.03273f,16.934587f,-14.205255f,-52.010536f,-52.556496f,10.2902775f,55.366367f,-91.71692f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(-27.32455f,34.96926f,0f,-12.543729f,-14.323945f,-56.788563f,-8.526419f,-21.561949f,13.014687f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(27.744886f,23.041485f,10.916691f,-12.061942f,-46.49564f,72.41179f,-29.497015f,100.0f,0f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(27.838316f,14.798091f,-94.23463f,-3.4448264f,24.883049f,32.74558f,-66.50067f,-79.80408f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(2.81808f,-66.39654f,39.113037f,-3.5411608f,-15.83417f,7.654072f,-1.148553f,-1.0530514f,7.3374195f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(28.370712f,52.028915f,37.479122f,-38.546066f,42.265823f,-2.11242f,-24.665981f,58.134937f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(28.465918f,36.990402f,-100.0f,-23.126728f,-46.96844f,0f,-59.97004f,-65.32957f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(28.566023f,30.894783f,13.884889f,-16.630693f,-18.871778f,-75.35523f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(28.64786f,-16.767015f,-35.980442f,31.358456f,-26.790909f,0f,91.23611f,0f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(28.911491f,19.879284f,-22.086855f,-4.2333612f,-19.83352f,4.8323054f,-26.011415f,-99.812355f,61.24961f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(28.997293f,11.116532f,2.6570547f,4.872645f,-87.18822f,-100.0f,8.753789f,30.14251f,-45.208187f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(29.427893f,30.3253f,-34.198887f,-12.613731f,-6.7211485f,0f,-16.216291f,-52.251434f,22.93737f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(-29.468506f,-57.73671f,0f,-71.36594f,-11.74218f,0f,-18.224735f,-1.5329994f,30.138071f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(29.63768f,27.050304f,35.66297f,-8.499586f,-85.04483f,0f,-9.39902f,-29.096495f,-21.942131f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(30.295097f,-61.195908f,11.361468f,82.3763f,-31.29346f,0f,57.96641f,44.6043f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(30.32048f,3.3732357f,50.47264f,17.76888f,22.115927f,10.534024f,18.639112f,56.78757f,100.0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(30.357683f,-30.963028f,0f,-17.891853f,-63.15886f,0f,99.58303f,0f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(30.418583f,30.272718f,-28.395115f,-8.598387f,-61.601463f,0f,10.115615f,49.06085f,-42.00723f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(30.423794f,17.212334f,-70.2358f,4.482841f,8.661346f,33.541916f,-21.153776f,80.986534f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(30.45699f,21.313963f,66.427155f,0.5139921f,-64.52204f,19.770329f,36.121017f,-50.951775f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(30.598349f,31.832726f,67.06843f,29.238588f,9.488642f,-11.737085f,76.86736f,-11.3796625f,41.405003f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(30.956324f,17.014347f,-44.197254f,4.5591264f,15.222995f,6.5863404f,-27.942812f,32.732162f,-38.289825f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(31.301357f,25.744137f,-61.89268f,-0.5387105f,33.567867f,35.154724f,-67.02407f,73.91132f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(31.37606f,21.083849f,-2.6043558f,14.446703f,8.340349f,13.897427f,18.0704f,-16.06658f,49.85371f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(31.61195f,68.285194f,-31.7185f,-41.837402f,13.44875f,0f,-5.304115f,20.620943f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(31.889624f,26.365826f,-15.090777f,1.1926676f,-10.278284f,50.9931f,-16.84067f,-68.55534f,-55.628696f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(31.95815f,16.038033f,0f,99.5762f,-5.251667f,0f,8.2476425f,-66.58564f,-19.442616f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(32.011475f,27.406334f,-51.10746f,0.6395721f,-74.50875f,38.598007f,45.055565f,22.24784f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(32.06605f,39.96636f,-41.69096f,-11.7021475f,69.49034f,-41.55213f,-100.0f,-40.809242f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(3.2100258f,8.238138f,-53.697712f,-95.39803f,-16.559761f,73.755356f,-75.846275f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(32.28238f,26.875154f,56.304142f,2.2543547f,-81.0859f,50.73609f,3.4306927f,0f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(32.306183f,30.971748f,29.958353f,-1.7538133f,-38.37807f,63.456875f,-0.9424649f,-2.0160463f,31.264065f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(32.366123f,35.286167f,82.64363f,-5.821674f,-73.86509f,18.712067f,-11.128344f,-38.6917f,-75.135124f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(32.636963f,23.792473f,-53.885643f,12.5093565f,11.94796f,-19.537954f,5.4525027f,31.027967f,-45.089157f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(32.818058f,30.954893f,-74.32603f,0.31733558f,27.203253f,13.219307f,-58.75197f,64.32147f,100.0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(33.051003f,19.669613f,-100.0f,12.534399f,0.81183136f,-100.0f,16.274763f,52.56465f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(33.203285f,79.883255f,48.89448f,-47.070114f,66.23682f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(33.4937f,27.801826f,-99.09192f,6.172972f,-2.2666295f,-10.727618f,-6.5351815f,-32.313698f,99.375114f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(33.57192f,28.634972f,-95.537636f,5.652699f,76.50561f,-99.47207f,-87.466736f,-43.622623f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(33.851803f,46.67719f,58.784126f,-11.269984f,-5.927172f,36.02075f,2.5770357f,21.578127f,89.66264f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(34.07854f,44.207222f,63.978874f,-4.2387204f,-45.72182f,-206.90344f,-6.8103976f,-19.723005f,-75.97744f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(34.290413f,18.315807f,48.3341f,18.845844f,37.658817f,-26.116823f,11.74275f,28.125156f,63.09906f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(34.665302f,32.6467f,3.1507769f,10.391091f,-6.8968267f,-160.16826f,20.305565f,71.78172f,88.800354f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(34.74976f,48.76549f,38.284744f,-9.766454f,22.027466f,4.3734813f,100.0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(34.8252f,26.0494f,-38.3733f,13.251396f,4.583245f,-65.10832f,13.597142f,44.140503f,15.753367f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(34.85829f,33.01792f,53.367363f,6.415238f,-56.153965f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(34.89141f,53.34547f,100.0f,-13.779829f,-21.509527f,-86.24117f,-12.637493f,-36.77014f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.283863f,42.919678f,0f,36.48394f,100.0f,-94.977394f,10.651902f,6.123669f,-86.15723f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(-35.326538f,25.47685f,41.557537f,-2.6505811f,27.895718f,98.79203f,-3.171504f,-10.035435f,-64.86595f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.55042f,25.83232f,-31.505724f,16.36935f,16.119358f,-13.996425f,13.807624f,36.272186f,-40.59933f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(35.629337f,-11.103044f,0f,-5.973382f,-57.67281f,22.821909f,-1.8500557f,-1.4268407f,34.094875f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(35.78661f,36.81824f,20.03658f,6.3306656f,-10.217424f,-99.91352f,-0.24486452f,-7.310124f,-18.778206f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(35.81826f,-44.566498f,0f,9.82024f,17.851513f,-64.42844f,-14.388812f,2.2775693f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(36.04321f,34.491085f,99.23732f,9.681755f,-97.31619f,82.33697f,100.0f,-27.314558f,0f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(36.24465f,42.241806f,85.05857f,2.7368097f,21.43341f,-100.0f,-46.730827f,38.981426f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(36.48366f,39.855465f,30.228348f,6.0791373f,-7.290184f,-99.99921f,-4.8766384f,-25.585691f,-90.1758f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(36.52246f,-19.819008f,0f,-79.126305f,-1.6019783f,72.26007f,-24.648977f,-19.46961f,-51.627483f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(36.569775f,40.84728f,-32.439274f,5.4318156f,12.9519615f,-35.812958f,-27.794472f,41.34171f,18.523502f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(36.706852f,-15.161574f,0f,23.202757f,-42.629314f,41.15035f,3.9049008f,-7.5831537f,8.391799f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(36.840176f,26.72413f,34.539494f,20.636574f,-64.48315f,-48.912918f,16.315428f,-45.2942f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(37.041695f,44.498886f,50.598515f,3.6678984f,-9.644669f,19.590158f,6.8688164f,23.807367f,8.095627f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(37.173172f,51.965878f,-73.82445f,-3.273192f,-57.731888f,0f,7.465948f,31.025719f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(37.310814f,27.331867f,-53.172424f,21.91138f,24.710625f,0.009444558f,25.624088f,49.5898f,28.499577f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(37.41452f,40.14999f,2.0670245f,9.508089f,21.118416f,-12.210194f,-20.500578f,37.07236f,13.565503f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(37.9128f,47.82291f,93.82725f,3.828287f,-40.44841f,99.994774f,17.848759f,-99.99983f,0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(38.00223f,-28.913664f,77.95306f,80.92259f,31.506876f,0f,13.841616f,-25.556131f,-14.29163f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(38.018646f,47.449684f,37.52422f,4.6249027f,14.255867f,2.6471894f,3.7412775f,10.340207f,33.887806f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(38.261333f,23.331491f,-84.797554f,29.713837f,30.507812f,88.476585f,50.086205f,-19.490658f,38.89863f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(38.363712f,39.75979f,-4.0619597f,13.695054f,24.737406f,-31.826086f,-8.3209f,13.026196f,35.688274f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(38.553925f,43.555454f,21.118221f,10.660251f,14.549664f,-97.88383f,-10.462586f,-26.945398f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(38.606895f,63.158733f,94.25927f,-8.731151f,19.768772f,-97.20657f,-93.30027f,0f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(39.19143f,30.220545f,25.827204f,26.545177f,-80.60249f,0f,5.9405518f,-2.7829707f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(-39.25902f,100.0f,0f,-12.745069f,-1.6586475f,-23.59171f,-10.062604f,-27.505348f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(39.451675f,36.414326f,4.731594f,21.392372f,-1.0992596f,-10.2137f,47.217075f,-51.990036f,-44.487133f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(39.60334f,6.914314f,-85.18006f,51.499054f,56.129677f,12.554302f,18.027836f,20.61229f,8.291648f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(39.682217f,63.056103f,0f,-3.107254f,-53.963966f,-94.55968f,1.8527329f,10.518186f,94.183975f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(39.92553f,54.065296f,11.061223f,5.636826f,-4.0630155f,-28.252375f,-13.315211f,45.08342f,0f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(40.04302f,61.232292f,28.070534f,-1.060226f,-25.316675f,-86.63001f,-18.967245f,-74.808754f,-26.43728f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(40.104233f,54.637867f,49.22035f,5.7790637f,0.08938396f,-56.60681f,-17.077362f,-74.08852f,-9.075806f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(40.1702f,60.867878f,-39.837357f,-0.18708225f,-42.32349f,8.001021f,1.4049639f,5.8069377f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(40.6742f,48.58004f,47.634304f,14.1167555f,6.011652f,64.87634f,9.781171f,-82.62536f,0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.80269f,46.971252f,26.637701f,16.2395f,20.444624f,-40.42045f,4.2095604f,0.5987411f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(40.97369f,43.505726f,-0.87495536f,20.38904f,16.998432f,-59.824406f,23.584036f,63.923367f,41.2638f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(41.066895f,39.021637f,-27.248041f,25.24594f,44.146046f,100.0f,15.770815f,37.837322f,-62.828316f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(41.123703f,36.53791f,100.0f,27.956903f,-46.736572f,0f,11.565851f,18.306501f,-6.6277037f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(41.140408f,77.75832f,0f,3.523191f,-20.287588f,-56.734592f,-6.760056f,-30.563416f,-95.20602f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(41.288475f,18.636219f,-100.0f,46.517677f,-28.351116f,-54.932415f,12.802475f,4.692224f,34.31754f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(41.431694f,100.0f,26.475447f,-34.27322f,20.94192f,0f,-11.242334f,-10.696119f,-52.484062f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(42.1232f,49.74263f,81.54981f,18.750174f,-0.15894987f,-41.71569f,33.036446f,27.460272f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(-42.220387f,83.68576f,80.85835f,-11.749395f,41.1093f,47.079185f,-45.886494f,45.42164f,66.34909f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(42.27826f,43.24264f,33.352676f,25.870398f,-2.6603737f,-9.831937f,11.961487f,21.97555f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(42.33311f,36.663235f,-3.8075197f,32.6692f,-28.859577f,0f,20.334427f,48.668507f,-20.2227f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(42.752533f,44.494736f,-23.309462f,26.515394f,58.535873f,-48.504322f,4.773173f,-0.5665736f,-10.985079f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(42.761154f,-17.03416f,0f,22.55188f,-38.638256f,-19.559422f,86.08462f,28.608847f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(42.836678f,-13.04206f,-96.70582f,84.38876f,-98.299095f,98.14527f,18.81164f,-9.142206f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(42.972034f,31.89127f,-55.125637f,39.99687f,39.71868f,-100.0f,77.29675f,15.682301f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(43.167294f,55.58406f,37.811996f,17.085114f,41.35696f,-37.219505f,-16.183802f,-95.70937f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(43.2713f,36.773098f,59.193275f,36.312107f,-55.372185f,100.0f,100.0f,80.98929f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(43.628757f,47.283947f,40.85827f,27.23108f,4.648771f,87.42068f,-63.367504f,15.509953f,0f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(43.78312f,49.05818f,-1.2272099f,26.074299f,53.676815f,100.0f,6.8372583f,1.2747341f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(43.81135f,28.447231f,-78.40693f,46.79818f,-23.463549f,2.3487172f,10.9012f,-3.1933784f,-0.21116531f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.867718f,56.298203f,55.44026f,19.172672f,25.871077f,19.382744f,6.950692f,8.63069f,1.6997898f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(43.86824f,155.06895f,121.059044f,38.399128f,73.69069f,-4.89056f,36.03759f,105.90718f,-84.6708f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(43.895523f,47.786747f,0f,62.548023f,-16.428698f,0f,15.738426f,0.4056825f,2.3130014f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(44.015438f,33.49454f,-2.5516338f,42.567204f,-63.27687f,0f,-2.4805884f,-52.48956f,41.8104f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(44.11997f,61.08838f,40.503944f,15.391503f,59.729595f,-100.0f,-42.28355f,33.955856f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(44.14502f,63.868473f,100.0f,12.711608f,11.328871f,8.593463f,58.63757f,97.57901f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(-44.186073f,14.237229f,0f,-19.619038f,-35.170376f,0f,0.8802967f,0f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(44.49541f,51.498222f,99.34794f,26.483418f,48.94534f,24.655088f,12.492922f,23.488268f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(44.937145f,47.61804f,57.100178f,32.130543f,-11.565164f,80.78267f,95.15019f,0f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(45.10778f,45.222584f,74.85867f,35.208538f,61.92424f,92.72713f,33.802135f,100.0f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(45.405193f,52.15169f,84.415184f,29.469078f,30.256062f,-6.675502f,42.215057f,46.078983f,-61.39234f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(45.72309f,55.79092f,46.079124f,27.101446f,31.361467f,28.525581f,31.321228f,14.027919f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(46.120773f,98.632645f,0f,-15.261081f,-26.164917f,-17.641193f,-81.00018f,63.337376f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(46.459343f,64.772865f,-100.0f,21.06451f,39.45675f,-2.3528087f,-1.65805f,74.34244f,-28.213886f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(46.4676f,64.56717f,39.023735f,21.303276f,72.77735f,98.00553f,12.654736f,29.315685f,31.83031f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(46.476246f,37.22044f,-100.0f,48.684544f,97.344406f,-100.0f,50.91752f,100.0f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(46.488197f,59.09975f,15.0572195f,26.85304f,40.078533f,17.832836f,20.845392f,56.528526f,16.195593f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(46.93967f,24.102346f,45.388058f,63.65634f,-95.91834f,57.44988f,8.096637f,-31.269794f,-63.43475f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(47.221375f,46.38432f,13.468334f,42.501186f,24.84756f,-89.197296f,12.549809f,7.698053f,-6.605159f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(47.288513f,60.444122f,42.656166f,28.709911f,46.437572f,40.851917f,21.113564f,55.74433f,71.7851f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(47.290302f,94.114914f,37.547115f,-4.9537024f,-48.810326f,8.087739f,-18.294788f,-47.307693f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(-47.66776f,-77.15756f,0f,24.834167f,13.392814f,0f,-2.11335f,-33.287567f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(47.677708f,34.583378f,61.20563f,56.127453f,-62.902412f,0f,7.6169887f,-25.659496f,-47.352566f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(47.731514f,15.040309f,-11.107333f,75.88575f,-76.462944f,20.497143f,27.159863f,0f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(47.77094f,65.83583f,71.77473f,25.247925f,43.797665f,55.2667f,9.423096f,12.444457f,5.3681016f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(48.001366f,48.19104f,40.94256f,43.814423f,3.8202407f,15.579187f,-70.88764f,33.614178f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(48.012962f,65.199356f,-100.0f,26.852495f,48.746754f,36.078712f,10.650262f,66.85646f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(48.106533f,74.68012f,100.0f,10.56342f,10.638018f,13.512034f,-16.490868f,-56.203506f,-56.589878f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(48.19401f,-25.523699f,0f,15.070402f,5.8771415f,9.303747f,6.210458f,9.771428f,26.998116f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(48.29507f,38.035374f,34.244884f,55.144913f,-30.39846f,-8.637164f,12.309346f,-5.907527f,-5.5409946f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(48.505733f,99.98307f,31.731928f,-5.960135f,65.16964f,-91.910545f,-3.5705197f,-8.321944f,-94.886894f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(-48.59693f,-35.847767f,36.73475f,-14.9343405f,-7.059002f,23.937479f,-4.08143f,-1.3913789f,5.5749164f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(48.703564f,20.846819f,27.588598f,73.96744f,-92.904884f,21.204014f,9.876072f,-34.463146f,65.145966f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(48.86678f,62.619087f,46.94591f,32.848034f,54.663662f,23.560198f,27.861685f,99.627335f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(49.14491f,65.83578f,0f,-1.1281081f,-12.725816f,-97.20887f,-40.931526f,-18.402067f,0f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(49.30832f,85.933846f,0f,17.929623f,18.604525f,75.990875f,3.8056507f,-2.7070208f,-33.23826f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(49.5277f,14.389466f,54.023144f,83.72133f,-83.86512f,-8.608066f,15.1965065f,-22.935303f,-23.072594f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(49.640602f,-20.877975f,0f,-93.22808f,52.880756f,0f,-2.2997544f,84.02906f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(49.7001f,37.06302f,85.46881f,61.73739f,-86.91684f,42.97101f,11.095794f,-17.354212f,6.4041996f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(-49.98581f,17.298527f,0f,-16.001951f,-2.9058383f,-7.942237f,-11.1161585f,-28.46268f,-99.82873f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(50.577873f,63.555614f,20.786228f,38.75588f,82.85836f,-83.425995f,21.58728f,47.593243f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(50.853725f,-92.58407f,0f,76.53964f,27.020956f,0f,5.516728f,-54.472733f,66.772385f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(-5.1000543f,26.047482f,34.28098f,11.451927f,17.026518f,98.95812f,33.881245f,-68.35146f,-15.399583f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(51.77949f,72.790375f,11.840188f,34.32758f,35.580307f,-3.5847154f,49.950527f,38.78798f,-100.0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(51.845135f,95.483086f,-67.9065f,11.897453f,4.7420173f,-18.428354f,-8.99734f,-91.26774f,0f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(52.630985f,-98.44369f,98.05574f,15.979043f,3.1180897f,78.247665f,8.167095f,16.689339f,2.9403396f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(52.99585f,26.758959f,54.039986f,85.224434f,-100.0f,-100.0f,43.776752f,89.882576f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(53.28071f,33.275658f,-48.86303f,79.84718f,28.684944f,-68.45905f,39.8818f,16.55257f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(53.857258f,3.0246558f,0f,7.0253468f,9.617136f,0f,-36.091797f,23.679983f,0f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(53.935345f,94.53042f,59.278297f,21.210958f,21.522877f,-54.008415f,9.385614f,16.331501f,17.706469f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(54.032093f,74.10426f,80.63037f,42.024113f,61.754574f,-100.0f,12.153955f,6.5917115f,-47.541687f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(-54.039932f,66.85143f,-58.010654f,-31.788322f,-11.418418f,-65.72112f,-61.69494f,-15.015656f,-80.736374f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(5.425262f,-99.99985f,-93.99943f,-15.389187f,-48.36745f,-19.01171f,-18.61456f,-59.069054f,-3.75143f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(54.66694f,99.82445f,68.898224f,18.430365f,14.217807f,-62.305885f,4.8367143f,0.92230254f,-15.345896f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(54.857624f,91.77161f,71.999245f,27.658886f,-59.61734f,0f,100.0f,-70.62593f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(54.889416f,28.684563f,46.918262f,90.87311f,-87.06943f,11.047867f,-1.6477985f,27.945833f,0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(55.67955f,7.037417f,0f,-29.410788f,32.062695f,0f,-55.18854f,-24.753263f,0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(55.701344f,70.39298f,25.666311f,52.412395f,-47.272194f,0f,-44.991386f,0f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(56.522568f,67.18201f,32.6707f,58.90827f,79.53475f,-36.4992f,2.5575602f,0f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(5.6669636f,-66.48357f,8.885177f,-10.8485775f,-12.204588f,-59.238758f,-36.856686f,87.75255f,-4.4948926f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(56.733482f,54.636375f,28.754631f,72.297554f,33.057384f,-39.617847f,17.367996f,-2.825569f,-54.08985f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(56.82615f,-5.9280214f,0f,-8.711705f,-46.542927f,15.838953f,-5.375149f,-12.78889f,0.76251596f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(56.870995f,-62.868973f,81.252045f,15.493421f,-32.000206f,14.5186f,37.102894f,-95.14387f,22.175512f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(5.6876116f,-10.666674f,0f,20.1634f,29.888786f,55.30527f,45.077206f,-50.09505f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(-57.825455f,-48.32731f,0f,-7.525725f,44.87374f,46.34426f,0.47688302f,9.433257f,-7.6175942f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(-58.37449f,-38.4032f,0f,-19.211432f,13.273761f,36.34537f,-31.744995f,-30.299212f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(-5.907594f,44.929314f,-25.6606f,-0.5938112f,5.6582284f,-13.792884f,-2.125879f,-7.9097047f,-35.16956f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(59.882664f,64.0663f,0f,4.08089f,43.506863f,0f,63.258842f,-92.82618f,0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(60.02795f,44.37672f,19.089493f,95.73508f,-57.716885f,0f,-80.45149f,-6.285346f,0f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(60.140976f,49.37504f,66.99187f,91.18886f,12.349147f,0f,-15.0505705f,-20.928537f,0f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(60.608917f,14.120464f,-100.0f,-5.582712f,-18.756346f,16.436863f,-64.18342f,-100.0f,49.237534f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(61.7906f,-53.597683f,0f,22.188253f,-37.652336f,0f,64.61475f,0f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(62.24742f,74.89742f,0f,55.102367f,-43.394695f,0f,37.16152f,-64.94737f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-62.465668f,-8.228516f,0f,-12.018203f,14.978386f,4.0065117f,-0.58553267f,9.676072f,24.311438f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(63.667923f,-59.528595f,57.03139f,5.692933f,-27.66743f,1.7739109f,-13.228761f,-58.607975f,-22.268316f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(63.78442f,58.9529f,48.739815f,96.18478f,23.287363f,13.363113f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(64.55221f,81.88906f,65.15213f,76.319786f,97.8519f,22.155151f,28.923264f,39.37327f,30.717913f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(65.375824f,-100.0f,0f,5.779771f,-41.325855f,-67.32017f,-0.93088317f,-9.503304f,-20.840487f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(66.16519f,100.0f,72.978325f,11.497211f,-3.5757322f,-47.900475f,-16.600613f,-77.899666f,20.986752f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-66.585175f,40.010864f,0f,-19.136026f,-1.7343861f,-16.484074f,-8.2245455f,-13.762154f,-63.771385f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-66.60366f,-52.895325f,0f,-17.165264f,-98.889175f,42.0412f,96.83177f,25.350471f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(6.6907043f,-28.520632f,0f,13.120048f,42.532776f,-55.370754f,5.6330624f,9.412202f,-10.517033f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(67.03065f,88.48597f,86.41529f,40.533966f,59.262478f,9.712306f,35.842735f,98.317665f,-97.97953f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(67.06947f,52.720295f,0f,66.83621f,44.85367f,-34.402477f,18.864084f,8.620125f,-29.237253f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(68.10937f,-41.89646f,0f,28.822025f,-1.7971386f,0f,-33.307384f,0f,0f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(-68.27743f,-54.25204f,-95.688614f,-34.404778f,-17.850895f,-27.626558f,-51.490788f,44.8798f,3.0332704f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(68.67659f,-85.97141f,0f,80.71988f,70.36369f,0f,10.308345f,-39.4865f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(68.82498f,9.674098f,0f,39.733814f,75.71212f,-58.28776f,14.398157f,17.858812f,-18.675035f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(-6.948015f,-81.95759f,-77.25133f,-45.83447f,71.71068f,0f,-2.5144315f,35.776745f,73.91073f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(69.58357f,-37.54563f,0f,29.78479f,33.248768f,-31.655037f,16.306816f,-98.06448f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(71.323746f,85.29497f,25.02036f,100.0f,96.09537f,100.0f,29.106026f,16.424107f,-59.50497f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(-71.94607f,93.01992f,26.19011f,-8.26449f,35.166367f,32.75859f,3.721741f,23.151453f,-45.802975f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(72.759445f,-52.88046f,0f,23.092735f,-21.933022f,28.343082f,41.544518f,-104.2927f,0f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(73.24968f,21.282747f,0f,-49.183918f,-69.57133f,0f,3.2549822f,62.203846f,-38.757984f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-73.25158f,27.241562f,0f,-23.381107f,-10.244083f,0f,-9.47115f,-14.503493f,-90.61079f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(-73.27053f,-84.49708f,0f,-35.4921f,-56.153847f,-95.27776f,-12.544018f,-14.683972f,55.932095f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(-73.82348f,83.38296f,0f,-76.298874f,19.57739f,0f,38.200096f,-47.144775f,0f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(73.88038f,-100.0f,0f,34.125164f,32.123188f,23.159718f,30.497093f,87.86321f,0f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(75.21003f,5.2545443f,0f,10.8790045f,-33.92831f,-44.501976f,2.2343013f,-1.9417987f,23.926817f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(75.538f,-75.933784f,0f,8.513652f,-74.014175f,40.121742f,32.530773f,-50.34794f,0f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(-75.65943f,10.714275f,0f,11.195179f,-27.81935f,0f,0.7629102f,-8.143538f,-22.697994f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(76.5846f,78.11761f,0f,22.11448f,-22.91185f,-27.335526f,4.731861f,-3.1870365f,5.431843f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(76.72232f,-100.0f,32.24433f,21.141493f,-4.839832f,8.080813E-4f,12.683484f,59.49837f,-27.401266f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(77.46395f,7.745137f,0f,-12.345569f,-100.0f,100.0f,-26.846224f,-95.03932f,-100.0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(77.756516f,-89.30383f,0f,-4.8265285f,-89.179375f,0f,-2.8520396f,-6.58163f,65.704895f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(-82.6096f,-9.413299f,7.205588f,-27.919874f,-15.788565f,-0.6156249f,-13.281334f,-25.205463f,6.120477f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(82.66757f,3.7890651f,0f,37.37495f,80.458115f,-30.535082f,-13.625895f,-91.87853f,16.21693f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(-83.42887f,70.709915f,0f,79.33014f,79.24498f,-16.190998f,26.620375f,27.151361f,2.7400913f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(86.039635f,-19.049881f,-15.995693f,19.024187f,-5.628328f,13.79478f,-4.314553f,-36.2824f,34.72195f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(86.42618f,-96.519745f,100.0f,18.065052f,-22.767109f,-28.953238f,8.601137f,16.339499f,79.523964f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(87.73589f,-5.106841f,-12.179721f,19.581636f,-11.401171f,-48.46515f,1.9918277f,-11.61433f,-37.04798f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(8.858376f,-18.074627f,0f,5.081671f,29.283913f,96.48712f,-17.815605f,33.64149f,0f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(8.909125f,-66.553474f,93.79827f,2.1578076f,-5.8227634f,21.082943f,5.544869f,20.021667f,-3.643738f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(8.988792f,-48.84359f,16.02018f,-15.201242f,-41.727936f,0f,-28.065828f,0f,0f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(90.998f,-2.4031005f,-64.63598f,42.0266f,18.794287f,89.133865f,58.314114f,-53.58022f,-13.708384f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(-93.12274f,27.949959f,0f,-4.5426335f,80.3227f,-41.514423f,-5.3704896f,-11.600792f,0f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(94.143326f,55.555935f,21.307354f,34.224728f,21.46488f,-54.85921f,21.2907f,50.938076f,12.2516985f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(-95.365456f,-24.451523f,36.873108f,-41.470837f,-6.557173f,0.17957267f,-63.96072f,39.5141f,33.228436f ) ;
  }
}
