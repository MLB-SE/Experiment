import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(37.736965f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(70.66373f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(92.67356f ) ;
  }
}
