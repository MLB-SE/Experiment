import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-322,120 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-444,196 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-445,287 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(864,-227 ) ;
  }
}
