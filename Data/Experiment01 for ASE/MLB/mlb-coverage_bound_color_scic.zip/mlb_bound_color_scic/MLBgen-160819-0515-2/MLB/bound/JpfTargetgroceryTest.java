import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(129,401,148,33 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(147,847,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(173,470,39,29 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(181,449,11,70 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(181,622,44,501 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(235,119,631,-998 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(287,0,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(372,313,5,11 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(382,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(395,549,8,226 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(421,324,82,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(47,441,76,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(478,218,1,14 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(503,907,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(514,284,910,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(590,-400,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(601,710,267,894 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(-652,0,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(681,641,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(698,34,-10,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(951,0,0,0 ) ;
  }
}
