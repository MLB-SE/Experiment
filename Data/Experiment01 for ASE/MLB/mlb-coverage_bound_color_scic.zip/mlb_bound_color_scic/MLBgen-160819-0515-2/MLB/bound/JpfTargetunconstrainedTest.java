import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,8,-750,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,10,2,-820 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(2,10,1,772 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(281,0,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,6,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(425,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(4,3,4,0 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(5,600,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(5,8,847,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(6,-130,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(-640,0,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(6,7,6,10 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(7,2,7,629 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(7,621,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(8,4,3,10 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(8,5,348,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(9,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,6,8,10 ) ;
  }
}
