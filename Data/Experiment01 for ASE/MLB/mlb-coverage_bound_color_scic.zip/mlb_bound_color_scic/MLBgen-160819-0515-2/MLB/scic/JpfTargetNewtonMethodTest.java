import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-14.360180304074817,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-2.7550623827848284,30.603377956218935 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-33.21843245527201,4.179846136609356 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-38.85197336779258,7.402138069984289 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-41.25000000000001,0.0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-43.42268368871903,0.23161571477150034 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-5.006681863168595,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-61.25,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(648.4477215362052,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(70.36759800214273,-95.78788784001924 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-73.25,-40.18399359282779 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-88.38687947334824,-35.824550261931634 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-90.17773944749757,0.08421358670639734 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(94.04916610644943,0 ) ;
  }
}
