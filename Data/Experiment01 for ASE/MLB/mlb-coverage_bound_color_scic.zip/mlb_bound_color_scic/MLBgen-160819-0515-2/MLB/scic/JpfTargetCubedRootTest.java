import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(20.860225876812038 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119125 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(40.061829219751445 ) ;
  }
}
