import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.16693903722647008,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.8452566802580179,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-15.620560494280838,56.436256260682114 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535054543452,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(16.775107294210784,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-1.7943768584275404,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-26.617279261322196,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(30.14573606001261,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-31.39037754252068,-20.34275408920307 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(32.33652351957582,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(35.53153493177831,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-36.2438092999575,-0.8867102950605101 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-37.52213820422907,88.68086589741097 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(-4.109991199855017,-64.24055814372943 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(55.77060968522599,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-5.888074547567214,26.099500375429386 ) ;
  }
}
