import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(23.27979824800596 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2715.3238817535625 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2717.9293774873872 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2718.272887968331 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2724.9883703974956 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2726.6162528884297 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2727.031359988134 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2727.9883664146914 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(40.48896595777077 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-42.644508751175316 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(75.88729368836982 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-87.03935515904242 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(87.90135479609518 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(91.21645444725058 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(92.06479149686018 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.49136921726449 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(95.22936045333569 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(95.97380330942283 ) ;
  }
}
