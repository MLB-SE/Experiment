import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.24878174166011 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(26.487105125860765 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-7.851721415073953 ) ;
  }
}
