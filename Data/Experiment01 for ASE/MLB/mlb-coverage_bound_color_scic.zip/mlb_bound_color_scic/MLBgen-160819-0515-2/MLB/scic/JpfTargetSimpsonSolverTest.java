import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-21.480187767691092,81.17729708024746 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(37.7879685225233,-46.04945948508099 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-77.08084203219535,0.23567652420984375 ) ;
  }
}
