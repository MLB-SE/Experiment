import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0);
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,1);
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,2,3);
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,5,5);
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,5,-8);
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,5,91);
  }

  @Test
  public void test6() {
    bound.golomb.solve(1,1,3);
  }

  @Test
  public void test7() {
    bound.golomb.solve(1,2,4);
  }

  @Test
  public void test8() {
    bound.golomb.solve(4,5,4);
  }

  @Test
  public void test9() {
    bound.golomb.solve(5,3,3);
  }

  @Test
  public void test10() {
    bound.golomb.solve(5,-8,0);
  }

  @Test
  public void test11() {
    bound.golomb.solve(5,91,0);
  }

  @Test
  public void test12() {
    bound.golomb.solve(-8,0,0);
  }

  @Test
  public void test13() {
    bound.golomb.solve(91,0,0);
  }
}
