import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,1,3,3);
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,1,3,-7);
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,1,3,91);
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,3,-7,0);
  }

  @Test
  public void test5() {
    bound.allinterval.solve(1,3,91,0);
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,-7,0,0);
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,91,0,0);
  }

  @Test
  public void test8() {
    bound.allinterval.solve(91,0,0,0);
  }
}
