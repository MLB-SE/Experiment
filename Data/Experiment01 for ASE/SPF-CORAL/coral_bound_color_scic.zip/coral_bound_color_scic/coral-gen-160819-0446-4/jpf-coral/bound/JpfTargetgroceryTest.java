import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(199,58,635,-8);
  }

  @Test
  public void test2() {
    bound.grocery.solve(199,58,635,831);
  }

  @Test
  public void test3() {
    bound.grocery.solve(204,103,148,256);
  }

  @Test
  public void test4() {
    bound.grocery.solve(58,635,-8,0);
  }

  @Test
  public void test5() {
    bound.grocery.solve(58,635,831,0);
  }

  @Test
  public void test6() {
    bound.grocery.solve(635,-8,0,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(635,831,0,0);
  }

  @Test
  public void test8() {
    bound.grocery.solve(711,0,0,0);
  }

  @Test
  public void test9() {
    bound.grocery.solve(-8,0,0,0);
  }

  @Test
  public void test10() {
    bound.grocery.solve(831,0,0,0);
  }
}
