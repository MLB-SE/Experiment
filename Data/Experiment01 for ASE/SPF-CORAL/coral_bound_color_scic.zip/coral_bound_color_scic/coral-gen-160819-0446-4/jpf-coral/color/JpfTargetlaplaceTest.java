import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.0f,0.0f,0,0.0f,0.0f,0.0f,0.0f,0.0f,0);
  }

  @Test
  public void test1() {
    color.laplace.solve(0.0f,0.0f,0,0.0f,0.0f,-91.75842f,0.0f,63.495792f,0);
  }

  @Test
  public void test2() {
    color.laplace.solve(-10.291502f,27.389782f,0,-83.96376f,2.0974057f,0,63.524094f,-49.002445f,0);
  }

  @Test
  public void test3() {
    color.laplace.solve(-11.436121f,64.696014f,0,-21.717787f,23.543196f,-47.928753f,-98.97822f,99.12331f,0);
  }

  @Test
  public void test4() {
    color.laplace.solve(12.680305f,46.00106f,57.459248f,-95.27984f,-30.055437f,0,-39.701134f,-63.524693f,-2.7133594f);
  }

  @Test
  public void test5() {
    color.laplace.solve(14.316454f,-30.628035f,0,-19.73658f,-2.3769956f,4.759464f,-3.6144485f,5.278786f,27.10659f);
  }

  @Test
  public void test6() {
    color.laplace.solve(-14.674643f,-21.517756f,0,27.850325f,63.031097f,-15.495569f,63.04485f,-51.659718f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(-14.908776f,-78.35552f,0,52.438717f,84.95465f,0,16.984934f,-26.718035f,0);
  }

  @Test
  public void test8() {
    color.laplace.solve(17.853567f,-25.985365f,15.364411f,-2.6003659f,-41.86276f,-99.932335f,13.607728f,-49.144714f,0);
  }

  @Test
  public void test9() {
    color.laplace.solve(18.697617f,-58.917374f,0,3.293396f,-90.98778f,0,-1.904858f,-10.912828f,83.69974f);
  }

  @Test
  public void test10() {
    color.laplace.solve(20.269806f,-65.38115f,0,13.800403f,76.77212f,40.30511f,-41.840317f,-34.27344f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(20.937738f,-29.395977f,-19.233715f,13.146931f,-59.544178f,-84.05102f,91.19416f,-99.01234f,0);
  }

  @Test
  public void test12() {
    color.laplace.solve(-21.331118f,51.857903f,0,2.9708178f,-7.2646146f,33.45604f,40.479004f,-41.296494f,0);
  }

  @Test
  public void test13() {
    color.laplace.solve(25.040976f,18.84522f,10.962151f,-18.681314f,-60.622246f,-19.662773f,-39.143986f,-97.62313f,0);
  }

  @Test
  public void test14() {
    color.laplace.solve(25.803694f,99.89009f,-38.619133f,-96.675316f,3.8103023f,0,9.242121f,23.855087f,0);
  }

  @Test
  public void test15() {
    color.laplace.solve(-2.7754753f,-63.711052f,20.663694f,-47.39085f,-99.872894f,-36.063484f,-86.91502f,-24.870451f,0);
  }

  @Test
  public void test16() {
    color.laplace.solve(27.974981f,-61.21788f,97.41134f,73.117805f,-94.86352f,0,26.373306f,85.37416f,0);
  }

  @Test
  public void test17() {
    color.laplace.solve(29.53914f,-13.008647f,28.348999f,31.16521f,18.62577f,0,4.8839197f,-11.629531f,-0.11231646f);
  }

  @Test
  public void test18() {
    color.laplace.solve(29.930342f,-10.040776f,-56.53559f,29.762144f,51.700413f,0,17.105108f,-32.91059f,0);
  }

  @Test
  public void test19() {
    color.laplace.solve(30.636137f,26.700165f,34.71217f,-4.1556144f,-58.54765f,30.458225f,11.289056f,-14.5557375f,0);
  }

  @Test
  public void test20() {
    color.laplace.solve(30.933538f,34.716133f,9.495358f,-10.981984f,-1.56436f,-58.0094f,-10.420725f,-2.3495684f,0);
  }

  @Test
  public void test21() {
    color.laplace.solve(-32.93572f,-13.542289f,0,-8.126755f,2.6564798f,0,4.5926366f,26.497301f,-32.63242f);
  }

  @Test
  public void test22() {
    color.laplace.solve(33.33662f,64.56694f,99.41346f,-31.220465f,25.517693f,90.38002f,7.0636754f,-41.372353f,0);
  }

  @Test
  public void test23() {
    color.laplace.solve(-33.650574f,66.243256f,0,-42.416958f,52.235313f,0,-31.845034f,-84.96317f,41.40851f);
  }

  @Test
  public void test24() {
    color.laplace.solve(34.881927f,25.985876f,-36.96743f,13.541829f,6.0290046f,34.803635f,-44.26072f,71.97088f,0);
  }

  @Test
  public void test25() {
    color.laplace.solve(36.389767f,11.989421f,5.1095448f,33.569645f,-93.541626f,-96.868774f,-99.164894f,-66.04818f,0);
  }

  @Test
  public void test26() {
    color.laplace.solve(37.267895f,7.366733f,0,-19.09257f,30.773632f,14.85374f,-2.9393122f,7.335321f,1.506964f);
  }

  @Test
  public void test27() {
    color.laplace.solve(37.494606f,33.33565f,-58.465927f,16.64277f,25.120619f,53.78832f,3.955859f,-4.570185f,0);
  }

  @Test
  public void test28() {
    color.laplace.solve(37.629356f,77.780914f,88.44605f,-27.263487f,-27.462341f,0,-33.850746f,7.8940845f,0);
  }

  @Test
  public void test29() {
    color.laplace.solve(3.7944546f,-81.03796f,-89.5355f,-3.784229f,-85.05406f,0,84.3336f,40.540012f,0);
  }

  @Test
  public void test30() {
    color.laplace.solve(39.98057f,-19.502811f,0,-66.59554f,-55.10556f,0,31.037415f,-56.68943f,0);
  }

  @Test
  public void test31() {
    color.laplace.solve(40.435535f,30.922852f,-93.63727f,30.819288f,76.89314f,-17.62335f,59.924137f,-58.138287f,0);
  }

  @Test
  public void test32() {
    color.laplace.solve(40.720573f,33.955387f,-19.623716f,28.926905f,14.724688f,4.992067f,60.26236f,-65.71959f,0);
  }

  @Test
  public void test33() {
    color.laplace.solve(41.61802f,53.431503f,-5.3476624f,13.040569f,-58.045147f,67.97063f,68.5894f,10.236161f,0);
  }

  @Test
  public void test34() {
    color.laplace.solve(42.16445f,58.464817f,-16.630304f,10.19299f,44.614418f,65.79861f,-46.00691f,-41.037212f,0);
  }

  @Test
  public void test35() {
    color.laplace.solve(-4.264046f,-23.912422f,0,-27.696154f,-52.66218f,-11.557281f,-53.858387f,-56.696568f,0);
  }

  @Test
  public void test36() {
    color.laplace.solve(43.580452f,74.57688f,-2.5116637f,-0.2550728f,-5.0426593f,0,20.223679f,81.14979f,53.131493f);
  }

  @Test
  public void test37() {
    color.laplace.solve(43.61361f,58.930737f,42.891754f,15.523702f,49.217587f,3.1198971f,-22.128681f,-42.14288f,0);
  }

  @Test
  public void test38() {
    color.laplace.solve(44.0661f,12.664963f,-85.750854f,63.599438f,-7.6553955f,-55.333775f,15.515533f,-31.360382f,0);
  }

  @Test
  public void test39() {
    color.laplace.solve(45.29609f,95.91135f,18.424072f,-14.726987f,-46.297512f,16.311003f,-57.906525f,-66.94858f,0);
  }

  @Test
  public void test40() {
    color.laplace.solve(45.54436f,47.820644f,0,20.606295f,-8.461459f,22.055477f,45.342278f,-29.105824f,0);
  }

  @Test
  public void test41() {
    color.laplace.solve(46.704956f,39.10429f,-82.785545f,47.715538f,0.34068373f,0,16.925268f,-10.248143f,0);
  }

  @Test
  public void test42() {
    color.laplace.solve(51.17278f,-84.15671f,0,98.537476f,-5.9352694f,0,39.643387f,60.03607f,-24.941687f);
  }

  @Test
  public void test43() {
    color.laplace.solve(51.284527f,38.659073f,0,64.93484f,84.50484f,0,-49.51468f,71.56921f,0);
  }

  @Test
  public void test44() {
    color.laplace.solve(55.99663f,70.36656f,-26.509315f,53.619972f,-37.98866f,0,10.459655f,-11.781356f,0);
  }

  @Test
  public void test45() {
    color.laplace.solve(56.672985f,79.75771f,75.23408f,46.934235f,43.835163f,0,-32.256172f,-42.823135f,0);
  }

  @Test
  public void test46() {
    color.laplace.solve(56.73488f,46.54931f,-6.662691f,80.39021f,49.75898f,0,34.296947f,56.79758f,-60.846935f);
  }

  @Test
  public void test47() {
    color.laplace.solve(-57.83774f,-54.167435f,0,-68.08897f,-63.647816f,0,-70.550606f,96.873f,0);
  }

  @Test
  public void test48() {
    color.laplace.solve(57.982693f,80.94965f,88.667114f,50.981113f,77.14881f,-0.14495039f,9.52997f,-54.224384f,0);
  }

  @Test
  public void test49() {
    color.laplace.solve(60.841984f,-24.50144f,0,2.976589f,-44.065285f,-16.281729f,-4.870343f,-22.457962f,-62.475994f);
  }

  @Test
  public void test50() {
    color.laplace.solve(65.970535f,47.19748f,0,52.753597f,49.346542f,83.74016f,95.69731f,-1.2457043f,0);
  }

  @Test
  public void test51() {
    color.laplace.solve(-6.864824f,-31.257502f,70.06766f,-96.2018f,19.944794f,0,-53.28891f,72.92935f,0);
  }

  @Test
  public void test52() {
    color.laplace.solve(71.25071f,-13.361245f,0,0.2588112f,-58.20673f,-31.570414f,-12.008738f,-48.293762f,-72.35203f);
  }

  @Test
  public void test53() {
    color.laplace.solve(72.98576f,53.10362f,0,9.494373f,6.6039944f,0,-4.4915643f,-27.46063f,12.038282f);
  }

  @Test
  public void test54() {
    color.laplace.solve(7.6137686f,-63.363686f,45.85728f,-6.181239f,47.23538f,99.42656f,-79.574104f,-99.14975f,0);
  }

  @Test
  public void test55() {
    color.laplace.solve(-78.10756f,-38.379807f,0,69.11005f,97.204544f,0,-41.97757f,-84.57322f,0);
  }

  @Test
  public void test56() {
    color.laplace.solve(83.494675f,58.966007f,0,-97.732025f,90.891884f,0,-0.16050276f,97.09002f,85.07874f);
  }

  @Test
  public void test57() {
    color.laplace.solve(87.30315f,54.728313f,0,27.774519f,16.276768f,0,-2.3469036f,-73.77909f,0);
  }

  @Test
  public void test58() {
    color.laplace.solve(88.12434f,-38.390915f,0,3.6796267f,-76.55832f,-33.03262f,3.1524825f,71.24019f,0);
  }

  @Test
  public void test59() {
    color.laplace.solve(88.909546f,-7.933851f,0,-76.349754f,-4.2302885f,0,-50.098484f,-12.846672f,0);
  }

  @Test
  public void test60() {
    color.laplace.solve(-92.404976f,-34.019005f,0,-36.808052f,-87.9659f,0,-15.08767f,-23.542627f,-73.08075f);
  }

  @Test
  public void test61() {
    color.laplace.solve(-94.177246f,-47.27096f,0,60.78629f,-18.489477f,0,-7.721756f,-91.67332f,-54.233814f);
  }
}
