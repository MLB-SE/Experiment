import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(0,0);
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(1,1);
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(1,15);
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(15,0);
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(1,-85);
  }
}
