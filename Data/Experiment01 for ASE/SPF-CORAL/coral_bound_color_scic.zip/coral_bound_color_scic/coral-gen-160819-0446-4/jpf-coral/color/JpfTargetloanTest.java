import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(0.0f);
  }

  @Test
  public void test1() {
    color.loan.solve(65.77794f);
  }

  @Test
  public void test2() {
    color.loan.solve(71.00639f);
  }
}
