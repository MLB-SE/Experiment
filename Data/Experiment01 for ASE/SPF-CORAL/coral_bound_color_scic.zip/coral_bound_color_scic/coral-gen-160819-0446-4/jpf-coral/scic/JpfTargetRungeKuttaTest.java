import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(0.0);
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(131458.25582335176);
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(15311.143807108632);
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(179125.7891676017);
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(204464.2770120378);
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(205256.5945277702);
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(21896.3980141882);
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(268701.6488488168);
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(268747.9917382581);
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(31275.7837020482);
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(32217.313499087497);
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(61713.3561363289);
  }
}
