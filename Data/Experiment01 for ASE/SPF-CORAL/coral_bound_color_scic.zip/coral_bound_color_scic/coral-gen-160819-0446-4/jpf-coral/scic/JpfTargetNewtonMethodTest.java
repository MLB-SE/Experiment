import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,1.94155443292792);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(1.0471975511965976,0.16776588897889133);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(3.9269908169872414,19.6712195192);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(5.235987755982989,61.2332786929);
  }
}
