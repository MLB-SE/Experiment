import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,28.852574628949125);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543465,0.0);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535054543467,2.6735395568909106);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(19.6712195192,1.2784346741430507E83);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(3.2930390163,77.5440917569);
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-54.0082617418,0);
  }
}
