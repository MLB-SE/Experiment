import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-22.3909790634,53.3756786273);
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-3.75801995079738,3.94531726199436);
  }
}
