import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,21,0,0);
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,3,1,1);
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,3,1,21);
  }

  @Test
  public void test4() {
    bound.allinterval.solve(1,3,1,-78);
  }

  @Test
  public void test5() {
    bound.allinterval.solve(1,-78,0,0);
  }

  @Test
  public void test6() {
    bound.allinterval.solve(21,0,0,0);
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,1,21,0);
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,1,-78,0);
  }
}
