import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(0,0);
  }

  @Test
  public void test1() {
    bound.unbounded.solve(11,67);
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-84,-58);
  }
}
