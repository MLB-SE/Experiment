import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,21,0,0);
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(1,-78,0,0);
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(21,0,0,0);
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,8,1,2);
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(3,8,1,21);
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(3,8,1,-78);
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(8,1,21,0);
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(8,1,-78,0);
  }
}
