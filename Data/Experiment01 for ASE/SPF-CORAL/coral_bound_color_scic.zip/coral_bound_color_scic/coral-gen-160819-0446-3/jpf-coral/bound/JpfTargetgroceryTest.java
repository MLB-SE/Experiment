import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(164,19,715,0);
  }

  @Test
  public void test2() {
    bound.grocery.solve(190,572,53,-79);
  }

  @Test
  public void test3() {
    bound.grocery.solve(190,734,0,0);
  }

  @Test
  public void test4() {
    bound.grocery.solve(49,611,396,764);
  }

  @Test
  public void test5() {
    bound.grocery.solve(53,-79,0,0);
  }

  @Test
  public void test6() {
    bound.grocery.solve(572,53,-79,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(60,242,222,187);
  }

  @Test
  public void test8() {
    bound.grocery.solve(734,0,0,0);
  }

  @Test
  public void test9() {
    bound.grocery.solve(-79,0,0,0);
  }
}
