import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f);
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.3813975f,-3.072912f,0,0.23398915f,-2.1949725f,0,0.3012634f,0.9710644f,96.017715f);
  }

  @Test
  public void test2() {
    color.laplace.solve(11.617092f,9.275438f,0,1.3777031f,0.54062706f,0,2.2278688f,7.5337725f,8.185917f);
  }

  @Test
  public void test3() {
    color.laplace.solve(14.377383f,-93.730286f,-17.137022f,51.23982f,7.8983474f,0,-78.06554f,-95.17771f,0);
  }

  @Test
  public void test4() {
    color.laplace.solve(15.588016f,-11.142647f,-1.3874762f,-26.50529f,30.747484f,0,-18.119068f,-45.97098f,8.911684f);
  }

  @Test
  public void test5() {
    color.laplace.solve(17.038855f,60.046806f,95.019936f,-91.89139f,28.12843f,74.03271f,-88.03149f,96.07368f,0);
  }

  @Test
  public void test6() {
    color.laplace.solve(17.919876f,-30.913538f,8.641314f,2.593041f,15.441228f,-12.248427f,-22.98894f,-12.75052f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(19.95518f,11.861346f,86.662445f,-32.04063f,19.79935f,0,8.330518f,65.3627f,-74.89009f);
  }

  @Test
  public void test8() {
    color.laplace.solve(22.027178f,0.20614749f,0,-12.440601f,60.744167f,0,-14.679894f,-46.278976f,58.7784f);
  }

  @Test
  public void test9() {
    color.laplace.solve(22.55484f,-51.533337f,-55.68849f,9.552847f,-9.08923f,96.10409f,24.745777f,-90.480515f,87.2784f);
  }

  @Test
  public void test10() {
    color.laplace.solve(22.7995f,22.873142f,28.439548f,-31.675142f,-59.74648f,-57.303253f,8.966883f,27.298435f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(-23.119259f,40.7948f,0,41.796265f,12.237848f,0,-76.34708f,-19.731878f,0);
  }

  @Test
  public void test12() {
    color.laplace.solve(-23.773365f,88.02878f,0,16.984945f,-20.56383f,0,2.8506515f,-5.5823383f,-5.6660447f);
  }

  @Test
  public void test13() {
    color.laplace.solve(23.960432f,25.3199f,-5.6370616f,-29.478168f,-17.04377f,-2.98121f,-24.830513f,-69.41223f,0);
  }

  @Test
  public void test14() {
    color.laplace.solve(24.820894f,-16.111477f,-23.269608f,15.395057f,15.621867f,0,-2.2161627f,-24.259708f,-3.2655375f);
  }

  @Test
  public void test15() {
    color.laplace.solve(26.398403f,13.418392f,27.965601f,-7.824779f,-71.15857f,14.951939f,13.461047f,37.705532f,0);
  }

  @Test
  public void test16() {
    color.laplace.solve(27.762144f,30.731462f,-14.4564085f,-19.68289f,9.620119f,4.6390276f,-11.865551f,-27.779314f,-4.7469854f);
  }

  @Test
  public void test17() {
    color.laplace.solve(28.150782f,19.812626f,49.40303f,-7.209498f,-30.851044f,-24.22249f,-26.13773f,-35.557144f,0);
  }

  @Test
  public void test18() {
    color.laplace.solve(28.243738f,-22.335274f,-20.504128f,35.310226f,-16.63212f,0,20.408962f,46.325623f,-25.779812f);
  }

  @Test
  public void test19() {
    color.laplace.solve(28.587372f,-7.497453f,1.41688f,21.846941f,2.0391448f,0,67.020325f,6.799568f,0);
  }

  @Test
  public void test20() {
    color.laplace.solve(29.362839f,32.43906f,33.549206f,-14.987705f,-33.155807f,1.7577573f,-1.6412406f,32.741432f,0);
  }

  @Test
  public void test21() {
    color.laplace.solve(29.782957f,14.463753f,75.08052f,4.6680737f,-28.95517f,-82.92555f,17.844507f,66.70995f,0);
  }

  @Test
  public void test22() {
    color.laplace.solve(31.541273f,52.00378f,7.7441845f,-25.838686f,-99.8986f,-40.402603f,-34.99742f,-91.77327f,0);
  }

  @Test
  public void test23() {
    color.laplace.solve(32.485756f,-81.31074f,-69.427795f,-19.12662f,-46.22876f,-33.674057f,-62.763474f,-50.80363f,-50.089054f);
  }

  @Test
  public void test24() {
    color.laplace.solve(33.527252f,29.095314f,-57.15276f,5.0137f,40.00676f,48.9684f,4.4873514f,12.935704f,-10.057443f);
  }

  @Test
  public void test25() {
    color.laplace.solve(33.88162f,29.294071f,8.674641f,6.232401f,-35.379887f,0,3.0909948f,36.547264f,0);
  }

  @Test
  public void test26() {
    color.laplace.solve(34.13082f,4.732611f,0,11.424063f,9.6729965f,29.299973f,1.892432f,-3.8543346f,-17.50674f);
  }

  @Test
  public void test27() {
    color.laplace.solve(35.04175f,-17.652906f,0,23.937523f,44.344482f,-63.09735f,7.815188f,7.323229f,-22.866753f);
  }

  @Test
  public void test28() {
    color.laplace.solve(35.604496f,18.93706f,76.223f,23.48093f,41.724247f,85.15192f,16.594975f,32.280945f,0);
  }

  @Test
  public void test29() {
    color.laplace.solve(36.195965f,29.241014f,1.9795394f,15.542847f,-21.211447f,-41.929455f,59.266678f,54.859993f,0);
  }

  @Test
  public void test30() {
    color.laplace.solve(36.28916f,33.316525f,37.177593f,11.840117f,-40.20065f,15.3938465f,53.20649f,36.447514f,0);
  }

  @Test
  public void test31() {
    color.laplace.solve(36.489243f,30.996979f,14.905917f,14.959986f,-27.407244f,-71.37331f,-10.398613f,0,0);
  }

  @Test
  public void test32() {
    color.laplace.solve(37.112324f,11.173282f,5.0209107f,37.27601f,-97.44011f,-69.55594f,-55.431202f,33.021835f,0);
  }

  @Test
  public void test33() {
    color.laplace.solve(39.339344f,9.410748f,-99.97867f,47.946632f,-2.0383484f,0,10.982924f,-4.014932f,-25.004305f);
  }

  @Test
  public void test34() {
    color.laplace.solve(39.72862f,-10.406936f,-98.0042f,69.32141f,-96.9802f,0,15.688121f,-6.5689297f,-5.917472f);
  }

  @Test
  public void test35() {
    color.laplace.solve(44.06299f,-4.4647837f,0,4.428301f,-64.365845f,0,-7.679209f,-35.145138f,-32.15557f);
  }

  @Test
  public void test36() {
    color.laplace.solve(-45.312553f,98.48668f,0,81.16849f,-31.449448f,0,42.61411f,-60.020187f,0);
  }

  @Test
  public void test37() {
    color.laplace.solve(46.251343f,83.341675f,44.734875f,1.6636895f,35.579815f,0,-41.5452f,74.87339f,0);
  }

  @Test
  public void test38() {
    color.laplace.solve(46.302685f,14.13175f,0,27.943624f,-23.680265f,8.373676f,89.15208f,-63.737144f,0);
  }

  @Test
  public void test39() {
    color.laplace.solve(47.23735f,23.030647f,-12.419132f,65.91875f,22.340004f,0,91.60796f,-12.254858f,0);
  }

  @Test
  public void test40() {
    color.laplace.solve(47.589382f,71.21898f,-36.165745f,19.138557f,31.653418f,23.920706f,-2.6885703f,-29.892838f,32.204052f);
  }

  @Test
  public void test41() {
    color.laplace.solve(47.710014f,30.388472f,57.200054f,60.45159f,-91.26002f,0,-8.790841f,-95.61495f,11.422308f);
  }

  @Test
  public void test42() {
    color.laplace.solve(47.72177f,52.443497f,-26.333258f,38.44358f,71.81459f,-29.710821f,34.23797f,98.50829f,97.042694f);
  }

  @Test
  public void test43() {
    color.laplace.solve(4.811546f,-27.765453f,0,4.1930227f,3.7127295f,2.9396057f,8.247815f,2.9012654f,0);
  }

  @Test
  public void test44() {
    color.laplace.solve(50.153538f,85.502365f,-87.69499f,15.11179f,31.176083f,0.5569106f,-20.882462f,-36.56776f,0);
  }

  @Test
  public void test45() {
    color.laplace.solve(51.873035f,87.35845f,-42.535496f,20.133696f,81.31883f,0,79.175705f,-78.955956f,0);
  }

  @Test
  public void test46() {
    color.laplace.solve(53.106735f,19.631428f,25.218563f,92.79552f,-99.79959f,-73.95803f,-46.46972f,74.51785f,0);
  }

  @Test
  public void test47() {
    color.laplace.solve(53.761677f,64.23928f,63.1904f,50.807426f,40.005047f,33.135754f,52.787144f,53.16192f,0);
  }

  @Test
  public void test48() {
    color.laplace.solve(53.79468f,80.1191f,67.95701f,35.05963f,58.517807f,42.87549f,27.926043f,2.8933756f,0);
  }

  @Test
  public void test49() {
    color.laplace.solve(55.427086f,-59.2079f,0,-30.224392f,-14.424801f,0.6798594f,-10.205557f,-10.597837f,-17.760992f);
  }

  @Test
  public void test50() {
    color.laplace.solve(56.022335f,60.376152f,-14.385161f,63.71318f,99.86743f,58.004387f,48.496864f,99.55732f,0);
  }

  @Test
  public void test51() {
    color.laplace.solve(-56.208466f,19.267508f,0,-15.701328f,49.707077f,-60.347736f,-56.303925f,99.64352f,0);
  }

  @Test
  public void test52() {
    color.laplace.solve(56.211983f,37.995186f,55.51404f,5.192327f,9.207905f,-1.8730876f,-44.65058f,-4.4828067f,-25.794292f);
  }

  @Test
  public void test53() {
    color.laplace.solve(-60.59745f,-60.611763f,0,-55.925438f,-87.631775f,45.277073f,-75.47252f,-71.48292f,0);
  }

  @Test
  public void test54() {
    color.laplace.solve(61.722576f,65.48813f,-75.85023f,81.40217f,-14.087703f,0,92.723145f,-35.091835f,0);
  }

  @Test
  public void test55() {
    color.laplace.solve(68.0915f,-33.150055f,0,-6.9707184f,-51.581512f,-57.17934f,-2.189848f,-1.788674f,46.616665f);
  }

  @Test
  public void test56() {
    color.laplace.solve(6.895257f,6.075239f,0,-5.6189795f,7.17867f,0,-4.315694f,-11.643796f,-11.493626f);
  }

  @Test
  public void test57() {
    color.laplace.solve(-7.022204f,-44.787716f,86.88065f,-83.3011f,59.520115f,0,-33.85332f,73.628815f,0);
  }

  @Test
  public void test58() {
    color.laplace.solve(70.625755f,49.002247f,-35.82442f,27.24044f,-9.465568f,-47.99168f,47.80157f,-66.11327f,-47.56807f);
  }

  @Test
  public void test59() {
    color.laplace.solve(-75.14452f,-79.20534f,0,-17.552155f,32.407753f,0,70.375374f,-16.257713f,0);
  }

  @Test
  public void test60() {
    color.laplace.solve(76.47322f,-76.12634f,0,-76.84544f,-65.89878f,0,-41.091614f,35.96331f,0);
  }

  @Test
  public void test61() {
    color.laplace.solve(76.72812f,71.520676f,0,17.734713f,51.364117f,-87.76717f,-57.153385f,-7.5686703f,0);
  }

  @Test
  public void test62() {
    color.laplace.solve(7.707924f,3.765357f,0,4.636969f,1.3367064f,10.37165f,9.503246f,0.26899502f,0);
  }

  @Test
  public void test63() {
    color.laplace.solve(78.20067f,-20.013504f,0,-28.41724f,-31.267708f,0,-11.464824f,-74.015175f,0);
  }

  @Test
  public void test64() {
    color.laplace.solve(85.71284f,-59.904877f,0,77.46119f,77.604324f,0,41.964565f,90.39708f,54.526035f);
  }

  @Test
  public void test65() {
    color.laplace.solve(90.315605f,-96.42682f,0,41.500904f,-2.7076373f,51.93078f,17.491026f,28.463198f,99.0694f);
  }

  @Test
  public void test66() {
    color.laplace.solve(92.48127f,96.84037f,0,43.01153f,45.478672f,-39.90916f,34.08618f,93.33319f,57.996937f);
  }

  @Test
  public void test67() {
    color.laplace.solve(-94.4264f,-32.001087f,0,-81.64269f,-74.703606f,0,-30.03265f,-32.434376f,0);
  }

  @Test
  public void test68() {
    color.laplace.solve(98.04865f,48.020103f,0,18.587969f,-45.67327f,0,29.411995f,99.06001f,-37.732105f);
  }

  @Test
  public void test69() {
    color.laplace.solve(98.44664f,82.31484f,0,50.29099f,14.658302f,0,31.71339f,-65.501625f,0);
  }

  @Test
  public void test70() {
    color.laplace.solve(98.80957f,-22.703144f,0,69.22659f,78.35836f,20.821186f,99.73844f,-5.6060686f,0);
  }

  @Test
  public void test71() {
    color.laplace.solve(99.31035f,92.112f,0,-6.8613777f,-26.973879f,-92.039154f,-99.78198f,97.90391f,0);
  }

  @Test
  public void test72() {
    color.laplace.solve(99.74495f,25.533628f,0,40.720108f,30.588123f,0,-27.258255f,20.975912f,0);
  }
}
