import org.junit.Test;

public class JpfTargetDartTest {

  @Test
  public void test0() {
    concolic.DART.test(0,0);
  }

  @Test
  public void test1() {
    concolic.DART.test(33,10);
  }

  @Test
  public void test2() {
    concolic.DART.test(33,-22);
  }
}
