import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.8481538571658542,27.372457494887488);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(10.8983007118,7.749612377654747E24);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535054543465,0.0);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(1.6448535054543465,2.285548902348466);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(2.152814904145374,2.461522854870255);
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(78.4036346016,0);
  }
}
