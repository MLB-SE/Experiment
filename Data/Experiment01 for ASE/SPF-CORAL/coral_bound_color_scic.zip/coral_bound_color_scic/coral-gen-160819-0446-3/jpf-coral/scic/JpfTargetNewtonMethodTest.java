import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,70.41774736107163);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(2.0943951023931953,58.9128617898);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(2.6179938779914944,41.6567294098);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(4.1887902047863905,5.257986227251555);
  }
}
