import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(0.0);
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(15311.143807108632);
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(18071.9574222042);
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(190288.0608941348);
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(204464.2770120378);
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(239676.2689409136);
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(268701.6488488168);
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(268880.4036346016);
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(28092.181943418804);
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(97979.0633652437);
  }
}
