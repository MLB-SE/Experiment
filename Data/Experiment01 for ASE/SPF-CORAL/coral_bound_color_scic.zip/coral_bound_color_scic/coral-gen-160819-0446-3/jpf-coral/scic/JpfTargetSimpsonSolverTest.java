import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-37.9086927721,15.2727538951);
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-4.275152150012409,5.221753715797091);
  }
}
