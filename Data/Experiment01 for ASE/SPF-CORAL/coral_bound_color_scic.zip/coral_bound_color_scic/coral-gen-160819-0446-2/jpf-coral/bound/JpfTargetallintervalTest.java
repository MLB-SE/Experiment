import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,2,3,2);
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,2,3,-42);
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,2,3,57);
  }

  @Test
  public void test4() {
    bound.allinterval.solve(2,3,-42,0);
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,3,57,0);
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,-42,0,0);
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,57,0,0);
  }

  @Test
  public void test8() {
    bound.allinterval.solve(57,0,0,0);
  }
}
