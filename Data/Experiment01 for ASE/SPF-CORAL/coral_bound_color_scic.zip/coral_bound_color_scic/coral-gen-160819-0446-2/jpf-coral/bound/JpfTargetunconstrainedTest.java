import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(2,5,8,-42);
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(2,5,8,57);
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(2,5,8,6);
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(57,0,0,0);
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(5,8,-42,0);
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(5,8,57,0);
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(8,-42,0,0);
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(8,57,0,0);
  }
}
