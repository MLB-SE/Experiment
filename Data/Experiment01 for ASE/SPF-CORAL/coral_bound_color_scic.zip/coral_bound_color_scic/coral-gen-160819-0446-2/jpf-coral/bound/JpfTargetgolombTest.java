import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0);
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,5);
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,3,0);
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,3,5);
  }

  @Test
  public void test4() {
    bound.golomb.solve(2,4,5);
  }

  @Test
  public void test5() {
    bound.golomb.solve(3,3,5);
  }

  @Test
  public void test6() {
    bound.golomb.solve(3,5,1);
  }

  @Test
  public void test7() {
    bound.golomb.solve(3,5,-43);
  }

  @Test
  public void test8() {
    bound.golomb.solve(3,5,56);
  }

  @Test
  public void test9() {
    bound.golomb.solve(-43,0,0);
  }

  @Test
  public void test10() {
    bound.golomb.solve(5,0,0);
  }

  @Test
  public void test11() {
    bound.golomb.solve(5,-43,0);
  }

  @Test
  public void test12() {
    bound.golomb.solve(5,56,0);
  }

  @Test
  public void test13() {
    bound.golomb.solve(56,0,0);
  }
}
