import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(116,364,626,-43);
  }

  @Test
  public void test2() {
    bound.grocery.solve(184,93,562,713);
  }

  @Test
  public void test3() {
    bound.grocery.solve(190,235,129,157);
  }

  @Test
  public void test4() {
    bound.grocery.solve(213,799,0,0);
  }

  @Test
  public void test5() {
    bound.grocery.solve(364,626,-43,0);
  }

  @Test
  public void test6() {
    bound.grocery.solve(371,213,799,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(-43,0,0,0);
  }

  @Test
  public void test8() {
    bound.grocery.solve(435,0,276,0);
  }

  @Test
  public void test9() {
    bound.grocery.solve(626,-43,0,0);
  }

  @Test
  public void test10() {
    bound.grocery.solve(802,0,0,0);
  }
}
