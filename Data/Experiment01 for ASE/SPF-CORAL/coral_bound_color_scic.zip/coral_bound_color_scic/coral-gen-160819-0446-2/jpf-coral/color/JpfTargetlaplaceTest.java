import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.008426685f,-97.57175f,-15.63175f,-2.4619613f,-80.728035f,0,28.059492f,14.983541f,0);
  }

  @Test
  public void test1() {
    color.laplace.solve(0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f);
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.81240076f,-17.158663f,0,0.05103619f,2.403514f,-21.097946f,-1.3869684f,2.3845758f,0);
  }

  @Test
  public void test3() {
    color.laplace.solve(-0.95535964f,-86.77331f,58.93472f,-17.04813f,26.789734f,0,-42.338825f,-62.86682f,0);
  }

  @Test
  public void test4() {
    color.laplace.solve(11.327413f,18.82737f,0,4.0097914f,-9.8598995f,0,3.5593991f,10.227805f,-7.5703964f);
  }

  @Test
  public void test5() {
    color.laplace.solve(1.337011f,8.810321f,0,-8.534712f,8.693981f,0,0.2991312f,9.731237f,7.568983f);
  }

  @Test
  public void test6() {
    color.laplace.solve(13.496054f,8.44033f,-16.807632f,-54.456116f,-74.34392f,0,42.640507f,-28.779703f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(-14.601812f,-69.08545f,45.711437f,-16.265577f,-17.23332f,2.1619694f,-33.22718f,14.255776f,-40.25713f);
  }

  @Test
  public void test8() {
    color.laplace.solve(19.386728f,4.49567f,-3.254987f,-26.948755f,12.289552f,0,-5.397283f,5.3596215f,8.062202f);
  }

  @Test
  public void test9() {
    color.laplace.solve(1.975784f,-62.565487f,0,0.8186056f,-4.170309f,0,-1.6660558f,-7.4828286f,57.295856f);
  }

  @Test
  public void test10() {
    color.laplace.solve(20.764933f,-10.657073f,51.370884f,-6.2831936f,-28.390905f,44.155323f,-17.506802f,16.953514f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(-21.261553f,-85.07059f,-99.45124f,-99.975624f,-98.10505f,0,99.42046f,-99.27705f,0);
  }

  @Test
  public void test12() {
    color.laplace.solve(21.27583f,6.500999f,0,1.1220765f,-5.737404f,12.555615f,-11.050118f,-6.4426937f,0);
  }

  @Test
  public void test13() {
    color.laplace.solve(21.778706f,66.719696f,47.19403f,-79.60487f,97.90605f,-77.98863f,85.2876f,38.585167f,0);
  }

  @Test
  public void test14() {
    color.laplace.solve(21.872938f,19.729292f,-50.58281f,-32.237537f,-28.818565f,0,-18.50306f,-0.39901564f,0);
  }

  @Test
  public void test15() {
    color.laplace.solve(22.091219f,16.639185f,-11.124052f,-28.274311f,-44.410427f,4.00299f,39.089f,18.411633f,0);
  }

  @Test
  public void test16() {
    color.laplace.solve(22.574125f,-12.642851f,-26.672392f,2.939349f,22.265823f,-98.14007f,-33.082554f,-48.15815f,0);
  }

  @Test
  public void test17() {
    color.laplace.solve(-23.093716f,-42.575684f,0,-8.932907f,-91.58072f,0,11.300269f,69.73003f,0);
  }

  @Test
  public void test18() {
    color.laplace.solve(24.153225f,-9.849475f,29.871078f,6.4623775f,-29.39151f,0,3.5419338f,7.7053576f,20.334757f);
  }

  @Test
  public void test19() {
    color.laplace.solve(24.94054f,-74.17187f,9.172397f,73.93403f,78.25145f,0,-4.959189f,50.715088f,0);
  }

  @Test
  public void test20() {
    color.laplace.solve(25.113512f,22.484892f,13.5982065f,-22.030848f,6.864366f,0,-8.075086f,-10.269497f,-23.167303f);
  }

  @Test
  public void test21() {
    color.laplace.solve(26.248058f,10.67518f,-42.231915f,-5.682948f,-41.31542f,11.941124f,-3.3527024f,52.53921f,0);
  }

  @Test
  public void test22() {
    color.laplace.solve(-2.8425717f,2.6456404f,0,-1.6341351f,14.991772f,0,-1.9408933f,-6.129438f,0.1489343f);
  }

  @Test
  public void test23() {
    color.laplace.solve(28.910696f,-52.988415f,0,-35.811897f,1.7525551f,0,-9.433446f,-1.9218862f,54.171494f);
  }

  @Test
  public void test24() {
    color.laplace.solve(29.672455f,10.854027f,-31.420752f,7.835794f,-24.411547f,-49.292f,26.082268f,-30.751638f,0);
  }

  @Test
  public void test25() {
    color.laplace.solve(30.331543f,5.6390696f,23.497406f,15.687099f,15.107712f,0,7.0467f,12.4997f,36.877094f);
  }

  @Test
  public void test26() {
    color.laplace.solve(31.12015f,-2.2649615f,-42.133793f,6.9910574f,16.005705f,20.843994f,-19.161625f,38.45273f,-56.568375f);
  }

  @Test
  public void test27() {
    color.laplace.solve(31.830828f,71.03556f,78.87765f,-43.712254f,73.43377f,-40.043613f,-18.194786f,76.133575f,0);
  }

  @Test
  public void test28() {
    color.laplace.solve(32.356792f,36.235966f,-14.367923f,-6.8087897f,-5.199407f,0,1.4423397f,12.578149f,1.3010684f);
  }

  @Test
  public void test29() {
    color.laplace.solve(33.415913f,52.748337f,11.122786f,-19.084694f,-60.02004f,0,-18.269564f,-53.99356f,62.724285f);
  }

  @Test
  public void test30() {
    color.laplace.solve(35.003265f,34.448357f,30.519125f,5.564703f,-27.72896f,-12.3718605f,-1.6537774f,0,0);
  }

  @Test
  public void test31() {
    color.laplace.solve(35.212704f,38.61171f,31.988964f,2.2391043f,-12.754836f,-10.6558485f,-8.192097f,0,0);
  }

  @Test
  public void test32() {
    color.laplace.solve(35.73385f,10.817948f,-98.377556f,32.117447f,77.00933f,95.55765f,15.726608f,-87.15348f,0);
  }

  @Test
  public void test33() {
    color.laplace.solve(36.387493f,61.321083f,14.553059f,-15.771114f,-62.850006f,-71.62507f,-36.621944f,-12.077663f,0);
  }

  @Test
  public void test34() {
    color.laplace.solve(-3.8149598f,-64.79534f,0,-88.31222f,12.63352f,0,-27.862253f,90.87277f,0);
  }

  @Test
  public void test35() {
    color.laplace.solve(38.23578f,-59.45345f,0,65.760475f,-51.227116f,0,-19.47928f,18.56775f,0);
  }

  @Test
  public void test36() {
    color.laplace.solve(38.303116f,30.73567f,0,16.898556f,15.559875f,93.55643f,13.731235f,38.026382f,56.329094f);
  }

  @Test
  public void test37() {
    color.laplace.solve(38.329308f,12.917536f,0,14.620779f,10.19945f,45.18182f,9.95436f,-34.78604f,0);
  }

  @Test
  public void test38() {
    color.laplace.solve(42.721626f,-58.936512f,0,8.23481f,-91.879814f,-82.27448f,82.09743f,6.1630297f,0);
  }

  @Test
  public void test39() {
    color.laplace.solve(42.8459f,52.66926f,39.004295f,18.714352f,28.826834f,4.109147f,3.1846702f,-41.602203f,0);
  }

  @Test
  public void test40() {
    color.laplace.solve(42.885628f,52.985798f,46.228054f,18.556707f,22.829508f,25.712084f,8.511695f,12.820746f,0);
  }

  @Test
  public void test41() {
    color.laplace.solve(42.982834f,52.539513f,34.68076f,19.391825f,32.494457f,21.176205f,2.0900085f,37.67805f,0);
  }

  @Test
  public void test42() {
    color.laplace.solve(43.502598f,-38.96326f,0,6.9071326f,-40.372753f,0,5.9364166f,16.838533f,83.08535f);
  }

  @Test
  public void test43() {
    color.laplace.solve(43.506416f,36.432583f,-40.390087f,37.593075f,-68.24701f,0,96.97691f,50.9743f,0);
  }

  @Test
  public void test44() {
    color.laplace.solve(44.66815f,66.29881f,-18.455267f,12.373789f,-10.1397705f,0,10.160346f,28.267595f,-12.39872f);
  }

  @Test
  public void test45() {
    color.laplace.solve(46.58218f,59.998795f,30.954632f,26.329931f,44.40481f,-12.563234f,14.332734f,0.6626926f,0);
  }

  @Test
  public void test46() {
    color.laplace.solve(47.506763f,66.58013f,40.515675f,23.446926f,78.298096f,40.515358f,19.77874f,55.66803f,0);
  }

  @Test
  public void test47() {
    color.laplace.solve(47.559795f,57.680878f,22.01488f,32.558304f,61.148838f,39.91368f,13.369679f,19.788141f,0);
  }

  @Test
  public void test48() {
    color.laplace.solve(47.89931f,67.6437f,43.015377f,23.953535f,19.257612f,-67.38977f,28.657219f,90.67534f,0);
  }

  @Test
  public void test49() {
    color.laplace.solve(48.203842f,75.388985f,44.063328f,17.42638f,5.812868f,56.237244f,15.688811f,-15.345695f,0);
  }

  @Test
  public void test50() {
    color.laplace.solve(48.221214f,50.272415f,19.443022f,42.612434f,33.42543f,-72.94634f,20.558922f,39.62325f,-1.5890628f);
  }

  @Test
  public void test51() {
    color.laplace.solve(48.295227f,99.03025f,77.936935f,-5.84934f,88.835724f,0,11.0152445f,49.910316f,99.7903f);
  }

  @Test
  public void test52() {
    color.laplace.solve(48.71072f,87.603294f,-59.289795f,7.2395806f,-31.620283f,0,-46.81487f,-76.397675f,0);
  }

  @Test
  public void test53() {
    color.laplace.solve(48.977386f,79.80087f,89.61184f,16.108671f,80.61426f,-60.725113f,-65.15696f,70.30487f,0);
  }

  @Test
  public void test54() {
    color.laplace.solve(-49.91705f,-41.643093f,0,41.05079f,57.82545f,0,68.717354f,-86.94671f,0);
  }

  @Test
  public void test55() {
    color.laplace.solve(50.027298f,70.746735f,63.545307f,29.362455f,50.686195f,28.059708f,16.73633f,56.404335f,0);
  }

  @Test
  public void test56() {
    color.laplace.solve(52.42602f,61.82822f,39.451614f,47.87587f,55.43525f,35.09009f,0.10090898f,11.046029f,0);
  }

  @Test
  public void test57() {
    color.laplace.solve(54.92503f,-16.115557f,0,21.910992f,22.569155f,98.67822f,10.149782f,18.688139f,42.038925f);
  }

  @Test
  public void test58() {
    color.laplace.solve(55.31065f,-57.420006f,73.241f,44.87737f,31.430017f,99.985085f,92.7688f,38.27763f,97.73223f);
  }

  @Test
  public void test59() {
    color.laplace.solve(55.56475f,54.73468f,44.28842f,67.52433f,19.085545f,-5.284309f,-0.8241596f,-70.82097f,-32.766968f);
  }

  @Test
  public void test60() {
    color.laplace.solve(55.729343f,75.659966f,73.75663f,47.257412f,73.153885f,30.893173f,23.626236f,14.975726f,0);
  }

  @Test
  public void test61() {
    color.laplace.solve(56.847466f,89.05956f,99.53294f,38.330307f,99.85783f,-25.521955f,-15.005588f,55.446888f,0);
  }

  @Test
  public void test62() {
    color.laplace.solve(59.842045f,67.72162f,25.70439f,71.64657f,4.1163845f,0,17.381153f,-2.1219532f,15.502341f);
  }

  @Test
  public void test63() {
    color.laplace.solve(-63.01362f,1.7649586f,0,2.3943868f,57.824764f,8.43766f,14.766402f,2.0535595f,0);
  }

  @Test
  public void test64() {
    color.laplace.solve(64.17707f,-85.04142f,0,41.785355f,14.034814f,0,67.09789f,-70.53896f,0);
  }

  @Test
  public void test65() {
    color.laplace.solve(66.09273f,-52.149002f,0,-12.3025f,-41.722225f,-81.666504f,-73.580505f,-31.455578f,0);
  }

  @Test
  public void test66() {
    color.laplace.solve(68.29485f,-37.72768f,44.26398f,25.075777f,-19.903133f,-11.599314f,51.911392f,-55.36132f,2.0706708f);
  }

  @Test
  public void test67() {
    color.laplace.solve(82.25944f,61.124588f,0,-8.06184f,-37.90549f,72.18293f,-76.60131f,-97.573944f,0);
  }

  @Test
  public void test68() {
    color.laplace.solve(-83.83871f,-65.35847f,0,-81.6792f,-42.32616f,0,65.36922f,-77.59712f,0);
  }

  @Test
  public void test69() {
    color.laplace.solve(84.77682f,-65.44398f,0,-62.320618f,-95.81504f,-68.585075f,-29.318213f,-54.952236f,-94.6757f);
  }

  @Test
  public void test70() {
    color.laplace.solve(85.158325f,60.594475f,0,59.338654f,-82.22281f,0,3.5562956f,-45.11347f,-35.929802f);
  }

  @Test
  public void test71() {
    color.laplace.solve(85.82861f,42.683304f,0,-64.67237f,-76.48741f,0,-23.872149f,-30.816227f,-49.94045f);
  }

  @Test
  public void test72() {
    color.laplace.solve(8.651911f,-31.725798f,0,6.2304516f,-33.226948f,-13.557232f,49.49684f,-13.236225f,0);
  }

  @Test
  public void test73() {
    color.laplace.solve(-91.24823f,24.375113f,0,-27.975245f,29.79565f,0,-43.48791f,99.20481f,0);
  }

  @Test
  public void test74() {
    color.laplace.solve(91.39143f,-55.590008f,0,-70.44685f,38.9211f,0,56.474136f,33.167526f,0);
  }

  @Test
  public void test75() {
    color.laplace.solve(93.51755f,-30.84087f,-14.435949f,16.594564f,-11.302357f,-11.465908f,-15.836932f,-19.497213f,31.197432f);
  }

  @Test
  public void test76() {
    color.laplace.solve(98.94915f,-84.40073f,0,-26.73116f,-26.251963f,-38.84627f,-9.650318f,-11.870114f,-11.578176f);
  }
}
