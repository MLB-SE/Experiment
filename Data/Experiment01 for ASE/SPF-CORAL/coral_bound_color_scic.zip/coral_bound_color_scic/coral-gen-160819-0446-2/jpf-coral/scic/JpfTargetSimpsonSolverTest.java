import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-28.5535252408,18.8620780461);
  }
}
