import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(0.0);
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(131458.25582335176);
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(15311.143807108632);
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(167247.865931606);
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(19363.811374487);
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(204464.2770120378);
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(204563.6892703653);
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(24424.0414652291);
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(268701.6488488168);
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(268854.2783976833);
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(45689.3864173064);
  }
}
