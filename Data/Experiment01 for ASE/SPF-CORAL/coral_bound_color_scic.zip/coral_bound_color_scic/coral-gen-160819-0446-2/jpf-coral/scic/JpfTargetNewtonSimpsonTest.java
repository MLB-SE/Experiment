import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(1.6448535054543465,0.0);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543467,20.308076941876205);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-2.0973266508,89.8922479689);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(24.5138547567,2.906915422620177E129);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(2.6615095480001694,12.761577754759614);
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(52.2783976833,0);
  }
}
