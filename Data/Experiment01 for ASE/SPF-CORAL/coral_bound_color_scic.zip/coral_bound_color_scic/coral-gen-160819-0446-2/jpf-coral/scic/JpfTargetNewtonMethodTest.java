import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,30.978429702266848);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(0.3490658503988659,0.28570649686531363);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(4.4505895925855405,53.3246656616);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(4.71238898038469,24.5138547567);
  }
}
