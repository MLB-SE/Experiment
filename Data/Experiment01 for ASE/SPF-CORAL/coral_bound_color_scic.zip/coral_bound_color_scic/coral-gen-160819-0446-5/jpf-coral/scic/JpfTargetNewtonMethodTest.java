import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(0.1512095066616058,0.0);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(0.1512095066616058,91.22014651856576);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(2.0943951023931953,0.7442921190931244);
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(2.356194490192345,83.582603642);
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(2.6179938779914944,9.9551277795);
  }
}
