import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(0.0);
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(101235.8207359432);
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(145247.8888919329);
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(15311.143807108632);
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(204464.2770120378);
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(23137.1584203213);
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(23524.046053911126);
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(246636.8551209835);
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(268701.6488488168);
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(268777.3981151449);
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(31610.7344201299);
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(32217.313499087497);
  }
}
