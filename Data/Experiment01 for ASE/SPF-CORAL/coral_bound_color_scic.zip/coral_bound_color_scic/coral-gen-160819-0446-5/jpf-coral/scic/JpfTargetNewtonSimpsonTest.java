import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.24704813151963423,47.924220484592645);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543465,27.408373332857053);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535054543467,0.0);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(2.210774107297796,69.21179854448492);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(8.1449460137,3.1888898083786375E13);
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(83.582603642,0);
  }
}
