import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-3.944385308972182,4.788510151256124);
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-83.2531673423,56.1895960729);
  }
}
