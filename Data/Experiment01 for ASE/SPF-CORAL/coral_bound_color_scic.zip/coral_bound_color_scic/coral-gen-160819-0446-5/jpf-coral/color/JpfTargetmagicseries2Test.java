import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,0,0);
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,38,0,0);
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,4,0,0);
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,-61,0,0);
  }

  @Test
  public void test4() {
    color.magicseries.solve2(1,0,3,0);
  }

  @Test
  public void test5() {
    color.magicseries.solve2(1,2,1,0);
  }

  @Test
  public void test6() {
    color.magicseries.solve2(2,0,2,0);
  }

  @Test
  public void test7() {
    color.magicseries.solve2(2,0,38,0);
  }

  @Test
  public void test8() {
    color.magicseries.solve2(2,0,-61,0);
  }

  @Test
  public void test9() {
    color.magicseries.solve2(2,1,0,1);
  }

  @Test
  public void test10() {
    color.magicseries.solve2(3,2,0,38);
  }

  @Test
  public void test11() {
    color.magicseries.solve2(3,2,0,-61);
  }

  @Test
  public void test12() {
    color.magicseries.solve2(38,0,0,0);
  }

  @Test
  public void test13() {
    color.magicseries.solve2(-61,0,0,0);
  }
}
