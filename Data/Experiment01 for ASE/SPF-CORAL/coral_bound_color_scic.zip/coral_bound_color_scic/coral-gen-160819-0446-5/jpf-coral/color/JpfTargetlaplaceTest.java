import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.08909694f,-0.43357378f,0,26.889257f,-11.297768f,0,8.32355f,6.4049454f,-67.04723f);
  }

  @Test
  public void test1() {
    color.laplace.solve(0.0f,0.0f,0,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f);
  }

  @Test
  public void test2() {
    color.laplace.solve(0.0f,0.0f,0,0.0f,0.0f,0.0f,0.0f,0.0f,43.226303f);
  }

  @Test
  public void test3() {
    color.laplace.solve(10.70377f,-8.960453f,-68.78098f,-48.22447f,11.098646f,0,-40.746517f,80.6927f,0);
  }

  @Test
  public void test4() {
    color.laplace.solve(12.287462f,38.747528f,-57.045555f,-89.59768f,99.7482f,98.94998f,85.34957f,71.18687f,0);
  }

  @Test
  public void test5() {
    color.laplace.solve(12.41221f,-36.58427f,0,-20.243963f,-29.294413f,0.5779523f,-64.09365f,-74.33614f,0);
  }

  @Test
  public void test6() {
    color.laplace.solve(14.215577f,16.537537f,49.307972f,-59.675224f,-97.373405f,51.15395f,92.787834f,95.154465f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(15.937454f,-12.03065f,7.4259686f,-24.219534f,-97.41213f,0,-60.350357f,6.6965876f,0);
  }

  @Test
  public void test8() {
    color.laplace.solve(16.212978f,4.139907f,0,6.6674633f,18.43115f,0,7.5538955f,23.548119f,-57.999348f);
  }

  @Test
  public void test9() {
    color.laplace.solve(17.175823f,52.550037f,51.55038f,-83.84674f,41.473946f,40.700356f,-19.215067f,6.9864693f,0);
  }

  @Test
  public void test10() {
    color.laplace.solve(17.240997f,15.721154f,-92.03825f,-46.757164f,37.681873f,63.698055f,-91.60026f,-21.920055f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(17.810627f,-51.683895f,-93.90163f,22.926401f,19.619865f,-10.371959f,54.275116f,85.30476f,0);
  }

  @Test
  public void test12() {
    color.laplace.solve(18.051182f,64.5582f,-91.04476f,-92.35347f,-60.42565f,0,-0.6406358f,89.79093f,56.1729f);
  }

  @Test
  public void test13() {
    color.laplace.solve(18.123335f,69.61301f,-99.47133f,-97.11966f,-73.83326f,0,70.700836f,-82.69376f,0);
  }

  @Test
  public void test14() {
    color.laplace.solve(19.471693f,13.5673485f,0,-36.40204f,9.790062f,0,-14.596228f,-21.98287f,23.753662f);
  }

  @Test
  public void test15() {
    color.laplace.solve(21.447218f,-6.334578f,-4.812208f,-7.876552f,3.4809272f,0,35.653076f,10.134211f,0);
  }

  @Test
  public void test16() {
    color.laplace.solve(22.75582f,-30.78186f,-4.786029f,21.805138f,26.503826f,0,24.34839f,75.588425f,0);
  }

  @Test
  public void test17() {
    color.laplace.solve(23.47765f,-32.050686f,0,14.42719f,-28.398598f,0,12.620679f,36.055527f,16.934893f);
  }

  @Test
  public void test18() {
    color.laplace.solve(25.057108f,3.2860403f,57.693756f,-3.057611f,-17.13634f,0,-1.0656697f,-1.2050676f,1.1427968f);
  }

  @Test
  public void test19() {
    color.laplace.solve(25.997349f,-38.237686f,6.1744056f,42.227077f,24.270508f,0,42.618057f,56.23751f,0);
  }

  @Test
  public void test20() {
    color.laplace.solve(26.674204f,42.316486f,26.570055f,-35.619667f,-92.6362f,93.57543f,-76.51668f,-86.88908f,0);
  }

  @Test
  public void test21() {
    color.laplace.solve(31.305012f,-7.028307f,12.132394f,4.352492f,30.61617f,28.135273f,-44.511215f,97.005226f,-82.53448f);
  }

  @Test
  public void test22() {
    color.laplace.solve(32.533978f,11.3348465f,-16.949047f,18.801058f,-70.245544f,-52.37102f,5.982859f,4.393547f,0);
  }

  @Test
  public void test23() {
    color.laplace.solve(34.22897f,26.792658f,19.928856f,10.1232195f,24.375898f,0,-4.2613344f,-27.168558f,29.888462f);
  }

  @Test
  public void test24() {
    color.laplace.solve(35.410767f,33.328587f,-24.28678f,8.314486f,21.643082f,0,-7.196084f,-37.09882f,44.277374f);
  }

  @Test
  public void test25() {
    color.laplace.solve(36.444283f,-77.68825f,0,25.915041f,40.5286f,14.847667f,26.687283f,-78.20838f,0);
  }

  @Test
  public void test26() {
    color.laplace.solve(36.757652f,-89.72336f,0,-87.7084f,48.07773f,-38.37004f,-26.119312f,-16.768858f,-89.033844f);
  }

  @Test
  public void test27() {
    color.laplace.solve(36.874973f,32.813892f,-24.455605f,14.685992f,18.58543f,-56.496014f,3.2835686f,82.99239f,0);
  }

  @Test
  public void test28() {
    color.laplace.solve(39.91448f,42.850327f,52.783264f,16.80758f,80.97103f,54.324635f,-53.65518f,-21.711067f,0);
  }

  @Test
  public void test29() {
    color.laplace.solve(-42.777264f,40.63171f,0,-58.331528f,20.844845f,0,82.79869f,-24.941849f,0);
  }

  @Test
  public void test30() {
    color.laplace.solve(44.880985f,78.00134f,83.74473f,1.5226039f,-29.02427f,-10.226654f,-9.766302f,-44.45151f,0);
  }

  @Test
  public void test31() {
    color.laplace.solve(45.24187f,79.1301f,-92.91359f,1.837384f,78.787346f,0,-25.357277f,-34.89024f,0);
  }

  @Test
  public void test32() {
    color.laplace.solve(4.526117f,-0.3247454f,0,-1.1416937f,-1.698493f,5.2647085f,-7.3943987f,-9.811492f,0);
  }

  @Test
  public void test33() {
    color.laplace.solve(46.023556f,-31.511206f,0,-2.1086054f,-41.883724f,-11.289047f,-12.574252f,-48.1884f,23.99968f);
  }

  @Test
  public void test34() {
    color.laplace.solve(-4.771144f,6.762233f,0,1.4453639f,1.5772184f,-3.0272462f,8.975381f,9.551692f,0);
  }

  @Test
  public void test35() {
    color.laplace.solve(4.9337735f,23.642143f,0,10.346648f,9.010507f,0,1.2217988f,-5.459453f,50.590923f);
  }

  @Test
  public void test36() {
    color.laplace.solve(49.452427f,35.359768f,15.196159f,62.449947f,-25.823195f,0,15.714401f,0.40766022f,-13.824644f);
  }

  @Test
  public void test37() {
    color.laplace.solve(5.099489f,-6.3833017f,0,-1.9308685f,-3.0695279f,4.487514f,-9.753435f,-10.453528f,0);
  }

  @Test
  public void test38() {
    color.laplace.solve(51.032692f,63.610165f,13.465816f,40.520603f,24.532305f,0,-1.2073264f,-45.349907f,71.23336f);
  }

  @Test
  public void test39() {
    color.laplace.solve(51.341522f,-69.01447f,0,-68.80662f,60.835735f,0,-5.6457376f,46.22367f,93.31846f);
  }

  @Test
  public void test40() {
    color.laplace.solve(54.14082f,72.14485f,93.571304f,44.418427f,-12.509003f,0,80.963806f,-13.999102f,0);
  }

  @Test
  public void test41() {
    color.laplace.solve(54.175846f,-9.449336f,0,39.087635f,-41.023163f,-26.060188f,3.8632314f,-23.63471f,-57.378906f);
  }

  @Test
  public void test42() {
    color.laplace.solve(56.135307f,-88.64927f,0,50.491543f,0.41702595f,0,-5.856051f,-4.021624f,0);
  }

  @Test
  public void test43() {
    color.laplace.solve(57.238403f,82.95585f,0,82.04472f,98.850296f,0,5.3014817f,-90.679985f,0);
  }

  @Test
  public void test44() {
    color.laplace.solve(5.8100896f,-61.035057f,20.803862f,-17.82152f,-11.718835f,-18.142925f,-65.377335f,50.12416f,-9.101272f);
  }

  @Test
  public void test45() {
    color.laplace.solve(59.70763f,-95.50314f,0,14.355907f,-19.314634f,-41.434998f,17.030632f,53.766624f,44.595535f);
  }

  @Test
  public void test46() {
    color.laplace.solve(-59.882385f,57.69674f,0,-19.220098f,36.479977f,0,-40.978786f,-34.684334f,0);
  }

  @Test
  public void test47() {
    color.laplace.solve(-6.2248836f,18.6262f,0,5.6570687f,0.29441664f,-7.12758f,28.558743f,-45.59902f,0);
  }

  @Test
  public void test48() {
    color.laplace.solve(62.997578f,60.34536f,-58.43823f,91.64495f,31.137009f,0,-9.434732f,22.149277f,0);
  }

  @Test
  public void test49() {
    color.laplace.solve(63.511227f,56.941284f,-32.11767f,97.10363f,96.37158f,30.257174f,26.622643f,10.970655f,0);
  }

  @Test
  public void test50() {
    color.laplace.solve(65.14266f,63.771122f,0,60.840683f,34.527714f,0,0.8760344f,-57.336544f,-2.022226f);
  }

  @Test
  public void test51() {
    color.laplace.solve(65.41842f,-12.070209f,0,-52.69228f,67.99591f,0,-23.964823f,36.969196f,0);
  }

  @Test
  public void test52() {
    color.laplace.solve(-6.5573072f,5.8717036f,0,-20.821724f,13.572049f,0,-8.419043f,-12.8544445f,88.202576f);
  }

  @Test
  public void test53() {
    color.laplace.solve(67.04903f,-12.769522f,0,81.655975f,-96.283905f,49.366627f,18.445538f,-7.8738246f,46.34307f);
  }

  @Test
  public void test54() {
    color.laplace.solve(67.182945f,98.96783f,0,10.242219f,-99.79579f,99.48612f,73.581726f,20.25476f,0);
  }

  @Test
  public void test55() {
    color.laplace.solve(-7.042658f,1.6386505f,0,-1.6717718f,1.6071745f,1.7490747f,-1.2516036f,4.7127447f,-50.987503f);
  }

  @Test
  public void test56() {
    color.laplace.solve(79.00115f,24.179777f,0,11.771598f,91.36166f,9.6268635f,12.527615f,38.33886f,49.466175f);
  }

  @Test
  public void test57() {
    color.laplace.solve(80.682816f,-90.45358f,0,-6.6183786f,-53.830975f,72.15492f,-53.32535f,0.7452421f,0);
  }

  @Test
  public void test58() {
    color.laplace.solve(85.28427f,12.13427f,0,8.779554f,0.6238883f,0,56.50718f,44.95576f,0);
  }

  @Test
  public void test59() {
    color.laplace.solve(8.928381f,-21.513985f,-83.8369f,-42.77249f,-95.52232f,-27.603354f,-84.49603f,41.69571f,0);
  }

  @Test
  public void test60() {
    color.laplace.solve(9.009155f,35.19627f,98.310585f,-99.15965f,-66.53466f,36.54816f,-60.55783f,90.33296f,0);
  }

  @Test
  public void test61() {
    color.laplace.solve(-93.82444f,-68.66787f,0,99.84469f,90.28037f,0,-61.888298f,-75.27205f,0);
  }

  @Test
  public void test62() {
    color.laplace.solve(95.47829f,-68.365486f,95.53482f,16.978153f,-46.312096f,-87.53788f,18.74642f,-46.323162f,40.116608f);
  }

  @Test
  public void test63() {
    color.laplace.solve(99.46871f,-84.93336f,0,48.533886f,13.343822f,0,7.600839f,-79.0254f,0);
  }
}
