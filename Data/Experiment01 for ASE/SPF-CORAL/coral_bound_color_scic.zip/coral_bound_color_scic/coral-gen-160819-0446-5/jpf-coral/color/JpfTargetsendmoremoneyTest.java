import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(0,0,0,0,0,0,0,0);
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(2,3,3,7,7,6,2,8);
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(2,3,7,7,6,2,38,0);
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(2,3,7,7,6,2,-61,0);
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,38,0,0,0,0,0,0);
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(2,-61,0,0,0,0,0,0);
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(38,0,0,0,0,0,0,0);
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(4,7,7,6,2,38,0,0);
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(4,7,7,6,2,-61,0,0);
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(6,2,38,0,0,0,0,0);
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(6,2,-61,0,0,0,0,0);
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(7,6,2,38,0,0,0,0);
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(7,6,2,-61,0,0,0,0);
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(7,7,6,2,38,0,0,0);
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(7,7,6,2,-61,0,0,0);
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(8,1,3,7,7,6,2,38);
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(8,1,3,7,7,6,2,-61);
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(9,0,0,8,1,0,0,8);
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(9,0,0,9,1,0,0,9);
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(9,0,1,0,1,0,9,0);
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(9,2,3,8,1,0,8,0);
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,4,5,6,1,0,8,0);
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(9,4,5,7,1,0,8,1);
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,5,6,5,1,0,8,0);
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(9,7,8,3,1,0,8,0);
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(9,7,8,8,1,0,8,5);
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(9,8,8,1,1,0,0,9);
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(9,8,9,0,1,0,9,8);
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(9,9,9,0,1,0,0,9);
  }
}
