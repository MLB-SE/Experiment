import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(1,-84,0,0);
  }

  @Test
  public void test2() {
    bound.grocery.solve(206,196,228,81);
  }

  @Test
  public void test3() {
    bound.grocery.solve(393,90,210,18);
  }

  @Test
  public void test4() {
    bound.grocery.solve(396,404,773,0);
  }

  @Test
  public void test5() {
    bound.grocery.solve(404,603,621,801);
  }

  @Test
  public void test6() {
    bound.grocery.solve(695,1,-84,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(-84,0,0,0);
  }

  @Test
  public void test8() {
    bound.grocery.solve(891,0,0,0);
  }

  @Test
  public void test9() {
    bound.grocery.solve(92,695,1,-84);
  }

  @Test
  public void test10() {
    bound.grocery.solve(92,891,0,0);
  }
}
