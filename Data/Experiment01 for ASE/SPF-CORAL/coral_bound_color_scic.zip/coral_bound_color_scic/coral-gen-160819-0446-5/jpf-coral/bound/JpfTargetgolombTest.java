import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0);
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,1);
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,15,0);
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,3,5);
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,5,0);
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,-84,0);
  }

  @Test
  public void test6() {
    bound.golomb.solve(15,0,0);
  }

  @Test
  public void test7() {
    bound.golomb.solve(2,3,4);
  }

  @Test
  public void test8() {
    bound.golomb.solve(3,5,3);
  }

  @Test
  public void test9() {
    bound.golomb.solve(5,0,0);
  }

  @Test
  public void test10() {
    bound.golomb.solve(5,0,15);
  }

  @Test
  public void test11() {
    bound.golomb.solve(5,0,5);
  }

  @Test
  public void test12() {
    bound.golomb.solve(5,0,-84);
  }

  @Test
  public void test13() {
    bound.golomb.solve(-84,0,0);
  }
}
