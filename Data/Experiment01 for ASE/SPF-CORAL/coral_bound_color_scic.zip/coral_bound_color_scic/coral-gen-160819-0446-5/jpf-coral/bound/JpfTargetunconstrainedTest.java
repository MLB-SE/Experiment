import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,15,0,0);
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(15,0,0,0);
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(1,-84,0,0);
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(2,9,1,15);
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(2,9,1,2);
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(2,9,1,-84);
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(9,1,15,0);
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(9,1,-84,0);
  }
}
