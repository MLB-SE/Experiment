import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(0.0,0.5);
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(1.5707963267948966,83.3996487613);
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(2.356194490192345,1.3653964847605444);
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(5.235987755982989,55.9904669951);
  }
}
