import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-4.296284632163333,5.24802219366744);
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-56.770974113,55.2848040454);
  }
}
