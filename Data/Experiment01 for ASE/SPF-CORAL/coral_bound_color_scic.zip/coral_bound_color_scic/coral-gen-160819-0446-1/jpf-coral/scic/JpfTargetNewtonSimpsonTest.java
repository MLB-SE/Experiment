import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.0,1.1279827235839501);
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.0,90.32135549574672);
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.6448535054543465,80.68751150243462);
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.6448535054543467,0.0);
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(2.1218974532404493,100.0);
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(21.5457477004,7.222516184794974E99);
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-69.3609218506,0);
  }
}
