import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(0.0);
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(131458.25582335176);
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(15311.143807108632);
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(16278.72452853914);
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(163258.7003668886);
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(204464.2770120378);
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(246390.9619317413);
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(268701.6488488168);
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(268732.6390781493);
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(32174.520513054144);
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(32217.313499087497);
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(41079.2274235265);
  }
}
