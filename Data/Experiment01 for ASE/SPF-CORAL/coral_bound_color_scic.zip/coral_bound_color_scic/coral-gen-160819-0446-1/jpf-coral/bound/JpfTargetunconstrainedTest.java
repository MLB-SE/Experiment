import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(44,0,0,0);
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(4,-92,0,0);
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(7,8,4,1);
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(7,8,4,-92);
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(7,87,0,0);
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(8,3,68,0);
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(8,4,-92,0);
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(8,8,8,27);
  }
}
