import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0);
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,2);
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,1,4);
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,5,4);
  }

  @Test
  public void test4() {
    bound.golomb.solve(2,3,5);
  }

  @Test
  public void test5() {
    bound.golomb.solve(2,7,0);
  }

  @Test
  public void test6() {
    bound.golomb.solve(2,-92,0);
  }

  @Test
  public void test7() {
    bound.golomb.solve(3,4,4);
  }

  @Test
  public void test8() {
    bound.golomb.solve(4,4,1);
  }

  @Test
  public void test9() {
    bound.golomb.solve(5,0,2);
  }

  @Test
  public void test10() {
    bound.golomb.solve(5,2,7);
  }

  @Test
  public void test11() {
    bound.golomb.solve(5,2,-92);
  }

  @Test
  public void test12() {
    bound.golomb.solve(7,0,0);
  }

  @Test
  public void test13() {
    bound.golomb.solve(-92,0,0);
  }
}
