import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.allinterval.solve(2,8,0,0);
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,-92,0,0);
  }

  @Test
  public void test3() {
    bound.allinterval.solve(3,2,8,0);
  }

  @Test
  public void test4() {
    bound.allinterval.solve(3,2,-92,0);
  }

  @Test
  public void test5() {
    bound.allinterval.solve(3,3,2,1);
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,3,2,8);
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,3,2,-92);
  }

  @Test
  public void test8() {
    bound.allinterval.solve(8,0,0,0);
  }
}
