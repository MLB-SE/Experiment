import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(213,174,618,818);
  }

  @Test
  public void test2() {
    bound.grocery.solve(252,125,125,209);
  }

  @Test
  public void test3() {
    bound.grocery.solve(314,-92,0,0);
  }

  @Test
  public void test4() {
    bound.grocery.solve(373,585,742,0);
  }

  @Test
  public void test5() {
    bound.grocery.solve(487,622,314,-92);
  }

  @Test
  public void test6() {
    bound.grocery.solve(487,797,0,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(622,314,-92,0);
  }

  @Test
  public void test8() {
    bound.grocery.solve(711,0,0,0);
  }

  @Test
  public void test9() {
    bound.grocery.solve(797,0,0,0);
  }

  @Test
  public void test10() {
    bound.grocery.solve(-92,0,0,0);
  }
}
