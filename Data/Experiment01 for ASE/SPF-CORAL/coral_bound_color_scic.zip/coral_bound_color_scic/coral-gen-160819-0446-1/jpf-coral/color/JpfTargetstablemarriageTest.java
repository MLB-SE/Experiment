import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(0,0);
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(2,2);
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(2,29);
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(2,-70);
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(29,0);
  }
}
