import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(0,0,0,0,0,0,0,0);
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,3,28,0,0,0,0,0);
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,3,-71,0,0,0,0,0);
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(2,0,3,28,0,0,0,0);
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,0,3,-71,0,0,0,0);
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(2,6,4,7,2,0,3,28);
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(2,6,4,7,2,0,3,-71);
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(29,0,0,0,0,0,0,0);
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(4,28,0,0,0,0,0,0);
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(4,-71,0,0,0,0,0,0);
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(5,7,1,0,4,28,0,0);
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(5,7,1,0,4,-71,0,0);
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(6,2,4,7,2,0,3,2);
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(6,4,7,1,1,3,28,0);
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(6,4,7,1,1,3,-71,0);
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,1,0,3,29,0,0,0);
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,1,0,3,-70,0,0,0);
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(9,0,0,0,1,0,0,0);
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(9,0,0,9,1,0,0,9);
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(9,0,1,0,1,0,9,0);
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(9,3,3,6,1,0,0,9);
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,5,6,5,1,0,8,0);
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(9,8,9,2,1,0,8,0);
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,9,9,0,1,0,0,9);
  }
}
