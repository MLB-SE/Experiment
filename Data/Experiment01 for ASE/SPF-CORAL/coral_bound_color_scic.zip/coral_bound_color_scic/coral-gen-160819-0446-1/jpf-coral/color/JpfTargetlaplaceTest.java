import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.0f,0.0f,0,0.0f,0.0f,0.0f,0.0f,0.0f,0);
  }

  @Test
  public void test1() {
    color.laplace.solve(0.270853f,78.239716f,0,-14.466485f,-12.101601f,0,2.280475f,23.588385f,63.12305f);
  }

  @Test
  public void test2() {
    color.laplace.solve(10.572145f,19.21332f,0,11.743965f,-7.5519648f,0,-1.8591952f,-19.180746f,10.760511f);
  }

  @Test
  public void test3() {
    color.laplace.solve(12.138196f,-60.432377f,71.15881f,8.98516f,-51.542084f,0,11.545878f,37.198353f,-36.379543f);
  }

  @Test
  public void test4() {
    color.laplace.solve(12.602697f,-63.523346f,-69.77979f,-25.715218f,-55.281685f,-33.91947f,-60.18188f,-97.9687f,-52.702393f);
  }

  @Test
  public void test5() {
    color.laplace.solve(14.009628f,-24.336376f,-41.73572f,-19.62511f,-35.981525f,0,-3.383688f,6.0903583f,-41.811394f);
  }

  @Test
  public void test6() {
    color.laplace.solve(14.163087f,28.549053f,32.245945f,-71.896706f,-32.212822f,0.43472913f,-35.16928f,-36.717026f,0);
  }

  @Test
  public void test7() {
    color.laplace.solve(-15.339096f,-66.99269f,0,82.57151f,82.51759f,0,90.44845f,38.47393f,0);
  }

  @Test
  public void test8() {
    color.laplace.solve(15.845873f,-25.50108f,50.285175f,-11.11543f,66.08991f,0,-58.565907f,68.57315f,0);
  }

  @Test
  public void test9() {
    color.laplace.solve(16.40925f,24.185448f,58.70774f,-58.54845f,-78.3752f,12.286893f,41.562126f,14.856978f,0);
  }

  @Test
  public void test10() {
    color.laplace.solve(16.943888f,0.9387992f,0,-4.823985f,-33.22617f,14.557169f,-3.0136607f,-7.230657f,0);
  }

  @Test
  public void test11() {
    color.laplace.solve(17.094488f,-59.02926f,20.843681f,27.40721f,35.276962f,0,-2.1658878f,-7.422502f,0);
  }

  @Test
  public void test12() {
    color.laplace.solve(17.79432f,-12.017541f,82.27325f,-16.805183f,-43.682945f,0,95.18339f,4.768418f,0);
  }

  @Test
  public void test13() {
    color.laplace.solve(19.542614f,-9.499657f,0,14.835929f,23.504343f,-3.1941574f,16.296759f,15.339948f,0);
  }

  @Test
  public void test14() {
    color.laplace.solve(19.661804f,6.4425206f,0,7.059588f,29.226519f,16.48177f,-20.649971f,-4.736718f,0);
  }

  @Test
  public void test15() {
    color.laplace.solve(23.291798f,2.747823f,10.9608135f,-9.580632f,-16.9273f,19.47441f,-44.687027f,33.664646f,0);
  }

  @Test
  public void test16() {
    color.laplace.solve(23.529552f,-28.407925f,-7.977559f,22.526136f,82.6868f,73.27169f,-16.111801f,28.295856f,0);
  }

  @Test
  public void test17() {
    color.laplace.solve(24.281593f,50.89285f,47.980446f,-53.766476f,31.309359f,41.028934f,4.0573473f,-5.4424825f,0);
  }

  @Test
  public void test18() {
    color.laplace.solve(25.553385f,9.808781f,-42.58359f,-7.595243f,-43.734673f,-24.392805f,-12.166325f,-41.070057f,0);
  }

  @Test
  public void test19() {
    color.laplace.solve(26.579445f,-93.76737f,0,6.7975006f,-62.901394f,67.490364f,63.51195f,-59.50495f,0);
  }

  @Test
  public void test20() {
    color.laplace.solve(-27.093626f,-1.1658281f,0,-14.71762f,-31.292568f,7.262475f,-0.48428512f,-3.7982283f,0);
  }

  @Test
  public void test21() {
    color.laplace.solve(-28.073128f,-94.7982f,0,30.396667f,71.242645f,0,31.335005f,94.94335f,-49.6954f);
  }

  @Test
  public void test22() {
    color.laplace.solve(28.793348f,61.44884f,-90.756485f,-46.27545f,38.61371f,0,12.519394f,-69.110504f,0);
  }

  @Test
  public void test23() {
    color.laplace.solve(29.57617f,4.5071425f,1.5670851f,13.797535f,41.413754f,27.18966f,-15.799783f,-77.01297f,0);
  }

  @Test
  public void test24() {
    color.laplace.solve(-3.007138f,-14.034227f,-99.32759f,-97.99432f,-88.14497f,0,-94.608116f,50.62766f,0);
  }

  @Test
  public void test25() {
    color.laplace.solve(30.172411f,-93.35994f,3.3405042f,9.970058f,-7.8549805f,32.340515f,17.562803f,19.629438f,9.851926f);
  }

  @Test
  public void test26() {
    color.laplace.solve(30.899376f,15.229716f,29.241642f,8.367791f,-99.22215f,54.11984f,-52.244446f,-85.23869f,0);
  }

  @Test
  public void test27() {
    color.laplace.solve(31.41292f,45.258595f,11.8658905f,-19.606916f,37.75557f,-44.711807f,-49.397926f,-63.738148f,0);
  }

  @Test
  public void test28() {
    color.laplace.solve(31.737656f,41.225792f,15.421439f,-14.27517f,17.744076f,-82.85424f,-67.2464f,21.071465f,0);
  }

  @Test
  public void test29() {
    color.laplace.solve(33.778088f,20.856213f,37.650047f,14.256135f,-88.00328f,64.22289f,5.2590604f,6.7801065f,-33.228046f);
  }

  @Test
  public void test30() {
    color.laplace.solve(34.52512f,50.60756f,-60.47103f,-12.507077f,-72.77051f,23.36635f,-11.782921f,-34.624607f,0);
  }

  @Test
  public void test31() {
    color.laplace.solve(34.534542f,-48.452103f,0,13.184648f,-61.78924f,0,10.065239f,27.076307f,-78.42183f);
  }

  @Test
  public void test32() {
    color.laplace.solve(35.394783f,-17.838491f,23.843216f,59.417633f,93.2508f,0,54.05499f,34.209003f,0);
  }

  @Test
  public void test33() {
    color.laplace.solve(35.425003f,35.854015f,81.945786f,5.845996f,-73.95473f,35.902527f,61.913708f,0,0);
  }

  @Test
  public void test34() {
    color.laplace.solve(35.569107f,28.721565f,-21.445627f,13.554869f,0.7627779f,28.686535f,3.720082f,1.3254586f,9.49318f);
  }

  @Test
  public void test35() {
    color.laplace.solve(35.785465f,16.14295f,13.256349f,26.998909f,-2.2774909f,0,2.1346672f,-18.460241f,-5.661669f);
  }

  @Test
  public void test36() {
    color.laplace.solve(36.404713f,52.676582f,2.700407f,-7.0577297f,11.250056f,17.956785f,-75.88569f,-33.756027f,0);
  }

  @Test
  public void test37() {
    color.laplace.solve(37.578617f,-10.481593f,0,-2.0672383f,1.8860326f,73.56743f,-47.733604f,-16.135582f,0);
  }

  @Test
  public void test38() {
    color.laplace.solve(37.671494f,-89.63607f,53.024384f,0.81702816f,-36.512253f,-56.545532f,2.1088724f,-0.68444043f,-65.41792f);
  }

  @Test
  public void test39() {
    color.laplace.solve(38.691723f,43.51355f,9.476119f,11.253342f,25.886356f,8.219888f,-3.2755303f,-24.39779f,0);
  }

  @Test
  public void test40() {
    color.laplace.solve(41.14151f,57.654194f,-86.90809f,6.911842f,-15.555256f,0,2.3415797f,2.4544768f,82.574036f);
  }

  @Test
  public void test41() {
    color.laplace.solve(41.806686f,60.142384f,-93.65879f,7.0843635f,-4.6080046f,0,5.6507454f,15.518619f,61.01574f);
  }

  @Test
  public void test42() {
    color.laplace.solve(43.649048f,94.29924f,-89.48441f,-19.703045f,-98.218254f,2.7326865f,-24.242975f,-97.31852f,0);
  }

  @Test
  public void test43() {
    color.laplace.solve(43.766468f,29.645449f,17.914005f,45.42042f,-43.09868f,-57.989426f,-12.871757f,0,0);
  }

  @Test
  public void test44() {
    color.laplace.solve(43.87016f,42.919067f,-15.694887f,32.56156f,-79.414154f,0,-4.4869366f,-50.509308f,1.4119396f);
  }

  @Test
  public void test45() {
    color.laplace.solve(44.761765f,31.226772f,-58.237236f,47.82029f,38.38256f,-24.330196f,59.614574f,84.1782f,0);
  }

  @Test
  public void test46() {
    color.laplace.solve(46.295967f,60.499744f,0,-1.3368042f,-72.14191f,0,-16.106165f,-63.087856f,-5.274494f);
  }

  @Test
  public void test47() {
    color.laplace.solve(47.177624f,95.15663f,-85.85626f,-6.446131f,0.018526379f,-20.056608f,-72.980675f,-57.421257f,0);
  }

  @Test
  public void test48() {
    color.laplace.solve(47.347588f,-61.954937f,0,18.7633f,-92.88306f,0,-79.7791f,14.346847f,0);
  }

  @Test
  public void test49() {
    color.laplace.solve(47.93946f,-65.34676f,0,72.70086f,15.566717f,59.857838f,24.222847f,24.190525f,56.972538f);
  }

  @Test
  public void test50() {
    color.laplace.solve(47.956917f,35.747852f,16.222242f,56.07981f,-21.187742f,-76.5034f,-51.03091f,1.719143f,0);
  }

  @Test
  public void test51() {
    color.laplace.solve(54.609066f,10.743451f,0,-54.64345f,0.49537903f,0,35.689564f,-58.76356f,0);
  }

  @Test
  public void test52() {
    color.laplace.solve(54.78445f,-42.379528f,0,-30.051283f,-12.120727f,0,0.7966956f,33.238064f,-50.369907f);
  }

  @Test
  public void test53() {
    color.laplace.solve(58.0023f,73.18873f,67.47525f,58.82048f,67.27736f,-53.86476f,10.051137f,-35.523163f,0);
  }

  @Test
  public void test54() {
    color.laplace.solve(-58.285522f,2.8591595f,0,-20.882206f,67.17683f,0,-42.07019f,-99.69343f,0);
  }

  @Test
  public void test55() {
    color.laplace.solve(58.679695f,48.105667f,-55.043118f,86.61312f,11.890487f,0,77.01256f,-50.276688f,0);
  }

  @Test
  public void test56() {
    color.laplace.solve(-5.967422f,-49.561314f,6.400126f,-74.30837f,-42.166832f,0,-16.086397f,9.962782f,99.07844f);
  }

  @Test
  public void test57() {
    color.laplace.solve(60.36818f,-25.427618f,32.61441f,11.476154f,-13.307029f,-39.880142f,-1.1565313f,0.60348815f,-58.78682f);
  }

  @Test
  public void test58() {
    color.laplace.solve(-6.0818105f,63.734314f,0,-7.1505265f,-0.29657176f,0,0.36993575f,8.63027f,69.79837f);
  }

  @Test
  public void test59() {
    color.laplace.solve(64.45041f,99.96514f,-66.52421f,57.836494f,99.86149f,-99.96981f,67.03408f,-99.61896f,0);
  }

  @Test
  public void test60() {
    color.laplace.solve(69.483665f,87.85864f,6.0254188f,90.07603f,-46.732258f,0,15.140514f,99.55962f,0);
  }

  @Test
  public void test61() {
    color.laplace.solve(69.818726f,84.8716f,-95.07523f,94.4033f,-80.87903f,0,46.944027f,93.3728f,38.689907f);
  }

  @Test
  public void test62() {
    color.laplace.solve(-73.86285f,-35.43341f,0,-89.549095f,3.5635035f,0,19.065603f,-70.59967f,0);
  }

  @Test
  public void test63() {
    color.laplace.solve(76.03337f,71.49298f,0,40.059074f,-3.38365f,0,87.53634f,100.0f,0);
  }

  @Test
  public void test64() {
    color.laplace.solve(77.91462f,-85.164604f,0,64.8633f,89.7877f,99.53399f,91.75088f,98.64578f,0);
  }

  @Test
  public void test65() {
    color.laplace.solve(-78.01453f,-29.59846f,0,36.634396f,-52.635902f,0,-36.5817f,-28.951761f,0);
  }

  @Test
  public void test66() {
    color.laplace.solve(-8.458968f,6.346658f,0,-5.8296795f,-6.5536394f,-8.369144f,-8.306109f,-4.8953533f,0);
  }

  @Test
  public void test67() {
    color.laplace.solve(84.9353f,53.52827f,0,-17.35585f,-71.2425f,0,-11.711314f,-29.489407f,-34.74746f);
  }

  @Test
  public void test68() {
    color.laplace.solve(96.72023f,55.663967f,0,53.5649f,-30.871443f,-11.296336f,7.0043526f,-25.54749f,-78.32287f);
  }

  @Test
  public void test69() {
    color.laplace.solve(97.123f,67.554f,0,-69.15719f,-15.536224f,0,-28.826735f,99.72886f,0);
  }

  @Test
  public void test70() {
    color.laplace.solve(9.720346f,18.383282f,0,16.8974f,22.298683f,36.0084f,35.570564f,17.905655f,0);
  }

  @Test
  public void test71() {
    color.laplace.solve(99.65179f,-18.350409f,0,48.681774f,96.5105f,80.532f,-1.4351863f,-27.444242f,0);
  }
}
