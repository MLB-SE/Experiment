import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,2.941466802003043,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(3.874307618332039E-4,0.0,0,0);
  }
}
