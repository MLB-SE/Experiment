import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helplog(0.0);
  }
}
