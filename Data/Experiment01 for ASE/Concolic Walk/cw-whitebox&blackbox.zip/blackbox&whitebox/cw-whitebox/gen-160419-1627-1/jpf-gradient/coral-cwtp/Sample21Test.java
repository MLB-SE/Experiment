import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpcos(0.0);
  }
}
