import org.junit.Test;

public class Sample65Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark65(0.0,0.0,0.0,-8.0,-8.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark65(-0.02741659380336135,0.0,0.0,-8.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.helpsqrt(0);
  }
}
