import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,1.0956980909277705,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(0.15362765431924932,0.0,0,0);
  }
}
