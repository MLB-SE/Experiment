import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helppow(0.0,2.0);
  }
}
