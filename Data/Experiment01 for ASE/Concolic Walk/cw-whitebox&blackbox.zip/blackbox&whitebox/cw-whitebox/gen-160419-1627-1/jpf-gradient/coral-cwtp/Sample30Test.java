import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helplog10(0.0);
  }
}
