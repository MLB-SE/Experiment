import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpexp(0.0);
  }
}
