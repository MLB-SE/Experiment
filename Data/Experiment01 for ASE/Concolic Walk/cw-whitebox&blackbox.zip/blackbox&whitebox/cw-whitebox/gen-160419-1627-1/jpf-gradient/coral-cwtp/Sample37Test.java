import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0.0,0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helptan(0.0);
  }
}
