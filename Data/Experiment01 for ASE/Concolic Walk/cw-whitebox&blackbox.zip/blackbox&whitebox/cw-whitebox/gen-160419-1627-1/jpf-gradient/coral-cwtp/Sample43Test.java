import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helppow(0.0,0.0);
  }
}
