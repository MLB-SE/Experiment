import junit.framework.TestCase;

/**
 * Generated {@link TestCase} for {@link JCuteTargetMagicSolve}.
 * 
 * Each test method first sets up the {@link #input} array and then
 * registers this test class as input provider for {@link cute.Cute}.
 * Thus, the test driver (that is, the method under test) will
 * retrieve the {@code input} array contents when it requests inputs
 * from {@code Cute}.
 * 
 * The template is based on jCUTE's {@code Template.java}.
 */ 

public class JCuteTargetMagicSolveTest extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public JCuteTargetMagicSolveTest (String name) {
        super(name);
    }

    // Generated test methods
                                    

    public void test1() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(-659997629);
        input[i++] = new Integer(2095394349);
        input[i++] = new Integer(-1777508959);
        input[i++] = new Integer(-1530019226);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test2() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(2);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test3() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(2095394349);
        input[i++] = new Integer(-1777508959);
        input[i++] = new Integer(-1530019226);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test4() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(1);
        input[i++] = new Integer(2);
        input[i++] = new Integer(1);
        input[i++] = new Integer(0);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test5() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1777508959);
        input[i++] = new Integer(-1530019226);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test6() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1530019226);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test7() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    public void test8() {
        i=0;
        input = new Object[4];
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        cute.Cute.input = this;
        i=0;
        JCuteTargetMagicSolve.main(null);
    }

    // Implement {@link cute.Input} interface that the test driver
    // uses to request input values.

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }
    
    public Object ObjectShallow(String type) {
        return input[i++];
    }
}
