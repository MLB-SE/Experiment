import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-118587,125403l,-642144);
  }
}
