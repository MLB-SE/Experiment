import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(242269,-528320l,220823,458131,-959418l,-170634);
  }
}
