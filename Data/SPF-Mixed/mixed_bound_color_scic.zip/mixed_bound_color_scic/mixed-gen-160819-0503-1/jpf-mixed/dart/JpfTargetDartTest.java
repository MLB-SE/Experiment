import org.junit.Test;

public class JpfTargetDartTest {

  @Test
  public void test0() {
    concolic.DART.test(-1000000,0);
  }

  @Test
  public void test1() {
    concolic.DART.test(1,10);
  }

  @Test
  public void test2() {
    concolic.DART.test(1,-1000000);
  }

  @Test
  public void test3() {
    concolic.DART.test(1,20);
  }
}
