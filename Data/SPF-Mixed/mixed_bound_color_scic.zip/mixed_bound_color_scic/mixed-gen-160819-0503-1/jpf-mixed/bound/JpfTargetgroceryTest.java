import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(0,0,0,0);
  }

  @Test
  public void test1() {
    bound.grocery.solve(0,0,0,-1000000);
  }

  @Test
  public void test2() {
    bound.grocery.solve(0,0,0,712);
  }

  @Test
  public void test3() {
    bound.grocery.solve(0,0,-1000000,0);
  }

  @Test
  public void test4() {
    bound.grocery.solve(0,0,712,0);
  }

  @Test
  public void test5() {
    bound.grocery.solve(0,-1000000,0,0);
  }

  @Test
  public void test6() {
    bound.grocery.solve(0,712,0,0);
  }

  @Test
  public void test7() {
    bound.grocery.solve(-1000000,0,0,0);
  }

  @Test
  public void test8() {
    bound.grocery.solve(712,0,0,0);
  }
}
