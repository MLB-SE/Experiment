import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(-1000000,0);
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(1,1);
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(1,-1000000);
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(1,6);
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(6,0);
  }
}
