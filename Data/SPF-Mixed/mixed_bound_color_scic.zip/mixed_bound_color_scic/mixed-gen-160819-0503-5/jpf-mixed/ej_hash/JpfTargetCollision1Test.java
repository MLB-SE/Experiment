import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-528243,290814l,-649207,575146,107010l,-980644);
  }
}
