import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-110037,-463076l,793017);
  }
}
