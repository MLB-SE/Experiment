import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(781580,-667739l,-791526,29013,530259l,-524351);
  }
}
