import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-77192,403620l,688920,-377628,521363l,-125440);
  }
}
