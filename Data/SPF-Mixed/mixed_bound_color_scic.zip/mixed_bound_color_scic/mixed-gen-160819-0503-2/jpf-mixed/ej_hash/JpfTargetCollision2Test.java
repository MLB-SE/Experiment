import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-173487l,-326908,371289l,-324749);
  }
}
