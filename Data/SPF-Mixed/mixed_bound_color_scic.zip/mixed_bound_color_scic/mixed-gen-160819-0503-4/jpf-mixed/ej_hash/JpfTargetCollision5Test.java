import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(939705l,-302612);
  }
}
