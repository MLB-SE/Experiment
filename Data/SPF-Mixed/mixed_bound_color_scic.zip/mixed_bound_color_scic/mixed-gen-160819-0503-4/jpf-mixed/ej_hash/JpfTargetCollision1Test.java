import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-510183,-936900l,-481655,266336,-959674l,-769235);
  }
}
