import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(1.5,0.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(5.469077888312476,0.0);
  }
}
