import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,85.19394208457916,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(0.9767402992468263,0.0,0,0);
  }
}
