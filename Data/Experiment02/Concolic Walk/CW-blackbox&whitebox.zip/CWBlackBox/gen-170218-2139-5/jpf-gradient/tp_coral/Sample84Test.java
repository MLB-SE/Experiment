import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,2002.3352576588277,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(10.847620111709805,0.0,0,0);
  }
}
