import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(21.0,0.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(32.13,0.0);
  }
}
