import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.017717510310303986,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,78.51555644619117,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0000009999999997,1.0000020000009995,0,0);
  }
}
