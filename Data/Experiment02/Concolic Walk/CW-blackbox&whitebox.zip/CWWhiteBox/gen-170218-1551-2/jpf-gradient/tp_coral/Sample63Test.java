import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,0.0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.0,0.0,-8.0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(-0.006229646962826938,0.0,0.0,-8.0,0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(0.13223032026504364,0.0,0.0,-8.0,0);
  }
}
