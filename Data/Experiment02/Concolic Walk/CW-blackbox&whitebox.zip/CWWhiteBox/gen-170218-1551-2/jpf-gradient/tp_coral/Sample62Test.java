import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0.0,0.0,0.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(-0.14329655409350514,0.0,0.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.0222049312812136,0.0,0.0,-8.0);
  }
}
