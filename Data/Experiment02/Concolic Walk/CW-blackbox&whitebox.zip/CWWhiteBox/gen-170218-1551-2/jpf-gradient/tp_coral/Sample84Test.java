import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,25.791044820912326,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(447.1381877555589,0.0,0,0);
  }
}
