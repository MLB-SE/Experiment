import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0.0,0.0,0.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(-0.0014065922516757268,0.0,0.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.01032826772692193,0.0,0.0,-8.0);
  }
}
