import org.junit.Test;

public class Sample66Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark66(0.0,0.0,0.0,-8.0,2.0E-323);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark66(0.0,0.0,0.0,-8.0,7.0327288018949226);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark66(0.0,0.0,0.0,-8.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark66(0,0,0,-2.3333336114883427,2.333332777023316);
  }
}
