import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,0.01438905746913264,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(0.03340382024013234,0.0,0,0);
  }
}
