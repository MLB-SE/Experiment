import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,0.0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.0,0.0,-8.0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(1.0391411140284734,0.0,0.0,-8.0,0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(-4.9893225467614695,0.0,0.0,-8.0,0);
  }
}
