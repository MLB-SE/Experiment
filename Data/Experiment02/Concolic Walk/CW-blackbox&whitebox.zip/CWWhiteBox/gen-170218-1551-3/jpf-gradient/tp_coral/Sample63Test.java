import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,0.0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.0,0.0,-8.0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(26.31617087831238,0.0,0.0,-8.0,0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(-45.153450974866054,0.0,0.0,-8.0,0);
  }
}
