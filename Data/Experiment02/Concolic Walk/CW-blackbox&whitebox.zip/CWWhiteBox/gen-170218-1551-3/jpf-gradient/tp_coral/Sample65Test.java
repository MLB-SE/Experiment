import org.junit.Test;

public class Sample65Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark65(0.0,0.0,0.0,-8.0,-8.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark65(0,0,0,-2.3333336114883427,2.333332777023316);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark65(-0.8942470314819096,0.0,0.0,-8.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark65(10.612364514776216,0.0,0.0,-8.0,-8.0);
  }
}
