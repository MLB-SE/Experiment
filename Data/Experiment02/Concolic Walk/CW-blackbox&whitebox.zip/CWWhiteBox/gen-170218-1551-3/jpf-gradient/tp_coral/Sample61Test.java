import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0.0,0.0,0.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(2.052348348842578,0.0,0.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(-5.964605891675906,0.0,0.0,-8.0);
  }
}
