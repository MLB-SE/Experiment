import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(1.5,0.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(4.320000000000068,0.0);
  }
}
