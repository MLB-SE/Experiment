import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0.0,0.0,0.0,0.0,0.0);
  }
}
