import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(0.0,0.0,0.0,0.0,0.0);
  }
}
