import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(0.0);
  }
}
