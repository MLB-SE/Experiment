import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0.0,0.0,0.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(164.6840464632038,0.0,0.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(-3.420502913962121,0.0,0.0,-8.0);
  }
}
