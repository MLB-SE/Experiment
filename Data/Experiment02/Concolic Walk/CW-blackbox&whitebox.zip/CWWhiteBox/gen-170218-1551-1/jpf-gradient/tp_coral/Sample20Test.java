import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(0.0,0.0);
  }
}
