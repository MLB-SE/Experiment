import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(0.0,0.0,0.0,0.0,0);
  }
}
