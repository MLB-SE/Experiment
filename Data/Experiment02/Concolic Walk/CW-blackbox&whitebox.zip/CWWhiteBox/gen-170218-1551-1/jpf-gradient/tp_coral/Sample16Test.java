import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0.0,0.0,0.0,0.0,0.0);
  }
}
