import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(0.0,0.0,0.0,0.0,0.0,0.0,0.0);
  }
}
