import org.junit.Test;

public class Sample71Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark71(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
  }
}
