import org.junit.Test;

public class Sample67Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark67(0.0,0.0,0.0,0.0,0.0,0.0);
  }
}
