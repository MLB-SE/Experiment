import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(0.0);
  }
}
