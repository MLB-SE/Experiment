import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.0,0.0);
  }
}
