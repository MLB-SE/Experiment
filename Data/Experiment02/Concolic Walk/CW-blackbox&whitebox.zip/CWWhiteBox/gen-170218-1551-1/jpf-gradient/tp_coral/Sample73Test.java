import org.junit.Test;

public class Sample73Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark73(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
  }
}
