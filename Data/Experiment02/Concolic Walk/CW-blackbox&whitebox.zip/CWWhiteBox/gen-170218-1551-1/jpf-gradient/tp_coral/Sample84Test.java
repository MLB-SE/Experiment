import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.009218696362868234,0.0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(0.0,1015.6099767335093,0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0000009999999997,1.0000020000009995,0,0);
  }
}
