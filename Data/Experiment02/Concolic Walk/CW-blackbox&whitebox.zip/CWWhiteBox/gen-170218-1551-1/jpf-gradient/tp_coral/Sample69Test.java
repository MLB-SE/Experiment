import org.junit.Test;

public class Sample69Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark69(0.0,0.0,0.0,0.0,0.0,0.0);
  }
}
