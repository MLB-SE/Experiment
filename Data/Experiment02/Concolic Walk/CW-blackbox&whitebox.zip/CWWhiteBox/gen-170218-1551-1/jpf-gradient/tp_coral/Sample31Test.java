import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(0.0);
  }
}
