import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,0.0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.0,0.0,-8.0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(-27.49261500289646,0.0,0.0,-8.0,0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(34.745388283700905,0.0,0.0,-8.0,0);
  }
}
