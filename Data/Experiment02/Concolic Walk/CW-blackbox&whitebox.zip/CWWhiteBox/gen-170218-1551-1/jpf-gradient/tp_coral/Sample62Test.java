import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0.0,0.0,0.0,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.8484419105876572,0.0,0.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(-7.624974601125891E-4,0.0,0.0,-8.0);
  }
}
